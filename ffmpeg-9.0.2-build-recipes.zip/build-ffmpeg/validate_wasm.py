#!/usr/bin/env python3
"""Execute actual WASM tools and link an independent static C API consumer."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

from build_wasm import environment
from probe_media import probe

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
sdk = root / 'output/ffmpeg_9.0.2_wasm32_release'
env = environment(root)
sys.path.insert(0, '/opt/mycef/build-cef')
from archive_posix import digest_file

results = {}
for mode in ('threads',):
    work = root / 'validation' / ('wasm-' + mode)
    work.mkdir(parents=True, exist_ok=True)
    # The native Python probe runs the SDK's Node-backed CLI entry scripts.
    # Its kernel/glibc fields describe the host, not a WASM operating system.
    original_path = __import__('os').environ.get('PATH', '')
    __import__('os').environ['PATH'] = env['PATH']
    try:
        media = probe(sdk / mode, work / 'media', timeout=900, cli_player=False, thread_limit=1)
    finally:
        __import__('os').environ['PATH'] = original_path
    build = work / 'c-api'
    subprocess.run(['emcmake', str(root / 'host-tools/bin/cmake'), '-S', str(sdk / 'examples/c-api'),
                    '-B', str(build), '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
                    '-DFFMPEG_WASM_ABI=' + mode], env=env, check=True)
    subprocess.run([str(root / 'host-tools/bin/cmake'), '--build', str(build), '-j', '2'], env=env, check=True)
    javascript = build / 'media-info.js'
    wasm = build / 'media-info.wasm'
    demo = subprocess.check_output([env['EMSDK_NODE'], str(javascript)], env=env, text=True, timeout=300)
    if 'FFmpeg 9.0.2' not in demo or 'x264 encoder: available' not in demo or 'x265 encoder: available' not in demo:
        raise RuntimeError('Independent WASM C API example did not load the actual encoders')
    records = [{'file': path.relative_to(sdk).as_posix(), 'sha256': digest_file(path)}
               for path in sorted((sdk / mode / 'bin').iterdir()) if path.is_file()]
    results[mode] = {'passed': True, 'media': media, 'files': records,
                      'c_api_demo_js_sha256': digest_file(javascript), 'c_api_demo_wasm_sha256': digest_file(wasm),
                      'c_api_demo_output': demo,
                      'scope': 'Real Node execution of the WASM tools and independent C API consumer; actual software encode/decode/filter files verified. Host kernel/glibc are not a WASM platform requirement. Browser/CEF loading is a separate local check.'}
    (sdk / 'validation' / mode / 'runtime.json').write_text(json.dumps(results[mode], indent=2) + '\n')
record = {'target': 'wasm32', 'passed': True, 'runtime_verified': True, 'variants': results,
          'scope': 'Actual threaded WebAssembly modules and static SDK consumer executed under Node, with media round-trip tests. Browser/CEF integration is not claimed by this receipt.'}
path = root / 'state/runtime-wasm32.json'
path.write_text(json.dumps(record, indent=2) + '\n')
shutil.copy2(path, sdk / 'validation/wasm-runtime.json')
print('FFMPEG_WASM_RUNTIME_AND_STATIC_C_API_PASSED', flush=True)
