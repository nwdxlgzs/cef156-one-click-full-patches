#!/usr/bin/env python3
"""Resolve target metadata without importing the Linux build host headers."""
import argparse
import os
from pathlib import Path
import shlex
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--triplet', required=True)
p.add_argument('arguments', nargs=argparse.REMAINDER)
a = p.parse_args()
cpu = a.triplet.split('-')[0]
target = 'linux-' + cpu
sysroot = a.root / 'sysroots' / (target + '-glibc228')
triple = 'x86_64-linux-gnu' if cpu == 'x64' else 'aarch64-linux-gnu'
installed = a.root / 'installed' / target / a.triplet
env = dict(os.environ)
paths = [installed / 'lib/pkgconfig', installed / 'share/pkgconfig',
         sysroot / 'usr/lib' / triple / 'pkgconfig', sysroot / 'usr/lib/pkgconfig',
         sysroot / 'usr/share/pkgconfig']
for item in (env.get('PKG_CONFIG_PATH', '') + os.pathsep + env.get('PKG_CONFIG_LIBDIR', '')).split(os.pathsep):
    if item:
        path = Path(item).resolve()
        # vcpkg validates a just-built package before installing it. Its
        # staging metadata must precede the already-installed dependencies.
        if a.root.resolve() in path.parents or sysroot.resolve() in path.parents:
            if path not in paths:
                paths.insert(0, path)
env['PKG_CONFIG_LIBDIR'] = os.pathsep.join(map(str, paths))
env['PKG_CONFIG_PATH'] = env['PKG_CONFIG_LIBDIR']
env.pop('PKG_CONFIG_SYSROOT_DIR', None)
env['PKG_CONFIG_SYSTEM_INCLUDE_PATH'] = ''
env['PKG_CONFIG_SYSTEM_LIBRARY_PATH'] = ''
args = a.arguments[1:] if a.arguments[:1] == ['--'] else a.arguments
r = subprocess.run(['/usr/bin/pkg-config'] + args, env=env, text=True,
                   stdout=subprocess.PIPE)
if r.returncode == 0:
    if any(x in ('--cflags', '--libs', '--cflags-only-I', '--libs-only-L') for x in args):
        tokens = shlex.split(r.stdout)
        for i, token in enumerate(tokens):
            for prefix in ('-I', '-L', ''):
                path = token[len(prefix):] if token.startswith(prefix) else ''
                if path.startswith(('/usr/', '/lib/')):
                    tokens[i] = prefix + str(sysroot) + path
                    break
        sys.stdout.write(shlex.join(tokens) + '\n')
    else:
        text = r.stdout
        if any(x.startswith('--variable=') for x in args) and text.strip().startswith(('/usr/', '/lib/')):
            text = str(sysroot) + text
        sys.stdout.write(text)
sys.exit(r.returncode)
