#!/usr/bin/env python3
"""Extract the SHA-authenticated LLVM-MinGW toolchain and compile CPU probes."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    asset = json.loads((root / 'state/llvm-mingw-asset.json').read_text())
    archive = root / 'downloads' / asset['name']
    sha = hashlib.sha256(archive.read_bytes()).hexdigest()
    if archive.stat().st_size != asset['size'] or asset['digest'] != 'sha256:' + sha:
        raise RuntimeError('LLVM-MinGW archive identity differs')
    destination = root / 'toolchains/llvm-mingw'
    if not destination.exists():
        with tarfile.open(archive) as t:
            prefix = t.getmembers()[0].name
            if '/' in prefix or prefix in ('', '.', '..'):
                raise RuntimeError('Unexpected toolchain archive root')
            t.extractall(destination.parent, filter='data')
        (destination.parent / prefix).rename(destination)
    work = root / 'state/windows-toolchain-probes'
    work.mkdir(exist_ok=True)
    (work / 'probe.c').write_text('#include <windows.h>\nint main(void){return GetCurrentProcessId()==0;}\n')
    images = []
    for cpu, triple in [('x86', 'i686'), ('x64', 'x86_64'), ('arm64', 'aarch64')]:
        cc = destination / 'bin' / (triple + '-w64-mingw32-clang')
        exe = work / (cpu + '.exe')
        subprocess.run([str(cc), '-O2', str(work / 'probe.c'), '-o', str(exe)], check=True)
        report = subprocess.check_output([str(destination / 'bin/llvm-readobj'), '--file-headers', str(exe)], text=True)
        expected = {'x86': 'IMAGE_FILE_MACHINE_I386', 'x64': 'IMAGE_FILE_MACHINE_AMD64',
                    'arm64': 'IMAGE_FILE_MACHINE_ARM64'}[cpu]
        if expected not in report:
            raise RuntimeError('Toolchain CPU probe differs')
        images.append({'cpu': cpu, 'binary_sha256': hashlib.sha256(exe.read_bytes()).hexdigest(),
                       'compiler': str(cc), 'machine_checked': True})
    (root / 'state/windows-toolchain-verified.json').write_text(json.dumps({
        'archive_sha256': sha, 'targets': images, 'compilation_linking_passed': True,
        'target_execution_verified': False}, indent=2) + '\n')
    print('WINDOWS_TOOLCHAIN_CPU_PROBES_PASSED', flush=True)


if __name__ == '__main__':
    main()
