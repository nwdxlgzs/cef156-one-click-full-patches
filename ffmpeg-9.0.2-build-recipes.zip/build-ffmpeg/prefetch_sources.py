#!/usr/bin/env python3
"""Prefetch pinned GitHub source archives from the actual vcpkg build plan."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--plan', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=6)
    a = p.parse_args()
    root = a.root.resolve()
    plan = a.plan.read_text().rsplit('The following packages will be built and installed:', 1)[-1]
    ports = sorted(set(re.findall(r'^\s+\*?\s*([a-z0-9-]+)(?:\[[^\n]*?\])?:', plan, re.M)))
    jobs = []
    for name in ports:
        folder = root / 'overlay-ports' / name
        if not folder.exists():
            folder = root / 'vcpkg/ports' / name
        if not (folder / 'vcpkg.json').exists():
            continue
        meta = json.loads((folder / 'vcpkg.json').read_text())
        version = next((meta[x] for x in ('version', 'version-semver', 'version-string', 'version-date') if x in meta), '')
        text = (folder / 'portfile.cmake').read_text().replace('${VERSION}', version)
        match = re.search(r'vcpkg_from_github\((.*?)\n\)', text, re.S)
        if not match:
            continue
        block = match[1]
        fields = [re.search(pattern, block) for pattern in
                  (r'\bREPO\s+"?([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)"?',
                   r'\bREF\s+"?([^\s"$]+)"?', r'\bSHA512\s+([a-f0-9]{128})\b')]
        if not all(fields) or any(x in block for x in ('GITHUB_HOST', 'USE_TARBALL_API', 'FILE_DISAMBIGUATOR')):
            continue
        repo, ref, sha = [x[1] for x in fields]
        filename = repo.replace('/', '-') + '-' + ref.replace('/', '_-') + '.tar.gz'
        jobs.append((name, repo, ref, sha, filename))
    cache = root / 'vcpkg-downloads'
    work = root / 'downloads/prefetch'
    work.mkdir(exist_ok=True, parents=True)

    def fetch(job):
        name, repo, ref, sha, filename = job
        final = cache / filename
        if final.exists():
            if hashlib.sha512(final.read_bytes()).hexdigest() != sha:
                raise RuntimeError('Existing source cache differs: ' + filename)
            return {'port': name, 'cached': True, 'sha512': sha}
        if list(cache.glob(filename + '*.part')):
            return {'port': name, 'skipped_live_vcpkg_download': True}
        temporary = work / (filename + '.pending')
        with (work / (name + '.log')).open('a') as log:
            result = subprocess.run(['/usr/bin/python3', str(root / 'asset_mirror.py'),
                'https://github.com/' + repo + '/archive/' + ref + '.tar.gz', sha, str(temporary)],
                stdout=log, stderr=log)
        if result.returncode:
            print('PREFETCH_DEFERRED', name, result.returncode, flush=True)
            return {'port': name, 'deferred_to_vcpkg': True}
        if hashlib.sha512(temporary.read_bytes()).hexdigest() != sha:
            raise RuntimeError('Downloaded source SHA512 differs: ' + name)
        temporary.replace(final)
        print('SOURCE_PREFETCHED', name, final.stat().st_size, flush=True)
        return {'port': name, 'archive': filename, 'sha512': sha, 'verified': True}
    print('SOURCE_PREFETCH_JOBS', len(jobs), flush=True)
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        results = list(pool.map(fetch, jobs))
    (root / 'state/source-prefetch.json').write_text(json.dumps(results, indent=2) + '\n')


if __name__ == '__main__':
    main()
