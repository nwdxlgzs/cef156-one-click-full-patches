#!/usr/bin/env python3
"""Seed vcpkg's AOM archive from a mirror with the exact upstream Git identity."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

REVISION = 'b141d9c45db236335351c8a4b2a14b3ade27c937'
TREE = 'c189fab279823f60b8db54f16641bab3c8fc78c3'


def prepare(root):
    root = Path(root)
    recipe = (root / 'vcpkg/ports/aom/portfile.cmake').read_text()
    if 'REF ' + REVISION not in recipe:
        raise RuntimeError('AOM upstream recipe no longer matches the pinned source')
    archive = root / 'vcpkg-downloads' / ('aom-' + REVISION + '.tar.gz')
    git = root / 'sources/aom-mirror'
    git.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', '-C', str(git), 'init', '--quiet'], check=True)
    available = subprocess.run(['git', '-C', str(git), 'cat-file', '-e', REVISION + '^{commit}'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    if not available:
        subprocess.run(['git', '-C', str(git), 'fetch', '--depth=1',
                        'https://ghfast.top/https://github.com/arthenica/libaom.git', REVISION, '-n'],
                       check=True, timeout=180)
    tree = subprocess.check_output(['git', '-C', str(git), 'rev-parse', REVISION + '^{tree}'], text=True).strip()
    if tree != TREE:
        raise RuntimeError('AOM mirror tree identity differs')
    if not archive.exists():
        temporary = archive.with_suffix('.pending.tar.gz')
        subprocess.run(['git', '-C', str(git), '-c', 'core.autocrlf=false', 'archive', REVISION,
                        '-o', str(temporary)], check=True)
        temporary.rename(archive)
    with gzip.open(archive, 'rb') as f:
        commit = subprocess.check_output(['git', 'get-tar-commit-id'], input=f.read()).decode().strip()
    if commit != REVISION:
        raise RuntimeError('Cached AOM Git archive has another source identity')
    record = {'revision': REVISION, 'tree': tree, 'archive': str(archive),
              'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
              'upstream': 'https://aomedia.googlesource.com/aom',
              'mirror': 'https://github.com/arthenica/libaom',
              'scope': 'Git objects and tree match the exact immutable upstream vcpkg source revision; the cached archive retains its Git commit identity.'}
    (root / 'state/source-aom.json').write_text(json.dumps(record, indent=2) + '\n')
    return record
