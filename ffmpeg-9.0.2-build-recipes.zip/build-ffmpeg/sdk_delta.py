#!/usr/bin/env python3
"""Transfer only changed SDK files and reconstruct a fully checked local archive."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def manifest(folder):
    result = json.loads((folder / 'SHA256SUMS.json').read_text())
    p = folder / 'SHA256SUMS.json'
    result['SHA256SUMS.json'] = {'type': 'file', 'sha256': digest(p), 'bytes': p.stat().st_size,
                               'mode': p.stat().st_mode & 0o777}
    return result


def export(old, new, old_archive, receipt, output):
    before, after = manifest(old), manifest(new)
    changed = [p for p, info in after.items() if before.get(p) != info]
    record = {'sdk': new.name, 'source_archive_sha256': digest(old_archive),
              'server_receipt': json.loads(receipt.read_text()),
              'manifest': after, 'changed': changed}
    with output.open('wb') as f:
        process = subprocess.Popen(['zstd', '-6', '--check', '-q', '-c'], stdin=subprocess.PIPE, stdout=f)
        with tarfile.open(fileobj=process.stdin, mode='w|') as tar:
            data = (json.dumps(record, sort_keys=True, indent=2) + '\n').encode()
            entry = tarfile.TarInfo('delta.json'); entry.size = len(data); entry.mode = 0o644
            tar.addfile(entry, io.BytesIO(data))
            for relative in changed:
                info = after[relative]
                if info['type'] != 'file':
                    continue
                entry = tarfile.TarInfo('payload/' + relative)
                entry.mode = info['mode']; entry.size = info['bytes']
                with (new / relative).open('rb') as source:
                    tar.addfile(entry, source)
        process.stdin.close()
        if process.wait():
            raise RuntimeError('Delta compression failed')
    return {'delta': str(output), 'sha256': digest(output), 'bytes': output.stat().st_size,
            'changed_entries': len(changed), 'target': record['server_receipt']['target']}


def apply(destination, delta, expected_sha):
    import zstandard
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'build-cef'))
    from minimize_sdk import zstd_reader
    if digest(delta) != expected_sha:
        raise RuntimeError('Transferred delta SHA256 differs')
    payloads = {}
    with zstd_reader(delta) as reader, tarfile.open(fileobj=reader, mode='r|') as tar:
        for member in tar:
            if not member.isfile():
                raise RuntimeError('Unexpected delta entry')
            if member.name == 'delta.json':
                record = json.load(tar.extractfile(member))
            elif member.name.startswith('payload/'):
                relative = member.name[len('payload/'):]
                if relative in payloads:
                    raise RuntimeError('Duplicate delta payload')
                payloads[relative] = tar.extractfile(member).read()
            else:
                raise RuntimeError('Unexpected delta path')
    name, desired = record['sdk'], record['manifest']
    if '/' in name or '\\' in name or name in ('.', '..'):
        raise RuntimeError('Unsafe SDK root')
    for relative, info in desired.items():
        path = PurePosixPath(relative)
        if path.is_absolute() or '..' in path.parts or '\\' in relative or ':' in relative:
            raise RuntimeError('Unsafe SDK member')
        if relative in payloads and (len(payloads[relative]) != info['bytes'] or
                hashlib.sha256(payloads[relative]).hexdigest() != info['sha256']):
            raise RuntimeError('Delta payload differs from target manifest')
    archive = destination / (name + '.tar.zst')
    receipt_path = archive.with_name(archive.name + '.verified.json')
    prior = json.loads(receipt_path.read_text())
    if digest(archive) != record['source_archive_sha256'] or prior['archive_sha256'] != record['source_archive_sha256']:
        raise RuntimeError('Local source archive does not match delta base')
    source_manifest = None
    with zstd_reader(archive) as reader, tarfile.open(fileobj=reader, mode='r|') as tar:
        for member in tar:
            if member.name == name + '/SHA256SUMS.json':
                source_manifest = json.load(tar.extractfile(member)); break
    if source_manifest is None:
        raise RuntimeError('Local source payload manifest absent')
    for relative, info in desired.items():
        if info['type'] == 'file' and relative not in payloads and source_manifest.get(relative) != info:
            raise RuntimeError('Delta omits changed file: ' + relative)
    pending = archive.with_name(archive.name + '.delta.pending')
    written = set()

    def add(tar, relative, source=None):
        info = desired[relative]
        entry = tarfile.TarInfo(name + '/' + relative); entry.mode = info['mode']
        if info['type'] == 'directory':
            entry.type = tarfile.DIRTYPE; tar.addfile(entry)
        elif info['type'] == 'symlink':
            entry.type = tarfile.SYMTYPE; entry.linkname = info['target']; tar.addfile(entry)
        elif info['type'] == 'file':
            entry.size = info['bytes']
            tar.addfile(entry, io.BytesIO(payloads[relative]) if relative in payloads else source)
        else:
            raise RuntimeError('Unknown target entry type')
        written.add(relative)

    with zstd_reader(archive) as reader, tarfile.open(fileobj=reader, mode='r|') as source:
        with pending.open('wb') as f, zstandard.ZstdCompressor(level=8, threads=2, write_checksum=True).stream_writer(f) as writer:
            with tarfile.open(fileobj=writer, mode='w|') as target:
                for member in source:
                    if not member.name.startswith(name + '/'):
                        raise RuntimeError('Unexpected source archive root')
                    relative = member.name[len(name)+1:]
                    if relative in desired:
                        add(target, relative, source.extractfile(member) if member.isfile() else None)
                for relative in sorted(set(desired) - written):
                    add(target, relative)
    seen = set()
    with zstd_reader(pending) as reader, tarfile.open(fileobj=reader, mode='r|') as tar:
        for member in tar:
            relative = member.name[len(name)+1:]
            if relative in seen or relative not in desired:
                raise RuntimeError('Unexpected/duplicate reconstructed entry')
            seen.add(relative); info = desired[relative]
            if member.mode != info['mode']:
                raise RuntimeError('Reconstructed SDK mode differs')
            if info['type'] == 'file':
                h = hashlib.sha256(); stream = tar.extractfile(member)
                for b in iter(lambda: stream.read(4 * 1024 * 1024), b''): h.update(b)
                if member.size != info['bytes'] or h.hexdigest() != info['sha256']:
                    raise RuntimeError('Reconstructed SDK file differs: ' + relative)
            elif info['type'] == 'directory' and not member.isdir():
                raise RuntimeError('Directory mismatch')
            elif info['type'] == 'symlink' and (not member.issym() or member.linkname != info['target']):
                raise RuntimeError('Symlink mismatch')
    if seen != set(desired):
        raise RuntimeError('Reconstructed archive omits files')
    backup = destination / 'source-downloads' / (record['server_receipt']['target'] + '-before-feature-update')
    backup.mkdir(parents=True, exist_ok=False)
    for path in [archive, receipt_path, archive.with_name(archive.name + '.sha256')]:
        path.replace(backup / path.name)
    pending.replace(archive)
    sha = digest(archive)
    result = {**record['server_receipt'], 'remote_archive_sha256': record['server_receipt']['archive_sha256'],
              'archive': str(archive), 'archive_sha256': sha, 'bytes': archive.stat().st_size,
              'local_download_verified': True, 'local_path': str(archive), 'local_sha256': sha,
              'delta_reconstruction': {'source_download_sha256': record['source_archive_sha256'],
                  'delta_sha256': expected_sha, 'changed_entries': len(record['changed']),
                  'all_payloads_match_validated_server_sdk': True}}
    receipt_path.write_text(json.dumps(result, indent=2) + '\n')
    archive.with_name(archive.name + '.sha256').write_text(sha + '  ' + archive.name + '\n')
    compact_backup = backup / 'compact'; compact_backup.mkdir()
    for path in [destination/'strip-lib'/name, destination/'strip-lib'/archive.name,
                 destination/'strip-lib'/receipt_path.name, destination/'strip-lib'/(archive.name+'.sha256')]:
        path.replace(compact_backup / path.name)
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(); sub = p.add_subparsers(dest='mode', required=True)
    e = sub.add_parser('export')
    for n in ('old', 'new', 'old-archive', 'receipt', 'output'): e.add_argument('--'+n, type=Path, required=True)
    a = sub.add_parser('apply'); a.add_argument('--destination', type=Path, required=True)
    a.add_argument('--delta', type=Path, required=True); a.add_argument('--sha256', required=True)
    x = p.parse_args()
    if x.mode == 'export': result = export(x.old, x.new, x.old_archive, x.receipt, x.output)
    else: result = apply(x.destination.resolve(), x.delta.resolve(), x.sha256)
    print(json.dumps(result, indent=2))
