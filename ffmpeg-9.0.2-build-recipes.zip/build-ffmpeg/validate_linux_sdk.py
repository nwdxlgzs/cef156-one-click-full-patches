#!/usr/bin/env python3
"""Validate actual FFmpeg shared SDKs on Linux 4.9/glibc 2.28 guests."""
import argparse
import datetime as dt
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    p.add_argument('--target', choices=['linux-x64', 'linux-arm64'], required=True)
    a = p.parse_args()
    root, cef = a.root.resolve(), a.cef_root.resolve()
    sys.path.insert(0, '/opt/mycef/build-cef')
    from audit_elf import inspect, MACHINES, version_key
    from archive_posix import digest_file
    cpu = a.target.split('-')[1]
    arch = 'amd64' if cpu == 'x64' else 'arm64'
    sdk = root / 'output' / ('ffmpeg_9.0.2_' + a.target + '_release')
    libraries = sdk / 'lib'
    tools = sdk / 'tools/ffmpeg'
    elfs = []
    for path in list(libraries.iterdir()) + list(tools.iterdir()):
        if not path.is_file() or path.is_symlink():
            continue
        with path.open('rb') as f:
            if f.read(4) != b'\x7fELF':
                continue
        rpath = '$ORIGIN' if path.parent == libraries else '$ORIGIN/../../lib'
        if subprocess.check_output(['patchelf', '--print-rpath', str(path)], text=True).strip() != rpath:
            subprocess.run(['patchelf', '--set-rpath', rpath, str(path)], check=True)
        info = inspect(path)
        if info['machine'] != MACHINES[cpu] or info['glibc_other_requirements'] or version_key(info['glibc_max_required']) > version_key('2.28'):
            raise RuntimeError('FFmpeg SDK exceeds Linux compatibility limits: ' + str(path))
        needed = subprocess.check_output(['patchelf', '--print-needed', str(path)], text=True).splitlines()
        for name in needed:
            if '/' in name or name.startswith(('libav', 'libsw', 'libstdc++')) and not (libraries / name).is_file():
                raise RuntimeError('SDK contains an unresolved private dependency: ' + name)
        elfs.append({'file': path.relative_to(sdk).as_posix(), 'sha256': digest_file(path), 'elf': info})
    work = root / 'validation' / (a.target + '-' + dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'))
    work.mkdir(parents=True)
    toolchain = root / 'toolchains' / (a.target + '.cmake')
    out = work / 'demo-build'
    subprocess.run([str(root / 'host-tools/bin/cmake'), '-S', str(sdk / 'examples'), '-B', str(out),
                    '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TOOLCHAIN_FILE=' + str(toolchain)], check=True)
    subprocess.run([str(root / 'host-tools/bin/cmake'), '--build', str(out), '-j', '2'], check=True)
    binary = out / 'media-info'
    # The guest mounts SDK as /opt/mycef-sdk; use an explicit target library
    # search path for the independently compiled example and leave the SDK clean.
    shutil.copy2(binary, work / 'media-info')
    shutil.copy2(Path(__file__).resolve().parent / 'probe_media.py', work / 'probe_media.py')
    (work / 'reports').mkdir(mode=0o777)
    (work / 'reports').chmod(0o777)
    guest = '''set -eu
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export LC_ALL=C
uname -a
ldd --version
export LD_LIBRARY_PATH=/opt/mycef-sdk/lib
/usr/sbin/runuser -u nobody -- /usr/bin/env LD_LIBRARY_PATH=/opt/mycef-sdk/lib /opt/mycef-validation/media-info
/usr/sbin/runuser -u nobody -- /usr/bin/python3 /opt/mycef-validation/probe_media.py --sdk /opt/mycef-sdk --output /opt/mycef-validation/reports --timeout 900
/usr/sbin/runuser -u nobody -- /usr/bin/env LD_LIBRARY_PATH=/opt/mycef-sdk/lib /opt/mycef-validation/media-info /opt/mycef-validation/reports/libx265-yuv420p10le.mkv
echo MYCEF_FFMPEG_OLDLINUX_MEDIA_OK
'''
    (work / 'guest-run.sh').write_text(guest)
    boot = json.loads((cef / 'state' / ('linux49-vm-' + arch + '-runtime.json')).read_text())
    for key in ('kernel', 'initramfs'):
        if digest_file(Path(boot[key])) != boot[key + '_sha256']:
            raise RuntimeError('Validated guest boot input changed')
    if arch == 'amd64':
        cmd = ['qemu-system-x86_64', '-machine', 'q35,accel=tcg', '-cpu', 'max',
               '-append', 'console=ttyS0 panic=-1 rdinit=/init', '-virtfs',
               'local,path=' + str(cef / 'validation/oldlinux/buster-x64') + ',mount_tag=oldroot,security_model=none']
    else:
        cmd = ['qemu-system-aarch64', '-machine', 'virt,accel=tcg,gic-version=2', '-cpu', 'cortex-a72',
               '-append', 'console=ttyAMA0 panic=-1 rdinit=/init', '-drive',
               'file=' + str(cef / 'cache/oldlinux/buster-arm64.img') + ',format=raw,if=virtio']
    cmd += ['-m', '4096', '-smp', '4', '-kernel', boot['kernel'], '-initrd', boot['initramfs'],
            '-display', 'none', '-monitor', 'none', '-serial', 'stdio', '-no-reboot', '-nic', 'none',
            '-virtfs', 'local,path=' + str(work) + ',mount_tag=exchange,security_model=none',
            '-virtfs', 'local,path=' + str(sdk) + ',mount_tag=sdk,security_model=none,readonly=on']
    log = work / 'vm.log'
    with log.open('w') as f:
        result = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, timeout=3600)
    text = log.read_text(errors='replace')
    media_path = work / 'reports/result.json'
    media = json.loads(media_path.read_text()) if media_path.exists() else {}
    if (result.returncode or 'MYCEF_GUEST_VALIDATION_FAILED' in text
            or 'MYCEF_GUEST_VALIDATION_DONE' not in text or 'MYCEF_FFMPEG_OLDLINUX_MEDIA_OK' not in text
            or not media.get('passed') or not media.get('kernel', '').startswith('4.9.')
            or media.get('glibc') != 'glibc 2.28' or media.get('machine') != ('x86_64' if cpu == 'x64' else 'aarch64')):
        raise RuntimeError('FFmpeg old Linux runtime failed; inspect ' + str(log))
    record = {'target': a.target, 'passed': True, 'elfs': elfs, 'media': media,
              'demo_sha256': digest_file(binary), 'vm_log': str(log), 'vm_log_sha256': digest_file(log),
              'scope': 'Actual shared-library C API example and software encode/decode/filter tests in a full-system Linux 4.9/glibc 2.28 guest. No UOS product or hardware-acceleration execution claim.'}
    path = root / 'state' / ('runtime-' + a.target + '.json')
    path.write_text(json.dumps(record, indent=2) + '\n')
    shutil.copy2(path, sdk / 'validation/oldlinux-runtime.json')
    print('FFMPEG_LINUX49_GLIBC228_RUNTIME_PASSED', a.target, flush=True)


if __name__ == '__main__':
    main()
