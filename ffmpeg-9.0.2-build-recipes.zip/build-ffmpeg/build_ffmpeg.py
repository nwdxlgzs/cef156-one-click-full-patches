#!/usr/bin/env python3
"""Run a real version-locked FFmpeg target build and preserve its evidence."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

from prepare_vcpkg import TARGETS, VCPKG_REV, prepare
from prepare_aom_source import prepare as prepare_aom


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    p.add_argument('--target', choices=TARGETS, required=True)
    p.add_argument('--jobs', type=int, default=14)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    root = a.root.resolve()
    prepare(root, a.cef_root.resolve())
    if not a.dry_run:
        prepare_aom(root)
    aliases = {'dlltool': root / 'toolchains/llvm-mingw/bin/llvm-dlltool',
               'strip': a.cef_root.resolve() / 'chromium/src/third_party/llvm-build/Release+Asserts/bin/llvm-strip',
               'install_name_tool': a.cef_root.resolve() / 'chromium/src/third_party/llvm-build/Release+Asserts/bin/llvm-install-name-tool',
               'otool': a.cef_root.resolve() / 'cache/mac-aux/bin/llvm-otool'}
    for name, original in aliases.items():
        alias = root / 'host-tools/bin' / name
        if original.is_file() and not alias.exists():
            alias.symlink_to(original)
    platform, cpu = a.target.split('-')
    triplet = cpu + '-mycef-' + platform
    executable = root / 'vcpkg/vcpkg'
    if not executable.is_file():
        subprocess.run([str(root / 'vcpkg/bootstrap-vcpkg.sh'), '-disableMetrics'], check=True)
    env = dict(os.environ)
    env.update(VCPKG_ROOT=str(root / 'vcpkg'), VCPKG_DOWNLOADS=str(root / 'vcpkg-downloads'),
               VCPKG_MAX_CONCURRENCY=str(a.jobs), VCPKG_DISABLE_METRICS='1',
               VCPKG_FORCE_SYSTEM_BINARIES='1',
               VCPKG_BINARY_SOURCES='clear;files,' + str(root / 'binary-cache') + ',readwrite',
               VCPKG_DEFAULT_HOST_TRIPLET='x64-linux', LC_ALL='C.UTF-8')
    env['PATH'] = (str(root / 'host-tools/bin') + ':'
                   + str(a.cef_root.resolve() / 'chromium/src/third_party/llvm-build/Release+Asserts/bin')
                   + ':' + env['PATH'])
    env['X_VCPKG_ASSET_SOURCES'] = ('clear;x-script,/usr/bin/python3 ' + str(root / 'asset_mirror.py')
                                    + ' {url} {sha512} {dst}')
    cmd = [str(executable), 'install', '--triplet=' + triplet,
           '--host-triplet=x64-linux', '--overlay-triplets=' + str(root / 'triplets'),
           '--overlay-ports=' + str(root / 'overlay-ports'),
           '--x-manifest-root=' + str(root / 'manifests' / a.target),
           '--x-install-root=' + str(root / 'installed' / a.target),
           '--x-buildtrees-root=' + str(root / 'buildtrees' / a.target),
           '--x-packages-root=' + str(root / 'packages-work' / a.target)]
    if a.dry_run:
        cmd.append('--dry-run')
    state = root / 'state' / ('build-' + a.target + '.json')
    record = {'target': a.target, 'phase': 'planning' if a.dry_run else 'compiling',
              'vcpkg_revision': VCPKG_REV, 'command': cmd,
              'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'sdk_complete': False}
    state.write_text(json.dumps(record, indent=2) + '\n')
    with (root / 'logs' / (a.target + ('-plan.log' if a.dry_run else '-build.log'))).open('a') as f:
        result = subprocess.run(cmd, env=env, stdout=f, stderr=subprocess.STDOUT)
    record.update(returncode=result.returncode, phase='planned' if a.dry_run else 'compiled',
                  finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    if result.returncode:
        record['phase'] = 'failed'
    state.write_text(json.dumps(record, indent=2) + '\n')
    if result.returncode:
        raise RuntimeError('FFmpeg dependency/build failed; preserve logs and do not disable features')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()
