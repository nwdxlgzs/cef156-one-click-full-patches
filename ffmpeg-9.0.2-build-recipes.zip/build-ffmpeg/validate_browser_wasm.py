#!/usr/bin/env python3
"""Execute the downloaded FFmpeg WASM module in a real local Chromium browser."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading

from playwright.sync_api import sync_playwright
from package_ffmpeg import digest


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.wasm': 'application/wasm'}

    def log_message(self, *_):
        pass

    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        super().end_headers()


def validate(sdk, output):
    sdk, output = Path(sdk).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    page_path = sdk / 'examples/index.html'
    if not page_path.is_file():
        raise RuntimeError('Downloaded WASM browser example is absent')
    inputs = [p for p in (sdk / 'threads/bin').iterdir() if p.is_file()]
    inputs += [sdk / 'examples/worker.js', page_path]
    identity = {p.relative_to(sdk).as_posix(): digest(p) for p in inputs}
    receipt = output / 'browser-runtime.json'
    if receipt.exists():
        record = json.loads(receipt.read_text())
        if record.get('passed') and record['module_inputs'] == identity:
            return record
        raise RuntimeError('Previous browser verification used another module')
    server = ThreadingHTTPServer(('127.0.0.1', 0), functools.partial(Handler, directory=str(sdk)))
    threading.Thread(target=server.serve_forever, daemon=True).start()
    try:
        with sync_playwright() as playwright:
            browser = playwright.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',
                                                  headless=True, args=['--disable-gpu'])
            context = browser.new_context()
            page = context.new_page()
            page.set_default_timeout(180000)
            errors = []
            page.on('pageerror', lambda error: errors.append(str(error)))
            page.on('console', lambda msg: print('BROWSER_FFMPEG', msg.text, flush=True))
            page.goto('http://127.0.0.1:' + str(server.server_port) + '/examples/')
            result = page.evaluate('''async () => {
              if (!crossOriginIsolated || typeof SharedArrayBuffer === 'undefined')
                throw new Error('Cross-origin isolated pthread environment is unavailable');
              return await new Promise((resolve, reject) => {
                const worker = new Worker('worker.js');
                const logs = [];
                const deadline = setTimeout(() => { worker.terminate(); reject(new Error('Browser FFmpeg timeout after 180 seconds')); }, 180000);
                worker.onerror = error => { worker.terminate(); reject(new Error(error.message)); };
                worker.onmessage = event => {
                  if (event.data.log) { logs.push(event.data.log); console.log(event.data.log); }
                  if (event.data.error) { worker.terminate(); reject(new Error(event.data.error)); }
                  if (event.data.done) {
                    clearTimeout(deadline);
                    const bytes = new Uint8Array(event.data.results[0].data);
                    const base64 = btoa(Array.from(bytes, n => String.fromCharCode(n)).join(''));
                    worker.terminate(); resolve({ logs, bytes: bytes.length, output_base64: base64,
                      crossOriginIsolated, sharedArrayBuffer: typeof SharedArrayBuffer !== 'undefined' });
                  }
                };
                worker.postMessage({base: new URL('../threads/bin/', location.href).href,
                  args: ['-v', 'error', '-y', '-cpucount', '2', '-threads', '1', '-filter_threads', '1', '-f', 'lavfi', '-i',
                         'testsrc2=size=64x64:rate=5', '-frames:v', '2', '-c:v', 'libx264',
                         '-preset', 'ultrafast', '-threads', '1', '-pix_fmt', 'yuv420p', '/probe.mp4'],
                  files: [], outputs: ['/probe.mp4']});
              });
            }''')
            if result['bytes'] < 100 or errors:
                raise RuntimeError('Browser WASM media probe failed: ' + repr(errors))
            import base64
            media = output / 'browser-h264.mp4'
            media.write_bytes(base64.b64decode(result.pop('output_base64')))
            ffprobe = sdk.parent / 'ffmpeg_9.0.2_windows-x64_release/bin/ffprobe.exe'
            if not ffprobe.is_file():
                raise RuntimeError('Native verified FFprobe is required to inspect the browser-generated MP4')
            import os
            import subprocess
            env = dict(os.environ)
            env['PATH'] = str(ffprobe.parent) + os.pathsep + env['PATH']
            streams = json.loads(subprocess.check_output([str(ffprobe), '-v', 'error', '-show_streams', '-of', 'json', str(media)],
                                                        env=env, text=True, timeout=30))
            if len(streams['streams']) != 1 or streams['streams'][0]['codec_name'] != 'h264':
                raise RuntimeError('Browser output is not an actual H.264 stream')
            record = {'target': 'wasm32', 'passed': True, 'module_inputs': identity,
                      'browser_version': browser.version, 'result': result, 'streams': streams,
                      'output_sha256': digest(media),
                      'scope': 'Actual downloaded pthread FFmpeg JS/WASM loaded in Chrome Worker with COOP/COEP and produced an H.264 MP4 inspected by native FFprobe. CEF execution and native hardware codecs are not covered.'}
            receipt.write_text(json.dumps(record, indent=2) + '\n')
            browser.close()
            return record
    finally:
        server.shutdown()
        server.server_close()


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--sdk', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    print('LOCAL_REAL_BROWSER_FFMPEG_WASM_PASSED', json.dumps(validate(a.sdk, a.output)), flush=True)
