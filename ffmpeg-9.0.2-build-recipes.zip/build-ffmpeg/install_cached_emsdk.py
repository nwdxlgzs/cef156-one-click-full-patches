#!/usr/bin/env python3
"""Run the pinned SDK installer using only independently verified local files."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

from prepare_wasm import EMSDK_VERSION

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
sdk = a.root.resolve() / 'toolchains/emsdk'
os.chdir(sdk)
sys.path.insert(0, str(sdk))
spec = importlib.util.spec_from_file_location('emsdk_cached_install', sdk / 'emsdk.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def cached(url, dstpath, filename_prefix=''):
    path = Path(dstpath) / (filename_prefix + url.rsplit('/', 1)[-1])
    receipt = json.loads(path.with_suffix(path.suffix + '.verified.json').read_text())
    if path.stat().st_size != receipt['size'] or hashlib.sha256(path.read_bytes()).hexdigest() != receipt['sha256']:
        raise RuntimeError('Verified Emscripten archive changed: ' + str(path))
    print('USING_VERIFIED_SDK_DOWNLOAD', path, flush=True)
    return str(path)


# The official extraction, marker and activation logic is unchanged. Only its
# unconditional serial downloader is replaced by a verified local-file reader.
module.download_file = cached
sys.argv = [str(sdk / 'emsdk'), 'install', EMSDK_VERSION]
result = module.main(['install', EMSDK_VERSION])
if result:
    raise SystemExit(result)
subprocess.run([sys.executable, str(sdk / 'emsdk.py'), 'activate', EMSDK_VERSION], check=True)
