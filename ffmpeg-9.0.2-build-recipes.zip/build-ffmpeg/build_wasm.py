#!/usr/bin/env python3
"""Build the portable software libraries and actual FFmpeg JS/WASM tools."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from prepare_wasm import EMSDK_VERSION, LIBRARIES, prepare
from prepare_aom_source import prepare as prepare_aom
from wasm_metadata import normalize_prefix


def run(cmd, *, env, cwd, log):
    with log.open('a') as f:
        f.write('\nCOMMAND ' + json.dumps(list(map(str, cmd))) + '\n')
        f.flush()
        subprocess.run(list(map(str, cmd)), cwd=cwd, env=env,
                       stdout=f, stderr=subprocess.STDOUT, check=True)


def environment(root):
    sdk = root / 'toolchains/emsdk'
    env = dict(os.environ)
    # Read only the environment emitted by the pinned SDK; no global changes.
    script = 'set +u; source "' + str(sdk / 'emsdk_env.sh') + '" >/dev/null 2>&1; env -0'
    output = subprocess.check_output(['/bin/bash', '-c', script])
    for item in output.split(b'\0'):
        if b'=' in item:
            k, v = item.split(b'=', 1)
            env[k.decode()] = v.decode()
    env['PATH'] = str(root / 'host-tools/bin') + ':' + env['PATH']
    env.update(EMSCRIPTEN_ROOT=str(sdk / 'upstream/emscripten'),
               VCPKG_FORCE_SYSTEM_BINARIES='1', VCPKG_DISABLE_METRICS='1',
               VCPKG_ROOT=str(root / 'vcpkg'), VCPKG_DOWNLOADS=str(root / 'vcpkg-downloads'),
               VCPKG_BINARY_SOURCES='clear;files,' + str(root / 'binary-cache') + ',readwrite',
               X_VCPKG_ASSET_SOURCES='clear;x-script,/usr/bin/python3 ' + str(root / 'asset_mirror.py') + ' {url} {sha512} {dst}',
               LC_ALL='C.UTF-8')
    return env


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--mode', choices=['threads'], default='threads')
    p.add_argument('--jobs', type=int, default=12)
    p.add_argument('--dry-run', action='store_true')
    a = p.parse_args()
    root = a.root.resolve()
    plan = prepare(root)
    if not a.dry_run:
        prepare_aom(root)
    env = environment(root)
    env['VCPKG_MAX_CONCURRENCY'] = str(a.jobs)
    version = subprocess.check_output(['emcc', '--version'], env=env, text=True)
    if EMSDK_VERSION not in version:
        raise RuntimeError('Wrong active Emscripten compiler')
    for mode in (a.mode,):
        variant = 'wasm-' + mode
        triplet = plan['variants'][mode]['triplet']
        log = root / 'logs' / (variant + '-build.log')
        state = root / 'state' / ('build-' + variant + '.json')
        record = {'target': 'wasm32', 'variant': mode, 'phase': 'planning' if a.dry_run else 'dependencies',
                  'started_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                  'sdk_complete': False, 'emscripten_version_output': version}
        state.write_text(json.dumps(record, indent=2) + '\n')
        cmd = [root / 'vcpkg/vcpkg', 'install', '--triplet=' + triplet, '--host-triplet=x64-linux',
               '--overlay-triplets=' + str(root / 'triplets'),
               '--overlay-ports=' + str(root / 'overlay-ports-wasm'),
               '--overlay-ports=' + str(root / 'overlay-ports'),
               '--x-manifest-root=' + str(root / 'manifests' / variant),
               '--x-install-root=' + str(root / 'installed' / variant),
               '--x-buildtrees-root=' + str(root / 'buildtrees' / variant),
               '--x-packages-root=' + str(root / 'packages-work' / variant)]
        try:
            run(cmd + (['--dry-run'] if a.dry_run else []), env=env, cwd=root, log=log)
            if a.dry_run:
                record['phase'] = 'planned'
                state.write_text(json.dumps(record, indent=2) + '\n')
                continue
            installed = root / 'installed' / variant / triplet
            normalize_prefix(installed)
            source_info = json.loads((root / 'state/source-ffmpeg.json').read_text())
            archive = Path(source_info['source'])
            if hashlib.sha256(archive.read_bytes()).hexdigest() != source_info['source_sha256']:
                raise RuntimeError('Authenticated FFmpeg source differs')
            source = root / 'sources' / ('FFmpeg-' + source_info['revision'])
            build = root / 'buildtrees' / variant / 'ffmpeg'
            build.mkdir(parents=True, exist_ok=True)
            prefix = root / 'wasm-install' / mode
            compile_flags = '-O3 -msimd128 -I' + str(installed / 'include')
            if mode == 'threads':
                compile_flags += ' -pthread'
            link_flags = ['-L' + str(installed / 'lib'), '-sMODULARIZE=1', '-sEXPORT_NAME=createFFmpeg',
                          '-sDEFAULT_TO_CXX=1',
                          '-sINVOKE_RUN=0', '-sEXIT_RUNTIME=1', '-sALLOW_MEMORY_GROWTH=1',
                          '-sINITIAL_MEMORY=134217728', '-sMAXIMUM_MEMORY=4294967296',
                          '-sENVIRONMENT=web,worker,node', '-sFORCE_FILESYSTEM=1',
                          '-sEXPORTED_RUNTIME_METHODS=callMain,FS']
            if mode == 'threads':
                link_flags += ['-pthread', '-sPTHREAD_POOL_SIZE=16', '-sPTHREAD_POOL_SIZE_STRICT=1']
            local_env = dict(env)
            local_env.update(PKG_CONFIG_PATH='', PKG_CONFIG_LIBDIR=str(installed / 'lib/pkgconfig')
                             + ':' + str(installed / 'share/pkgconfig'))
            local_env.pop('PKG_CONFIG_SYSROOT_DIR', None)
            configure = [str(source / 'configure'), '--prefix=' + str(prefix), '--target-os=none',
                         '--arch=wasm32', '--enable-cross-compile', '--enable-asm', '--enable-simd128',
                         '--disable-x86asm', '--disable-runtime-cpudetect', '--disable-stripping',
                         '--disable-doc', '--disable-debug', '--disable-autodetect', '--disable-shared',
                         '--enable-static', '--enable-gpl', '--enable-version3', '--disable-network',
                         '--disable-ffplay', '--enable-ffmpeg', '--enable-ffprobe',
                         '--cc=emcc', '--cxx=em++', '--objcc=emcc', '--dep-cc=emcc',
                         '--ar=emar', '--nm=emnm', '--ranlib=emranlib', '--host-cc=/usr/bin/cc',
                         '--pkg-config=/usr/bin/pkg-config', '--pkg-config-flags=--static',
                         '--extra-cflags=' + compile_flags, '--extra-cxxflags=' + compile_flags,
                         '--extra-ldflags=' + ' '.join(link_flags), '--extra-libs=-lstdc++',
                         '--enable-pthreads' if mode == 'threads' else '--disable-pthreads',
                         '--disable-w32threads', '--disable-os2threads']
            configure += ['--enable-' + option for option in LIBRARIES]
            run(configure, env=local_env, cwd=build, log=log)
            record['phase'] = 'ffmpeg-compiling'
            record['configure'] = configure
            state.write_text(json.dumps(record, indent=2) + '\n')
            run(['make', '-j' + str(a.jobs)], env=local_env, cwd=build, log=log)
            run(['make', 'install'], env=local_env, cwd=build, log=log)
            for tool in ('ffmpeg', 'ffprobe'):
                wasm_files = [build / (tool + suffix) for suffix in ('.wasm', '_g.wasm')]
                wasm_files = [path for path in wasm_files if path.is_file()]
                if not (build / tool).is_file() or not wasm_files or any(path.read_bytes()[:4] != b'\0asm' for path in wasm_files):
                    raise RuntimeError('Missing actual linked JS/WASM tool: ' + tool)
            record['phase'] = 'compiled'
            record['finished_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
        except Exception as exc:
            record.update(phase='failed', error=str(exc))
            state.write_text(json.dumps(record, indent=2) + '\n')
            raise
        state.write_text(json.dumps(record, indent=2) + '\n')
        print('WASM_VARIANT_COMPILED_PENDING_RUNTIME_VALIDATION', mode, flush=True)


if __name__ == '__main__':
    main()
