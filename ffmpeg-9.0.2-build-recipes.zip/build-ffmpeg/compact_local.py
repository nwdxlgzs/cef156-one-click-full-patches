#!/usr/bin/env python3
"""Create a minimal development SDK locally from one verified full artifact."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'build-cef'))
from minimize_sdk import archive_sdk, digest, elf_runtime, zstd_reader


def compact(source, destination, objcopy):
    receipt = json.loads(source.with_name(source.name + '.verified.json').read_text())
    if not receipt.get('local_download_verified') or digest(source) != receipt['archive_sha256']:
        raise RuntimeError('Full archive is not locally authenticated')
    target = receipt['target']
    name = source.name.removesuffix('.tar.zst')
    sdk = destination / name
    archive = destination / source.name
    if archive.exists():
        prior = json.loads(archive.with_name(archive.name + '.verified.json').read_text())
        if prior['source_archive_sha256'] != receipt['archive_sha256'] or digest(archive) != prior['archive_sha256']:
            raise RuntimeError('Previously compacted package changed')
        return prior
    if sdk.exists():
        raise RuntimeError('Partial local compact SDK exists; preserve it for inspection')
    sdk.mkdir(parents=True)
    links = []
    checks = {}
    full_manifest = None
    public = {'libavcodec', 'libavdevice', 'libavfilter', 'libavformat', 'libavutil', 'libswresample', 'libswscale'}
    with zstd_reader(source) as stream, tarfile.open(fileobj=stream, mode='r|') as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            if path.is_absolute() or '..' in path.parts or '\\' in member.name or ':' in member.name or not path.parts or path.parts[0] != name:
                raise RuntimeError('Unsafe archive path')
            relative = PurePosixPath(*path.parts[1:])
            if not relative.parts:
                continue
            if relative.as_posix() == 'SHA256SUMS.json':
                full_manifest = json.load(tar.extractfile(member))
                continue
            # External media implementations are linked into the shared native
            # FFmpeg libraries. Native consumers need only FFmpeg's public API.
            if target != 'wasm32' and relative.parts[0] == 'include' and len(relative.parts) > 1 and relative.parts[1] not in public:
                continue
            if any(part.endswith('.dSYM') for part in relative.parts) or relative.suffix.lower() in ('.pdb', '.debug', '.dwo', '.dwp', '.map', '.ilk'):
                continue
            output = sdk.joinpath(*relative.parts)
            if member.isdir():
                output.mkdir(parents=True, exist_ok=True)
                continue
            output.parent.mkdir(parents=True, exist_ok=True)
            if member.issym():
                resolved = (output.parent / member.linkname).resolve()
                if os.path.isabs(member.linkname) or sdk.resolve() not in resolved.parents:
                    raise RuntimeError('Archive symlink escapes SDK')
                links.append((output, member.linkname))
                checks[relative.as_posix()] = {'type': 'symlink', 'target': member.linkname}
            elif member.isfile():
                sha = hashlib.sha256()
                with tar.extractfile(member) as input_file, output.open('wb') as f:
                    for data in iter(lambda: input_file.read(8 * 1024 * 1024), b''):
                        sha.update(data)
                        f.write(data)
                os.chmod(output, member.mode & 0o777)
                checks[relative.as_posix()] = {'type': 'file', 'sha256': sha.hexdigest(), 'bytes': member.size}
            else:
                raise RuntimeError('Unexpected archive member type')
    if not full_manifest:
        raise RuntimeError('Full SDK payload manifest is absent')
    for relative, info in checks.items():
        expected = full_manifest.get(relative)
        if not expected or any(expected.get(key) != value for key, value in info.items()):
            raise RuntimeError('Extracted SDK payload differs from verified source: ' + relative)
    for output, link in links:
        output.symlink_to(link, target_is_directory=(output.parent / link).is_dir())
    stripped = []
    if target.startswith('linux-'):
        if not objcopy or not objcopy.is_file():
            raise RuntimeError('Local LLVM objcopy is required for Linux debug removal')
        for path in sdk.rglob('*'):
            if path.is_symlink() or not path.is_file():
                continue
            with path.open('rb') as f:
                if f.read(4) != b'\x7fELF':
                    continue
            before, original_debug = elf_runtime(path)
            original_sha, original_bytes = digest(path), path.stat().st_size
            if original_debug:
                subprocess.run([str(objcopy), '--strip-debug', str(path)], check=True)
            after, debug = elf_runtime(path)
            if before != after or debug:
                raise RuntimeError('Local strip changed ELF runtime content or retained DWARF')
            stripped.append({'file': path.relative_to(sdk).as_posix(), 'original_sha256': original_sha,
                              'original_bytes': original_bytes, 'stripped_bytes': path.stat().st_size,
                              'stripped_sha256': digest(path), 'allocated_sections_and_program_headers_unchanged': True})
    if target.startswith('mac-'):
        from audit_macho import inspect
        for path in sdk.rglob('*'):
            if not path.is_file() or path.is_symlink():
                continue
            with path.open('rb') as f:
                magic = f.read(4)
            if magic == b'\xcf\xfa\xed\xfe' and any(section['name'].startswith('__debug') for section in inspect(path)['sections']):
                raise RuntimeError('Mac image contains embedded DWARF; preserve it until a signature-aware local strip is available')
    feature_file = sdk / 'FEATURES.json'
    features = json.loads(feature_file.read_text())
    features['distribution_variant'] = 'compact-development'
    features['runtime_verified_before_local_compaction'] = features.pop('runtime_verified', False)
    features['runtime_verified_after_local_compaction'] = False
    features['source_full_archive_sha256'] = receipt['archive_sha256']
    feature_file.write_text(json.dumps(features, indent=2) + '\n')
    metadata = {'target': target, 'source_archive': source.name, 'source_archive_sha256': receipt['archive_sha256'],
                'created_locally': True, 'elf_strip': stripped, 'external_native_dependency_headers_removed': target != 'wasm32',
                'scope': 'Public FFmpeg API, runtime/link libraries, tools, examples and provenance retained. Linux allocated sections/program headers compared after local strip; target runtime is not rerun by this compactor.'}
    (sdk / 'COMPACT-MANIFEST.json').write_text(json.dumps(metadata, indent=2) + '\n')
    sdk_bytes = sum(path.stat().st_size for path in sdk.rglob('*') if path.is_file() and not path.is_symlink())
    result = archive_sdk(sdk, archive)
    result.update(source_archive_sha256=receipt['archive_sha256'], target=target, sdk_bytes=sdk_bytes,
                  archive_sha256=digest(archive), bytes=archive.stat().st_size, created_locally=True)
    archive.with_name(archive.name + '.verified.json').write_text(json.dumps(result, indent=2) + '\n')
    archive.with_name(archive.name + '.sha256').write_text(result['archive_sha256'] + '  ' + archive.name + '\n')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--source', type=Path, required=True)
    p.add_argument('--destination', type=Path, required=True)
    p.add_argument('--objcopy', type=Path)
    a = p.parse_args()
    a.destination.mkdir(parents=True, exist_ok=True)
    print('LOCAL_COMPACT_FFMPEG_SDK_VERIFIED', json.dumps(compact(a.source.resolve(), a.destination.resolve(), a.objcopy)), flush=True)
