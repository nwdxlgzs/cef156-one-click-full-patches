"""Make WASM SDK linker metadata relocatable without overriding app workers."""
from pathlib import Path
import re


def normalize_prefix(prefix):
    for pc in (Path(prefix) / 'lib/pkgconfig').glob('*.pc'):
        text = pc.read_text()
        # Meson's Emscripten dependency detection injects its own default pool.
        # Applications choose their pool at the final link, not in a media .pc.
        text = re.sub(r'(?<!\S)-sPTHREAD_POOL_SIZE(?:=\S+|\s+\S+)', '', text)
        pc.write_text(text)


def normalize(sdk):
    sdk = Path(sdk)
    normalize_prefix(sdk / 'threads')
    # PTHREAD_POOL_SIZE only controls generated JavaScript worker allocation.
    # Earlier dependency .pc defaults overrode the requested final-link value.
    # Keep the compiled WASM byte-for-byte and make its JS loader match the ABI.
    for name in ('ffmpeg.js', 'ffprobe.js'):
        path = sdk / 'threads/bin' / name
        text = path.read_text()
        pattern = r'var pthreadPoolSize = (\d+);'
        counts = re.findall(pattern, text)
        if counts not in (['4'], ['16']):
            raise RuntimeError('Unexpected generated pthread pool configuration: ' + name)
        path.write_text(re.sub(pattern, 'var pthreadPoolSize = 16;', text))
