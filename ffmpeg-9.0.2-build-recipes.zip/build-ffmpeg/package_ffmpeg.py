#!/usr/bin/env python3
"""Stage the actual Release libraries, public API, tools and feature evidence."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from prepare_vcpkg import TARGETS


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    p.add_argument('--target', choices=TARGETS, required=True)
    a = p.parse_args()
    root = a.root.resolve()
    record = json.loads((root / 'state' / ('build-' + a.target + '.json')).read_text())
    if record['phase'] != 'compiled' or record['returncode'] != 0:
        raise RuntimeError('Actual target build is not complete')
    platform, cpu = a.target.split('-')
    triplet = cpu + '-mycef-' + platform
    installed = root / 'installed' / a.target / triplet
    config_dir = root / 'buildtrees' / a.target / 'ffmpeg' / (triplet + '-rel')
    config = config_dir / 'config.h'
    components = config_dir / 'config_components.h'
    flags = {name: int(value) for file in (config, components)
             for name, value in re.findall(r'^#define (CONFIG_\w+) ([01])$', file.read_text(), re.M)}
    needed = ['CONFIG_GPL', 'CONFIG_VERSION3', 'CONFIG_AVCODEC', 'CONFIG_AVFORMAT',
              'CONFIG_AVFILTER', 'CONFIG_AVDEVICE', 'CONFIG_SWRESAMPLE', 'CONFIG_SWSCALE',
              'CONFIG_LIBX264', 'CONFIG_LIBX265', 'CONFIG_LIBDAV1D', 'CONFIG_LIBAOM',
              'CONFIG_LIBASS', 'CONFIG_LIBFREETYPE', 'CONFIG_LIBHARFBUZZ', 'CONFIG_LIBOPUS',
              'CONFIG_LIBVORBIS', 'CONFIG_LIBMP3LAME', 'CONFIG_LIBVPX', 'CONFIG_LIBWEBP',
              'CONFIG_LIBOPENJPEG', 'CONFIG_LIBJXL', 'CONFIG_LIBZIMG', 'CONFIG_LIBMYSOFA',
              'CONFIG_LIBRUBBERBAND', 'CONFIG_OPENSSL', 'CONFIG_FFMPEG', 'CONFIG_FFPROBE', 'CONFIG_FFPLAY']
    if any(flags.get(name) != 1 for name in needed) or flags.get('CONFIG_NONFREE'):
        raise RuntimeError('Missing requested media feature, tool or GPL configuration')
    stage = root / 'output' / ('ffmpeg_9.0.2_' + a.target + '_release')
    if stage.exists():
        raise RuntimeError('SDK staging exists; preserve and inspect it')
    stage.mkdir()
    shutil.copytree(installed / 'include', stage / 'include', symlinks=True)
    (stage / 'lib').mkdir()
    cxx_runtime = None
    if platform == 'linux':
        cxx_runtime = json.loads((a.cef_root / 'state/linux-cxx-runtime.json').read_text())['targets'][cpu]
        original = Path(cxx_runtime['library'])
        copyright_file = Path(cxx_runtime['copyright'])
        if digest(original) != cxx_runtime['library_sha256'] or digest(copyright_file) != cxx_runtime['copyright_sha256']:
            raise RuntimeError('Authenticated full C++ runtime changed')
        shutil.copy2(original, stage / 'lib' / original.name)
        (stage / 'lib/libstdc++.so.6').symlink_to(original.name)
        license_dir = stage / 'licenses/libstdc++'
        license_dir.mkdir(parents=True)
        shutil.copy2(copyright_file, license_dir / 'copyright')
    components_names = ['avcodec', 'avformat', 'avutil', 'avfilter', 'avdevice', 'swresample', 'swscale']
    for name in components_names:
        matches = [x for x in (installed / 'lib').glob('*' + name + '*')
                   if x.is_file() or x.is_symlink()]
        if not matches:
            raise RuntimeError('Missing FFmpeg link library: ' + name)
        for source in matches:
            if source.is_symlink():
                (stage / 'lib' / source.name).symlink_to(source.readlink())
            else:
                shutil.copy2(source, stage / 'lib' / source.name)
    # Ports such as D-Bus require shared linkage even when the codec/filter
    # libraries are static. Preserve the actual target runtime closure.
    if platform != 'windows':
        for source in (installed / 'lib').iterdir():
            if not ('.so' in source.name if platform == 'linux' else source.name.endswith('.dylib')):
                continue
            destination = stage / 'lib' / source.name
            if destination.exists() or destination.is_symlink():
                continue
            if source.is_symlink():
                destination.symlink_to(source.readlink())
            elif source.is_file():
                shutil.copy2(source, destination)
    pcdir = stage / 'lib/pkgconfig'
    pcdir.mkdir()
    for source in (installed / 'lib/pkgconfig').glob('*.pc'):
        if source.stem not in ['lib' + x for x in components_names]:
            continue
        text = re.sub(r'^prefix=.*$', 'prefix=${pcfiledir}/../..', source.read_text(), flags=re.M)
        text = re.sub(r'^(?:Libs\.private|Requires\.private):.*\n?', '', text, flags=re.M)
        (pcdir / source.name).write_text(text)
    source_tools = installed / 'tools/ffmpeg'
    tools = stage / ('bin' if platform == 'windows' else 'tools/ffmpeg')
    tools.mkdir(parents=True)
    for name in ['ffmpeg', 'ffprobe', 'ffplay']:
        source = source_tools / (name + ('.exe' if platform == 'windows' else ''))
        if not source.is_file():
            raise RuntimeError('Requested CLI tool is missing: ' + name)
        shutil.copy2(source, tools / source.name)
    if platform == 'windows':
        for folder in (installed / 'bin', source_tools):
            for source in folder.glob('*.dll'):
                target = tools / source.name
                if target.exists() and digest(target) != digest(source):
                    raise RuntimeError('Different runtime DLLs share one name')
                shutil.copy2(source, target)
        # Clang's C++ and unwind runtime DLLs are outside the vcpkg prefix.
        runtime_cpu = {'x64': 'x86_64', 'x86': 'i686', 'arm64': 'aarch64'}[cpu]
        runtime_dir = root / 'toolchains/llvm-mingw' / (runtime_cpu + '-w64-mingw32') / 'bin'
        for source in runtime_dir.glob('*.dll'):
            destination = tools / source.name
            if not destination.exists():
                shutil.copy2(source, destination)
        llvm = root / 'toolchains/llvm-mingw/bin'
        for name in components_names:
            dlls = list(tools.glob(name + '-*.dll')) + list(tools.glob('lib' + name + '-*.dll'))
            if len(dlls) != 1:
                raise RuntimeError('Missing or ambiguous FFmpeg DLL: ' + name)
            dll = dlls[0]
            report = subprocess.check_output([str(llvm / 'llvm-readobj'), '--coff-exports', str(dll)], text=True)
            exports = re.findall(r'^\s+Name: (\S+)\s*$', report, re.M)
            if not exports or any(not re.fullmatch('[A-Za-z_][A-Za-z0-9_@?$.]*', x) for x in exports):
                raise RuntimeError('Unexpected DLL exports')
            definition = stage / 'lib' / (name + '.def')
            definition.write_text('LIBRARY ' + dll.name + '\nEXPORTS\n' + '\n'.join(exports) + '\n')
            subprocess.run([str(llvm / 'llvm-dlltool'), '-m', {'x64': 'i386:x86-64', 'x86': 'i386', 'arm64': 'arm64'}[cpu],
                            '-d', str(definition), '-D', dll.name, '-l', str(stage / 'lib' / (name + '.lib'))], check=True)
    # Retain every dependency's actual license and source provenance.
    licenses = stage / 'licenses'
    for source in (installed / 'share').rglob('*'):
        if source.is_file() and source.name in ('copyright', 'vcpkg.spdx.json'):
            target = licenses / source.relative_to(installed / 'share')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    if platform == 'windows':
        (licenses / 'llvm-mingw').mkdir(parents=True, exist_ok=True)
        shutil.copy2(root / 'toolchains/llvm-mingw/LICENSE.TXT', licenses / 'llvm-mingw/LICENSE.TXT')
    examples = Path(__file__).resolve().parent / 'examples'
    shutil.copytree(examples, stage / 'examples')
    recipes = stage / 'build-recipes'
    recipes.mkdir()
    for source in Path(__file__).resolve().parent.glob('*.py'):
        shutil.copy2(source, recipes / source.name)
    shutil.copytree(Path(__file__).resolve().parent / 'x265-multilib', recipes / 'x265-multilib')
    for overlay in (root / 'overlay-ports').iterdir():
        if overlay.is_dir():
            shutil.copytree(overlay, recipes / 'overlay-ports' / overlay.name)
    validation = stage / 'validation'
    validation.mkdir()
    if cxx_runtime:
        (validation / 'cxx-runtime.json').write_text(json.dumps(cxx_runtime, indent=2) + '\n')
    for path in (config, components, config_dir / 'ffbuild/config.mak'):
        shutil.copy2(path, validation / path.name)
    for name in ('source-ffmpeg.json', 'prepared-manifests.json', 'build-' + a.target + '.json'):
        shutil.copy2(root / 'state' / name, validation / name)
    feature_record = {'target': a.target, 'configuration': 'Release', 'flags': flags,
                      'component_counts': {kind.lower(): sum(v for k, v in flags.items() if k.endswith('_' + kind))
                                           for kind in ['DECODER', 'ENCODER', 'FILTER', 'DEMUXER', 'MUXER', 'PROTOCOL', 'INDEV', 'OUTDEV', 'HWACCEL']},
                      'build_record_sha256': digest(root / 'state' / ('build-' + a.target + '.json')),
                      'runtime_verified': False, 'sdk_complete': False,
                      'scope': 'Actual linked Release outputs and generated feature headers; runtime, relocation and archive verification remain separate gates.'}
    (stage / 'FEATURES.json').write_text(json.dumps(feature_record, indent=2) + '\n')
    (stage / 'README.zh-CN.md').write_text(
        '# FFmpeg 9.0.2 开发包：' + a.target + '\n\n'
        '本包同时包含 Release 动态库、全部相关头文件及 ffmpeg / ffprobe / ffplay。\n'
        '公共 FFmpeg API 位于 include/libav*、include/libsw*；开发链接文件位于 lib。\n'
        'Windows 程序和 DLL 位于 bin；Linux/macOS 程序位于 tools/ffmpeg，动态库位于 lib。\n'
        'examples/media-info.c 展示直接调用动态库读取音视频信息，使用示例 CMakeLists.txt 构建。\n'
        'Windows 运行自编译示例时，需将 bin 中 DLL 放到示例 EXE 旁或加入 PATH。\n'
        '本包为共享库开发包，不提供外部依赖的完整静态链接套件。\n'
        '实际功能以 FEATURES.json 和 validation 中的配置、运行及兼容性记录为准。\n'
        'GPL 构建；各依赖的许可证和源码位置见 licenses。原生 AAC 已启用，不包含 nonfree 编码库。\n'
        'CEF 的媒体库与此 SDK 独立，不将本包 DLL/dylib/so 替换进 CEF 安装目录。\n', encoding='utf-8')
    print('FFMPEG_SDK_STAGED_PENDING_RUNTIME_VALIDATION', stage, flush=True)


if __name__ == '__main__':
    main()
