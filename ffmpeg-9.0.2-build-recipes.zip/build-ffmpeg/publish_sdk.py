#!/usr/bin/env python3
"""Publish only validated SDK contents, then safely recycle target intermediates."""
import argparse
import datetime as dt
import json
from pathlib import Path
import shutil
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--target', required=True)
p.add_argument('--cleanup', action='store_true')
a = p.parse_args()
root = a.root.resolve()
sys.path.insert(0, '/opt/mycef/build-cef')
from archive_posix import create_archive, digest_file, list_sdk, verify_archive

stage = root / 'output' / ('ffmpeg_9.0.2_' + a.target + '_release')
validation = root / 'state' / ('runtime-' + a.target + '.json')
receipt = root / 'state' / ('archive-' + a.target + '.json')
record = json.loads(validation.read_text())
if record.get('target') != a.target or record.get('passed') is not True:
    raise RuntimeError('Actual platform validation has not passed')
features = json.loads((stage / 'FEATURES.json').read_text())
features.update(sdk_complete=True, validation_scope=record['scope'],
                runtime_verified=record.get('runtime_verified', a.target.startswith('linux-') or a.target == 'wasm32'))
(stage / 'FEATURES.json').write_text(json.dumps(features, indent=2) + '\n')
destination = root / 'archives' / (stage.name + '.tar.zst')
result = create_archive(stage, destination)
result.update(target=a.target, validation_sha256=digest_file(validation),
              published_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
              sdk_complete=True, local_download_verified=False,
              validation_scope=record['scope'])
receipt.write_text(json.dumps(result, indent=2) + '\n')
if a.cleanup:
    # Recheck archive identity immediately before any irreversible cleanup.
    if digest_file(destination) != result['archive_sha256']:
        raise RuntimeError('Published artifact changed before cleanup')
    verify_archive(destination, stage.name, list_sdk(stage))
    recycled = []
    variants = ['wasm-single', 'wasm-threads'] if a.target == 'wasm32' else [a.target]
    for parent in ('buildtrees', 'packages-work', 'installed'):
        for variant in variants:
            target = root / parent / variant
            resolved = target.resolve()
            if resolved.parent != (root / parent).resolve() or target.is_symlink():
                raise RuntimeError('Unsafe intermediate cleanup target: ' + str(target))
            if target.exists():
                shutil.rmtree(target)
                recycled.append(str(target))
    result['recycled_intermediate_directories'] = recycled
    receipt.write_text(json.dumps(result, indent=2) + '\n')
print('FFMPEG_SDK_ARCHIVE_VERIFIED', json.dumps(result), flush=True)
