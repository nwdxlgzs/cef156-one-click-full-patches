#!/usr/bin/env python3
"""Exercise real FFmpeg encoders/filters and verify the resulting streams."""
import argparse
import json
import os
from pathlib import Path
import platform
import subprocess


def probe(sdk, output, timeout=300, cli_player=True, thread_limit=None):
    sdk, output = Path(sdk).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    windows = platform.system() == 'Windows'
    tools = sdk / ('bin' if windows else 'tools/ffmpeg')
    ffmpeg = tools / ('ffmpeg.exe' if windows else 'ffmpeg')
    ffprobe = tools / ('ffprobe.exe' if windows else 'ffprobe')
    env = dict(os.environ)
    if windows:
        env['PATH'] = str(tools) + os.pathsep + env.get('PATH', '')
    else:
        env['LD_LIBRARY_PATH'] = str(sdk / 'lib')

    def run(command):
        if thread_limit is not None and command[0] == ffmpeg:
            command = [ffmpeg, '-cpucount', '2', '-threads', str(thread_limit),
                       '-filter_threads', str(thread_limit),
                       '-filter_complex_threads', str(thread_limit), *command[1:]]
        p = subprocess.run(list(map(str, command)), env=env, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
        if p.returncode:
            raise RuntimeError('Media probe command failed: ' + p.stderr.decode('utf-8', 'replace')[-6000:])
        return p.stdout.decode('utf-8', 'replace')
    version = run([ffmpeg, '-version'])
    if 'ffmpeg version 9.0.2' not in version:
        raise RuntimeError('Unexpected actual FFmpeg version')
    variants = [('libx264', 'yuv420p'), ('libx264', 'yuv420p10le'),
                ('libx264', 'yuv422p10le'), ('libx264', 'yuv444p10le'),
                ('libx265', 'yuv420p'), ('libx265', 'yuv420p10le'), ('libx265', 'yuv420p12le'),
                ('libvpx-vp9', 'yuv420p'), ('libvpx-vp9', 'yuv420p10le'), ('libaom-av1', 'yuv420p10le'),
                ('ffv1', 'yuv444p16le'), ('prores_ks', 'yuv422p10le')]
    tests = []
    for encoder, pixel in variants:
        media = output / (encoder + '-' + pixel + '.mkv')
        cmd = [ffmpeg, '-v', 'error', '-y', '-filter_threads', '1', '-f', 'lavfi', '-i',
               'testsrc2=size=64x64:rate=5', '-frames:v', '2', '-vf',
               'trim=start_frame=0:end_frame=2,setpts=PTS-STARTPTS,scale=64:64,format=' + pixel,
               '-c:v', encoder, '-threads', '1']
        if encoder in ('libx264', 'libx265'):
            cmd += ['-preset', 'ultrafast']
        if encoder == 'libx265':
            cmd += ['-x265-params', 'pools=none:frame-threads=1:log-level=error']
        if encoder == 'libaom-av1':
            cmd += ['-cpu-used', '8', '-row-mt', '0']
        if encoder == 'libvpx-vp9':
            cmd += ['-deadline', 'realtime', '-cpu-used', '8']
        run(cmd + [media])
        info = json.loads(run([ffprobe, '-v', 'error', '-show_streams', '-of', 'json', media]))
        if len(info['streams']) != 1 or info['streams'][0]['pix_fmt'] != pixel:
            raise RuntimeError('Encoded stream pixel format differs: ' + encoder + ' ' + pixel)
        run([ffmpeg, '-v', 'error', '-i', media, '-f', 'null', '-'])
        tests.append({'encoder': encoder, 'pixel_format': pixel, 'passed': True,
                      'codec_name': info['streams'][0]['codec_name']})
    for encoder, extension, codec in [('aac', 'm4a', 'aac'), ('libmp3lame', 'mp3', 'mp3'),
                                       ('libopus', 'opus', 'opus'), ('libvorbis', 'ogg', 'vorbis')]:
        media = output / (encoder + '.' + extension)
        run([ffmpeg, '-v', 'error', '-y', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000',
             '-t', '0.2', '-af', 'atrim=0:0.2,asetpts=PTS-STARTPTS,volume=0.5', '-c:a', encoder, media])
        info = json.loads(run([ffprobe, '-v', 'error', '-show_streams', '-of', 'json', media]))
        if info['streams'][0]['codec_name'] != codec:
            raise RuntimeError('Audio encoder did not produce the requested codec')
        run([ffmpeg, '-v', 'error', '-i', media, '-f', 'null', '-'])
        tests.append({'encoder': encoder, 'passed': True, 'codec_name': codec})
    for flag in ('encoders', 'decoders', 'filters', 'formats', 'protocols', 'hwaccels'):
        (output / (flag + '.txt')).write_text(run([ffmpeg, '-' + flag]), encoding='utf-8')
    run([ffmpeg, '-v', 'error', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=0.2',
         '-af', 'rubberband=tempo=1.1:pitch=1.05', '-f', 'null', '-'])
    tests.append({'filter': 'rubberband', 'passed': True})
    if cli_player:
        ffplay = tools / ('ffplay.exe' if windows else 'ffplay')
        player_version = run([ffplay, '-version'])
        if 'ffplay version 9.0.2' not in player_version:
            raise RuntimeError('Actual ffplay runtime cannot be loaded')
    result = {'passed': True, 'tests': tests, 'kernel': platform.release(),
              'machine': platform.machine(), 'glibc': os.confstr('CS_GNU_LIBC_VERSION') if platform.system() == 'Linux' else None,
              'version': version, 'scope': 'Real encode, demux, probe and decode of the listed software codecs and filter chains. GPU hardware APIs and full editor workloads are not covered.'}
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print('FFMPEG_SOFTWARE_MEDIA_PROBES_PASSED', json.dumps(result), flush=True)
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--sdk', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--timeout', type=int, default=300)
    a = p.parse_args()
    probe(a.sdk, a.output, a.timeout)
