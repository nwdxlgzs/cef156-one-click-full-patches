# FFmpeg 开发包制作

用户已选择接受 GPL、优先完整功能。目标共八个：Windows x64、x86、ARM64，Linux x64、ARM64，macOS ARM64、x64，以及 WebAssembly。

七个原生目标同时提供 Release 动态库、公共头文件、开发链接文件及 ffmpeg / ffprobe / ffplay 命令行程序。动态库接口适合逐帧解码、时间戳控制、滤镜处理、音视频同步和导出；命令行程序适合转码与批处理。两者来自同一套构建，不需要重复制作一套 FFmpeg。WASM 提供独立的静态开发库、JS/WASM 工具及浏览器示例。

FFmpeg 固定 9.0.2，源码提交 `946fcce07b6dcd0331c8cc609192aeff5e1924f8`。依赖配方固定 Microsoft vcpkg 提交 `ec48c11eae9448c8c6e7739d93e06fa2433aa95f`，使用 all-gpl 并补齐 drawtext、DVD、rubberband、ZeroMQ、OpenSSL 等功能。启用原生编解码器、封装器、解封装器、滤镜和协议；各平台的硬件接口按实际可编译范围记录，编译成功不代表已有对应 GPU 实测。

GPL 构建不启用使 FFmpeg 标记为 nonfree / unredistributable 的组件。AAC 使用 FFmpeg 原生实现。外部 x264 / x265 与 CEF 内部的媒体实现分别构建，不替换 CEF 的库。

Linux 复用已经核实的旧 glibc sysroot，macOS 复用已核实的 Apple SDK 和 LLVM 交叉工具链。Windows 使用独立的 LLVM-MinGW 工具链。Linux 4.9、Windows 旧系统和 Mac 实机支持必须分别用运行或导入符号检查证明，不凭配置选项认定通过。

服务器目录：`/home/ubuntu/ffmpeg-build`。下载一次完整成品到本地后，在本地完成精简和压缩；不额外下载服务器精简副本。每个目标完成归档与核验后再回收构建中间文件，保留源码锁、配置、功能清单、许可证和验证记录。

WebAssembly 单独使用固定的 Emscripten 7.0.0 工具链，提供多线程静态开发库、JS/WASM 模块及浏览器调用示例。FFmpeg 9 的源码明确声明 `ffmpeg_deps="avcodec avfilter avformat threads"`，因此不制作单线程 CLI 回退。尽量启用软件编解码、字幕和滤镜；原生 GPU 接口、原始 TCP/UDP 网络协议和桌面 ffplay 窗口按浏览器环境明确记录差异。运行需要 SharedArrayBuffer 和跨源隔离响应头。

当前状态以服务器 state、logs 和实际成品为准。本文件记录构建要求，不表示八个目标已经完成。
