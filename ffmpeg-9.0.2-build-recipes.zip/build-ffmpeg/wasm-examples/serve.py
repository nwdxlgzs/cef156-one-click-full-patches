#!/usr/bin/env python3
"""Serve the SDK locally with the headers required for WASM pthreads."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, '.wasm': 'application/wasm', '.js': 'text/javascript'}

    def end_headers(self):
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Embedder-Policy', 'require-corp')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        super().end_headers()


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--port', type=int, default=8080)
    a = p.parse_args()
    root = Path(__file__).resolve().parent.parent
    print('Open http://localhost:' + str(a.port) + '/examples/', flush=True)
    ThreadingHTTPServer(('127.0.0.1', a.port), partial(Handler, directory=str(root))).serve_forever()
