// Run each CLI invocation in a fresh WASM instance. Arguments with absolute
// file paths are copied between the host filesystem and the WASM virtual FS.
const fs = require('node:fs');
const path = require('node:path');
const [modulePath, ...originalArgs] = process.argv.slice(2);
if (!modulePath) throw new Error('Usage: node node-runner.cjs <ffmpeg.js|ffprobe.js> <arguments>');
(async () => {
  const factory = require(path.resolve(modulePath));
  const module = await factory({
    print: text => process.stdout.write(text + '\n'),
    printErr: text => process.stderr.write(text + '\n'),
  });
  const outputs = new Map();
  const paths = new Map();
  const args = originalArgs.map(arg => {
    if (!path.isAbsolute(arg)) return arg;
    if (!paths.has(arg)) paths.set(arg, '/file-' + paths.size + '-' + path.basename(arg));
    const target = paths.get(arg);
    if (fs.existsSync(arg) && fs.statSync(arg).isFile()) {
      module.FS.writeFile(target, fs.readFileSync(arg));
    } else {
      outputs.set(target, arg);
    }
    return target;
  });
  let status = 0;
  try {
    const result = module.callMain(args);
    if (typeof result === 'number') status = result;
  } catch (error) {
    if (typeof error.status === 'number') status = error.status;
    else throw error;
  }
  for (const [virtual, host] of outputs) {
    if (module.FS.analyzePath(virtual).exists) fs.writeFileSync(host, module.FS.readFile(virtual));
  }
  // End the disposable process after all virtual output files have been copied.
  process.stdout.write('', () => process.stderr.write('', () => process.exit(status)));
})().catch(error => { console.error(error); process.exit(1); });
