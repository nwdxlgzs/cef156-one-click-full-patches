// Emscripten 7 restarts this worker's URL for its pthread workers.
// Those workers must load the generated module before receiving CMD_LOAD.
const configuredBase = new URL(new URL(self.location.href).searchParams.get('base') || '../threads/bin/', self.location.href).href;
if (self.name?.startsWith('em-pthread')) {
  importScripts(new URL('ffmpeg.js', configuredBase).href);
} else self.onmessage = async event => {
  const { base, args, files, outputs } = event.data;
  try {
    importScripts(new URL('ffmpeg.js', base).href);
    const module = await self.createFFmpeg({
      locateFile: name => new URL(name, base).href,
      print: text => self.postMessage({ log: text }),
      printErr: text => self.postMessage({ log: text }),
    });
    for (const file of files) module.FS.writeFile(file.name, new Uint8Array(file.data));
    let status = 0;
    try { status = module.callMain(args) || 0; }
    catch (error) {
      if (typeof error.status === 'number') status = error.status;
      else throw error;
    }
    if (status !== 0) throw new Error('FFmpeg exited with status ' + status);
    const results = outputs.map(name => ({ name, data: module.FS.readFile(name).slice().buffer }));
    self.postMessage({ done: true, results }, results.map(file => file.data));
  } catch (error) {
    self.postMessage({ error: String(error.stack || error) });
  }
};
