#include <stdio.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/avutil.h>

int main(int argc, char **argv) {
  printf("FFmpeg %s\n", av_version_info());
  printf("x264 encoder: %s\n", avcodec_find_encoder_by_name("libx264") ? "available" : "missing");
  printf("x265 encoder: %s\n", avcodec_find_encoder_by_name("libx265") ? "available" : "missing");
  if (argc < 2) {
    printf("Usage: media-info <input-media>\n");
    return 0;
  }
  AVFormatContext *input = NULL;
  int result = avformat_open_input(&input, argv[1], NULL, NULL);
  if (result >= 0) result = avformat_find_stream_info(input, NULL);
  if (result < 0) {
    char message[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(result, message, sizeof(message));
    fprintf(stderr, "Cannot inspect media: %s\n", message);
    avformat_close_input(&input);
    return 1;
  }
  for (unsigned int i = 0; i < input->nb_streams; ++i) {
    AVStream *stream = input->streams[i];
    const AVCodecParameters *codec = stream->codecpar;
    printf("stream %u: %s, time_base=%d/%d", i, avcodec_get_name(codec->codec_id),
           stream->time_base.num, stream->time_base.den);
    if (codec->codec_type == AVMEDIA_TYPE_VIDEO)
      printf(", %dx%d", codec->width, codec->height);
    if (codec->codec_type == AVMEDIA_TYPE_AUDIO)
      printf(", %d Hz, %d channels", codec->sample_rate, codec->ch_layout.nb_channels);
    putchar('\n');
  }
  avformat_close_input(&input);
  return 0;
}
