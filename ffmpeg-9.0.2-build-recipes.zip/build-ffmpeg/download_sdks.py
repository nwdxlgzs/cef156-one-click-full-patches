#!/usr/bin/env python3
"""Download each published full artifact once, resume SFTP and verify locally."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import subprocess
import time

TARGETS = ['linux-x64', 'windows-x64', 'windows-x86', 'windows-arm64',
           'linux-arm64', 'mac-arm64', 'mac-x64', 'wasm32']


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as f:
        for data in iter(lambda: f.read(8 * 1024 * 1024), b''):
            sha.update(data)
    return sha.hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--destination', type=Path, required=True)
    p.add_argument('--key', type=Path, required=True)
    p.add_argument('--host', default='ubuntu@81.68.82.48')
    p.add_argument('--interval', type=int, default=300)
    p.add_argument('--once', action='store_true')
    p.add_argument('--objcopy', type=Path, help='Create compact SDKs locally after each full download')
    a = p.parse_args()
    destination = a.destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    state = destination / 'DOWNLOAD-STATE.json'
    verified = {}
    if state.exists():
        verified = json.loads(state.read_text()).get('verified', {})
        for target, item in verified.items():
            path = destination / item['name']
            if not path.is_file() or digest(path) != item['sha256']:
                raise RuntimeError('A previously verified local SDK changed: ' + str(path))
            if a.objcopy:
                from compact_local import compact
                compact(path, destination / 'strip-lib', a.objcopy)
                if target in ('windows-x64', 'windows-x86'):
                    from validate_local_windows import validate
                    validate(destination / 'strip-lib' / path.name.removesuffix('.tar.zst'), target,
                             destination / 'validation' / target)
                elif target == 'wasm32':
                    from validate_browser_wasm import validate
                    validate(destination / 'strip-lib' / path.name.removesuffix('.tar.zst'), destination / 'validation/wasm32')

    def save(phase, **extra):
        value = {'phase': phase, 'expected_targets': TARGETS, 'verified': verified,
                 'updated_utc': dt.datetime.now(dt.timezone.utc).isoformat(), **extra}
        pending = state.with_suffix('.json.pending')
        pending.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
        pending.replace(state)
        index = {'expected_targets': TARGETS, 'locally_verified': verified,
                 'all_eight_complete': len(verified) == len(TARGETS),
                 'updated_utc': value['updated_utc']}
        (destination / 'SDK-INDEX.json').write_text(json.dumps(index, indent=2) + '\n', encoding='utf-8')

    while len(verified) < len(TARGETS):
        try:
            command = ("python3 - <<'PY'\nimport pathlib,json\n"
                       "p=pathlib.Path('/home/ubuntu/ffmpeg-build/state')\n"
                       "print(json.dumps({x.stem.removeprefix('archive-'):json.loads(x.read_text()) for x in p.glob('archive-*.json')}))\nPY\n")
            result = subprocess.run(['ssh.exe', '-i', str(a.key), '-o', 'BatchMode=yes',
                                     '-o', 'ConnectTimeout=15', '-o', 'ServerAliveInterval=20', a.host, 'bash -s'],
                                    input=command.encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            if result.returncode:
                raise RuntimeError(result.stderr.decode(errors='replace')[-1000:])
            records = json.loads(result.stdout.decode())
            for target in TARGETS:
                if target in verified or target not in records:
                    continue
                item = records[target]
                name = 'ffmpeg_9.0.2_' + target + '_release.tar.zst'
                remote = '/home/ubuntu/ffmpeg-build/archives/' + name
                if (not item.get('sdk_complete') or item.get('archive') != remote
                        or not item.get('modes_symlinks_frame_and_all_file_hashes_verified')
                        or len(item.get('archive_sha256', '')) != 64):
                    raise RuntimeError('Published archive receipt is incomplete: ' + target)
                expected = item['archive_sha256']
                final = destination / name
                if final.exists():
                    if final.stat().st_size != item['bytes'] or digest(final) != expected:
                        raise RuntimeError('Existing final artifact differs; preserve it: ' + str(final))
                else:
                    pending = final.with_suffix(final.suffix + '.partial')
                    save('downloading', current_target=target, expected_bytes=item['bytes'])
                    batch = 'reget "' + remote + '" "' + pending.as_posix() + '"\n'
                    print('RESUMABLE_FULL_SDK_DOWNLOAD', target, item['bytes'], flush=True)
                    subprocess.run(['sftp.exe', '-q', '-b', '-', '-i', str(a.key),
                                    '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
                                    '-o', 'ServerAliveInterval=20', a.host],
                                   input=batch.encode(), check=True)
                    if pending.stat().st_size != item['bytes'] or digest(pending) != expected:
                        raise RuntimeError('Downloaded artifact size or SHA256 differs; preserve partial for inspection')
                    pending.replace(final)
                final.with_name(final.name + '.sha256').write_text(expected + '  ' + final.name + '\n', encoding='ascii')
                local_receipt = {**item, 'local_download_verified': True,
                                 'local_path': str(final), 'local_sha256': expected}
                final.with_name(final.name + '.verified.json').write_text(json.dumps(local_receipt, indent=2) + '\n')
                print('LOCAL_FULL_FFMPEG_SDK_SHA256_VERIFIED', target, expected, flush=True)
                if a.objcopy:
                    from compact_local import compact
                    compact(final, destination / 'strip-lib', a.objcopy)
                    if target in ('windows-x64', 'windows-x86'):
                        from validate_local_windows import validate
                        validate(destination / 'strip-lib' / final.name.removesuffix('.tar.zst'), target,
                                 destination / 'validation' / target)
                    elif target == 'wasm32':
                        from validate_browser_wasm import validate
                        validate(destination / 'strip-lib' / final.name.removesuffix('.tar.zst'), destination / 'validation/wasm32')
                # Count a target only after its local compaction and applicable
                # runtime checks pass. A failed check then retries the existing
                # authenticated archive without paying for another download.
                verified[target] = {'name': name, 'bytes': item['bytes'], 'sha256': expected}
                save('waiting_for_remaining_archives')
            if a.once:
                break
            if len(verified) < len(TARGETS):
                save('waiting_for_remaining_archives')
                time.sleep(a.interval)
        except Exception as exc:
            save('retryable_transfer_or_connection_error', error=str(exc))
            print('DOWNLOAD_WAIT', str(exc), flush=True)
            if a.once:
                raise
            time.sleep(a.interval)
    if len(verified) == len(TARGETS):
        save('all_eight_full_sdk_archives_locally_verified')
        print('EIGHT_LOCAL_FFMPEG_RELEASE_SDKS_VERIFIED', flush=True)


if __name__ == '__main__':
    main()
