#!/usr/bin/env python3
"""Prepare the full threaded Emscripten ABI for the eighth SDK package."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

from prepare_vcpkg import VCPKG_REV, write

EMSDK_REV = '1693ce7359fc9694f198694f902a2cc061239b86'
EMSDK_VERSION = '7.0.0'
EMSDK_RELEASE = '6afbd83493d647051772d491124187d4e9a0cda9'

# These are actual software implementations, not platform hardware shims.
LIBRARIES = {
    'libaom': 'aom', 'libass': 'libass', 'libfreetype': 'freetype',
    'libharfbuzz': 'harfbuzz', 'fontconfig': 'fontconfig', 'libfribidi': 'fribidi',
    'libmodplug': 'libmodplug', 'libopenmpt': 'libopenmpt', 'libopenh264': 'openh264',
    'libilbc': 'libilbc', 'libmp3lame': 'mp3lame', 'libopenjpeg': 'openjpeg',
    'libopus': 'opus', 'libsnappy': 'snappy', 'libsoxr': 'soxr', 'libspeex': 'speex',
    'libtheora': 'libtheora', 'libtwolame': 'libtwolame', 'libvorbis': 'libvorbis',
    'libvpx': 'libvpx', 'libwebp': 'libwebp', 'libxml2': 'libxml2',
    'bzlib': 'bzip2', 'lzma': 'liblzma', 'zlib': 'zlib', 'libx264': 'x264',
    'libx265': 'x265', 'libdav1d': 'dav1d', 'librubberband': 'rubberband',
    'libjxl': 'libjxl', 'libzimg': 'zimg', 'libmysofa': 'libmysofa',
    'libaribcaption': 'libaribcaption', 'libvvenc': 'vvenc', 'libsvtav1': 'svt-av1',
    'libdvdnav': 'libdvdnav', 'libdvdread': 'libdvdread',
    'libtesseract': 'tesseract',
}


def prepare(root):
    sdk = root / 'toolchains/emsdk'
    actual = subprocess.check_output(['git', '-C', str(sdk), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != EMSDK_REV:
        raise RuntimeError('Emscripten SDK checkout does not match its lock')
    releases = json.loads((sdk / 'emscripten-releases-tags.json').read_text())
    if releases['releases'][EMSDK_VERSION] != EMSDK_RELEASE:
        raise RuntimeError('Emscripten release mapping changed')
    # Preserve the base overlay's native ABI and cached packages. WASM patches
    # below apply only to a separate overlay used by the WASM triplet.
    overlay = root / 'overlay-ports-wasm'
    overlay.mkdir(exist_ok=True)
    soxr = overlay / 'soxr'
    if not soxr.exists():
        shutil.copytree(root / 'vcpkg/ports/soxr', soxr)
    soxr_port = soxr / 'portfile.cmake'
    soxr_text = soxr_port.read_text()
    if '# MYCEF WASM retains scalar HQ/VHQ resamplers without x86 CPU instructions' not in soxr_text:
        soxr_text = soxr_text.replace('        -DBUILD_TESTS=OFF',
            '# MYCEF WASM retains scalar HQ/VHQ resamplers without x86 CPU instructions\n'
            '        -DWITH_CR32S=OFF\n        -DWITH_CR64S=OFF\n'
            '        -DWITH_CR32=ON\n        -DWITH_CR64=ON\n        -DBUILD_TESTS=OFF', 1)
        write(soxr_port, soxr_text)
    tesseract = overlay / 'tesseract'
    if not tesseract.exists():
        shutil.copytree(root / 'overlay-ports/tesseract', tesseract)
    tess_port = tesseract / 'portfile.cmake'
    tess_text = tess_port.read_text()
    if '# MYCEF Emscripten CMake processor alias is not a native x86 CPU' not in tess_text:
        tess_text = tess_text.replace('vcpkg_cmake_configure(', '''# MYCEF Emscripten CMake processor alias is not a native x86 CPU
vcpkg_replace_string("${SOURCE_PATH}/CMakeLists.txt"
    "if(CMAKE_SYSTEM_PROCESSOR MATCHES \\"x86|x86_64|AMD64|amd64|i386|i686\\")"
    "if(NOT EMSCRIPTEN AND CMAKE_SYSTEM_PROCESSOR MATCHES \\"x86|x86_64|AMD64|amd64|i386|i686\\")")

vcpkg_cmake_configure(''', 1)
        write(tess_port, tess_text)
    vvenc = overlay / 'vvenc'
    if not vvenc.exists():
        shutil.copytree(root / 'overlay-ports/vvenc', vvenc)
    vvenc_port = vvenc / 'portfile.cmake'
    vvenc_text = vvenc_port.read_text()
    if '# MYCEF VVenC WASM 64-bit comparison uses its existing SIMDe dependency' not in vvenc_text:
        vvenc_text = vvenc_text.replace('vcpkg_check_features(', '''# MYCEF VVenC WASM 64-bit comparison uses its existing SIMDe dependency
vcpkg_replace_string("${SOURCE_PATH}/source/Lib/CommonLib/x86/CommonDefX86.h"
    "#    include <simde/x86/sse4.1.h>"
    "#    include <simde/x86/sse4.1.h>\\n#    if REAL_TARGET_WASM\\n#      include <simde/x86/sse4.2.h>\\n#      define _mm_cmpgt_epi64 simde_mm_cmpgt_epi64\\n#    endif")

vcpkg_check_features(''', 1)
        write(vvenc_port, vvenc_text)
    zimg = overlay / 'zimg'
    if not zimg.exists():
        shutil.copytree(root / 'overlay-ports/zimg', zimg)
    zimg_port = zimg / 'portfile.cmake'
    zimg_text = zimg_port.read_text()
    if '# MYCEF zimg Autoconf must use the compiler target instead of the host CPU' not in zimg_text:
        zimg_text = zimg_text.replace('    AUTOCONFIG\n',
            '    AUTOCONFIG\n'
            '    # MYCEF zimg Autoconf must use the compiler target instead of the host CPU\n'
            '    OPTIONS "--host=wasm32-unknown-emscripten"\n', 1)
        write(zimg_port, zimg_text)
    vpx = overlay / 'libvpx'
    if not vpx.exists():
        shutil.copytree(root / 'overlay-ports/libvpx', vpx)
    vpx_port = vpx / 'portfile.cmake'
    vpx_text = vpx_port.read_text()
    if '# MYCEF libvpx objects must share the FFmpeg pthread/SIMD ABI' not in vpx_text:
        vpx_text = vpx_text.replace('    elseif(VCPKG_TARGET_IS_EMSCRIPTEN)', '''    elseif(VCPKG_TARGET_IS_EMSCRIPTEN)
        # MYCEF libvpx objects must share the FFmpeg pthread/SIMD ABI
        set(ENV{CFLAGS} "${VCPKG_DETECTED_CMAKE_C_FLAGS}")
        set(ENV{CXXFLAGS} "${VCPKG_DETECTED_CMAKE_CXX_FLAGS}")
        set(ENV{LDFLAGS} "${VCPKG_DETECTED_CMAKE_EXE_LINKER_FLAGS}")
        list(APPEND OPTIONS "--extra-cflags=${VCPKG_DETECTED_CMAKE_C_FLAGS}"
            "--extra-cxxflags=${VCPKG_DETECTED_CMAKE_CXX_FLAGS}" --enable-multithread)''', 1)
        write(vpx_port, vpx_text)
    if '# MYCEF remainder is below the 512-byte buffer and fits streamsize' not in vvenc_text:
        vvenc_text = vvenc_text.replace('vcpkg_check_features(', '''# MYCEF remainder is below the 512-byte buffer and fits streamsize
vcpkg_replace_string("${SOURCE_PATH}/source/Lib/apputils/YuvFileIO.h"
    "inStream.read( buf, offset_mod_bufsize );"
    "inStream.read( buf, static_cast<std::streamsize>(offset_mod_bufsize) );")

vcpkg_check_features(''', 1)
        write(vvenc_port, vvenc_text)
    if '# MYCEF preserve Emscripten CLI JavaScript and its WASM companion' not in tess_text:
        tess_text = tess_text.replace('vcpkg_copy_tools(TOOL_NAMES tesseract AUTO_CLEAN)', '''# MYCEF preserve Emscripten CLI JavaScript and its WASM companion
file(MAKE_DIRECTORY "${CURRENT_PACKAGES_DIR}/tools/tesseract")
file(GLOB _mycef_tesseract_tools "${CURRENT_PACKAGES_DIR}/bin/*")
file(COPY ${_mycef_tesseract_tools} DESTINATION "${CURRENT_PACKAGES_DIR}/tools/tesseract")
file(REMOVE_RECURSE "${CURRENT_PACKAGES_DIR}/bin" "${CURRENT_PACKAGES_DIR}/debug/bin")''')
        write(tess_port, tess_text)
    aom = overlay / 'aom'
    if not aom.exists():
        shutil.copytree(root / 'vcpkg/ports/aom', aom)
    aom_port = aom / 'portfile.cmake'
    aom_text = aom_port.read_text()
    if '# MYCEF AOM portable WASM software implementation' not in aom_text:
        aom_text = aom_text.replace('vcpkg_cmake_configure(',
                                    '# MYCEF AOM portable WASM software implementation\n'
                                    'set(aom_target_cpu "-DAOM_TARGET_CPU=generic")\n\nvcpkg_cmake_configure(', 1)
        write(aom_port, aom_text)
    dvdcss = overlay / 'libdvdcss'
    if not dvdcss.exists():
        shutil.copytree(root / 'vcpkg/ports/libdvdcss', dvdcss)
    dvd_port = dvdcss / 'portfile.cmake'
    dvd_text = dvd_port.read_text()
    if '# MYCEF browser virtual files have no physical DVD drive ioctl' not in dvd_text:
        dvd_text = dvd_text.replace('vcpkg_configure_meson(', '''# MYCEF browser virtual files have no physical DVD drive ioctl
vcpkg_replace_string("${SOURCE_PATH}/src/ioctl.c"
    "#   error \\"DVD ioctls are unavailable on this system\\""
    "#   if defined(__EMSCRIPTEN__)\\n    return -1; /* Physical DVD device ioctls are unavailable in a browser. */\\n#   else\\n#   error \\"DVD ioctls are unavailable on this system\\"\\n#   endif")

vcpkg_configure_meson(''', 1)
        write(dvd_port, dvd_text)
    dvdread = overlay / 'libdvdread'
    if not dvdread.exists():
        shutil.copytree(root / 'vcpkg/ports/libdvdread', dvdread)
    read_port = dvdread / 'portfile.cmake'
    read_text = read_port.read_text()
    if '# MYCEF use portable endian conversion on WebAssembly' not in read_text:
        read_text = read_text.replace('vcpkg_configure_make(', '''# MYCEF use portable endian conversion on WebAssembly
vcpkg_replace_string("${SOURCE_PATH}/src/bswap.h" "#elif defined(__FreeBSD__) ||" "#elif defined(__EMSCRIPTEN__) || defined(__FreeBSD__) ||")

vcpkg_configure_make(''', 1)
        write(read_port, read_text)
    mysofa = overlay / 'libmysofa'
    if not mysofa.exists():
        shutil.copytree(root / 'vcpkg/ports/libmysofa', mysofa)
    sofa_port = mysofa / 'portfile.cmake'
    sofa_text = sofa_port.read_text()
    if '# MYCEF Emscripten provides the standard endian.h conversions' not in sofa_text:
        sofa_text = sofa_text.replace('vcpkg_cmake_configure(', '''# MYCEF Emscripten provides the standard endian.h conversions
vcpkg_replace_string("${SOURCE_PATH}/src/hrtf/portable_endian.h" "#if defined(__linux__) ||" "#if defined(__EMSCRIPTEN__) || defined(__linux__) ||")

vcpkg_cmake_configure(''', 1)
        write(sofa_port, sofa_text)
    lame = overlay / 'mp3lame'
    if not lame.exists():
        shutil.copytree(root / 'overlay-ports/mp3lame', lame)
    config_sub = Path('/usr/share/misc/config.sub')
    shutil.copy2(config_sub, lame / 'config.sub')
    x264 = overlay / 'x264'
    if not x264.exists():
        shutil.copytree(root / 'vcpkg/ports/x264', x264)
    shutil.copy2(config_sub, x264 / 'config.sub')
    x264_port = x264 / 'portfile.cmake'
    x264_text = x264_port.read_text()
    if '# MYCEF x264 portable Emscripten system and current config.sub' not in x264_text:
        x264_text = x264_text.replace('vcpkg_make_configure(', '''# MYCEF x264 portable Emscripten system and current config.sub
file(COPY_FILE "${CMAKE_CURRENT_LIST_DIR}/config.sub" "${SOURCE_PATH}/config.sub" ONLY_IF_DIFFERENT)
vcpkg_replace_string("${SOURCE_PATH}/configure" "case $host_os in"
    "case $host_os in\\n    emscripten*)\\n        SYS=EMSCRIPTEN\\n        libm=-lm\\n        define HAVE_MALLOC_H\\n        ;;")
list(APPEND OPTIONS --disable-opencl)

vcpkg_make_configure(''', 1)
        write(x264_port, x264_text)
    lame_port = lame / 'portfile.cmake'
    lame_text = lame_port.read_text()
    marker = '# MYCEF refresh config.sub to recognize the actual Emscripten target'
    if marker not in lame_text:
        lame_text = lame_text.replace('vcpkg_make_configure(', marker + '''
file(COPY_FILE "${CMAKE_CURRENT_LIST_DIR}/config.sub" "${SOURCE_PATH}/config.sub" ONLY_IF_DIFFERENT)
vcpkg_make_configure(''', 1)
        write(lame_port, lame_text)
    openh264 = overlay / 'openh264'
    if not openh264.exists():
        shutil.copytree(root / 'vcpkg/ports/openh264', openh264)
    open_port = openh264 / 'portfile.cmake'
    open_text = open_port.read_text()
    if '# MYCEF select OpenH264 portable pthread software primitives for WASM' not in open_text:
        open_text = open_text.replace('vcpkg_configure_meson(', '''# MYCEF select OpenH264 portable pthread software primitives for WASM
vcpkg_replace_string("${SOURCE_PATH}/meson.build" "'openbsd'].contains(system)" "'openbsd', 'emscripten'].contains(system)")
vcpkg_replace_string("${SOURCE_PATH}/meson.build" "elif cpu_family == 'ppc'" "elif cpu_family == 'wasm32'\\n    asm_format = 'elf' # no native assembler sources selected\\n  elif cpu_family == 'ppc'")

vcpkg_configure_meson(''', 1)
        write(open_port, open_text)
    if '# MYCEF enable portable C++ OpenH264 implementations in each codec subdir' not in open_text:
        open_text = open_text.replace('vcpkg_configure_meson(', '''# MYCEF enable portable C++ OpenH264 implementations in each codec subdir
foreach(_component common encoder decoder processing)
    vcpkg_replace_string("${SOURCE_PATH}/codec/${_component}/meson.build" "elif cpu_family == 'riscv64'" "elif cpu_family in ['riscv64', 'wasm32']")
endforeach()

vcpkg_configure_meson(''', 1)
        write(open_port, open_text)
    write(root / 'state/wasm-config-sub.json', json.dumps({
        'source': str(config_sub), 'sha256': hashlib.sha256(config_sub.read_bytes()).hexdigest(),
        'scope': 'Host distribution config.sub used only to recognize the compiler target triplet; copied into the build recipe.'}, indent=2) + '\n')
    x265 = overlay / 'x265'
    if not x265.exists():
        shutil.copytree(root / 'overlay-ports/x265', x265)
    port = x265 / 'portfile.cmake'
    text = port.read_text()
    marker = '# MYCEF WebAssembly has no native x86/ARM assembler'
    if marker not in text:
        text = marker + '\nlist(APPEND OPTIONS "-DENABLE_ASSEMBLY=OFF")\n' + text
        write(port, text)
    marker = '# MYCEF x265 actual WASM architecture and post-feature assembly option'
    if marker not in text:
        text = text.replace('vcpkg_cmake_configure(', marker + '''
vcpkg_replace_string("${SOURCE_PATH}/source/CMakeLists.txt"
    "set(X86_ALIASES"
    "if(EMSCRIPTEN)\\n    set(SYSPROC wasm32)\\nendif()\\nset(X86_ALIASES")
list(APPEND OPTIONS "-DENABLE_ASSEMBLY=OFF")
vcpkg_cmake_configure(''', 1)
        write(port, text)
    dependencies = []
    for name in sorted(set(LIBRARIES.values())):
        dependency = {'name': name}
        if name == 'x264':
            dependency.update(**{'default-features': False, 'features': ['gpl', 'chroma-format-all']})
        elif name == 'libvpx':
            dependency['features'] = ['highbitdepth']
        elif name == 'tesseract':
            # The browser supplies URL inputs with fetch; OCR and archive
            # model loading remain enabled without native libcurl sockets.
            dependency.update(**{'default-features': False, 'features': ['libarchive']})
        dependencies.append(dependency)
    variants = {}
    for mode in ('threads',):
        triplet = 'wasm32-mycef-' + mode
        flags = '-msimd128' + (' -pthread' if mode == 'threads' else '')
        content = f'''set(VCPKG_TARGET_ARCHITECTURE wasm32)
set(VCPKG_CRT_LINKAGE dynamic)
set(VCPKG_LIBRARY_LINKAGE static)
set(VCPKG_BUILD_TYPE release)
set(VCPKG_CMAKE_SYSTEM_NAME Emscripten)
set(VCPKG_ENV_PASSTHROUGH_UNTRACKED EMSDK EMSCRIPTEN_ROOT EM_CONFIG PATH)
set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "${{VCPKG_ROOT_DIR}}/scripts/toolchains/emscripten.cmake")
set(VCPKG_C_FLAGS "{flags}")
set(VCPKG_CXX_FLAGS "{flags}")
set(VCPKG_LINKER_FLAGS "{flags}")
'''
        write(root / 'triplets' / (triplet + '.cmake'), content)
        manifest = {'name': 'mycef-ffmpeg-wasm-' + mode, 'version-string': '9.0.2',
                    'builtin-baseline': VCPKG_REV, 'dependencies': dependencies}
        write(root / 'manifests' / ('wasm-' + mode) / 'vcpkg.json', json.dumps(manifest, indent=2) + '\n')
        variants[mode] = {'triplet': triplet, 'flags': flags}
    record = {'target': 'wasm32', 'package_count': 1, 'variants': variants,
              'emsdk_revision': EMSDK_REV, 'emscripten_version': EMSDK_VERSION,
              'emscripten_release': EMSDK_RELEASE, 'software_dependencies': LIBRARIES,
              'platform_differences': {
                  'native_gpu_apis': 'NVENC/QSV/AMF/VAAPI/VideoToolbox/OpenCL/Vulkan cannot be linked as native browser device drivers.',
                  'network': 'Browser fetch supplies files to MEMFS; native TCP/UDP/SRT/SSH/ZeroMQ protocols are not exposed as browser sockets.',
                  'playback': 'Browser HTML media/canvas playback replaces the native ffplay SDL window.',
                  'dvd': 'DVD files/navigation and software libraries are requested; physical optical-drive ioctl/authentication calls explicitly return unsupported in the browser.',
                  'threads': 'The complete FFmpeg 9 CLI requires threads (ffmpeg_deps includes threads). This package requires crossOriginIsolated and SharedArrayBuffer; it does not provide a single-thread CLI fallback.',
                  'dynamic_libraries': 'WASM static archives and JS/WASM modules replace OS DLL/so/dylib loading.'},
              'sdk_complete': False,
              'scope': 'Prepared source/toolchain/feature requirements only; no successful compilation claimed.'}
    write(root / 'state/prepared-wasm.json', json.dumps(record, indent=2) + '\n')
    return record


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(prepare(a.root.resolve()), indent=2))
