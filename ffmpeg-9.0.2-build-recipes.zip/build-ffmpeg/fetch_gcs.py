#!/usr/bin/env python3
"""Resume parallel GCS ranges, pin object generation and verify upstream CRC32C."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import time
import urllib.parse
import urllib.request

import google_crc32c

p = argparse.ArgumentParser()
p.add_argument('--object', required=True)
p.add_argument('--destination', type=Path, required=True)
p.add_argument('--jobs', type=int, default=24)
a = p.parse_args()
metadata_url = 'https://storage.googleapis.com/storage/v1/b/webassembly/o/' + urllib.parse.quote(a.object, safe='')
metadata = json.load(urllib.request.urlopen(metadata_url, timeout=45))
if metadata.get('name') != a.object or not metadata.get('crc32c'):
    raise RuntimeError('Missing official object identity/checksum')
length = int(metadata['size'])
url = 'https://storage.googleapis.com/webassembly/' + a.object + '?generation=' + metadata['generation']
final = a.destination.resolve()
final.parent.mkdir(parents=True, exist_ok=True)
metadata_file = final.with_suffix(final.suffix + '.upstream.json')
metadata_file.write_text(json.dumps(metadata, indent=2) + '\n')
parts = final.with_name(final.name + '.ranges')
parts.mkdir(exist_ok=True)
block = 1024 * 1024
count = (length + block - 1) // block
# An interrupted emsdk download is useful input, but never considered final.
if final.exists() and final.stat().st_size != length:
    partial = final.with_suffix(final.suffix + '.partial-original')
    if partial.exists():
        partial = final.with_suffix(final.suffix + '.partial-retry-' + str(time.time_ns()))
    final.rename(partial)
    with partial.open('rb') as f:
        for i in range(partial.stat().st_size // block):
            path = parts / str(i)
            data = f.read(block)
            if not path.exists():
                path.write_bytes(data)


def fetch(i):
    start, size = i * block, min(block, length - i * block)
    part = parts / str(i)
    if part.is_file() and part.stat().st_size == size:
        return
    for attempt in range(5):
        pending = part.with_suffix('.pending')
        header = part.with_suffix('.headers')
        result = subprocess.run(['curl', '-fsS', '--connect-timeout', '10', '--max-time', '90',
            '--max-filesize', str(size), '--range', f'{start}-{start + size - 1}',
            '-D', str(header), '-o', str(pending), '-w', '%{http_code}', url],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        headers = header.read_text(errors='replace').lower() if header.exists() else ''
        if (result.returncode == 0 and result.stdout.strip() == '206' and pending.stat().st_size == size
                and f'content-range: bytes {start}-{start+size-1}/{length}' in headers):
            pending.rename(part)
            header.unlink()
            if i % 16 == 0:
                print('RANGE_VERIFIED', i, 'of', count, flush=True)
            return
        time.sleep(attempt + 1)
    raise RuntimeError('Range failed: ' + str(i))


if not final.exists():
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        list(pool.map(fetch, range(count)))
    assembling = final.with_suffix(final.suffix + '.assembling')
    with assembling.open('wb') as f:
        for i in range(count):
            f.write((parts / str(i)).read_bytes())
else:
    assembling = final
sha = hashlib.sha256()
crc = google_crc32c.Checksum()
with assembling.open('rb') as f:
    for data in iter(lambda: f.read(8 * 1024 * 1024), b''):
        sha.update(data)
        crc.update(data)
if assembling.stat().st_size != length or base64.b64encode(crc.digest()).decode() != metadata['crc32c']:
    raise RuntimeError('Official generation/size/CRC32C verification failed; retain parts')
if assembling != final:
    assembling.rename(final)
receipt = {'file': str(final), 'size': length, 'sha256': sha.hexdigest(),
           'upstream_crc32c': metadata['crc32c'], 'upstream_generation': metadata['generation'],
           'upstream_metadata_url': metadata_url,
           'scope': 'Pinned official HTTPS object generation and official CRC32C checked; SHA256 is the computed local reproducibility digest.'}
final.with_suffix(final.suffix + '.verified.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('OFFICIAL_GCS_OBJECT_VERIFIED', json.dumps(receipt), flush=True)
