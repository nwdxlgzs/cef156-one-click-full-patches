#!/usr/bin/env python3
"""Fetch a public dependency through a mirror, accepting only its pinned SHA512."""
import hashlib
from pathlib import Path
import re
import subprocess
import sys
from urllib.parse import urlsplit


def fetch(url, expected, destination):
    if not re.fullmatch('[0-9a-fA-F]{128}', expected):
        raise RuntimeError('A pinned upstream SHA512 is required')
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_file() and hashlib.sha512(destination.read_bytes()).hexdigest() == expected.lower():
        return
    candidates = ['https://ghfast.top/' + url, url] if url.startswith('https://github.com/') else [url]
    if url.startswith('https://raw.githubusercontent.com/'):
        candidates.insert(0, 'https://ghfast.top/' + url)
    filename = Path(urlsplit(url).path).name
    if filename.startswith('bzip2-') and filename.endswith('.tar.gz'):
        version = filename.removeprefix('bzip2-').removesuffix('.tar.gz')
        candidates = ['https://mirrors.huaweicloud.com/debian/pool/main/b/bzip2/bzip2_' + version + '.orig.tar.gz',
                      'https://distfiles.macports.org/bzip2/' + filename] + candidates
    if filename.startswith('fftw-') and filename.endswith('.tar.gz'):
        version = filename.removeprefix('fftw-').removesuffix('.tar.gz')
        candidates = ['https://mirrors.huaweicloud.com/debian/pool/main/f/fftw3/fftw3_' + version + '.orig.tar.gz',
                      'https://distfiles.macports.org/fftw-3/' + filename,
                      'https://fftw.org/' + filename] + candidates
    if url.startswith('https://ftp.gnu.org/gnu/'):
        candidates.insert(0, url.replace('https://ftp.gnu.org/gnu/', 'https://mirrors.huaweicloud.com/gnu/'))
    temporary = destination.with_name(destination.name + '.mirror.pending')
    logdir = Path(__file__).resolve().parent / 'logs/assets'
    logdir.mkdir(parents=True, exist_ok=True)
    for candidate in candidates:
        with (logdir / (expected[:20] + '.log')).open('a') as log:
            result = subprocess.run(['curl', '-fL', '--retry', '3', '--retry-all-errors',
                '--connect-timeout', '10', '--max-time', '600', '--speed-limit', '1024',
                '--speed-time', '90', '-o', str(temporary), candidate], stdout=log, stderr=log)
        if result.returncode:
            continue
        if hashlib.sha512(temporary.read_bytes()).hexdigest() != expected.lower():
            raise RuntimeError('Dependency SHA512 mismatch; preserve downloaded bytes for inspection')
        temporary.replace(destination)
        print('PINNED_ASSET_VERIFIED', destination.name, flush=True)
        return
    raise RuntimeError('Dependency mirror and upstream downloads failed')


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit('Usage: asset_mirror.py URL SHA512 DESTINATION')
    fetch(*sys.argv[1:])
