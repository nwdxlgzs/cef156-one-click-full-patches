#!/usr/bin/env python3
"""Compile a real MSVC consumer and run the downloaded native Windows SDK."""
import argparse
import json
import os
from pathlib import Path
import subprocess

from package_ffmpeg import digest
from probe_media import probe


def validate(sdk, target, work):
    sdk, work = Path(sdk).resolve(), Path(work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    if target not in ('windows-x64', 'windows-x86') or os.name != 'nt':
        raise RuntimeError('Native MSVC/runtime validation requires an x64 Windows host and x86/x64 SDK')
    state = work / 'runtime.json'
    identity = {path.name: digest(path) for path in sorted((sdk / 'bin').iterdir()) if path.is_file()}
    if state.exists():
        prior = json.loads(state.read_text())
        if prior.get('passed') and prior['runtime_inputs'] == identity:
            return prior
        raise RuntimeError('Existing Windows verification uses different runtime inputs')
    cmake = Path('D:/Program Files/CMake/bin/cmake.exe')
    if not cmake.is_file():
        raise RuntimeError('Configured local CMake is missing')
    build = work / 'msvc-c-api'
    subprocess.run([str(cmake), '-S', str(sdk / 'examples'), '-B', str(build),
                    '-G', 'Visual Studio 17 2022', '-A', 'x64' if target.endswith('x64') else 'Win32'], check=True)
    subprocess.run([str(cmake), '--build', str(build), '--config', 'Release', '-j', '4'], check=True)
    binary = build / 'Release/media-info.exe'
    env = dict(os.environ)
    env['PATH'] = str(sdk / 'bin') + os.pathsep + env['PATH']
    demo = subprocess.check_output([str(binary)], env=env, text=True, timeout=30)
    if 'FFmpeg 9.0.2' not in demo or 'x264 encoder: available' not in demo or 'x265 encoder: available' not in demo:
        raise RuntimeError('MSVC consumer failed to load the downloaded shared SDK encoders')
    media = probe(sdk, work / 'media', timeout=300)
    result = subprocess.check_output([str(binary), str(work / 'media/libx265-yuv420p10le.mkv')],
                                     env=env, text=True, timeout=30)
    if 'hevc' not in result:
        raise RuntimeError('MSVC consumer did not inspect the actual encoded file')
    record = {'target': target, 'passed': True, 'runtime_verified': True, 'runtime_inputs': identity,
              'c_api_msvc_sha256': digest(binary), 'c_api_output': demo + result, 'media': media,
              'scope': 'Actual downloaded SDK DLLs, tools and independent MSVC C API consumer ran on this Windows x64 development computer; x86 tools ran through Windows WOW64. This does not certify Windows 7 or GPU execution.'}
    state.write_text(json.dumps(record, indent=2) + '\n')
    return record


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--sdk', type=Path, required=True)
    p.add_argument('--target', required=True)
    p.add_argument('--work', type=Path, required=True)
    a = p.parse_args()
    print('LOCAL_WINDOWS_MSCV_AND_MEDIA_PASSED', json.dumps(validate(a.sdk, a.target, a.work)), flush=True)
