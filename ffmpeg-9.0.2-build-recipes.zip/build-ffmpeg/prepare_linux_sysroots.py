#!/usr/bin/env python3
"""Use authenticated glibc 2.28 headers and link libraries for Linux builds."""
import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def normalize_links(root):
    changes = []
    for path in root.rglob('*'):
        if not path.is_symlink():
            continue
        link = os.readlink(path)
        if link.startswith('/'):
            destination = root / link.lstrip('/')
            relative = os.path.relpath(destination, path.parent)
            path.unlink()
            path.symlink_to(relative)
            changes.append({'path': path.relative_to(root).as_posix(), 'original': link, 'relative': relative})
    return changes


def adapt_gcc_headers(root):
    changes = []
    for path in (root / 'usr/include').rglob('bits/c++config.h'):
        original = path.read_text()
        text = original
        # GCC 10's pre-generated configure header came from glibc 2.31.
        # Select its built-in pthread timed-lock fallback for a 2.28 sysroot.
        for macro in ('_GLIBCXX_USE_PTHREAD_MUTEX_CLOCKLOCK', '_GLIBCXX_USE_PTHREAD_RWLOCK_CLOCKLOCK',
                      '_GLIBCXX_USE_PTHREAD_COND_CLOCKWAIT'):
            text = re.sub(r'^#define ' + macro + r' 1$', '/* #undef ' + macro + ' */', text, flags=re.M)
        if text != original:
            path.write_text(text)
            changes.append({'path': path.relative_to(root).as_posix(),
                            'original_sha256': hashlib.sha256(original.encode()).hexdigest(),
                            'adapted_sha256': digest(path),
                            'reason': 'Use GCC-provided timed pthread fallbacks available in glibc 2.28.'})
    return changes


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    a = p.parse_args()
    root, cef = a.root.resolve(), a.cef_root.resolve()
    download = root / 'downloads/buster-sysroot'
    download.mkdir(parents=True, exist_ok=True)
    base = 'https://mirrors.huaweicloud.com/debian-archive/debian/'

    def fetch(url, path, sha=None):
        if path.exists():
            if sha and digest(path) != sha:
                raise RuntimeError('Cached Debian artifact differs')
            return
        pending = path.with_suffix(path.suffix + '.pending')
        subprocess.run(['curl', '-fsSL', '--connect-timeout', '15', '--max-time', '300',
                        '--retry', '4', '-o', str(pending), url], check=True)
        if sha and digest(pending) != sha:
            raise RuntimeError('Signed Debian artifact SHA256 differs')
        pending.rename(path)
    release, signature = download / 'Release', download / 'Release.gpg'
    for path in (release, signature):
        fetch(base + 'dists/buster/' + path.name, path)
    subprocess.run(['gpgv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg',
                    str(signature), str(release)], check=True)
    text = release.read_text()
    if not re.search(r'^Codename: buster$', text, re.M):
        raise RuntimeError('Unexpected signed Debian distribution')
    sums = text.split('\nSHA256:\n')[1].split('\nSHA512:')[0]
    rows = {}
    for cpu, arch in [('x64', 'amd64'), ('arm64', 'arm64')]:
        relative = 'main/binary-' + arch + '/Packages.xz'
        match = re.search(r'^ ([a-f0-9]{64})\s+(\d+)\s+' + re.escape(relative) + '$', sums, re.M)
        if not match:
            raise RuntimeError('Missing signed package index')
        index = download / ('Packages-' + arch + '.xz')
        fetch(base + 'dists/buster/' + relative, index, match[1])
        if index.stat().st_size != int(match[2]):
            raise RuntimeError('Package index length differs')
        packages = {}
        for block in lzma.decompress(index.read_bytes()).decode().split('\n\n'):
            values = dict(line.split(': ', 1) for line in block.splitlines()
                          if ': ' in line and not line.startswith(' '))
            if values.get('Package') in ('libc6', 'libc6-dev', 'linux-libc-dev'):
                packages[values['Package']] = values
        if len(packages) != 3 or any(not packages[n]['Version'].startswith('2.28-') for n in ('libc6', 'libc6-dev')):
            raise RuntimeError('Unexpected glibc package versions')
        target = root / 'sysroots' / ('linux-' + cpu + '-glibc228')
        marker = target / 'MYCEF_SYSROOT.json'
        if marker.exists():
            prior = json.loads(marker.read_text())
            if prior['packages'] != packages:
                raise RuntimeError('Existing sysroot provenance differs')
            changes = normalize_links(target)
            if changes:
                prior.setdefault('normalized_symlinks', []).extend(changes)
            adjustments = adapt_gcc_headers(target)
            if adjustments:
                prior.setdefault('libstdcxx_header_adjustments', []).extend(adjustments)
            marker.write_text(json.dumps(prior, indent=2) + '\n')
            rows[cpu] = prior
            continue
        if target.exists():
            raise RuntimeError('Incomplete sysroot exists; preserve for inspection')
        source = cef / 'chromium/src/build/linux' / ('debian_bullseye_' + arch + '-sysroot')
        shutil.copytree(source, target, symlinks=True)
        for name in ('libc6', 'libc6-dev', 'linux-libc-dev'):
            item = packages[name]
            archive = download / Path(item['Filename']).name
            fetch(base + item['Filename'], archive, item['SHA256'])
            if archive.stat().st_size != int(item['Size']):
                raise RuntimeError('Debian package length differs')
            subprocess.run(['dpkg-deb', '-x', str(archive), str(target)], check=True)
        row = {'cpu': cpu, 'directory': str(target), 'glibc': '2.28', 'packages': packages,
               'normalized_symlinks': normalize_links(target),
               'libstdcxx_header_adjustments': adapt_gcc_headers(target),
               'debian_release_sha256': digest(release), 'packages_index_sha256': match[1],
               'scope': 'Signed glibc headers/link libraries; final required symbol versions and Linux 4.9 execution remain separate checks.'}
        marker.write_text(json.dumps(row, indent=2) + '\n')
        rows[cpu] = row
        print('GLIBC228_SYSROOT_PREPARED', cpu, flush=True)
    (root / 'state/linux-sysroots.json').write_text(json.dumps(rows, indent=2) + '\n')


if __name__ == '__main__':
    main()
