#!/usr/bin/env python3
"""Check the page hashes of an embedded ad-hoc Mach-O CodeDirectory."""
import hashlib
import struct


def verify(path, signature):
    if not signature:
        return {'embedded_signature': False, 'scope': 'No embedded signature; no Apple trust claim.'}
    with path.open('rb') as f:
        f.seek(signature['offset'])
        blob = f.read(signature['bytes'])
        magic, size, count = struct.unpack_from('>3I', blob)
        if magic != 0xFADE0CC0 or size > len(blob) or 12 + count * 8 > size:
            raise RuntimeError('Invalid Mach-O signature superblob: ' + str(path))
        directories = []
        for index in range(count):
            slot, offset = struct.unpack_from('>2I', blob, 12 + index * 8)
            if offset + 8 > size:
                raise RuntimeError('Code signature subblob offset exceeds its container')
            child_magic, child_size = struct.unpack_from('>2I', blob, offset)
            if offset + child_size > size:
                raise RuntimeError('Code signature subblob length exceeds its container')
            if child_magic != 0xFADE0C02:
                continue
            cd = blob[offset:offset + child_size]
            version, flags, hash_offset, ident_offset, special, code_slots, code_limit = struct.unpack_from('>7I', cd, 8)
            hash_size, hash_type, platform, page_shift = struct.unpack_from('>4B', cd, 36)
            if version >= 0x20300:
                extended_limit = struct.unpack_from('>Q', cd, 56)[0]
                code_limit = extended_limit or code_limit
            if (not flags & 2 or code_limit > signature['offset'] or page_shift > 24
                    or hash_offset + code_slots * hash_size > len(cd)):
                raise RuntimeError('Unsupported or invalid ad-hoc CodeDirectory')
            algorithms = {1: 'sha1', 2: 'sha256', 3: 'sha256', 4: 'sha384'}
            if hash_type not in algorithms:
                raise RuntimeError('Unsupported CodeDirectory page hash algorithm')
            page_bytes = (1 << page_shift) if page_shift else code_limit
            if code_slots != (code_limit + page_bytes - 1) // page_bytes:
                raise RuntimeError('CodeDirectory hash-slot count differs from actual code length')
            for index in range(code_slots):
                f.seek(index * page_bytes)
                data = f.read(min(page_bytes, code_limit - index * page_bytes))
                actual = hashlib.new(algorithms[hash_type], data).digest()[:hash_size]
                expected = cd[hash_offset + index * hash_size:hash_offset + (index + 1) * hash_size]
                if actual != expected:
                    raise RuntimeError('Mach-O ad-hoc page hash mismatch: ' + str(path) + ' page ' + str(index))
            directories.append({'version': hex(version), 'flags': flags, 'hash_type': hash_type,
                                'code_slots_verified': code_slots, 'page_bytes': page_bytes})
    if not directories:
        raise RuntimeError('Embedded signature has no verified CodeDirectory')
    return {'embedded_signature': True, 'code_directories': directories,
            'scope': 'Embedded ad-hoc code page hashes checked. This is not Apple developer signing, notarization or target execution.'}
