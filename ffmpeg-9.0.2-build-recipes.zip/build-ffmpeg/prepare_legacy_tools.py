#!/usr/bin/env python3
"""Use a signed Debian Wayland scanner compatible with the old target headers."""
import argparse
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
cache = root / 'downloads/buster-sysroot'
release = cache / 'Release'
subprocess.run(['gpgv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg',
                str(cache / 'Release.gpg'), str(release)], check=True)
index = cache / 'Packages-amd64.xz'
match = re.search(r'^ ([a-f0-9]{64})\s+\d+\s+main/binary-amd64/Packages.xz$',
                  release.read_text().split('\nSHA256:\n')[1].split('\nSHA512:')[0], re.M)
if not match or hashlib.sha256(index.read_bytes()).hexdigest() != match[1]:
    raise RuntimeError('Signed host tool package index differs')
packages = []
for block in lzma.decompress(index.read_bytes()).decode().split('\n\n'):
    values = dict(line.split(': ', 1) for line in block.splitlines()
                  if ': ' in line and not line.startswith(' '))
    if values.get('Package') == 'libwayland-bin':
        packages.append(values)
if len(packages) != 1:
    raise RuntimeError('Expected exactly one authenticated Wayland scanner package')
item = packages[0]
archive = cache / Path(item['Filename']).name
if not archive.exists():
    subprocess.run(['curl', '-fsSL', '--connect-timeout', '15', '--max-time', '180',
                    '--retry', '3', '-o', str(archive),
                    'https://mirrors.huaweicloud.com/debian-archive/debian/' + item['Filename']], check=True)
if hashlib.sha256(archive.read_bytes()).hexdigest() != item['SHA256']:
    raise RuntimeError('Signed host tool package digest differs')
destination = root / 'host-tools/legacy-wayland'
destination.mkdir(parents=True, exist_ok=True)
subprocess.run(['dpkg-deb', '-x', str(archive), str(destination)], check=True)
scanner = destination / 'usr/bin/wayland-scanner'
version = subprocess.check_output([str(scanner), '--version'], text=True, stderr=subprocess.STDOUT).strip()
record = {'source_package': item, 'scanner': str(scanner), 'version': version,
          'scanner_sha256': hashlib.sha256(scanner.read_bytes()).hexdigest(),
          'reason': 'Generate legacy-compatible client calls for the target Wayland 1.18 headers; avoid host scanner 1.22 protocol code requiring newer target APIs.'}
(root / 'state/legacy-wayland-scanner.json').write_text(json.dumps(record, indent=2) + '\n')
print(version)
