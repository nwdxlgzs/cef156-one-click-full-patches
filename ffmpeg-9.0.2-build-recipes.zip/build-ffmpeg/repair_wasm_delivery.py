#!/usr/bin/env python3
"""Repack browser integration fixes locally from the authenticated download.

The original download is retained. Every WASM/static library stays unchanged;
only JS worker allocation, examples, recipes and runtime receipts are updated.
"""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

import zstandard

from download_sdks import digest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'build-cef'))
from minimize_sdk import zstd_reader


def repair(destination):
    name = 'ffmpeg_9.0.2_wasm32_release'
    archive = destination / (name + '.tar.zst')
    receipt_path = archive.with_name(archive.name + '.verified.json')
    original = json.loads(receipt_path.read_text())
    if original.get('local_packaging_repair'):
        raise RuntimeError('This delivery has already been repaired')
    if not original['local_download_verified'] or digest(archive) != original['archive_sha256']:
        raise RuntimeError('Downloaded source archive is not authenticated')
    sdk = destination / 'strip-lib' / name
    recipe = Path(__file__).resolve().parent
    replacements = {}
    for relative in ['threads/bin/ffmpeg.js', 'threads/bin/ffprobe.js',
                     'examples/worker.js', 'examples/index.html',
                     'validation/wasm-runtime.json', 'validation/threads/runtime.json']:
        replacements[relative] = (sdk / relative).read_bytes()
    for n in ['wasm_metadata.py', 'build_wasm.py', 'probe_media.py',
              'validate_wasm.py', 'validate_browser_wasm.py']:
        replacements['build-recipes/' + n] = (recipe / n).read_bytes()
    # Load the complete source payload manifest before writing anything.
    with zstd_reader(archive) as reader, tarfile.open(fileobj=reader, mode='r|') as tar:
        for member in tar:
            if member.name == name + '/SHA256SUMS.json':
                manifest = json.load(tar.extractfile(member))
                break
        else:
            raise RuntimeError('Source manifest is absent')
    changes = []
    for relative, data in replacements.items():
        info = manifest.setdefault(relative, {'type': 'file', 'mode': 0o644})
        if info['type'] != 'file':
            raise RuntimeError('Unexpected replacement entry type')
        sha = hashlib.sha256(data).hexdigest()
        changes.append({'file': relative, 'source_sha256': info.get('sha256'), 'sha256': sha})
        info.update(sha256=sha, bytes=len(data))
    replacements['SHA256SUMS.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    pending = archive.with_name(archive.name + '.browserfix.pending')
    with zstd_reader(archive) as reader, tarfile.open(fileobj=reader, mode='r|') as source:
        with pending.open('wb') as output, zstandard.ZstdCompressor(level=8, threads=2, write_checksum=True).stream_writer(output) as writer:
            with tarfile.open(fileobj=writer, mode='w|', format=tarfile.PAX_FORMAT) as target:
                remaining = set(replacements)
                for member in source:
                    relative = member.name.removeprefix(name + '/')
                    if relative in replacements:
                        data = replacements[relative]
                        updated = copy.copy(member)
                        updated.size = len(data)
                        target.addfile(updated, io.BytesIO(data))
                        remaining.remove(relative)
                    else:
                        target.addfile(member, source.extractfile(member) if member.isfile() else None)
                for relative in sorted(remaining):
                    data = replacements[relative]
                    added = tarfile.TarInfo(name + '/' + relative)
                    added.mode = manifest[relative]['mode']
                    added.size = len(data)
                    target.addfile(added, io.BytesIO(data))
    expected = dict(manifest)
    expected['SHA256SUMS.json'] = {'type': 'file', 'bytes': len(replacements['SHA256SUMS.json']),
        'sha256': hashlib.sha256(replacements['SHA256SUMS.json']).hexdigest(), 'mode': 0o644}
    seen = set()
    with zstd_reader(pending) as reader, tarfile.open(fileobj=reader, mode='r|') as tar:
        for member in tar:
            if not member.name.startswith(name + '/'):
                raise RuntimeError('Unexpected archive root')
            relative = member.name[len(name)+1:]
            if relative in seen or relative not in expected:
                raise RuntimeError('Unexpected/duplicate entry')
            seen.add(relative)
            info = expected[relative]
            if info['mode'] != member.mode:
                raise RuntimeError('Archive mode mismatch')
            if info['type'] == 'file':
                if not member.isfile() or member.size != info['bytes']:
                    raise RuntimeError('Archive file metadata mismatch')
                h = hashlib.sha256()
                stream = tar.extractfile(member)
                for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                    h.update(block)
                if h.hexdigest() != info['sha256']:
                    raise RuntimeError('Archive payload hash mismatch: ' + relative)
            elif info['type'] == 'directory' and not member.isdir():
                raise RuntimeError('Archive directory mismatch')
            elif info['type'] == 'symlink' and (not member.issym() or member.linkname != info['target']):
                raise RuntimeError('Archive symlink mismatch')
    if seen != set(expected):
        raise RuntimeError('Repacked archive omits entries')
    backup = destination / 'source-downloads/wasm32-before-browser-fix'
    backup.mkdir(parents=True, exist_ok=True)
    for path in [archive, receipt_path, archive.with_name(archive.name + '.sha256')]:
        if (backup / path.name).exists():
            raise RuntimeError('Source download backup already exists')
    for path in [archive, receipt_path, archive.with_name(archive.name + '.sha256')]:
        path.replace(backup / path.name)
    pending.replace(archive)
    sha = digest(archive)
    fixed = {**original, 'archive': str(archive), 'archive_sha256': sha,
             'local_sha256': sha, 'bytes': archive.stat().st_size,
             'entries': len(expected), 'files': sum(x['type'] == 'file' for x in expected.values()),
             'validation_sha256': hashlib.sha256(replacements['validation/wasm-runtime.json']).hexdigest(),
             'source_download_receipt': str((backup / receipt_path.name).relative_to(destination)),
             'local_packaging_repair': {'source_download_sha256': original['archive_sha256'],
                 'source_download_verified': True, 'all_payloads_readback_verified': True,
                 'compiled_wasm_and_static_library_bytes_unchanged': True,
                 'changes': changes}}
    receipt_path.write_text(json.dumps(fixed, indent=2) + '\n')
    archive.with_name(archive.name + '.sha256').write_text(sha + '  ' + archive.name + '\n')
    # Keep the pre-fix compact outputs as recovery evidence, then regenerate
    # the compact SDK through the ordinary authenticated compaction workflow.
    compact_backup = backup / 'compact'
    compact_backup.mkdir()
    compact = destination / 'strip-lib'
    for path in [compact / name, compact / archive.name,
                 compact / receipt_path.name, compact / (archive.name + '.sha256')]:
        path.replace(compact_backup / path.name)
    return fixed


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(repair(a.destination.resolve()), indent=2))
