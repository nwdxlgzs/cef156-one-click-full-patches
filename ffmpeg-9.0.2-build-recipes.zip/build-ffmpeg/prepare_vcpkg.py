#!/usr/bin/env python3
"""Prepare version-locked, Release-only FFmpeg manifests and cross triplets."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

FFMPEG_REV = '946fcce07b6dcd0331c8cc609192aeff5e1924f8'
VCPKG_REV = 'ec48c11eae9448c8c6e7739d93e06fa2433aa95f'
TARGETS = ['linux-x64', 'linux-arm64', 'windows-x64', 'windows-x86',
           'windows-arm64', 'mac-arm64', 'mac-x64']


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data, encoding='utf-8')


def prepare(root, cef):
    vcpkg = root / 'vcpkg'
    actual = subprocess.check_output(['git', '-C', str(vcpkg), 'rev-parse', 'HEAD'], text=True).strip()
    if actual != VCPKG_REV:
        raise RuntimeError('vcpkg revision differs; preserve checkout for inspection')
    meson = root / 'overlay-ports/vcpkg-tool-meson'
    if not meson.exists():
        shutil.copytree(vcpkg / 'ports/vcpkg-tool-meson', meson)
    meson_helper = meson / 'vcpkg_configure_meson.cmake'
    meson_text = meson_helper.read_text()
    cross_check = 'OR (VCPKG_TARGET_IS_OSX AND NOT CMAKE_HOST_APPLE)'
    if cross_check not in meson_text:
        anchor = 'OR (VCPKG_TARGET_IS_APPLE AND NOT VCPKG_TARGET_IS_OSX)'
        if meson_text.count(anchor) != 1:
            raise RuntimeError('Unexpected Meson host/target OS detection')
        meson_text = meson_text.replace(anchor, anchor + '\n       ' + cross_check)
        write(meson_helper, meson_text)
    source = json.loads((root / 'state/source-ffmpeg.json').read_text())
    archive = Path(source['source'])
    if source['revision'] != FFMPEG_REV or hashlib.sha256(archive.read_bytes()).hexdigest() != source['source_sha256']:
        raise RuntimeError('FFmpeg source lock differs')
    # Keep D-Bus for SDL input/session integration without depending on a recent
    # systemd userland. FFmpeg's media modules and device APIs remain selected.
    dbus = root / 'overlay-ports/dbus'
    if not dbus.exists():
        shutil.copytree(vcpkg / 'ports/dbus', dbus)
    dbus_metadata = json.loads((dbus / 'vcpkg.json').read_text())
    dbus_metadata['default-features'] = []
    write(dbus / 'vcpkg.json', json.dumps(dbus_metadata, indent=2) + '\n')
    # FFTW implements the same Rubber Band FFT backend API without requiring
    # a separate OpenMP runtime; retain all time/pitch processing functions.
    rubberband = root / 'overlay-ports/rubberband'
    if not rubberband.exists():
        shutil.copytree(vcpkg / 'ports/rubberband', rubberband)
    rubber_metadata = json.loads((rubberband / 'vcpkg.json').read_text())
    dependencies = []
    for dependency in rubber_metadata['dependencies']:
        name = dependency.get('name') if isinstance(dependency, dict) else dependency
        if name == 'sleef':
            continue
        dependencies.append('fftw3' if name == 'fftw3' else dependency)
    rubber_metadata['dependencies'] = dependencies
    write(rubberband / 'vcpkg.json', json.dumps(rubber_metadata, indent=2) + '\n')
    rubber_port = (rubberband / 'portfile.cmake').read_text()
    rubber_port = rubber_port.replace('set(FFT_LIB "sleef")', 'set(FFT_LIB "fftw")')
    write(rubberband / 'portfile.cmake', rubber_port)
    tesseract = root / 'overlay-ports/tesseract'
    if not tesseract.exists():
        shutil.copytree(vcpkg / 'ports/tesseract', tesseract)
    tess_port = (tesseract / 'portfile.cmake').read_text()
    tess_marker = '# MYCEF retain Tesseract private static dependencies'
    if tess_marker not in tess_port:
        tess_port = tess_port.replace('vcpkg_fixup_pkgconfig()', tess_marker + '''
set(_mycef_tess_private "")
if("curl" IN_LIST FEATURES)
    string(APPEND _mycef_tess_private " libcurl")
endif()
if("libarchive" IN_LIST FEATURES)
    string(APPEND _mycef_tess_private " libarchive")
endif()
file(GLOB_RECURSE _mycef_tess_pc "${CURRENT_PACKAGES_DIR}/*tesseract.pc")
foreach(_pc IN LISTS _mycef_tess_pc)
    vcpkg_replace_string("${_pc}" "Requires.private: lept" "Requires.private: lept ${_mycef_tess_private}")
endforeach()
vcpkg_fixup_pkgconfig()
''', 1)
        write(tesseract / 'portfile.cmake', tess_port)
    tess_port = tess_port.replace('file(GLOB _mycef_tess_pc "${CURRENT_PACKAGES_DIR}/lib/pkgconfig/tesseract.pc" "${CURRENT_PACKAGES_DIR}/debug/lib/pkgconfig/tesseract.pc")',
                                  'file(GLOB_RECURSE _mycef_tess_pc "${CURRENT_PACKAGES_DIR}/*tesseract.pc")')
    tess_port = tess_port.replace('file(APPEND "${_pc}" "\\nRequires.private:${_mycef_tess_private}\\n")',
                                  'vcpkg_replace_string("${_pc}" "Requires.private: lept" "Requires.private: lept ${_mycef_tess_private}")')
    write(tesseract / 'portfile.cmake', tess_port)
    tess_math_marker = '# MYCEF expose Windows C math constants for Tesseract'
    if tess_math_marker not in tess_port:
        tess_port = tess_port.replace('vcpkg_cmake_configure(', tess_math_marker + '''
if(VCPKG_TARGET_IS_WINDOWS)
    vcpkg_replace_string("${SOURCE_PATH}/CMakeLists.txt" "project(" "add_compile_definitions(_USE_MATH_DEFINES)\\nproject(")
endif()

vcpkg_cmake_configure(''', 1)
        write(tesseract / 'portfile.cmake', tess_port)
    tess_winsock_marker = '# MYCEF MinGW import library filenames are case sensitive on Linux'
    if tess_winsock_marker not in tess_port:
        tess_port = tess_port.replace('vcpkg_cmake_configure(', tess_winsock_marker + '''
if(VCPKG_TARGET_IS_MINGW)
    vcpkg_replace_string("${SOURCE_PATH}/CMakeLists.txt" "set(LIB_Ws2_32 Ws2_32)" "set(LIB_Ws2_32 ws2_32)")
endif()

vcpkg_cmake_configure(''', 1)
        write(tesseract / 'portfile.cmake', tess_port)
    zeromq = root / 'overlay-ports/zeromq'
    if not zeromq.exists():
        shutil.copytree(vcpkg / 'ports/zeromq', zeromq)
    zmq_port = (zeromq / 'portfile.cmake').read_text()
    zmq_marker = '# MYCEF include the standard header declaring std::nothrow'
    if zmq_marker not in zmq_port:
        anchor = 'string(COMPARE EQUAL "${VCPKG_LIBRARY_LINKAGE}" "static" BUILD_STATIC)'
        zmq_port = zmq_port.replace(anchor, zmq_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/src/polling_util.hpp" "#include <vector>" "#include <new>\\n#include <vector>")

''' + anchor)
        write(zeromq / 'portfile.cmake', zmq_port)
    zmq_clock_marker = '# MYCEF Windows ARM64 uses the portable nanosecond clock path'
    if zmq_clock_marker not in zmq_port:
        zmq_port = zmq_port.replace('vcpkg_cmake_configure(', zmq_clock_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/src/clock.cpp" "const uint64_t nsecs_per_usec = 1000;\\n#endif" "#endif\\nconst uint64_t nsecs_per_usec = 1000;")

vcpkg_cmake_configure(''', 1)
        write(zeromq / 'portfile.cmake', zmq_port)
    zimg = root / 'overlay-ports/zimg'
    if not zimg.exists():
        shutil.copytree(vcpkg / 'ports/zimg', zimg)
    zimg_port = (zimg / 'portfile.cmake').read_text()
    zimg_marker = '# MYCEF include the standard exception_ptr declaration'
    if zimg_marker not in zimg_port:
        zimg_port = zimg_port.replace('vcpkg_configure_make(', zimg_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/src/zimg/api/zimg.cpp" "#include <cmath>" "#include <cmath>\\n#include <exception>")

vcpkg_configure_make(''', 1)
        write(zimg / 'portfile.cmake', zimg_port)
    zimg_case_marker = '# MYCEF MinGW header names on a case-sensitive build host'
    if zimg_case_marker not in zimg_port:
        zimg_port = zimg_port.replace('vcpkg_configure_make(', zimg_case_marker + '''
if(VCPKG_TARGET_IS_MINGW)
    vcpkg_replace_string("${SOURCE_PATH}/src/zimg/common/arm/cpuinfo_arm.cpp" "<Windows.h>" "<windows.h>")
endif()

vcpkg_configure_make(''', 1)
        write(zimg / 'portfile.cmake', zimg_port)
    vvenc = root / 'overlay-ports/vvenc'
    if not vvenc.exists():
        shutil.copytree(vcpkg / 'ports/vvenc', vvenc)
    vvenc_port = (vvenc / 'portfile.cmake').read_text()
    vvenc_marker = '# MYCEF use the Windows API baseline from the target triplet'
    if vvenc_marker not in vvenc_port:
        vvenc_port = vvenc_port.replace('vcpkg_check_features(', vvenc_marker + '''
if(VCPKG_TARGET_IS_WINDOWS)
    vcpkg_replace_string("${SOURCE_PATH}/CMakeLists.txt" "add_definitions( -D_WIN32_WINNT=0x0600 )" "# Windows API baseline is supplied by the MyCEF target triplet")
endif()

vcpkg_check_features(''', 1)
        write(vvenc / 'portfile.cmake', vvenc_port)
    vpl = root / 'overlay-ports/libvpl'
    if not vpl.exists():
        shutil.copytree(vcpkg / 'ports/libvpl', vpl)
    vpl_port = (vpl / 'portfile.cmake').read_text()
    vpl_marker = '# MYCEF only ancient MSVC needs the unsafe CRT fallback macros'
    if vpl_marker not in vpl_port:
        vpl_port = vpl_port.replace('vcpkg_cmake_configure(', vpl_marker + '''
if(VCPKG_TARGET_IS_MINGW)
    vcpkg_replace_string("${SOURCE_PATH}/libvpl/src/windows/mfx_dispatcher_defs.h" "#if _MSC_VER < 1400" "#if defined(_MSC_VER) && _MSC_VER < 1400")
endif()

vcpkg_cmake_configure(''', 1)
        write(vpl / 'portfile.cmake', vpl_port)
    avisynth = root / 'overlay-ports/avisynthplus'
    if not avisynth.exists():
        shutil.copytree(vcpkg / 'ports/avisynthplus', avisynth)
    avs_port = (avisynth / 'portfile.cmake').read_text()
    avs_marker = '# MYCEF include the C++ math declarations used by AviSynth SIMD templates'
    if avs_marker not in avs_port:
        avs_port = avs_port.replace('vcpkg_cmake_configure(', avs_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/avs_core/filters/intel/focus_sse.cpp" "#include <stdint.h>" "#include <stdint.h>\\n#include <cmath>")

vcpkg_cmake_configure(''', 1)
        write(avisynth / 'portfile.cmake', avs_port)
    avs_dtor_marker = '# MYCEF preserve the inherited C++ destructor calling convention on x86'
    if avs_dtor_marker not in avs_port:
        avs_port = avs_port.replace('vcpkg_cmake_configure(', avs_dtor_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/avs_core/core/avisynth_c.cpp" "AVSC_CC ~C_VideoFilter();" "~C_VideoFilter();")

vcpkg_cmake_configure(''', 1)
        write(avisynth / 'portfile.cmake', avs_port)
    leptonica = root / 'overlay-ports/leptonica'
    if not leptonica.exists():
        shutil.copytree(vcpkg / 'ports/leptonica', leptonica)
    lept_port = (leptonica / 'portfile.cmake').read_text()
    lept_marker = '# MYCEF keep the native .a suffix for MinGW static Leptonica'
    if lept_marker not in lept_port:
        lept_port = lept_port.replace('vcpkg_cmake_configure(', lept_marker + '''
vcpkg_replace_string("${SOURCE_PATH}/src/CMakeLists.txt" "if(MINGW)" "if(MINGW AND BUILD_SHARED_LIBS)")
vcpkg_replace_string("${SOURCE_PATH}/src/CMakeLists.txt" "endif(MINGW)" "endif()")

vcpkg_cmake_configure(''', 1)
        write(leptonica / 'portfile.cmake', lept_port)
    lame = root / 'overlay-ports/mp3lame'
    if not lame.exists():
        shutil.copytree(vcpkg / 'ports/mp3lame', lame)
    lame_port = (lame / 'portfile.cmake').read_text()
    lame_marker = '# MYCEF compile the x86 LAME SSE implementation with its required ISA'
    if lame_marker not in lame_port:
        lame_port = lame_port.replace('vcpkg_make_configure(', lame_marker + '''
if(VCPKG_TARGET_ARCHITECTURE STREQUAL "x86" AND NOT VCPKG_DETECTED_MSVC)
    string(APPEND VCPKG_C_FLAGS " -msse2")
    string(APPEND VCPKG_CXX_FLAGS " -msse2")
endif()

vcpkg_make_configure(''', 1)
        write(lame / 'portfile.cmake', lame_port)
    mpg123 = root / 'overlay-ports/mpg123'
    if not mpg123.exists():
        shutil.copytree(vcpkg / 'ports/mpg123', mpg123)
    mpg_port = (mpg123 / 'portfile.cmake').read_text()
    mpg_marker = '# MYCEF use mpg123 Windows CPU probing on ARM64 as well as ARM32'
    if mpg_marker not in mpg_port:
        mpg_port = mpg_port.replace('vcpkg_cmake_configure(', mpg_marker + '''
if(VCPKG_TARGET_IS_WINDOWS)
    vcpkg_replace_string("${SOURCE_PATH}/src/libmpg123/getcpuflags_arm.c" "#ifndef _M_ARM" "#ifndef _WIN32")
endif()

vcpkg_cmake_configure(''', 1)
        write(mpg123 / 'portfile.cmake', mpg_port)
    vpx = root / 'overlay-ports/libvpx'
    if not vpx.exists():
        shutil.copytree(vcpkg / 'ports/libvpx', vpx)
    vpx_port = (vpx / 'portfile.cmake').read_text()
    vpx_marker = '# MYCEF keep Darwin archive symbol tables in their native format'
    if vpx_marker not in vpx_port:
        vpx_port = vpx_port.replace('set(ENV{AR} ${VCPKG_DETECTED_CMAKE_AR})',
                                  'set(ENV{AR} ${VCPKG_DETECTED_CMAKE_AR})\n' + vpx_marker + '''
        if(VCPKG_TARGET_IS_OSX)
            set(ENV{AR} "${VCPKG_DETECTED_CMAKE_AR} --format=darwin")
            set(ENV{STRIP} "''' + str(cef / 'chromium/src/third_party/llvm-build/Release+Asserts/bin/llvm-strip') + '''")
        endif()
''')
        write(vpx / 'portfile.cmake', vpx_port)
    strip_option = 'set(ENV{STRIP} "' + str(cef / 'chromium/src/third_party/llvm-build/Release+Asserts/bin/llvm-strip') + '")'
    strip_marker = '# MYCEF override the host GNU strip after tool discovery'
    if strip_marker not in vpx_port:
        vpx_port = vpx_port.replace('set(ENV{STRIP} ${VCPKG_DETECTED_CMAKE_STRIP})',
                                    'set(ENV{STRIP} ${VCPKG_DETECTED_CMAKE_STRIP})\n'
                                    '    ' + strip_marker + '\n    if(VCPKG_TARGET_IS_OSX)\n        ' + strip_option + '\n    endif()')
        write(vpx / 'portfile.cmake', vpx_port)
    # SDL's pkg-config probes must not import the build host's /usr/include.
    # Keep platform backends enabled and resolve their metadata in the sysroot.
    sdl = root / 'overlay-ports/sdl2'
    if not sdl.exists():
        shutil.copytree(vcpkg / 'ports/sdl2', sdl)
    sdl_text = (sdl / 'portfile.cmake').read_text()
    marker = '# MYCEF isolate SDL target pkg-config'
    if marker not in sdl_text:
        sdl_text = sdl_text.replace('vcpkg_cmake_configure(\n', marker + '''
if(VCPKG_TARGET_IS_LINUX)
    set(_mycef_pc "${CURRENT_BUILDTREES_DIR}/target-pkg-config")
    set(_mycef_pc_content [=[#!/bin/sh
exec /usr/bin/python3 "''' + str(root / 'target_pkg_config.py') + '''" --root "''' + str(root) + '''" --triplet "@TARGET_TRIPLET@" -- "$@"
]=])
    string(CONFIGURE "${_mycef_pc_content}" _mycef_pc_content @ONLY)
    file(WRITE "${_mycef_pc}" "${_mycef_pc_content}")
    file(CHMOD "${_mycef_pc}" PERMISSIONS OWNER_READ OWNER_WRITE OWNER_EXECUTE GROUP_READ GROUP_EXECUTE WORLD_READ WORLD_EXECUTE)
    list(APPEND FEATURE_OPTIONS "-DPKG_CONFIG_EXECUTABLE=${_mycef_pc}")
endif()
vcpkg_cmake_configure(
''', 1)
        write(sdl / 'portfile.cmake', sdl_text)
    scanner_option = '"-DWAYLAND_SCANNER=' + str(root / 'host-tools/legacy-wayland/usr/bin/wayland-scanner') + '"'
    if scanner_option not in sdl_text:
        sdl_text = sdl_text.replace('list(APPEND FEATURE_OPTIONS "-DPKG_CONFIG_EXECUTABLE=${_mycef_pc}")',
                                  'list(APPEND FEATURE_OPTIONS "-DPKG_CONFIG_EXECUTABLE=${_mycef_pc}" ' + scanner_option + ')')
        write(sdl / 'portfile.cmake', sdl_text)
    x265 = root / 'overlay-ports/x265'
    if not x265.exists():
        shutil.copytree(vcpkg / 'ports/x265', x265)
    wrapper = Path(__file__).resolve().parent / 'x265-multilib'
    for name in ('CMakeLists.txt', 'merge.cmake.in'):
        shutil.copy2(wrapper / name, x265 / name)
    x265_port = x265 / 'portfile.cmake'
    x265_text = x265_port.read_text()
    x265_text = x265_text.replace('SOURCE_PATH "${SOURCE_PATH}/source"\n    OPTIONS',
        'SOURCE_PATH "${CMAKE_CURRENT_LIST_DIR}"\n    OPTIONS\n'
        '        "-DMYCEF_X265_SOURCE=${SOURCE_PATH}/source"\n'
        '        "-DMYCEF_X265_VERSION=${VERSION}"')
    write(x265_port, x265_text)
    overlay = root / 'overlay-ports/ffmpeg'
    if not overlay.exists():
        shutil.copytree(vcpkg / 'ports/ffmpeg', overlay)
    portfile = overlay / 'portfile.cmake'
    text = portfile.read_text()
    original = 'REF "n${VERSION}"'
    if original in text:
        text = text.replace(original, 'REF "' + FFMPEG_REV + '"', 1)
        text, count = re.subn(r'SHA512 [0-9a-f]{128}',
                             'SHA512 ' + hashlib.sha512(archive.read_bytes()).hexdigest(), text, count=1)
        if count != 1:
            raise RuntimeError('Unexpected FFmpeg source hash declaration')
        write(portfile, text)
    elif FFMPEG_REV not in text:
        raise RuntimeError('Unexpected existing FFmpeg overlay')
    build_shell = overlay / 'build.sh.in'
    shell_text = build_shell.read_text()
    # Each SDK has exactly one target architecture. Universal merging invokes
    # Apple's lipo unnecessarily and loses outputs on a Linux build host.
    shell_text = shell_text.replace('if [ $OSX_ARCH_COUNT -gt 0 ]; then',
                                    'if [ $OSX_ARCH_COUNT -gt 1 ]; then')
    write(build_shell, shell_text)
    extra = {'jxl': ('libjxl', 'libjxl'), 'zimg': ('zimg', 'libzimg'),
             'mysofa': ('libmysofa', 'libmysofa'),
             'aribcaption': ('libaribcaption', 'libaribcaption'),
             'vvenc': ('vvenc', 'libvvenc')}
    metadata = json.loads((overlay / 'vcpkg.json').read_text())
    for feature, (dependency, option) in extra.items():
        value = {'description': 'Enable ' + option, 'dependencies': [dependency]}
        if feature == 'vvenc':
            value['supports'] = '!x86 & !arm32'
        metadata['features'][feature] = value
    write(overlay / 'vcpkg.json', json.dumps(metadata, indent=2) + '\n')
    marker = '# MYCEF additional editing/codecs dependencies'
    if marker not in text:
        additions = [marker]
        for feature, (_, option) in extra.items():
            additions += ['if("' + feature + '" IN_LIST FEATURES)',
                          '  string(APPEND OPTIONS " --enable-' + option + '")',
                          'else()', '  string(APPEND OPTIONS " --disable-' + option + '")', 'endif()']
        anchor = 'if("nonfree" IN_LIST FEATURES)'
        if text.count(anchor) != 1:
            raise RuntimeError('Unexpected FFmpeg option declaration')
        text = text.replace(anchor, '\n'.join(additions) + '\n\n' + anchor)
        write(portfile, text)
    # FFmpeg is shared, but its external codec/filter dependencies are static.
    # Include their private transitive link requirements during configure probes.
    static_probe = 'if(VCPKG_LIBRARY_LINKAGE STREQUAL "static")\n    set(OPTIONS "${OPTIONS} --pkg-config-flags=--static")\nendif()'
    if static_probe in text:
        text = text.replace(static_probe, 'set(OPTIONS "${OPTIONS} --pkg-config-flags=--static")')
        write(portfile, text)
    pthread_marker = '# MYCEF glibc before 2.34 keeps pthread in its own library'
    if pthread_marker not in text:
        anchor = 'message(STATUS "Building Options: ${OPTIONS}")'
        text = text.replace(anchor, pthread_marker + '\nif(VCPKG_TARGET_IS_LINUX)\n'
                            '    string(APPEND OPTIONS " --extra-libs=-pthread")\nendif()\n\n' + anchor)
        write(portfile, text)
    runtime_marker = '# MYCEF C CLI links static C++ media dependencies'
    if runtime_marker not in text:
        anchor = 'message(STATUS "Building Options: ${OPTIONS}")'
        text = text.replace(anchor, runtime_marker + '''
if(VCPKG_TARGET_IS_LINUX)
    string(APPEND OPTIONS " --extra-libs=-lstdc++")
elseif(VCPKG_TARGET_IS_OSX)
    string(APPEND OPTIONS " --extra-libs=-lc++")
elseif(VCPKG_TARGET_IS_MINGW)
    string(APPEND OPTIONS " --extra-libs=-lc++ --extra-libs=-lunwind")
endif()

''' + anchor)
        write(portfile, text)
    text = text.replace('string(APPEND OPTIONS " --extra-libs=-lstdc++")',
                        'string(APPEND OPTIONS " --extra-libs=-lstdc++ --extra-libs=-lm")')
    write(portfile, text)
    mac_strip_marker = '# MYCEF GNU strip on the Linux host cannot process Mach-O'
    if mac_strip_marker not in text:
        anchor = 'message(STATUS "Building Options: ${OPTIONS}")'
        text = text.replace(anchor, mac_strip_marker + '\nif(VCPKG_TARGET_IS_OSX)\n'
                            '    string(APPEND OPTIONS " --disable-stripping --extra-ldflags=-Wl,-S,-x")\nendif()\n\n' + anchor)
        write(portfile, text)
    # LLVM 24 objcopy changes valid NASM Mach-O relocation widths when stripping
    # intermediate objects. Keep those objects intact; let ld64 remove debug
    # and local symbols at the final link, before creating its ad-hoc signature.
    text = text.replace('string(APPEND OPTIONS " --strip=llvm-strip")',
                        'string(APPEND OPTIONS " --disable-stripping --extra-ldflags=-Wl,-S,-x")')
    # vcpkg rewrites install names and adds loader-relative rpaths after linking.
    # Reserve load-command space so the x64 CLI's first section stays intact.
    text = text.replace('--extra-ldflags=-Wl,-S,-x"',
                        '--extra-ldflags=-Wl,-S,-x,-headerpad,0x4000"')
    write(portfile, text)
    downloads = root / 'vcpkg-downloads'
    downloads.mkdir(exist_ok=True)
    cached = downloads / ('ffmpeg-ffmpeg-' + FFMPEG_REV + '.tar.gz')
    if not cached.exists():
        shutil.copy2(archive, cached)
    clang = cef / 'chromium/src/third_party/llvm-build/Release+Asserts/bin'
    apple = cef / 'cache/apple-research/extracted-sdk-universal/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk'
    features = ['all-gpl', 'version3', 'ffmpeg', 'ffprobe', 'ffplay', 'drawtext',
                'dvdvideo', 'rubberband', 'zmq', 'openssl', 'x264', 'x265',
                'dav1d', 'ssh', 'jxl', 'zimg', 'mysofa', 'aribcaption', 'tesseract']
    for target in TARGETS:
        platform, cpu = target.split('-')
        arch = {'x86': 'x86', 'x64': 'x64', 'arm64': 'arm64'}[cpu]
        triplet = arch + '-mycef-' + platform
        tool = root / 'toolchains' / (target + '.cmake')
        if platform == 'linux':
            base = cef / 'cache/client-toolchains' / target / 'toolchain.cmake'
            content = base.read_text()
            sysroots = json.loads((root / 'state/linux-sysroots.json').read_text())
            old_root = cef / 'chromium/src/build/linux' / ('debian_bullseye_' + ('amd64' if cpu == 'x64' else 'arm64') + '-sysroot')
            content = content.replace(str(old_root), sysroots[cpu]['directory'])
            # CEF-specific pkg-config variables must not hide vcpkg dependencies.
            content = '\n'.join(x for x in content.splitlines()
                                if not x.startswith(('set(ENV{', 'set(PROJECT_ARCH')))
            system = 'Linux'
            content += '\nset(CMAKE_LINKER "' + str(clang / 'ld.lld') + '")\n'
        elif platform == 'mac':
            base = cef / 'cache/mac-client-toolchain' / cpu / 'v2/toolchain.cmake'
            content = base.read_text()
            content += '\nset(CMAKE_INSTALL_NAME_TOOL "' + str(clang / 'llvm-install-name-tool') + '")\n'
            content += '\nset(CMAKE_LINKER "' + str(clang / 'ld64.lld') + '")\n'
            system = 'Darwin'
        else:
            system = 'MinGW'
            mingw = root / 'toolchains/llvm-mingw/bin'
            triple = {'x64': 'x86_64', 'x86': 'i686', 'arm64': 'aarch64'}[cpu] + '-w64-mingw32'
            values = {'CMAKE_SYSTEM_NAME': 'Windows', 'CMAKE_SYSTEM_PROCESSOR': arch,
                      'CMAKE_C_COMPILER': mingw / (triple + '-clang'),
                      'CMAKE_CXX_COMPILER': mingw / (triple + '-clang++'),
                      'CMAKE_RC_COMPILER': mingw / (triple + '-windres'),
                      'CMAKE_AR': mingw / 'llvm-ar', 'CMAKE_RANLIB': mingw / 'llvm-ranlib'}
            content = '\n'.join('set(' + k + ' "' + str(v) + '")' for k, v in values.items())
        if platform in ('linux', 'mac'):
            # Some make-based ports use just CC/CXX and discard CMake's target,
            # sysroot or deployment variables during their initial probes.
            # Pin those properties in the compiler executable itself.
            wrappers = root / 'toolchains/compiler-wrappers' / target
            wrappers.mkdir(parents=True, exist_ok=True)
            if platform == 'linux':
                triple = 'x86_64-linux-gnu' if cpu == 'x64' else 'aarch64-linux-gnu'
                sysroot = root / 'sysroots' / (target + '-glibc228')
                mandatory = ['-Qunused-arguments', '--target=' + triple, '--sysroot=' + str(sysroot),
                             '--gcc-install-dir=' + str(sysroot / 'usr/lib/gcc' / triple / '10'), '-fuse-ld=lld']
            else:
                triple = ('x86_64' if cpu == 'x64' else 'arm64') + '-apple-macos13.0'
                mandatory = ['-Qunused-arguments', '--target=' + triple, '-isysroot', str(apple), '-fuse-ld=lld']
            import shlex
            for compiler in ('clang', 'clang++'):
                wrapper_path = wrappers / compiler
                write(wrapper_path, '#!/bin/sh\nexec ' + shlex.join([str(clang / compiler), *mandatory]) + ' "$@"\n')
                wrapper_path.chmod(0o755)
                content = content.replace(str(clang / compiler) + '"', str(wrapper_path) + '"')
            if platform == 'linux':
                pkg_wrapper = wrappers / 'pkg-config'
                write(pkg_wrapper, '#!/bin/sh\nexec /usr/bin/python3 ' + shlex.join([
                    str(root / 'target_pkg_config.py'), '--root', str(root), '--triplet', triplet, '--']) + ' "$@"\n')
                pkg_wrapper.chmod(0o755)
                content += '\nset(PKG_CONFIG_EXECUTABLE "' + str(pkg_wrapper) + '" CACHE FILEPATH "Target metadata resolver" FORCE)\n'
        if platform == 'linux':
            ranlib = cef / 'cache/mac-client-toolchain/x64/v2/llvm-ranlib'
            content += '\nset(CMAKE_AR "' + str(clang / 'llvm-ar') + '")\n'
            content += 'set(CMAKE_RANLIB "' + str(ranlib) + '")\n'
        elif platform == 'windows':
            ranlib = root / 'toolchains/llvm-mingw/bin/llvm-ranlib'
        else:
            ranlib = cef / 'cache/mac-client-toolchain' / cpu / 'v2/llvm-ranlib'
        for language in ('C', 'CXX'):
            content += '\nset(CMAKE_' + language + '_COMPILER_AR "${CMAKE_AR}")\n'
            content += 'set(CMAKE_' + language + '_COMPILER_RANLIB "' + str(ranlib) + '")\n'
        content += '''
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
string(APPEND CMAKE_C_FLAGS_INIT " ${VCPKG_C_FLAGS}")
string(APPEND CMAKE_CXX_FLAGS_INIT " ${VCPKG_CXX_FLAGS}")
# Chainload files can be read again during compiler/platform initialization.
# Preserve the target package root while keeping host libraries out of search.
if(DEFINED VCPKG_INSTALLED_DIR AND DEFINED VCPKG_TARGET_TRIPLET)
  list(PREPEND CMAKE_FIND_ROOT_PATH "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}")
  list(PREPEND CMAKE_PREFIX_PATH "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}")
endif()
'''
        write(tool, content + '\n')
        flags = '-fPIC' if platform != 'windows' else (
            '-D_WIN32_WINNT=0x0601 -DWINVER=0x0601' if cpu != 'arm64'
            else '-D_WIN32_WINNT=0x0A00 -DWINVER=0x0A00')
        if platform == 'linux':
            flags += ' --target=' + ('x86_64-linux-gnu' if cpu == 'x64' else 'aarch64-linux-gnu')
        elif platform == 'mac':
            flags += ' --target=' + ('x86_64' if cpu == 'x64' else 'arm64') + '-apple-macos13.0'
        lines = ['set(VCPKG_TARGET_ARCHITECTURE ' + arch + ')',
                 'set(VCPKG_CRT_LINKAGE dynamic)', 'set(VCPKG_LIBRARY_LINKAGE static)',
                 'if(PORT STREQUAL "ffmpeg"' + (' OR PORT STREQUAL "rubberband"' if platform == 'windows' else '') + ')',
                 '  set(VCPKG_LIBRARY_LINKAGE dynamic)', 'endif()',
                 'set(VCPKG_BUILD_TYPE release)', 'set(VCPKG_CMAKE_SYSTEM_NAME ' + system + ')',
                 'set(VCPKG_CHAINLOAD_TOOLCHAIN_FILE "' + str(tool) + '")',
                 'set(VCPKG_C_FLAGS "' + flags + '")',
                 'set(VCPKG_CXX_FLAGS "' + flags + '")']
        if platform == 'mac':
            lines += ['set(VCPKG_OSX_ARCHITECTURES ' + ('arm64' if cpu == 'arm64' else 'x86_64') + ')',
                      'set(VCPKG_OSX_DEPLOYMENT_TARGET 13.0)',
                      'set(VCPKG_OSX_SYSROOT "' + str(apple) + '")']
        if platform == 'linux':
            host_triple = 'x86_64-linux-gnu' if cpu == 'x64' else 'aarch64-linux-gnu'
            lines.append('set(VCPKG_MAKE_BUILD_TRIPLET "--host=' + host_triple + '")')
            lines.append('set(PKGCONFIG "' + str(pkg_wrapper) + '")')
        elif platform == 'mac':
            host_triple = ('x86_64' if cpu == 'x64' else 'aarch64') + '-apple-darwin'
            lines.append('set(VCPKG_MAKE_BUILD_TRIPLET "--host=' + host_triple + '")')
        write(root / 'triplets' / (triplet + '.cmake'), '\n'.join(lines) + '\n')
        requested = features + (['vaapi'] if platform == 'linux' else [])
        if cpu != 'x86':
            requested.append('vvenc')
        manifest = {'name': 'mycef-ffmpeg-' + target, 'version-string': '9.0.2',
                    'builtin-baseline': VCPKG_REV,
                    'dependencies': [{'name': 'ffmpeg', 'default-features': False, 'features': requested},
                                     {'name': 'x264', 'features': ['chroma-format-all']},
                                     {'name': 'libvpx', 'features': ['highbitdepth']}]}
        write(root / 'manifests' / target / 'vcpkg.json', json.dumps(manifest, indent=2) + '\n')
    write(root / 'state/prepared-manifests.json', json.dumps({
        'ffmpeg_revision': FFMPEG_REV, 'vcpkg_revision': VCPKG_REV,
        'targets': TARGETS, 'features': features, 'configuration': 'Release',
        'shared_ffmpeg_static_external_dependencies': True,
        'scope': 'Prepared inputs only; no build or compatibility pass claimed.'}, indent=2) + '\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    a = p.parse_args()
    prepare(a.root.resolve(), a.cef_root.resolve())
