#!/usr/bin/env python3
"""Audit the eight local SDK deliveries and write an evidence-based inventory."""
import argparse
import datetime as dt
import json
from pathlib import Path

from download_sdks import TARGETS, digest


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def audit(destination):
    items = {}
    common = ['CONFIG_GPL', 'CONFIG_VERSION3', 'CONFIG_AVCODEC', 'CONFIG_AVFORMAT',
              'CONFIG_AVFILTER', 'CONFIG_SWRESAMPLE', 'CONFIG_SWSCALE',
              'CONFIG_LIBX264', 'CONFIG_LIBX265', 'CONFIG_LIBAOM', 'CONFIG_LIBDAV1D',
              'CONFIG_LIBVPX', 'CONFIG_LIBASS', 'CONFIG_LIBJXL', 'CONFIG_LIBOPUS',
              'CONFIG_LIBRUBBERBAND', 'CONFIG_LIBSOXR', 'CONFIG_LIBTESSERACT']
    for target in TARGETS:
        name = 'ffmpeg_9.0.2_' + target + '_release'
        full = destination / (name + '.tar.zst')
        compact = destination / 'strip-lib' / full.name
        sdk = destination / 'strip-lib' / name
        receipts = []
        for artifact in (full, compact):
            receipt = read(artifact.with_name(artifact.name + '.verified.json'))
            if (receipt['target'] != target or artifact.stat().st_size != receipt['bytes']
                    or digest(artifact) != receipt['archive_sha256']):
                raise RuntimeError('Local delivery identity differs: ' + str(artifact))
            receipts.append(receipt)
        if not receipts[0]['local_download_verified'] or not receipts[1]['created_locally']:
            raise RuntimeError('Missing full download or local compaction evidence: ' + target)
        if receipts[1]['source_archive_sha256'] != receipts[0]['archive_sha256']:
            raise RuntimeError('Compact SDK does not derive from this full SDK: ' + target)
        features = read(sdk / 'FEATURES.json')
        flags = features['variants']['threads']['flags'] if target == 'wasm32' else features['flags']
        if not features['sdk_complete'] or any(flags.get(k) != 1 for k in common) or flags.get('CONFIG_NONFREE'):
            raise RuntimeError('Requested core/software configuration missing: ' + target)
        if target in ('windows-x64', 'windows-x86'):
            evidence_path = destination / 'validation' / target / 'runtime.json'
            evidence = read(evidence_path)
            scope = 'Local Windows MSVC C API consumer and 17 real media round-trip/filter probes.'
        elif target.startswith('linux-'):
            evidence_path = sdk / 'validation/oldlinux-runtime.json'
            evidence = read(evidence_path)
            scope = 'Linux 4.9/glibc 2.28 full-system guest: C API and 17 real media probes; compact ELF runtime sections preserved.'
        elif target == 'wasm32':
            evidence_path = destination / 'validation/wasm32/browser-runtime.json'
            evidence = read(evidence_path)
            if not read(sdk / 'validation/wasm-runtime.json')['passed']:
                raise RuntimeError('Node/static C API execution receipt failed')
            scope = 'Node media round trips/static C API plus local Chrome Worker H.264 MP4 encoding.'
        else:
            evidence_path = sdk / 'validation/cross-sdk.json'
            evidence = read(evidence_path)
            scope = ('Target architecture/imports and independently cross-linked C API checked; '
                     'macOS runtime/signing/notarization untested.' if target.startswith('mac-') else
                     'Target architecture/imports and MSVC-compatible C API cross-link checked; ARM Windows execution untested.')
        if evidence.get('passed') is not True:
            raise RuntimeError('Applicable execution or binary audit failed: ' + target)
        counts = features['variants']['threads']['component_counts'] if target == 'wasm32' else features['component_counts']
        items[target] = {'full_archive': full.name, 'full_bytes': full.stat().st_size,
                         'full_sha256': receipts[0]['archive_sha256'],
                         'compact_archive': compact.relative_to(destination).as_posix(),
                         'compact_bytes': compact.stat().st_size,
                         'compact_sha256': receipts[1]['archive_sha256'],
                         'sdk_directory': sdk.relative_to(destination).as_posix(),
                         'component_counts': counts, 'verification': scope,
                         'evidence': evidence_path.relative_to(destination).as_posix(),
                         'evidence_sha256': digest(evidence_path)}
        modules = ['LIBX264', 'LIBX265', 'LIBVPX', 'LIBAOM', 'LIBDAV1D', 'LIBSVTAV1',
                   'LIBVVENC', 'LIBJXL', 'LIBTESSERACT', 'LIBASS', 'LIBRUBBERBAND', 'OPENSSL']
        items[target]['software_modules'] = {n.lower(): bool(flags.get('CONFIG_' + n)) for n in modules}
        if receipts[0].get('local_packaging_repair'):
            items[target]['local_packaging_repair'] = receipts[0]['local_packaging_repair']
        if receipts[0].get('delta_reconstruction'):
            items[target]['delta_reconstruction'] = receipts[0]['delta_reconstruction']
    result = {'all_eight_downloaded_and_audited': True, 'ffmpeg_version': '9.0.2',
              'audited_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'targets': items}
    (destination / 'DELIVERY-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    rows = ['| 目标 | 完整包 MiB | 精简包 MiB | 解码器 | 编码器 | 滤镜 |',
            '| --- | ---: | ---: | ---: | ---: | ---: |']
    for target, item in items.items():
        c = item['component_counts']
        rows.append(f"| {target} | {item['full_bytes']/1048576:.1f} | {item['compact_bytes']/1048576:.1f} | "
                    f"{c.get('decoder', 0)} | {c.get('encoder', 0)} | {c.get('filter', 0)} |")
    text = '''# FFmpeg 9.0.2：8 个 Release 开发包

完整包位于本目录，精简包与解压后的开发目录位于 `strip-lib`。每个包都有 SHA256 和验证记录；详细功能开关见包内 `FEATURES.json`。

七个原生包提供动态库、开发链接文件、公共头文件、ffmpeg/ffprobe/ffplay、CMake 示例与许可证。WASM 提供多线程静态库、JS/WASM、浏览器与 C API 示例。

''' + '\n'.join(rows) + '''

Windows x64/x86 已在本机通过 MSVC 链接和 17 项媒体测试；Win7 尚未实机验证。Linux 两个架构已在 Linux 4.9/glibc 2.28 虚拟机通过媒体测试。Windows ARM64 和 macOS 已通过架构、依赖与 C API 交叉链接检查，尚未在对应实机运行；Mac 部署目标为 macOS 13.0，尚未完成分发签名/公证。

WASM 已通过 Node 和本机 Chrome Worker 运行验证。需要 HTTPS/localhost、COOP/COEP、SharedArrayBuffer；浏览器不提供原生 GPU 驱动接口、桌面 ffplay 窗口与原始 TCP/UDP 网络协议。默认使用 16 个 pthread Worker，建议显式限制编解码和滤镜线程数。

GPL/version3 已启用，FFmpeg nonfree 未启用。各平台按工具链和架构能力启用功能；不能把“完整功能”理解为每个硬件平台都能提供相同的设备驱动或编解码加速器。开发时请先运行包内示例；需要直接调用 CUDA、Direct3D、VideoToolbox 等硬件专用 API 时还需相应平台开发 SDK。

Windows x86 未启用上游不支持此架构的 SVT-AV1、VVenC；AV1 编码仍可使用 AOM。其余软件模块开关逐项列在 `DELIVERY-AUDIT.json`，完整编译开关见每包的 `FEATURES.json`。

编译配方见工作区 `build-ffmpeg` 和包内 `build-recipes`；最终逐包核验记录见 `DELIVERY-AUDIT.json`。完整包只下载一次，精简包在本地生成。
'''
    (destination / 'README.zh-CN.md').write_text(text, encoding='utf-8')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--destination', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(audit(a.destination.resolve()), indent=2))
