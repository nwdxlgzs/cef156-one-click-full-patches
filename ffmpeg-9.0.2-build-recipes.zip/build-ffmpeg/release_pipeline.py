#!/usr/bin/env python3
"""Persistent sequential FFmpeg build/validate/archive/cleanup pipeline."""
import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import time

NATIVE = ['linux-x64', 'windows-x64', 'windows-x86', 'windows-arm64',
          'linux-arm64', 'mac-arm64', 'mac-x64']


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--cef-root', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=14)
    a = p.parse_args()
    root, cef = a.root.resolve(), a.cef_root.resolve()
    here = Path(__file__).resolve().parent
    state = root / 'state/release-pipeline.json'
    record = {'targets': NATIVE + ['wasm32'], 'phase': 'running', 'completed': [], 'failures': {},
              'started_utc': dt.datetime.now(dt.timezone.utc).isoformat()}

    def save():
        state.write_text(json.dumps(record, indent=2) + '\n')

    def run(script, *arguments):
        cmd = [sys.executable, str(here / script), '--root', str(root), *map(str, arguments)]
        print('PIPELINE_COMMAND', json.dumps(cmd), flush=True)
        subprocess.run(cmd, cwd=root, check=True)

    for target in NATIVE + ['wasm32']:
        try:
            record['current_target'] = target
            save()
            receipt = root / 'state' / ('archive-' + target + '.json')
            if receipt.exists():
                info = json.loads(receipt.read_text())
                from package_ffmpeg import digest
                if not info.get('sdk_complete') or digest(Path(info['archive'])) != info['archive_sha256']:
                    raise RuntimeError('Existing published artifact changed: ' + target)
                if 'recycled_intermediate_directories' not in info:
                    run('publish_sdk.py', '--target', target, '--cleanup')
                record['completed'].append(target)
                save()
                continue
            if target == 'linux-x64':
                # Respect the actual build already running at dispatch time.
                while subprocess.run(['systemctl', 'is-active', '--quiet', 'mycef-ffmpeg-linux-x64']).returncode == 0:
                    time.sleep(30)
            if target != 'wasm32':
                build_state = root / 'state' / ('build-' + target + '.json')
                built = json.loads(build_state.read_text()) if build_state.exists() else {}
                if built.get('phase') != 'compiled' or built.get('returncode') != 0:
                    run('build_ffmpeg.py', '--cef-root', cef, '--target', target, '--jobs', a.jobs)
                sdk = root / 'output' / ('ffmpeg_9.0.2_' + target + '_release')
                if not sdk.exists():
                    run('package_ffmpeg.py', '--cef-root', cef, '--target', target)
                validator = 'validate_linux_sdk.py' if target.startswith('linux-') else 'validate_cross_sdk.py'
                run(validator, '--cef-root', cef, '--target', target)
            else:
                # FFmpeg 9's actual CLI scheduler requires threads.
                for mode in ('threads',):
                    variant = root / 'state' / ('build-wasm-' + mode + '.json')
                    built = json.loads(variant.read_text()) if variant.exists() else {}
                    if built.get('phase') != 'compiled':
                        run('build_wasm.py', '--mode', mode, '--jobs', a.jobs)
                sdk = root / 'output/ffmpeg_9.0.2_wasm32_release'
                if not sdk.exists():
                    run('package_wasm.py')
                run('validate_wasm.py')
            run('publish_sdk.py', '--target', target, '--cleanup')
            record['completed'].append(target)
            save()
        except Exception as exc:
            # Keep all feature requirements and evidence. An independent target
            # can use the paid machine while the failed target is being fixed.
            record['failures'][target] = {'error': str(exc), 'utc': dt.datetime.now(dt.timezone.utc).isoformat()}
            save()
            print('TARGET_REQUIRES_FIX_CONTINUING_QUEUE', target, str(exc), flush=True)
    if record['failures']:
        record.update(phase='targets_require_fixes', stopped_utc=dt.datetime.now(dt.timezone.utc).isoformat())
        save()
        raise SystemExit(1)
    record.update(phase='eight_archives_verified_pending_local_download_audit',
                  finished_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    save()
    print('EIGHT_FFMPEG_RELEASE_ARCHIVES_VERIFIED', flush=True)


if __name__ == '__main__':
    main()
