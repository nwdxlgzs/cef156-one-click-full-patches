#!/usr/bin/env python3
"""Stage compiled WASM ABIs, portable archives, tools and integration sources."""
import argparse
import json
from pathlib import Path
import re
import shutil

from prepare_wasm import LIBRARIES
from wasm_metadata import normalize

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
a = p.parse_args()
root = a.root.resolve()
stage = root / 'output/ffmpeg_9.0.2_wasm32_release'
if stage.exists():
    raise RuntimeError('Preserve and inspect the existing WASM SDK before restaging')
for mode in ('threads',):
    record = json.loads((root / 'state' / ('build-wasm-' + mode + '.json')).read_text())
    if record.get('phase') != 'compiled':
        raise RuntimeError('WASM ABI is not compiled: ' + mode)
stage.mkdir(parents=True)
shutil.copytree(Path(__file__).resolve().parent / 'wasm-examples', stage / 'examples')
shutil.copy2(Path(__file__).resolve().parent / 'examples/media-info.c', stage / 'examples/c-api/media-info.c')
validation = stage / 'validation'
validation.mkdir()
(stage / 'licenses/emscripten').mkdir(parents=True)
shutil.copy2(root / 'toolchains/emsdk/upstream/emscripten/LICENSE', stage / 'licenses/emscripten/LICENSE')
recipes = stage / 'build-recipes'
recipes.mkdir()
for source in Path(__file__).resolve().parent.glob('*.py'):
    shutil.copy2(source, recipes / source.name)
for source in ('x265-multilib', 'overlay-ports-wasm', 'overlay-ports'):
    original = Path(__file__).resolve().parent / source if source == 'x265-multilib' else root / source
    shutil.copytree(original, recipes / source)
variants = {}
for mode in ('threads',):
    prefix = root / 'wasm-install' / mode
    installed = root / 'installed' / ('wasm-' + mode) / ('wasm32-mycef-' + mode)
    build = root / 'buildtrees' / ('wasm-' + mode) / 'ffmpeg'
    folder = stage / mode
    folder.mkdir()
    shutil.copytree(installed / 'include', folder / 'include', symlinks=True)
    shutil.copytree(prefix / 'include', folder / 'include', symlinks=True, dirs_exist_ok=True)
    lib = folder / 'lib'
    lib.mkdir()
    for source in (installed / 'lib', prefix / 'lib'):
        for archive in source.glob('*.a'):
            if (lib / archive.name).exists():
                raise RuntimeError('WASM dependency archive name collision: ' + archive.name)
            shutil.copy2(archive, lib / archive.name)
    (lib / 'pkgconfig').mkdir()
    for source in (installed / 'lib/pkgconfig', prefix / 'lib/pkgconfig'):
        for pc in source.glob('*.pc'):
            text = re.sub(r'^prefix=.*$', 'prefix=${pcfiledir}/../..', pc.read_text(), flags=re.M)
            text = text.replace(str(installed), '${prefix}').replace(str(prefix), '${prefix}')
            (lib / 'pkgconfig' / pc.name).write_text(text)
    binaries = folder / 'bin'
    binaries.mkdir()
    tools = folder / 'tools/ffmpeg'
    tools.mkdir(parents=True)
    for name in ('ffmpeg', 'ffprobe'):
        shutil.copy2(build / name, binaries / (name + '.js'))
        for resource in build.glob(name + '*'):
            if resource.suffix in ('.wasm', '.js', '.mjs'):
                shutil.copy2(resource, binaries / resource.name)
        wrapper = tools / name
        wrapper.write_text('#!/bin/sh\nset -eu\nhere=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\n'
                           'exec node "$here/../../../examples/node-runner.cjs" "$here/../../bin/' + name + '.js" "$@"\n')
        wrapper.chmod(0o755)
    licenses = folder / 'licenses'
    for source in (installed / 'share').rglob('*'):
        if source.is_file() and source.name in ('copyright', 'vcpkg.spdx.json'):
            target = licenses / source.relative_to(installed / 'share')
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
    ff_source = root / 'sources/FFmpeg-946fcce07b6dcd0331c8cc609192aeff5e1924f8'
    for name in ('COPYING.GPLv3', 'LICENSE.md'):
        (licenses / 'ffmpeg').mkdir(parents=True, exist_ok=True)
        shutil.copy2(ff_source / name, licenses / 'ffmpeg' / name)
    evidence = validation / mode
    evidence.mkdir()
    flags = {}
    for name in ('config.h', 'config_components.h', 'ffbuild/config.mak'):
        source = build / name
        shutil.copy2(source, evidence / source.name)
        if source.suffix == '.h':
            flags.update({k: int(v) for k, v in re.findall(r'^#define (CONFIG_\w+) ([01])$', source.read_text(), re.M)})
    required = ['CONFIG_GPL', 'CONFIG_VERSION3', 'CONFIG_STATIC', 'CONFIG_FFMPEG', 'CONFIG_FFPROBE',
                'CONFIG_AVCODEC', 'CONFIG_AVFORMAT', 'CONFIG_AVFILTER', 'CONFIG_SWRESAMPLE', 'CONFIG_SWSCALE']
    required += ['CONFIG_' + name.upper() for name in LIBRARIES]
    if any(flags.get(k) != 1 for k in required) or flags.get('CONFIG_NONFREE'):
        raise RuntimeError('Incomplete WASM software/API configuration: ' + mode)
    architecture = (build / 'config.h').read_text()
    if '#define ARCH_WASM 1' not in architecture or '#define HAVE_SIMD128 1' not in architecture:
        raise RuntimeError('FFmpeg was not compiled for its actual WASM SIMD architecture')
    variants[mode] = {'flags': flags, 'sdk_complete': False,
                      'component_counts': {kind.lower(): sum(v for k, v in flags.items() if k.endswith('_' + kind))
                                           for kind in ('ENCODER', 'DECODER', 'FILTER', 'DEMUXER', 'MUXER')}}
    shutil.copy2(root / 'state' / ('build-wasm-' + mode + '.json'), evidence / 'build.json')
shutil.copy2(root / 'state/prepared-wasm.json', validation / 'prepared-wasm.json')
shutil.copy2(root / 'state/source-ffmpeg.json', validation / 'source-ffmpeg.json')
features = {'target': 'wasm32', 'configuration': 'Release', 'variants': variants,
            'sdk_complete': False, 'runtime_verified': False,
            'scope': 'Actual compiled JS/WASM and static archives staged; browser/Node execution remains a separate validation gate.'}
normalize(stage)
(stage / 'FEATURES.json').write_text(json.dumps(features, indent=2) + '\n')
(stage / 'README.zh-CN.md').write_text('''# FFmpeg 9.0.2 WebAssembly 开发包

本包使用 threads（多线程）ABI，bin 含真正的 JS/WASM 工具，include/lib 含静态开发库和依赖。
请查看 FEATURES.json 和 validation 中的真实编译与运行记录，确认具体功能。

运行 `python examples/serve.py` 后打开提示的本地地址，可用浏览器完成 H.264/AAC MP4 转码。
多线程需要 COOP: same-origin、COEP: require-corp，并通过 localhost 或 HTTPS 提供服务。
FFmpeg 9 的 CLI 调度器依赖线程；此包不提供单线程 CLI 回退。
将浏览器示例集成到 CEF 时也需要满足页面源及这些响应头条件。

浏览器 API：新建 examples/worker.js Worker，传入 base（对应 ABI 的 bin 目录 URL）、args、files（name/data）和 outputs 文件名列表。
每个任务使用独立 Worker，收到 done 后读取输出数据并 terminate，避免旧任务的退出状态污染下一个任务。
可先用 fetch 获取远程媒体，再以 ArrayBuffer 放进虚拟文件系统。原生 TCP/UDP/SRT/SSH 等协议及 NVENC/QSV/VideoToolbox 等驱动接口不适用于此浏览器模块。
浏览器通过 video/canvas 播放结果；不提供原生桌面 ffplay 可执行文件。

C/C++ 扩展需要使用锁定的 Emscripten 7.0.0；线程标志和 SIMD 标志必须与对应 ABI 一致。原生 DLL/so 不能加载这些静态归档。
WASM 使用独立内存和虚拟文件系统；字体、字幕文件等需由应用写入虚拟文件系统，并在滤镜参数中指定路径。
此包为 wasm32 + SIMD128，线性内存上限 4 GiB，实际可用空间受浏览器限制；示例同时保留输入和输出，处理大文件需控制拷贝并分段设计。
模块预创建 16 个 pthread Worker；示例限制编解码和滤镜线程数。自定义复杂图时应显式控制线程，超出池大小会报错；可用随包源码修改池大小后重新链接。
GPL 组件和上游源码信息见许可证、SPDX 与源码锁记录；本包不启用 FFmpeg nonfree。
''', encoding='utf-8')
print('FFMPEG_WASM_SDK_STAGED_PENDING_RUNTIME_VALIDATION', stage, flush=True)
