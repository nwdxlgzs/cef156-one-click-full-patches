#!/usr/bin/env python3
"""Download one pinned public release asset with checked HTTP byte ranges."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--asset', type=Path, required=True)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=12)
    a = p.parse_args()
    item = json.loads(a.asset.read_text())
    expected = item['digest'].removeprefix('sha256:')
    if len(expected) != 64:
        raise RuntimeError('Missing upstream SHA256')
    size = item['size']
    a.directory.mkdir(parents=True, exist_ok=True)
    final = a.directory / item['name']
    if final.exists():
        if final.stat().st_size == size and hashlib.sha256(final.read_bytes()).hexdigest() == expected:
            print('ALREADY_VERIFIED', final, flush=True)
            return
        raise RuntimeError('Existing final file differs')
    parts = final.with_name(final.name + '.parts')
    parts.mkdir(exist_ok=True)
    block = 1024 * 1024
    count = (size + block - 1) // block
    pending = final.with_name(final.name + '.pending')
    if pending.is_file():
        with pending.open('rb') as f:
            for i in range(min(count, pending.stat().st_size // block)):
                part = parts / str(i)
                data = f.read(block)
                if not part.exists():
                    part.write_bytes(data)
    url = subprocess.check_output(['curl', '-fsIL', '--connect-timeout', '10',
        '--max-time', '30', '--retry', '4', '--retry-all-errors',
        '-o', os.devnull, '-w', '%{url_effective}',
        item['browser_download_url']], text=True).strip()

    def fetch(i):
        start, length = i * block, min(block, size - i * block)
        part = parts / str(i)
        if part.is_file() and part.stat().st_size == length:
            return
        for attempt in range(5):
            try:
                temporary = part.with_suffix('.pending')
                received = temporary.stat().st_size if temporary.exists() else 0
                if received > length:
                    raise RuntimeError('Partial range is larger than its expected length')
                if received == length:
                    temporary.replace(part)
                    part.with_suffix('.headers').unlink(missing_ok=True)
                    return
                next_start = start + received
                remaining = length - received
                tail = part.with_suffix('.tail')
                header = part.with_suffix('.headers')
                result = subprocess.run(['curl', '-fsS', '--connect-timeout', '10',
                    '--max-time', '120', '--max-filesize', str(remaining),
                    '--range', f'{next_start}-{start + length - 1}', '-H', 'Cache-Control: no-cache',
                    '-D', str(header), '-o', str(tail), '-w', '%{http_code}', url],
                    text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                code = result.stdout.strip()
                headers = header.read_text().lower().splitlines()
                if code != '206' or f'content-range: bytes {next_start}-{start + length - 1}/{size}' not in headers:
                    raise RuntimeError('Server did not honor the requested range')
                if tail.stat().st_size > remaining:
                    raise RuntimeError('Range response exceeded requested length')
                with temporary.open('ab') as f:
                    f.write(tail.read_bytes())
                tail.unlink()
                if temporary.stat().st_size != length:
                    raise RuntimeError('Partial range retained for resume')
                temporary.replace(part)
                header.unlink()
                print('RANGE', i, length, flush=True)
                return
            except Exception:
                if attempt == 4:
                    raise
                time.sleep(2 + attempt)
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        list(pool.map(fetch, range(count)))
    assembled = final.with_name(final.name + '.assembling')
    with assembled.open('wb') as f:
        for i in range(count):
            f.write((parts / str(i)).read_bytes())
        f.flush()
        os.fsync(f.fileno())
    if assembled.stat().st_size != size or hashlib.sha256(assembled.read_bytes()).hexdigest() != expected:
        raise RuntimeError('Release asset SHA256 differs; retain parts')
    assembled.rename(final)
    for i in range(count):
        (parts / str(i)).unlink()
    parts.rmdir()
    if pending.exists():
        pending.unlink()
    print('ASSET_VERIFIED', final.name, expected, flush=True)


if __name__ == '__main__':
    main()
