#!/usr/bin/env python3
"""Audit genuine PE/Mach-O outputs and independently link the C API example."""
import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--cef-root', type=Path, required=True)
p.add_argument('--target', required=True)
a = p.parse_args()
root, cef = a.root.resolve(), a.cef_root.resolve()
platform, cpu = a.target.split('-')
if platform not in ('mac', 'windows'):
    raise RuntimeError('This validator handles Windows and macOS cross outputs')
sdk = root / 'output' / ('ffmpeg_9.0.2_' + a.target + '_release')
tools = sdk / ('bin' if platform == 'windows' else 'tools/ffmpeg')
library = sdk / 'lib'
sys.path.insert(0, '/opt/mycef/build-cef')
from archive_posix import digest_file

records = []
if platform == 'mac':
    from audit_macho import inspect, version_tuple
    from macho_adhoc import verify as verify_adhoc
    llvm = cef / 'chromium/src/third_party/llvm-build/Release+Asserts/bin'
    editor = llvm / 'llvm-install-name-tool'
    for path in sorted(list(library.iterdir()) + list(tools.iterdir())):
        if path.is_symlink() or not path.is_file():
            continue
        with path.open('rb') as f:
            if f.read(4) != b'\xcf\xfa\xed\xfe':
                continue
        info = inspect(path)
        cmd = [str(editor)]
        for dependency in info['dylibs']:
            name = dependency['name']
            if name.startswith(('/usr/lib/', '/System/Library/')):
                continue
            base = Path(name).name
            if not (library / base).is_file():
                raise RuntimeError('Unresolved macOS SDK runtime library: ' + name)
            replacement = '@loader_path/' + (base if path.parent == library else '../../lib/' + base)
            if dependency['id']:
                replacement = '@rpath/' + path.name
                if replacement != name:
                    cmd += ['-id', replacement]
            elif replacement != name:
                cmd += ['-change', name, replacement]
        for rpath in info['rpaths']:
            if rpath.startswith('/home/'):
                cmd += ['-delete_rpath', rpath]
        if len(cmd) > 1:
            subprocess.run(cmd + [str(path)], check=True)
        info = inspect(path)
        if info['architecture'] != cpu or not info['versions'] or any(
                version_tuple(v['minimum']) > version_tuple('13.0') for v in info['versions']):
            raise RuntimeError('Wrong CPU or macOS deployment requirement: ' + str(path))
        signature = verify_adhoc(path, info['code_signature'])
        records.append({'file': path.relative_to(sdk).as_posix(), 'sha256': digest_file(path), 'macho': info,
                        'adhoc_signature': signature})
else:
    llvm = root / 'toolchains/llvm-mingw/bin'
    machines = {'x64': 'IMAGE_FILE_MACHINE_AMD64', 'x86': 'IMAGE_FILE_MACHINE_I386', 'arm64': 'IMAGE_FILE_MACHINE_ARM64'}
    # OS DLLs are resolved by Windows; SDK/private DLLs must accompany the tools.
    system = {'kernel32.dll', 'user32.dll', 'gdi32.dll', 'advapi32.dll', 'shell32.dll',
              'ole32.dll', 'oleaut32.dll', 'uuid.dll', 'ws2_32.dll', 'msvcrt.dll',
              'ntdll.dll', 'bcrypt.dll', 'crypt32.dll', 'secur32.dll', 'iphlpapi.dll',
              'winmm.dll', 'version.dll', 'dwmapi.dll', 'imm32.dll', 'setupapi.dll',
              'shlwapi.dll', 'comdlg32.dll', 'comctl32.dll', 'psapi.dll', 'cfgmgr32.dll',
              'd3d11.dll', 'dxgi.dll', 'd3d9.dll', 'dxva2.dll', 'opengl32.dll',
              'mf.dll', 'mfplat.dll', 'mfreadwrite.dll', 'mfuuid.dll', 'strmiids.dll',
              'avrt.dll', 'propsys.dll', 'uxtheme.dll', 'winhttp.dll', 'wininet.dll',
              'normaliz.dll', 'netapi32.dll', 'userenv.dll', 'powrprof.dll', 'msimg32.dll',
              'dinput8.dll', 'hid.dll', 'usp10.dll', 'mswsock.dll', 'dnsapi.dll',
              'wtsapi32.dll', 'msacm32.dll', 'quartz.dll', 'dwrite.dll', 'd2d1.dll', 'avicap32.dll'}
    bundled = {path.name.lower() for path in tools.glob('*.dll')}
    for path in sorted(list(tools.glob('*.dll')) + list(tools.glob('*.exe'))):
        report = subprocess.check_output([str(llvm / 'llvm-readobj'), '--file-headers', '--coff-imports', str(path)], text=True)
        if machines[cpu] not in report:
            raise RuntimeError('PE machine mismatch: ' + str(path))
        imports = re.findall(r'^\s+Name: (\S+\.dll)\s*$', report, re.M | re.I)
        unresolved = [name for name in imports if name.lower() not in bundled | system
                      and not name.lower().startswith(('api-ms-win-', 'ext-ms-win-'))]
        if unresolved:
            raise RuntimeError('Unresolved Windows SDK imports: ' + repr(unresolved))
        records.append({'file': path.relative_to(sdk).as_posix(), 'sha256': digest_file(path),
                        'machine': machines[cpu], 'imported_dlls': imports,
                        'imported_symbols': re.findall(r'^\s+Symbol: (.+)$', report, re.M)})

work = root / 'validation' / (a.target + '-c-api')
work.mkdir(parents=True, exist_ok=True)
build = work / 'build'
subprocess.run([str(root / 'host-tools/bin/cmake'), '-S', str(sdk / 'examples'), '-B', str(build),
                '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
                '-DCMAKE_TOOLCHAIN_FILE=' + str(root / 'toolchains' / (a.target + '.cmake'))], check=True)
subprocess.run([str(root / 'host-tools/bin/cmake'), '--build', str(build), '-j', '2'], check=True)
binary = build / ('media-info.exe' if platform == 'windows' else 'media-info')
if not binary.is_file() or not records:
    raise RuntimeError('No actual cross-linked C API consumer or target runtime files')
scope = ('Real target CPU/import/deployment inspection, relocatable SDK runtime closure and an independently cross-linked public C API example. '
         'No target execution, Windows 7 runtime verification, macOS hardware/media execution or distribution signing is claimed.')
record = {'target': a.target, 'passed': True, 'runtime_verified': False, 'files': records,
          'demo_sha256': digest_file(binary), 'scope': scope}
path = root / 'state' / ('runtime-' + a.target + '.json')
path.write_text(json.dumps(record, indent=2) + '\n')
shutil.copy2(path, sdk / 'validation/cross-sdk.json')
print('FFMPEG_CROSS_SDK_API_AND_BINARY_AUDIT_PASSED', a.target, flush=True)
