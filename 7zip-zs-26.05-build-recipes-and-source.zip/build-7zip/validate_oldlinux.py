#!/usr/bin/env python3
"""Execute full 7-Zip ZS C ABI and CLI tests in Linux 4.9/glibc 2.28 guests."""
import argparse
import datetime as dt
import json
from pathlib import Path
import shutil
import subprocess
import sys

from build_sdk import VERSION,digest


def validate(root,target):
    cpu=target.split('-')[1];arch='amd64' if cpu=='x64' else 'arm64'
    cef=Path('/home/ubuntu/cef156');sdk=root/'output'/('7zip-zs_'+VERSION+'_'+target+'_release')
    work=root/'validation'/(target+'-oldlinux-'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S'));work.mkdir(parents=True)
    shutil.copy2(Path(__file__).resolve().parent/'probe_sdk.py',work/'probe_sdk.py')
    for mode in ['shared','static']:
        shutil.copy2(root/'validation'/target/(mode+'-example/zs-roundtrip'),work/('zs-'+mode))
    (work/'reports').mkdir(mode=0o777);(work/'reports').chmod(0o777)
    script='''set -eu
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export LC_ALL=C
uname -a
ldd --version
export LD_LIBRARY_PATH=/opt/mycef-sdk/lib
/usr/sbin/runuser -u nobody -- /usr/bin/env LD_LIBRARY_PATH=/opt/mycef-sdk/lib /opt/mycef-validation/zs-shared ZSTD
/usr/sbin/runuser -u nobody -- /usr/bin/env LD_LIBRARY_PATH=/opt/mycef-sdk/lib /opt/mycef-validation/zs-static FLZMA2
/usr/sbin/runuser -u nobody -- /usr/bin/python3 /opt/mycef-validation/probe_sdk.py --sdk /opt/mycef-sdk --output /opt/mycef-validation/reports
echo MYCEF_7ZIP_OLDLINUX_OK
'''
    (work/'guest-run.sh').write_text(script)
    boot=json.loads((cef/'state'/('linux49-vm-'+arch+'-runtime.json')).read_text())
    for k in ['kernel','initramfs']:
        if digest(Path(boot[k]))!=boot[k+'_sha256']:raise RuntimeError('Validated guest boot input differs')
    if cpu=='x64':
        cmd=['qemu-system-x86_64','-machine','q35,accel=tcg','-cpu','max','-append','console=ttyS0 panic=-1 rdinit=/init',
             '-virtfs','local,path='+str(cef/'validation/oldlinux/buster-x64')+',mount_tag=oldroot,security_model=none']
    else:
        cmd=['qemu-system-aarch64','-machine','virt,accel=tcg,gic-version=2','-cpu','cortex-a72','-append','console=ttyAMA0 panic=-1 rdinit=/init',
             '-drive','file='+str(cef/'cache/oldlinux/buster-arm64.img')+',format=raw,if=virtio']
    cmd+=['-m','4096','-smp','4','-kernel',boot['kernel'],'-initrd',boot['initramfs'],'-display','none','-monitor','none','-serial','stdio',
          '-no-reboot','-nic','none','-virtfs','local,path='+str(work)+',mount_tag=exchange,security_model=mapped-xattr',
          '-virtfs','local,path='+str(sdk)+',mount_tag=sdk,security_model=none,readonly=on']
    log=work/'vm.log'
    with log.open('w') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
    text=log.read_text(errors='replace');report=work/'reports/runtime.json'
    data=json.loads(report.read_text()) if report.exists() else {}
    if r.returncode or 'MYCEF_GUEST_VALIDATION_FAILED' in text or 'MYCEF_7ZIP_OLDLINUX_OK' not in text or not data.get('passed'):
        raise RuntimeError('Old Linux execution failed: '+str(log))
    if '4.9.' not in data['platform'] or data['machine']!=('x86_64' if cpu=='x64' else 'aarch64'):
        raise RuntimeError('Guest execution platform differs')
    record={'target':target,'passed':True,'runtime_verified':True,'guest_kernel':'Linux 4.9','guest_glibc':'2.28',
            'probe':data,'vm_log_sha256':digest(log),'scope':'Shared/static C consumers and 30 real library/CLI codec, container, UTF-8 and password tests in a Linux 4.9/glibc 2.28 full-system guest.'}
    p=root/'state'/('runtime-'+target+'.json');p.write_text(json.dumps(record,indent=2)+'\n');shutil.copy2(p,sdk/'validation/oldlinux-runtime.json')
    print('SEVENZIP_LINUX49_GLIBC228_RUNTIME_PASSED',target,flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--target',required=True)
    a=p.parse_args();validate(a.root.resolve(),a.target)
