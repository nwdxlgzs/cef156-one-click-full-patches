#!/usr/bin/env python3
"""Serve an SDK with optional cross-origin isolation for its pthread ABI."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8080);p.add_argument('--no-isolation',action='store_true');a=p.parse_args()
class Handler(SimpleHTTPRequestHandler):
    extensions_map={**SimpleHTTPRequestHandler.extensions_map,'.wasm':'application/wasm'}
    def end_headers(self):
        if not a.no_isolation:
            self.send_header('Cross-Origin-Opener-Policy','same-origin')
            self.send_header('Cross-Origin-Embedder-Policy','require-corp')
        super().end_headers()
root=Path(__file__).resolve().parent.parent
print('Open http://127.0.0.1:'+str(a.port)+'/examples/',flush=True)
ThreadingHTTPServer(('127.0.0.1',a.port),partial(Handler,directory=str(root))).serve_forever()
