// Usage: node node-cli.cjs <SDK>/bin/7zz.js <ordinary 7zz arguments>
// NODEFS supplies real host file access for the terminal entry point.
const path = require('node:path');
const [moduleFile, ...args] = process.argv.slice(2);
if (!moduleFile) throw new Error('Expected path to bin/7zz.js');
(async () => {
  const factory = require(path.resolve(moduleFile));
  const module = await factory({
    print: line => process.stdout.write(line + '\n'),
    printErr: line => process.stderr.write(line + '\n'),
  });
  module.FS.mkdir('/host');
  module.FS.mount(module.NODEFS, { root: path.parse(process.cwd()).root }, '/host');
  const toVirtual = p => '/host/' + path.resolve(p).slice(path.parse(process.cwd()).root.length).replaceAll('\\', '/');
  module.FS.chdir(toVirtual(process.cwd()));
  const virtualArgs = args.map(arg => path.isAbsolute(arg) ? toVirtual(arg) :
    arg.startsWith('-o') && path.isAbsolute(arg.slice(2)) ? '-o' + toVirtual(arg.slice(2)) : arg);
  let code = 0;
  try { code = module.callMain(virtualArgs) || 0; }
  catch (error) { if (typeof error.status === 'number') code = error.status; else throw error; }
  process.stdout.write('', () => process.stderr.write('', () => process.exit(code)));
})().catch(error => { console.error(error); process.exit(1); });
