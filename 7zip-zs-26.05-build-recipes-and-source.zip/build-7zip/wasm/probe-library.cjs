const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const [sdk, target, report] = process.argv.slice(2);
const methods = ['LZMA2','ZSTD','BROTLI','LZ4','LZ5','LIZARD','FLZMA2'];
(async () => {
  const m = await require(path.resolve(sdk,'lib/sevenzip.js'))();
  const view = () => new DataView(m.HEAPU8.buffer);
  const alloc = n => { const p=m._malloc(Math.max(1,n));assert(p);return p; };
  const text = s => { if(s===null)return 0;const n=m.lengthBytesUTF8(s)+1,p=alloc(n);m.stringToUTF8(s,p,n);return p; };
  const check = r => {if(r)throw new Error(m.UTF8ToString(m._zs_last_error()));};
  const payload=Buffer.concat([Buffer.from(Array.from({length:65536},(_,i)=>i&255)),Buffer.from('中文/✨\n'.repeat(100))]);
  const names=['文档','文档/数据.bin','empty'];
  const source=alloc(payload.length);m.HEAPU8.set(payload,source);
  const entries=alloc(48),utf=names.map(text);
  for(let i=0;i<3;i++){
    view().setUint32(entries+i*16,utf[i],true);
    view().setUint32(entries+i*16+4,i===1?source:0,true);
    view().setUint32(entries+i*16+8,i===1?payload.length:0,true);
    view().setUint32(entries+i*16+12,i===0?1:0,true);
  }
  const ptr=alloc(4),len=alloc(4),handleOut=alloc(4),countOut=alloc(4),info=alloc(24);
  const format7z=text('7z'),tests=[];
  function pack(format,method,password,threads){
    const f=text(format),mth=text(method),pw=text(password);
    try {
      check(m._zs_create(f,mth,3,threads,pw,entries,3,8*1024*1024,ptr,len));
      const p=view().getUint32(ptr,true),n=view().getUint32(len,true);
      const data=Buffer.from(m.HEAPU8.slice(p,p+n));m._zs_free(p);return data;
    }finally{m._free(f);if(mth)m._free(mth);if(pw)m._free(pw);}
  }
  function unpack(data,format,password){
    const p=alloc(data.length),fmt=text(format),pw=text(password);m.HEAPU8.set(data,p);
    let h=0;
    try {
      check(m._zs_open(fmt,p,data.length,pw,handleOut));h=view().getUint32(handleOut,true);
      check(m._zs_entry_count(h,countOut));assert.equal(view().getUint32(countOut,true),3);
      let found=false;
      for(let i=0;i<3;i++){
        check(m._zs_entry_info(h,i,info));const name=m.UTF8ToString(view().getUint32(info,true));
        if(view().getUint32(info+16,true))continue;
        check(m._zs_extract_entry(h,i,2*1024*1024,ptr,len));const out=view().getUint32(ptr,true),n=view().getUint32(len,true);
        const bytes=Buffer.from(m.HEAPU8.slice(out,out+n));m._zs_free(out);
        if(name==='文档/数据.bin'){
          assert.deepEqual(bytes,payload);found=true;
          assert.notEqual(m._zs_extract_entry(h,i,1,ptr,len),0);
        }else assert.equal(name,'empty');
      }
      assert(found);
    }finally{if(h)m._zs_close(h);m._free(p);m._free(fmt);if(pw)m._free(pw);}
  }
  for(const method of methods){
    console.log('WASM_CODEC',target,method);
    const threads=target==='wasm-single'?[1]:[1,2];
    for(const n of threads){
      const data=pack('7z',method,null,n);unpack(data,'7z',null);unpack(data,'auto',null);
      tests.push({method,threads:n,passed:true,archive_sha256:crypto.createHash('sha256').update(data).digest('hex')});
    }
  }
  for(const format of ['7z','zip','tar']){
    const pw=format==='7z'?'口令-secret':format==='zip'?'secret-ASCII':null;
    const data=pack(format,null,pw,1);unpack(data,format,pw);
    if(pw)assert.throws(()=>unpack(data,format,'wrong'));
    tests.push({format,password:!!pw,wrong_password_rejected:!!pw,passed:true});
  }
  if(target==='wasm-single')assert.notEqual(m._zs_create(format7z,0,3,2,0,entries,3,1024,ptr,len),0);
  check(m._zs_formats_json(ptr));const formatsPtr=view().getUint32(ptr,true),formats=JSON.parse(m.UTF8ToString(formatsPtr));m._zs_free(formatsPtr);
  for(const f of ['7z','zip','tar','Rar','Rar5'])assert(formats.includes(f));
  const result={target,passed:true,version:m.UTF8ToString(m._zs_version()),tests,formats,
    scope:'Actual WASM C library: seven software codecs, multi/one-thread use, UTF-8/binary/empty/directory entries, auto detection, size caps, encrypted 7z/ZIP and wrong-password rejection.'};
  fs.writeFileSync(report,JSON.stringify(result,null,2)+'\n');
  console.log('SEVENZIP_WASM_LIBRARY_PASSED',target,tests.length);
  process.exit(0);
})().catch(e=>{console.error(e);process.exit(1);});
