// The module's pthreads restart this worker URL. Preserve its selected module.
const moduleUrl = new URL(new URL(location.href).searchParams.get('module') || '../lib/sevenzip.js', location.href).href;
const isCLI = moduleUrl.endsWith('/7zz.js');
if (self.name?.startsWith('em-pthread')) {
  importScripts(moduleUrl);
} else self.onmessage = async event => {
  try {
    importScripts(moduleUrl);
    const factory = isCLI ? self.createSevenZipCLI : self.createSevenZipLibrary;
    const module = await factory({
      locateFile: name => new URL(name, moduleUrl).href,
      print: line => self.postMessage({ log: line }),
      printErr: line => self.postMessage({ log: line }),
    });
    const { operation, files = [], method = 'ZSTD', password = null, threads = 1, archive, args = [], outputs = [] } = event.data;
    if (isCLI) {
      for (const file of files) {
        const parts = file.name.split('/').filter(Boolean); parts.pop();
        let directory = '';
        for (const p of parts) { directory += '/' + p; try { module.FS.mkdir(directory); } catch (_) {} }
        module.FS.writeFile(file.name, new Uint8Array(file.data));
      }
      let status = 0;
      try { status = module.callMain(args) || 0; }
      catch (e) { if (typeof e.status === 'number') status = e.status; else throw e; }
      if (status) throw new Error('7zz exited with status ' + status);
      const results = outputs.map(name => ({ name, data: module.FS.readFile(name).slice().buffer }));
      self.postMessage({ done: true, results }, results.map(x => x.data));
      return;
    }
    const heap = () => module.HEAPU8;
    const view = () => new DataView(heap().buffer);
    const allocated = [];
    const alloc = size => {
      const p = module._malloc(Math.max(1, size));
      if (!p) throw new Error('WASM memory allocation failed');
      allocated.push(p); return p;
    };
    const text = s => {
      if (s === null) return 0;
      const p = alloc(module.lengthBytesUTF8(s) + 1); module.stringToUTF8(s, p, module.lengthBytesUTF8(s) + 1); return p;
    };
    const check = status => { if (status) throw new Error(module.UTF8ToString(module._zs_last_error())); };
    let handle = 0;
    try {
      let packed;
      if (operation === 'pack') {
        const entries = alloc(files.length * 16);
        files.forEach((file, i) => {
          const bytes = new Uint8Array(file.data), payload = alloc(bytes.length), name = text(file.name);
          heap().set(bytes, payload);
          view().setUint32(entries+i*16, name, true);
          view().setUint32(entries+i*16+4, payload, true);
          view().setUint32(entries+i*16+8, bytes.length, true);
          view().setUint32(entries+i*16+12, 0, true);
        });
        const output = alloc(4), size = alloc(4);
        check(module._zs_create(text('7z'), text(method), 3, threads, text(password), entries, files.length, 128*1024*1024, output, size));
        const pointer = view().getUint32(output,true), length = view().getUint32(size,true);
        packed = heap().slice(pointer, pointer + length); module._zs_free(pointer);
      } else if (operation === 'unpack') {
        packed = new Uint8Array(archive);
      } else throw new Error('Expected pack or unpack');
      const input = alloc(packed.length); heap().set(packed, input);
      const archiveOut = alloc(4);check(module._zs_open(text('7z'), input, packed.length, text(password), archiveOut));
      handle = view().getUint32(archiveOut,true);
      const countOut = alloc(4);check(module._zs_entry_count(handle,countOut));
      const count = view().getUint32(countOut,true), results = [], metadata = [];
      for (let i = 0; i < count; ++i) {
        const entry = alloc(24);check(module._zs_entry_info(handle,i,entry));
        const name = module.UTF8ToString(view().getUint32(entry,true));
        const directory = view().getUint32(entry+16,true);
        metadata.push({ name, directory: !!directory });
        if (directory) continue;
        const out = alloc(4), size = alloc(4);check(module._zs_extract_entry(handle,i,128*1024*1024,out,size));
        const pointer = view().getUint32(out,true), length = view().getUint32(size,true);
        results.push({ name, data: heap().slice(pointer,pointer+length).buffer }); module._zs_free(pointer);
      }
      const archiveData = packed.slice().buffer;
      self.postMessage({ done: true, archive: archiveData, results, metadata,
        version: module.UTF8ToString(module._zs_version()) }, [archiveData, ...results.map(x=>x.data)]);
    } finally {
      if (handle) module._zs_close(handle);
      for (const p of allocated) module._free(p);
    }
  } catch (error) { self.postMessage({ error: String(error.stack || error) }); }
};
