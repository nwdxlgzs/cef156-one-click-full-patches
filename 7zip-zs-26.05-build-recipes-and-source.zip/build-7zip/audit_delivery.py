#!/usr/bin/env python3
"""Verify the nine delivered packages and write their developer-facing index."""
import argparse
import datetime as dt
import json
from pathlib import Path

from build_sdk import TARGETS,VERSION,digest


def audit(destination):
    records={}
    for target in TARGETS:
        name='7zip-zs_'+VERSION+'_'+target+'_release';archive=destination/(name+'.tar.zst');sdk=destination/name
        receipt=json.loads(archive.with_name(archive.name+'.verified.json').read_text())
        if (not receipt.get('locally_finalized') or not receipt.get('all_final_payloads_readback_verified') or
            not receipt.get('compiled_assets_unchanged') or archive.stat().st_size!=receipt['bytes'] or digest(archive)!=receipt['archive_sha256']):
            raise RuntimeError('Final SDK identity or readback check failed: '+target)
        manifest=json.loads((sdk/'SHA256SUMS.json').read_text())
        for relative,info in manifest.items():
            p=sdk/relative
            if info['type']=='file' and (not p.is_file() or p.stat().st_size!=info['bytes'] or digest(p)!=info['sha256']):
                raise RuntimeError('Extracted SDK payload differs: '+str(p))
            if info['type']=='symlink' and (not p.is_symlink() or p.readlink().as_posix()!=info['target']):
                raise RuntimeError('Extracted SDK link differs')
        features=json.loads((sdk/'FEATURES.json').read_text())
        if not features['sdk_complete'] or not features['static_library'] or not (sdk/'include/sevenzip_zs.h').is_file():
            raise RuntimeError('SDK development files missing')
        if target.startswith('wasm-'):
            for p in ['lib/sevenzip.js','lib/sevenzip.wasm','bin/7zz.js','bin/7zz.wasm','lib/lib7zipzs.a']:
                if not (sdk/p).is_file():raise RuntimeError('WASM library/CLI payload missing')
            node=json.loads((sdk/'validation/wasm-runtime.json').read_text())
            browser=json.loads((sdk/'validation/browser-runtime.json').read_text())
            if not node['passed'] or not browser['passed']:raise RuntimeError('WASM runtime evidence failed')
            for inputs in [node['module_inputs'],browser['inputs']]:
                for relative,sha in inputs.items():
                    if digest(sdk/relative)!=sha:raise RuntimeError('WASM verification used a different file')
            scope='Node: 库/CLI/独立静态 C 示例；Chrome: 七种算法、加密、CLI；'+('无 SAB/隔离运行通过' if target=='wasm-single' else 'COOP/COEP 多线程运行通过')
        elif target.startswith('linux-'):
            evidence=json.loads((sdk/'validation/oldlinux-runtime.json').read_text())
            if not evidence['passed'] or not evidence['runtime_verified']:raise RuntimeError('Old Linux execution gate failed')
            lib=sdk/'lib/lib7zipzs.so';cli=sdk/'bin/7zz'
            if digest(lib)!=evidence['probe']['library_sha256'] or digest(cli)!=evidence['probe']['cli_sha256']:
                raise RuntimeError('Old Linux execution used different binaries')
            scope='Linux 4.9/glibc 2.28 对应架构虚拟机：共享/静态示例及 30 项库/CLI 测试通过'
        elif target in ['windows-x64','windows-x86']:
            evidence=json.loads((sdk/'validation/local-windows-runtime.json').read_text())
            if not evidence['passed'] or digest(sdk/'bin/7z.dll')!=evidence['dll_sha256'] or digest(sdk/'lib/7zipzs.lib')!=evidence['import_library_sha256']:
                raise RuntimeError('Local MSVC execution used another DLL/import library')
            scope='本机 MSVC C 程序、14 项库测试及 13 项 CLI 测试通过；Win7 未实测'
        else:
            evidence=json.loads((sdk/'validation/binary-audit.json').read_text())
            if not evidence['passed']:raise RuntimeError('Target binary/link gate failed')
            for item in evidence['files']:
                if digest(sdk/item['file'])!=item['sha256']:raise RuntimeError('Cross audit used different binaries')
            scope='架构、依赖和动态/静态 C 示例链接通过；对应实机运行未验证'
        records[target]={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':receipt['archive_sha256'],
                         'sdk_directory':name,'static_library':'lib/lib7zipzs.a','shared_library':features['shared_library'],
                         'validation':scope,'source_download_sha256':receipt['source_download_sha256'],
                         'final_payload_manifest_sha256':digest(sdk/'SHA256SUMS.json')}
    index={'all_nine_complete':True,'version':VERSION,'audited_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'targets':records}
    (destination/'SDK-INDEX.json').write_text(json.dumps(index,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    rows=['| 目标 | 压缩包 MiB | 验证 |','| --- | ---: | --- |']
    for target,item in records.items():rows.append(f"| {target} | {item['bytes']/1048576:.1f} | {item['validation']} |")
    text='''# 7-Zip ZS：9 个 Release 开发包

版本固定为 **7-Zip ZS 26.05 / Zstd 1.5.7 R1**。本目录同时包含 9 个压缩包与对应解压 SDK，各包自带使用说明、C/C++ 接口头文件、示例、许可证和验证记录。

'''+'\n'.join(rows)+'''

七个原生端提供动态库、静态 `.a`、CLI。Windows 还提供 MSVC 可用的 C ABI DLL 导入库 `.lib`；静态 `.a` 使用对应 Clang/MinGW C++ ABI，不直接与 MSVC C++ 静态链接混用。应用开发推荐先用 `include/sevenzip_zs.h` 和 `examples`；高级流式处理/进度/更新使用随包上游 IArchive 接口。

WASM 单线程、线程版各自提供 **C ABI JS/WASM 库、Emscripten 静态库，以及 CLI JS/WASM 入口**。线程版示例默认以 2 个编解码线程调用，内部预留 16 个 Worker 供归档和编解码工作使用。单线程版无需 SharedArrayBuffer；线程版需要 HTTPS/localhost、COOP/COEP。Node 终端运行 `node examples/node-cli.cjs bin/7zz.js <7zz 参数>`；浏览器运行 `python examples/serve.py` 后打开页面。

扩展算法包含 Zstd、Brotli、LZ4、LZ5、Lizard、Fast-LZMA2，保留 LZMA/LZMA2、ZIP、TAR、WIM、RAR 解压及上游其他归档/哈希/加密实现。RAR 没有压缩器，WASM 不能加载原生 OS 编解码 DLL，也不包含桌面图形界面。7z 扩展算法需使用支持相应算法的解压器。

Linux 兼容目标为 Linux 4.9、glibc 2.28；macOS 最低版本为 13.0。macOS 和 Windows ARM64 通过交叉链接/结构检查，尚未实机运行；Mac 分发签名/公证未执行。Win7 尚未实机认证。

上游源码锁和完整源归档随构建配方压缩包提供。完整成品只从服务器下载一次；Windows 示例的路径分隔符适配、验证报告及最终重新压缩均在本地完成。原始下载和摘要保留于 `source-downloads`，最终包的机器码、静态库与 WASM 字节保持不变。请保留 licenses 内的 LGPL/BSD/unRAR 等声明。
'''
    (destination/'README.zh-CN.md').write_text(text,encoding='utf-8')
    print('NINE_SEVENZIP_SDKS_LOCALLY_AUDITED',sum(x['bytes'] for x in records.values()),flush=True);return index


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);a=p.parse_args();audit(a.destination.resolve())
