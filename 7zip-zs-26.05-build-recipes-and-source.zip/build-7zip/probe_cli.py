#!/usr/bin/env python3
"""Run the full codec/container/crypto CLI suite independently of Python bitness."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess

from probe_sdk import METHODS


def probe(sdk,output):
    sdk,output=Path(sdk).resolve(),Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    cli=sdk/'bin'/('7zz.exe' if platform.system()=='Windows' else '7zz')
    source=output/'input';source.mkdir(exist_ok=True);(source/'中文').mkdir(exist_ok=True)
    data=bytes(range(256))*256+b'CLI independent fixture\n'*100
    (source/'中文/data.bin').write_bytes(data);(source/'empty').write_bytes(b'')
    def run(args,expected=True):
        r=subprocess.run([str(cli),*map(str,args)],cwd=output,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
        if expected and r.returncode:raise RuntimeError(r.stdout.decode(errors='replace')[-5000:])
        return r
    listing=run(['i']).stdout.decode('utf-8','replace');(output/'cli-info.txt').write_text(listing,encoding='utf-8')
    tests=[]
    for method in METHODS:
        if method not in listing:raise RuntimeError('Codec not listed '+method)
        archive=output/(method+'.7z');out=output/('out-'+method)
        run(['a','-y','-m0='+method,'-mx3','-mmt=2',archive,'./input/*']);run(['t',archive]);run(['x','-y','-o'+str(out),archive])
        if (out/'中文/data.bin').read_bytes()!=data or (out/'empty').read_bytes()!=b'':raise RuntimeError('CLI output differs')
        tests.append({'method':method,'passed':True})
    for fmt in ['zip','tar','wim']:
        archive=output/('container.'+fmt);out=output/('out-'+fmt)
        run(['a','-y','-t'+fmt,archive,'./input/*']);run(['t',archive]);run(['x','-y','-o'+str(out),archive])
        if (out/'中文/data.bin').read_bytes()!=data:raise RuntimeError('CLI container output differs')
        tests.append({'format':fmt,'passed':True})
    for method in ['LZMA2','ZSTD','BROTLI']:
        archive=output/('encrypted-'+method+'.7z')
        run(['a','-y','-m0='+method,'-mx3','-mmt=2','-psecret','-mhe=on',archive,'./input/*']);run(['t','-psecret',archive])
        if run(['t','-pwrong',archive],False).returncode==0:raise RuntimeError('Wrong password accepted')
        tests.append({'method':method,'header_encryption':True,'wrong_password_rejected':True,'passed':True})
    record={'passed':True,'tests':tests,'cli_sha256':hashlib.sha256(cli.read_bytes()).hexdigest()}
    (output/'runtime.json').write_text(json.dumps(record,indent=2)+'\n')
    print('SEVENZIP_NATIVE_CLI_PASSED',len(tests),flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sdk',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();probe(a.sdk,a.output)
