#!/usr/bin/env python3
"""Real library/CLI round-trip tests with codecs, passwords and bounded output."""
import argparse
import ctypes as C
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import tarfile
import zipfile

METHODS=['LZMA2','ZSTD','BROTLI','LZ4','LZ5','LIZARD','FLZMA2']


def digest_bytes(data):return hashlib.sha256(data).hexdigest()


def probe(sdk,output):
    sdk,output=Path(sdk).resolve(),Path(output).resolve();output.mkdir(parents=True,exist_ok=True)
    windows=platform.system()=='Windows'
    lib=sdk/'bin/7z.dll' if windows else sdk/'lib/lib7zipzs.dylib' if platform.system()=='Darwin' else sdk/'lib/lib7zipzs.so'
    dll=C.CDLL(str(lib))
    class Input(C.Structure):_fields_=[('name',C.c_char_p),('data',C.c_void_p),('size',C.c_size_t),('directory',C.c_uint32)]
    class Entry(C.Structure):_fields_=[('name',C.c_char_p),('size',C.c_uint64),('directory',C.c_uint32),('known',C.c_uint32)]
    dll.zs_version.restype=C.c_char_p;dll.zs_last_error.restype=C.c_char_p
    dll.zs_free.argtypes=[C.c_void_p];dll.zs_close.argtypes=[C.c_void_p]
    dll.zs_formats_json.argtypes=[C.POINTER(C.c_void_p)]
    dll.zs_open.argtypes=[C.c_char_p,C.c_void_p,C.c_size_t,C.c_char_p,C.POINTER(C.c_void_p)]
    dll.zs_entry_count.argtypes=[C.c_void_p,C.POINTER(C.c_uint32)]
    dll.zs_entry_info.argtypes=[C.c_void_p,C.c_uint32,C.POINTER(Entry)]
    dll.zs_extract_entry.argtypes=[C.c_void_p,C.c_uint32,C.c_size_t,C.POINTER(C.c_void_p),C.POINTER(C.c_size_t)]
    dll.zs_create.argtypes=[C.c_char_p,C.c_char_p,C.c_uint32,C.c_uint32,C.c_char_p,C.POINTER(Input),C.c_uint32,C.c_size_t,C.POINTER(C.c_void_p),C.POINTER(C.c_size_t)]
    def check(rc):
        if rc:raise RuntimeError(dll.zs_last_error().decode('utf-8','replace'))
    metadata=C.c_void_p();check(dll.zs_formats_json(C.byref(metadata)))
    formats=json.loads(C.string_at(metadata));dll.zs_free(metadata)
    for required in ['7z','zip','tar','Rar','Rar5','zstd','xz']:
        if required.lower() not in [x.lower() for x in formats]:raise RuntimeError('Full archive handler absent: '+required)
    sample=(bytes(range(256))*256)+('中文目录/媒体素材/✨.bin\n'.encode()*300)
    corpus={'文档':None,'文档/数据.bin':sample,'empty':b''}
    buffers={k:C.create_string_buffer(v) for k,v in corpus.items() if v is not None}
    entries=(Input*len(corpus))(*[Input(k.encode(),C.cast(buffers[k],C.c_void_p) if v is not None else None,len(v) if v is not None else 0,v is None) for k,v in corpus.items()])
    tests=[]
    def inspect(blob,fmt,password=None,check_limit=True):
        packed=C.create_string_buffer(blob);handle=C.c_void_p();check(dll.zs_open(fmt.encode(),packed,len(blob),password,C.byref(handle)))
        try:
            count=C.c_uint32();check(dll.zs_entry_count(handle,C.byref(count)))
            got={}
            for i in range(count.value):
                e=Entry();check(dll.zs_entry_info(handle,i,C.byref(e)));name=e.name.decode().replace('\\','/')
                if e.directory:got[name]=None;continue
                p=C.c_void_p();n=C.c_size_t();check(dll.zs_extract_entry(handle,i,2*1024*1024,C.byref(p),C.byref(n)))
                got[name]=C.string_at(p,n.value);dll.zs_free(p)
                if check_limit and n.value>1 and dll.zs_extract_entry(handle,i,1,C.byref(p),C.byref(n))==0:
                    dll.zs_free(p);raise RuntimeError('Library output limit is not enforced')
            if got!=corpus:raise RuntimeError('Extracted UTF-8 directory/binary/empty corpus differs')
        finally:dll.zs_close(handle)
    for method in METHODS:
        for threads in [1,2]:
            p=C.c_void_p();n=C.c_size_t()
            check(dll.zs_create(b'7z',method.encode(),3,threads,None,entries,len(entries),8*1024*1024,C.byref(p),C.byref(n)))
            blob=C.string_at(p,n.value);dll.zs_free(p);inspect(blob,'7z');inspect(blob,'auto')
            tests.append({'api':'C','method':method,'threads':threads,'passed':True,'archive_sha256':digest_bytes(blob)})
    for fmt in ['7z','zip','tar']:
        print('PROBE_C_CONTAINER',fmt,flush=True)
        password=('secret-ASCII'.encode() if fmt=='zip' else '口令-secret'.encode()) if fmt!='tar' else None
        p=C.c_void_p();n=C.c_size_t();check(dll.zs_create(fmt.encode(),None,3,1,password,entries,len(entries),8*1024*1024,C.byref(p),C.byref(n)))
        blob=C.string_at(p,n.value);dll.zs_free(p);inspect(blob,fmt,password)
        if password:
            packed=C.create_string_buffer(blob);a=C.c_void_p()
            if not dll.zs_open(fmt.encode(),packed,len(blob),b'wrong',C.byref(a)):
                try:
                    count=C.c_uint32();check(dll.zs_entry_count(a,C.byref(count)));rejected=False
                    for i in range(count.value):
                        e=Entry();check(dll.zs_entry_info(a,i,C.byref(e)))
                        if e.directory or not e.size:continue
                        out=C.c_void_p();ln=C.c_size_t()
                        if dll.zs_extract_entry(a,i,2*1024*1024,C.byref(out),C.byref(ln)):rejected=True;break
                        dll.zs_free(out)
                    if not rejected:raise RuntimeError('Encrypted archive accepted wrong password')
                finally:dll.zs_close(a)
        tests.append({'api':'C','format':fmt,'password':bool(password),'passed':True})
    # Explicit rejection of traversal names in the convenience API.
    malicious=Input(b'../escape',None,0,0);p=C.c_void_p();n=C.c_size_t()
    if not dll.zs_create(b'7z',b'ZSTD',1,1,None,C.byref(malicious),1,1024,C.byref(p),C.byref(n)):
        dll.zs_free(p);raise RuntimeError('Traversal input path accepted')
    cli=sdk/'bin'/('7zz.exe' if windows else '7zz')
    def command(args,expect=True):
        r=subprocess.run([str(cli),*map(str,args)],cwd=output,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
        if expect and r.returncode:raise RuntimeError(r.stdout.decode(errors='replace')[-6000:])
        return r
    listing=command(['i']).stdout.decode('utf-8','replace');(output/'cli-info.txt').write_text(listing,encoding='utf-8')
    for method in METHODS:
        if method not in listing:raise RuntimeError('CLI missing codec '+method)
    source=output/'input';source.mkdir(exist_ok=True)
    for name,data in corpus.items():
        p=source/name
        if data is None:p.mkdir(exist_ok=True)
        else:p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    for method in METHODS:
        archive=output/(method+'.7z');extract=output/('out-'+method)
        command(['a','-y','-t7z','-m0='+method,'-mx3','-mmt=2',archive,'./input/*'])
        command(['t',archive]);command(['x','-y','-o'+str(extract),archive])
        if (extract/'文档/数据.bin').read_bytes()!=sample or (extract/'empty').read_bytes()!=b'':raise RuntimeError('CLI round-trip differs '+method)
        tests.append({'api':'CLI','method':method,'passed':True})
    for fmt in ['zip','tar','wim']:
        archive=output/('container.'+fmt);extract=output/('out-'+fmt)
        command(['a','-y','-t'+fmt,archive,'./input/*']);command(['t',archive]);command(['x','-y','-o'+str(extract),archive])
        if (extract/'文档/数据.bin').read_bytes()!=sample:raise RuntimeError('CLI container differs')
        tests.append({'api':'CLI','format':fmt,'passed':True})
    for method in ['LZMA2','ZSTD','BROTLI']:
        archive=output/('encrypted-'+method+'.7z')
        command(['a','-y','-m0='+method,'-mx3','-mmt=2','-psecret','-mhe=on',archive,'./input/*'])
        command(['t','-psecret',archive]);bad=command(['t','-pwrong',archive],False)
        if bad.returncode==0:raise RuntimeError('CLI accepted wrong password')
        tests.append({'api':'CLI','method':method,'header_encryption':True,'wrong_password_rejected':True,'passed':True})
    record={'passed':True,'platform':platform.platform(),'machine':platform.machine(),
            'version':dll.zs_version().decode(),'formats':formats,'tests':tests,
            'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),
            'cli_sha256':hashlib.sha256(cli.read_bytes()).hexdigest(),
            'scope':'Real C ABI memory round-trips, UTF-8/binary/directory/empty inputs, output caps, password rejection, CLI codec/container/encryption tests. No GUI shell integration or untested external codec plugins claimed.'}
    (output/'runtime.json').write_text(json.dumps(record,indent=2)+'\n')
    print('SEVENZIP_LIBRARY_AND_CLI_PROBES_PASSED',len(tests),flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--sdk',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();probe(a.sdk,a.output)
