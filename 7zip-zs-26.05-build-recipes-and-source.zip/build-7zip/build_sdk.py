#!/usr/bin/env python3
"""Build locked 7-Zip ZS full-format libraries and CLIs for nine ABIs."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tarfile

TARGETS = ['linux-x64','windows-x64','windows-x86','windows-arm64',
           'linux-arm64','mac-arm64','mac-x64','wasm-single','wasm-threads']
VERSION = '26.05-zstd1.5.7-R1'
HERE = Path(__file__).resolve().parent
EXPORTS = ['zs_version','zs_last_error','zs_free','zs_formats_json','zs_open','zs_close',
           'zs_entry_count','zs_entry_info','zs_extract_entry','zs_create']


def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''):h.update(b)
    return h.hexdigest()


def run(cmd,log,env=None,cwd=None,output=False):
    with log.open('a') as f:
        f.write('\nCOMMAND '+shlex.join(map(str,cmd))+'\n');f.flush()
        if output:
            p=subprocess.run(list(map(str,cmd)),env=env,cwd=cwd,stdout=subprocess.PIPE,stderr=f,text=True,check=True)
            f.write(p.stdout);return p.stdout
        subprocess.run(list(map(str,cmd)),env=env,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)


def patch_source(source):
    changes={
      'C/zstdmt/threading.h':('/* POSIX Systems */', '''/* MYCEF_WASM_SYNC: the single-thread build runs each frame worker inline.
   These routines only wrap zstdmt's independent read/compress/write frame jobs. */
#if defined(__EMSCRIPTEN__) && defined(Z7_ST)
#include <pthread.h>
static inline int zs_sync_create(pthread_t *thread, const pthread_attr_t *attr,
    void *(*routine)(void *), void *arg) {
    (void)attr; *thread = (pthread_t)routine(arg); return 0;
}
static inline int zs_sync_join(pthread_t thread, void **result) {
    if (result) *result = (void *)thread; return 0;
}
#define pthread_create zs_sync_create
#define pthread_join zs_sync_join
#endif
/* POSIX Systems */'''),
      'CPP/Windows/System.cpp':('UInt32 GetNumberOfProcessors()\n{', '''UInt32 GetNumberOfProcessors()
{
#if defined(__EMSCRIPTEN__)
  // MYCEF_WASM_CPU: bounded default parallelism for a fixed worker pool.
  #if defined(Z7_ST)
  return 1;
  #else
  return 2;
  #endif
#endif'''),
      'CPP/7zip/Archive/BrotliHandler.cpp':(
          '  decoderSpec->_numThreads_WasForced = _props._numThreads_WasForced ? 1 : 0;\n'
          '  if (_props._numThreads_WasForced) {\n'
          '    decoderSpec->SetNumberOfThreads(_props._numThreads);\n  }',
          '#ifndef Z7_ST\n'
          '  decoderSpec->_numThreads_WasForced = _props._numThreads_WasForced ? 1 : 0;\n'
          '  if (_props._numThreads_WasForced) {\n'
          '    decoderSpec->SetNumberOfThreads(_props._numThreads);\n  }\n'
          '#endif'),
      'CPP/7zip/Compress/ZstdEncoder.cpp':(
          'err = ZSTD_CCtx_setParameter(_ctx, ZSTD_c_nbWorkers, _numThreads);',
          '#if defined(__EMSCRIPTEN__) && defined(Z7_ST)\n'
          '    err = ZSTD_CCtx_setParameter(_ctx, ZSTD_c_nbWorkers, 0); // synchronous Zstd engine\n'
          '#else\n    err = ZSTD_CCtx_setParameter(_ctx, ZSTD_c_nbWorkers, _numThreads);\n#endif'),
    }
    changes['C/Sha512.c']=('#include "Precomp.h"','#include "Precomp.h"\n#include <stdio.h> /* declaration used by the upstream ARM64 SHA512 ISA probe */')
    with tarfile.open(source.parent/(source.name+'.tar.gz')) as archive:
        originals={name:archive.extractfile(source.name+'/'+name).read().decode('utf-8').replace('\r\n','\n') for name in changes}
    for name,(before,after) in changes.items():
        p=source/name;text=originals[name]
        if before not in text:raise RuntimeError('Patch context missing: '+name)
        updated=text.replace(before,after,1) if name!='CPP/Windows/System.cpp' else text.replace(before,after)
        if name=='CPP/Windows/System.cpp':
            updated=updated.replace('  #else\n\n  struct sysinfo info;',
                '  #elif defined(__EMSCRIPTEN__)\n'
                '  size64 = 512ULL * 1024 * 1024; // browser module memory budget\n'
                '  #else\n\n  struct sysinfo info;',1)
        if p.read_text()!=updated:p.write_text(updated)


def settings(target, root, ffroot):
    env=dict(os.environ);flags=[];libs=[]
    clang=Path('/home/ubuntu/cef156/chromium/src/third_party/llvm-build/Release+Asserts/bin')
    if target.startswith('wasm-'):
        sys.path.insert(0,str(ffroot))
        from build_wasm import environment
        env=environment(ffroot)
        cc=ffroot/'toolchains/emsdk/upstream/emscripten/emcc'
        cxx=ffroot/'toolchains/emsdk/upstream/emscripten/em++'
        ar=ffroot/'toolchains/emsdk/upstream/bin/llvm-ar'
        strip=ffroot/'toolchains/emsdk/upstream/bin/llvm-strip'
        flags=['-fexceptions','-msimd128','-DZ7_AFFINITY_DISABLE']
        if target=='wasm-threads': flags+=['-pthread']
        else: flags+=['-DZ7_ST','-DFL2_SINGLETHREAD=1']
    elif target.startswith('windows-'):
        cpu=target.split('-')[1];triple={'x64':'x86_64','x86':'i686','arm64':'aarch64'}[cpu]+'-w64-mingw32'
        base=ffroot/'toolchains/llvm-mingw/bin'
        cc=base/(triple+'-clang');cxx=base/(triple+'-clang++');ar=base/'llvm-ar';strip=base/'llvm-strip'
        flags=['-D_WIN32_WINNT='+('0x0A00' if cpu=='arm64' else '0x0601')]
        libs=['-static','-loleaut32','-luuid','-ladvapi32','-luser32']
    else:
        base=ffroot/'toolchains/compiler-wrappers'/target
        cc=base/'clang';cxx=base/'clang++';ar=clang/'llvm-ar';strip=clang/'llvm-strip'
        libs=['-pthread']+(['-ldl'] if target.startswith('linux-') else [])
    wrappers=root/'toolchains'/target;wrappers.mkdir(parents=True,exist_ok=True)
    for name,path in [('cc',cc),('cxx',cxx)]:
        wrapper=wrappers/name;wrapper.write_text('#!/bin/sh\nexec '+shlex.join([str(path),*flags])+' "$@"\n');wrapper.chmod(0o755)
    return env, wrappers/'cc',wrappers/'cxx',ar,strip,flags,libs


def build(target,root,ffroot,jobs):
    lock=json.loads((root/'state/source-lock.json').read_text())
    if digest(Path(lock['source_archive']))!=lock['source_sha256']:raise RuntimeError('Locked source bytes differ')
    source=root/'sources'/('7-Zip-zstd-'+lock['revision']);patch_source(source)
    log=root/'logs'/(target+'.log')
    env,cc,cxx,ar,strip,flags,libs=settings(target,root,ffroot)
    wasm=target.startswith('wasm-');windows=target.startswith('windows-');mac=target.startswith('mac-')
    objects=root/'objects'/target;objects.mkdir(parents=True,exist_ok=True)
    sdk=root/'output'/('7zip-zs_'+VERSION+'_'+target+'_release')
    for n in ['lib','bin','include','examples','licenses','validation','build-recipes']:(sdk/n).mkdir(parents=True,exist_ok=True)
    state=root/'state'/('build-'+target+'.json')
    record={'target':target,'phase':'compiling','sdk_complete':False,'source':lock,'started_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
    state.write_text(json.dumps(record,indent=2)+'\n')
    tasks=root/'upstream-tasks.mk'
    tasks.write_text('include makefile.gcc\n.PHONY: zs-list zs-objects\n'
                     'zs-list:\n\t@echo ZS_OBJECTS $(OBJS)\nzs-objects: $(OBJS)\n')
    common=['make','--no-print-directory','-f',str(tasks),'-j'+str(jobs),
            'CC='+str(cc),'CXX='+str(cxx),'FLAGS_FLTO=','CFLAGS_WARN_WALL=-Wall',
            'LFLAGS_STRIP=','LFLAGS_NOEXECSTACK=','ZS_LIBS='+shlex.join(libs)]
    if windows:
        rc=ffroot/'toolchains/llvm-mingw/bin'/({'x64':'x86_64','x86':'i686','arm64':'aarch64'}[target.split('-')[1]]+'-w64-mingw32-windres')
        common+=['IS_MINGW=1','MSYSTEM=MYCEF','RC='+str(rc),'RFLAGS=']
    if wasm and target=='wasm-single': common+=['ST_MODE=1','ZSTDFLAGS=-DZSTD_LEGACY_SUPPORT']
    # Generate dependency targets from the upstream object/source lists.
    objlists={}
    for variant,bundle in [('lib','Format7zF'),('cli','Alone2')]:
        directory=source/'CPP/7zip/Bundles'/bundle;out=objects/variant;out.mkdir(exist_ok=True)
        cmd=common+['O='+str(out)]
        listed=run(cmd+['zs-list'],log,env,directory,True)
        line=next(x for x in listed.splitlines() if x.startswith('ZS_OBJECTS '))
        objs=line.split()[1:];objlists[variant]=objs
        run(cmd+['zs-objects'],log,env,directory)
        if windows:
            extra=out/'MyWindows.o'
            run([cxx,'-O2','-DNDEBUG','-c',source/'CPP/Common/MyWindows.cpp','-o',extra],log,env)
            objlists[variant].append(str(extra))
    api_obj=objects/'zs_api.o'
    run([cxx,'-std=c++17','-O2','-DNDEBUG','-fPIC','-I'+str(source),'-I'+str(HERE/'api'),'-c',HERE/'api/sevenzip_zs.cpp','-o',api_obj],log,env)
    archive=sdk/'lib/lib7zipzs.a'
    run([ar,'rcs',*(['--format=darwin'] if mac else []),archive,*objlists['lib'],api_obj],log,env)
    if wasm:
        link=['-O2','-fexceptions','-msimd128','-sALLOW_MEMORY_GROWTH=1','-sINITIAL_MEMORY=134217728',
              '-sMAXIMUM_MEMORY=2147483648','-sSTACK_SIZE=1048576','-sMODULARIZE=1',
              '-sENVIRONMENT=web,worker,node','-sFORCE_FILESYSTEM=1','-sINVOKE_RUN=0',
              '-sEXPORTED_RUNTIME_METHODS=HEAPU8,FS,ccall,cwrap,UTF8ToString,stringToUTF8,lengthBytesUTF8']
        if target=='wasm-threads':link+=['-pthread','-sPTHREAD_POOL_SIZE=16','-sPTHREAD_POOL_SIZE_STRICT=2']
        run([cxx,*objlists['lib'],api_obj,*link,'--no-entry','-sEXPORT_NAME=createSevenZipLibrary',
             '-sEXPORTED_FUNCTIONS='+','.join('_'+x for x in EXPORTS)+',_malloc,_free',
             '-o',sdk/'lib/sevenzip.js'],log,env)
        run([cxx,*objlists['cli'],*link,'-sEXPORTED_RUNTIME_METHODS=callMain,FS,NODEFS',
             '-lnodefs.js','-sEXIT_RUNTIME=1','-sEXPORT_NAME=createSevenZipCLI',
             '-o',sdk/'bin/7zz.js'],log,env)
    else:
        libname='7z.dll' if windows else 'lib7zipzs.dylib' if mac else 'lib7zipzs.so'
        shared=sdk/('bin' if windows else 'lib')/libname
        ld=['-dynamiclib','-Wl,-install_name,@rpath/lib7zipzs.dylib','-Wl,-headerpad,0x4000'] if mac else ['-shared']
        if windows:
            original=(source/'CPP/7zip/Archive/Archive2.def').read_text().replace(' PRIVATE','')
            definition=objects/'7zipzs.def';definition.write_text(original+'\n'+'\n'.join(EXPORTS)+'\n')
            ld+=[str(definition),'-Wl,--out-implib,'+str(sdk/'lib/lib7zipzs.dll.a')]
        elif not mac:ld+=['-Wl,-soname,lib7zipzs.so','-Wl,-rpath,$ORIGIN']
        run([cxx,*ld,'-o',shared,*objlists['lib'],api_obj,*libs],log,env)
        cli=sdk/'bin'/('7zz.exe' if windows else '7zz')
        run([cxx,'-o',cli,*objlists['cli'],*libs,*(['-Wl,-rpath,$ORIGIN/../lib'] if target.startswith('linux-') else [])],log,env)
        if windows:
            dlltool=ar.parent/'llvm-dlltool';machine={'x64':'i386:x86-64','x86':'i386','arm64':'arm64'}[target.split('-')[1]]
            capidef=objects/'c-api.def';capidef.write_text('LIBRARY 7z.dll\nEXPORTS\n'+'\n'.join(EXPORTS)+'\n')
            run([dlltool,'-m',machine,'-d',capidef,'-D','7z.dll','-l',sdk/'lib/7zipzs.lib'],log,env)
        if target.startswith('linux-'):
            libstd=next((ffroot/'output'/('ffmpeg_9.0.2_'+target+'_release')/'lib').glob('libstdc++.so.6.*'))
            shutil.copy2(libstd,sdk/'lib'/libstd.name)
            alias=sdk/'lib/libstdc++.so.6'
            if not alias.exists():alias.symlink_to(libstd.name)
            shutil.copytree(ffroot/'output'/('ffmpeg_9.0.2_'+target+'_release')/'licenses/libstdc++',sdk/'licenses/libstdc++',dirs_exist_ok=True)
        # Strip only final native images, before macOS ad-hoc integrity checks.
        run([strip,'--strip-debug',shared],log,env)
        run([strip,'--strip-debug',cli],log,env)
    shutil.copy2(HERE/'api/sevenzip_zs.h',sdk/'include/sevenzip_zs.h')
    # Raw interfaces retain their upstream include tree and matching source.
    for folder in ['C','CPP/Common','CPP/Windows','CPP/7zip']:
        for path in (source/folder).rglob('*.h'):
            relative=path.relative_to(source);dest=sdk/'include/upstream'/relative
            dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
    shutil.copytree(HERE/'examples',sdk/'examples',dirs_exist_ok=True)
    if wasm:
        shutil.copytree(HERE/'wasm',sdk/'examples',dirs_exist_ok=True)
        entry=sdk/'bin/7zz'
        entry.write_text('#!/bin/sh\nset -eu\nhere=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\n'
            'exec node "$here/../examples/node-cli.cjs" "$here/7zz.js" "$@"\n')
        entry.chmod(0o755)
    for name in ['COPYING','README.md']:shutil.copy2(source/name,sdk/'licenses'/name)
    shutil.copytree(source/'DOC',sdk/'docs',dirs_exist_ok=True)
    for path in (source/'C').rglob('*'):
        if path.is_file() and any(x in path.name.upper() for x in ['COPYING','LICENSE','PATENTS']):
            dest=sdk/'licenses'/path.relative_to(source);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
    for path in HERE.glob('*.py'):shutil.copy2(path,sdk/'build-recipes'/path.name)
    shutil.copytree(HERE/'api',sdk/'build-recipes/api',dirs_exist_ok=True)
    for original in [root/'state/source-lock.json',source/'C/7zVersion.h']:
        shutil.copy2(original,sdk/'validation'/original.name)
    record.update(phase='compiled',finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),sdk=str(sdk))
    state.write_text(json.dumps(record,indent=2)+'\n');shutil.copy2(state,sdk/'validation/build.json')
    print('SEVENZIP_TARGET_COMPILED',target,flush=True)
    return sdk


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True)
    p.add_argument('--ffmpeg-root',type=Path,default=Path('/home/ubuntu/ffmpeg-build'))
    p.add_argument('--target',choices=TARGETS,required=True);p.add_argument('--jobs',type=int,default=14)
    a=p.parse_args();build(a.target,a.root.resolve(),a.ffmpeg_root.resolve(),a.jobs)
