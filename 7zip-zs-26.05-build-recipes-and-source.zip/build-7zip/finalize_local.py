#!/usr/bin/env python3
"""Finalize examples/evidence locally while preserving all compiled binaries."""
import argparse
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

import zstandard

from build_sdk import TARGETS,VERSION,HERE,digest
sys.path.insert(0,str(HERE.parent/'build-cef'))
from minimize_sdk import zstd_reader


def finalize(destination,target):
    name='7zip-zs_'+VERSION+'_'+target+'_release';archive=destination/(name+'.tar.zst');sdk=destination/name
    receipt_path=archive.with_name(archive.name+'.verified.json');receipt=json.loads(receipt_path.read_text())
    if receipt.get('locally_finalized'):
        if digest(archive)!=receipt['archive_sha256']:raise RuntimeError('Final archive changed')
        return receipt
    if not receipt['local_download_verified'] or digest(archive)!=receipt['archive_sha256']:raise RuntimeError('Original download identity differs')
    with zstd_reader(archive) as reader,tarfile.open(fileobj=reader,mode='r|') as tar:
        for m in tar:
            if m.name==name+'/SHA256SUMS.json':manifest_mode=m.mode;manifest=json.load(tar.extractfile(m));break
        else:raise RuntimeError('Source payload manifest missing')
    replacements={'examples/roundtrip.c':(HERE/'examples/roundtrip.c').read_bytes()}
    # Refresh the recipe kit, not any compiled archive, DLL, executable or WASM.
    for p in HERE.glob('*.py'):replacements['build-recipes/'+p.name]=p.read_bytes()
    for folder in ['api','examples']+(['wasm'] if target.startswith('wasm-') else []):
        for p in (HERE/folder).rglob('*'):
            if p.is_file():replacements['build-recipes/'+p.relative_to(HERE).as_posix()]=p.read_bytes()
    features=json.loads((sdk/'FEATURES.json').read_text())
    if target in ['windows-x64','windows-x86']:
        p=destination/'validation'/target/'runtime.json';record=json.loads(p.read_text())
        if not record.get('passed') or record['dll_sha256']!=digest(sdk/'bin/7z.dll'):raise RuntimeError('Local MSVC verification differs from this DLL')
        replacements['validation/local-windows-runtime.json']=p.read_bytes()
        features.update(runtime_verified=True,local_msvc_and_cli_verified=True,local_runtime_scope=record['scope'])
    if target.startswith('wasm-'):
        p=destination/'validation'/target/'browser-runtime.json';record=json.loads(p.read_text())
        if not record.get('passed'):raise RuntimeError('Browser execution failed')
        for relative,sha in record['inputs'].items():
            if digest(sdk/relative)!=sha:raise RuntimeError('Browser verification used different module/example bytes')
        replacements['validation/browser-runtime.json']=p.read_bytes()
        features.update(browser_runtime_verified=True,browser_runtime_scope=record['scope'])
    replacements['FEATURES.json']=(json.dumps(features,indent=2)+'\n').encode()
    changes=[]
    for relative,data in replacements.items():
        old=manifest.get(relative);sha=hashlib.sha256(data).hexdigest()
        if old and old.get('sha256')==sha:continue
        if Path(relative).suffix in ('.a','.dll','.exe','.so','.dylib','.wasm','.lib'):raise RuntimeError('Finalization cannot change compiled assets')
        changes.append({'file':relative,'source_sha256':old.get('sha256') if old else None,'sha256':sha})
        manifest[relative]={'type':'file','mode':old['mode'] if old else 0o644,'bytes':len(data),'sha256':sha}
    replacements['SHA256SUMS.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
    pending=archive.with_name(archive.name+'.final.pending');written=set()
    with zstd_reader(archive) as reader,tarfile.open(fileobj=reader,mode='r|') as source:
        with pending.open('wb') as f,zstandard.ZstdCompressor(level=8,threads=2,write_checksum=True).stream_writer(f) as writer:
            with tarfile.open(fileobj=writer,mode='w|',format=tarfile.PAX_FORMAT) as out:
                for m in source:
                    relative=m.name.removeprefix(name+'/')
                    if relative in replacements:
                        entry=copy.copy(m);entry.size=len(replacements[relative]);out.addfile(entry,io.BytesIO(replacements[relative]));written.add(relative)
                    else:out.addfile(m,source.extractfile(m) if m.isfile() else None)
                for relative in sorted(set(replacements)-written):
                    data=replacements[relative];entry=tarfile.TarInfo(name+'/'+relative);entry.mode=manifest[relative]['mode'];entry.size=len(data)
                    out.addfile(entry,io.BytesIO(data))
    expected=dict(manifest);expected['SHA256SUMS.json']={'type':'file','mode':manifest_mode,'bytes':len(replacements['SHA256SUMS.json']),'sha256':hashlib.sha256(replacements['SHA256SUMS.json']).hexdigest()}
    seen=set()
    with zstd_reader(pending) as reader,tarfile.open(fileobj=reader,mode='r|') as tar:
        for m in tar:
            if not m.name.startswith(name+'/'):raise RuntimeError('Repacked root differs')
            relative=m.name[len(name)+1:]
            if relative in seen or relative not in expected:raise RuntimeError('Unexpected/duplicate repacked member')
            seen.add(relative);info=expected[relative]
            if m.mode!=info['mode']:raise RuntimeError('Repacked file mode differs')
            if info['type']=='file':
                h=hashlib.sha256();source=tar.extractfile(m)
                for b in iter(lambda:source.read(4*1024*1024),b''):h.update(b)
                if m.size!=info['bytes'] or h.hexdigest()!=info['sha256']:raise RuntimeError('Repacked payload differs: '+relative)
            elif info['type']=='symlink':
                if not m.issym() or m.linkname!=info['target']:raise RuntimeError('Repacked link differs')
            elif not m.isdir():raise RuntimeError('Repacked directory differs')
    if seen!=set(expected):raise RuntimeError('Repacked archive omits members')
    backup=destination/'source-downloads'/target;backup.mkdir(parents=True,exist_ok=False)
    for p in [archive,receipt_path,archive.with_name(archive.name+'.sha256')]:p.replace(backup/p.name)
    pending.replace(archive)
    for relative,data in replacements.items():
        p=sdk/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    sha=digest(archive)
    result={**receipt,'source_download_sha256':receipt['archive_sha256'],'source_download_receipt':(backup/receipt_path.name).relative_to(destination).as_posix(),
            'archive':str(archive),'archive_sha256':sha,'local_sha256':sha,'bytes':archive.stat().st_size,
            'entries':len(expected),'files':sum(x['type']=='file' for x in expected.values()),
            'locally_finalized':True,'compiled_assets_unchanged':True,'all_final_payloads_readback_verified':True,'local_metadata_and_example_changes':changes}
    receipt_path.write_text(json.dumps(result,indent=2)+'\n');archive.with_name(archive.name+'.sha256').write_text(sha+'  '+archive.name+'\n')
    (sdk/'LOCAL-EXTRACTION.json').write_text(json.dumps({'archive_sha256':sha,'all_payloads_verified':True,'entries':len(expected)},indent=2)+'\n')
    print('SEVENZIP_LOCAL_FINAL_SDK_VERIFIED',target,sha,flush=True);return result


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);p.add_argument('--targets',nargs='+',choices=TARGETS,default=TARGETS)
    a=p.parse_args()
    for target in a.targets:finalize(a.destination.resolve(),target)
