#!/usr/bin/env python3
"""Execute actual single/pthread WASM libraries, CLI modules and static examples."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from build_sdk import VERSION,digest
from probe_sdk import METHODS


def validate(root,target):
    ffroot=Path('/home/ubuntu/ffmpeg-build');sys.path.insert(0,str(ffroot))
    from build_wasm import environment
    env=environment(ffroot);node=env['EMSDK_NODE'];sdk=root/'output'/('7zip-zs_'+VERSION+'_'+target+'_release')
    work=root/'validation'/target;work.mkdir(parents=True,exist_ok=True)
    def run(args):
        p=subprocess.run(list(map(str,args)),env=env,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
        if p.returncode:raise RuntimeError(p.stdout.decode(errors='replace')[-7000:])
        return p.stdout.decode(errors='replace')
    report=work/'library-runtime.json'
    print(run([node,sdk/'examples/probe-library.cjs',sdk,target,report]),flush=True)
    def cli(args):return run([node,sdk/'examples/node-cli.cjs',sdk/'bin/7zz.js',*args])
    info=cli(['i']);(work/'cli-info.txt').write_text(info)
    data=bytes(range(256))*256+b'Archive WASM binary round-trip\n'*100
    source=work/'input.bin';source.write_bytes(data);tests=[]
    for method in METHODS:
        archive=work/(method+'.7z');out=work/('out-'+method)
        cli(['a','-y','-m0='+method,'-mx3','-mmt='+('1' if target=='wasm-single' else '2'),archive,source])
        cli(['t','-mmt=1',archive]);cli(['x','-y','-mmt=1','-o'+str(out),archive])
        if (out/source.name).read_bytes()!=data:raise RuntimeError('WASM Node CLI output differs')
        tests.append({'method':method,'passed':True})
    # Independently consume the static archive using the distributed CMake project.
    build=work/'static-example';cmake=ffroot/'host-tools/bin/cmake'
    run(['emcmake',cmake,'-S',sdk/'examples','-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
         '-DZS_USE_STATIC=ON','-DZS_WASM_THREADS='+('ON' if target=='wasm-threads' else 'OFF')])
    run([cmake,'--build',build,'-j','2'])
    for method in METHODS:
        output=run([node,build/'zs-roundtrip.js',method])
        if 'ZS_C_API_ROUNDTRIP_OK' not in output:raise RuntimeError('WASM independent static C API example failed')
    modules={p.relative_to(sdk).as_posix():digest(p) for folder in ['bin','lib'] for p in (sdk/folder).iterdir() if p.suffix in ('.js','.wasm')}
    record={'target':target,'passed':True,'runtime_verified':True,'library':json.loads(report.read_text()),
            'cli_tests':tests,'module_inputs':modules,'static_c_api_link_and_run':True,
            'scope':'Actual Node execution of the WASM C API and CLI codecs plus a separately linked static C API consumer; browser checks are recorded separately.'}
    p=root/'state'/('runtime-'+target+'.json');p.write_text(json.dumps(record,indent=2)+'\n');shutil.copy2(p,sdk/'validation/wasm-runtime.json')
    print('SEVENZIP_WASM_LIBRARY_CLI_AND_STATIC_API_PASSED',target,flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--target',required=True)
    a=p.parse_args();validate(a.root.resolve(),a.target)
