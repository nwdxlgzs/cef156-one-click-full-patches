#!/usr/bin/env python3
"""Use MSVC to consume the delivered C DLL/import library and run real codecs."""
import argparse
import json
import os
from pathlib import Path
import subprocess

from build_sdk import VERSION,digest
from probe_sdk import METHODS
from probe_cli import probe as probe_cli


def validate(destination,target):
    sdk=destination/('7zip-zs_'+VERSION+'_'+target+'_release');work=destination/'validation'/target;work.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ);env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']
    cmake=Path('D:/Program Files/CMake/bin/cmake.exe');build=work/'msvc-c-api'
    arch='x64' if target=='windows-x64' else 'Win32'
    subprocess.run([str(cmake),'-S',str(sdk/'examples'),'-B',str(build),'-G','Visual Studio 17 2022','-A',arch,
                    '-DCMAKE_GENERATOR_INSTANCE=C:/Program Files (x86)/Microsoft Visual Studio/2022/BuildTools'],check=True,env=env)
    subprocess.run([str(cmake),'--build',str(build),'--config','Release','-j','4'],check=True,env=env)
    binary=build/'Release/zs-roundtrip.exe';tests=[]
    for method in METHODS:
        for encrypted in [False,True]:
            cmd=[str(binary),method]+(['secret','2'] if encrypted else [])
            output=subprocess.check_output(cmd,text=True,encoding='utf-8',env=env,timeout=120)
            if 'ZS_C_API_ROUNDTRIP_OK' not in output:raise RuntimeError('MSVC-linked C consumer failed')
            tests.append({'method':method,'password':encrypted,'threads':2 if encrypted else 1,'passed':True})
    cli=probe_cli(sdk,work/'cli')
    if target=='windows-x64':
        from probe_sdk import probe
        direct=probe(sdk,work/'direct-c-api-and-cli')
    else:direct=None
    record={'target':target,'passed':True,'runtime_verified':True,'dll_sha256':digest(sdk/'bin/7z.dll'),
            'import_library_sha256':digest(sdk/'lib/7zipzs.lib'),'msvc_consumer_sha256':digest(binary),
            'c_api_tests':tests,'cli':cli,'direct_python_c_api':direct,
            'scope':'Actual Windows MSVC-built C application loading the delivered DLL, 14 codec/password/thread/size-cap tests, and 13 CLI codec/container/encryption tests. Win7 and ARM Windows execution not covered.'}
    (work/'runtime.json').write_text(json.dumps(record,indent=2)+'\n')
    print('SEVENZIP_LOCAL_MSVC_C_API_AND_CLI_PASSED',target,flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);p.add_argument('--target',required=True)
    a=p.parse_args();validate(a.destination.resolve(),a.target)
