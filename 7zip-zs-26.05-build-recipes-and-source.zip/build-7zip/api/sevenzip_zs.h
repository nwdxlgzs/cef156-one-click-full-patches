#ifndef SEVENZIP_ZS_H
#define SEVENZIP_ZS_H
#include <stddef.h>
#include <stdint.h>
#if defined(_WIN32) && !defined(ZS_STATIC)
# ifdef ZS_BUILD
#  define ZS_API __declspec(dllexport)
# else
#  define ZS_API __declspec(dllimport)
# endif
#elif defined(__GNUC__)
# define ZS_API __attribute__((visibility("default")))
#else
# define ZS_API
#endif
#ifdef __cplusplus
extern "C" {
#endif
typedef struct zs_archive zs_archive;
typedef struct zs_input {
  const char *path_utf8;
  const void *data;
  size_t size;
  uint32_t is_directory;
} zs_input;
typedef struct zs_entry {
  const char *path_utf8; /* Borrowed until the next zs_entry_info() on this handle. */
  uint64_t size;
  uint32_t is_directory;
  uint32_t size_known;
} zs_entry;
/* All functions return 0 on success, nonzero on failure; details in zs_last_error().
   Buffers returned by this SDK must be released with zs_free(), including empty ones.
   A handle borrows the archive input buffer; keep it alive through zs_close().
   One handle must not be used concurrently. Independent handles are independent.
   Memory APIs do not write archive paths to the filesystem or create links. */
ZS_API const char *zs_version(void);
ZS_API const char *zs_last_error(void);
ZS_API void zs_free(void *buffer);
ZS_API int zs_formats_json(char **json_utf8);
/* format is the actual handler name (7z, zip, tar, xz, zstd, ...).
   NULL/"auto" tries signature-bearing handlers; explicit hints are recommended
   for raw streams, split/multivolume archives and ambiguous containers. */
ZS_API int zs_open(const char *format, const void *data, size_t size,
                   const char *password_utf8, zs_archive **archive);
ZS_API void zs_close(zs_archive *archive);
ZS_API int zs_entry_count(zs_archive *archive, uint32_t *count);
ZS_API int zs_entry_info(zs_archive *archive, uint32_t index, zs_entry *entry);
/* max_output is a hard per-entry memory limit; zero is rejected. */
ZS_API int zs_extract_entry(zs_archive *archive, uint32_t index, size_t max_output,
                            void **data, size_t *size);
/* method is e.g. LZMA2, ZSTD, BROTLI, LZ4, LZ5, LIZARD (7z container).
   NULL uses the format's default. level is 0..9; threads must be >=1.
   For WASM single-thread use threads=1; multithread supports up to 4 here.
   A password enables the handler's encryption, where supported (7z/zip).
   ZIP uses AES256 and upstream currently restricts ZIP passwords to ASCII.
   Advanced properties/streaming are available through upstream IArchive.h. */
ZS_API int zs_create(const char *format, const char *method, uint32_t level,
                     uint32_t threads, const char *password_utf8,
                     const zs_input *inputs, uint32_t count, size_t max_output,
                     void **data, size_t *size);
#ifdef __cplusplus
}
#endif
#endif
