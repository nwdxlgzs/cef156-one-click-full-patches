#define ZS_BUILD
#include "sevenzip_zs.h"
#include "CPP/Common/MyWindows.h"
#include "CPP/Common/MyCom.h"
#include "CPP/Common/UTFConvert.h"
#include "CPP/Windows/PropVariant.h"
#include "CPP/7zip/Archive/IArchive.h"
#include "CPP/7zip/IPassword.h"
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

using NWindows::NCOM::CPropVariant;
extern "C" {
HRESULT WINAPI CreateObject(const GUID *, const GUID *, void **);
HRESULT WINAPI GetNumberOfFormats(UInt32 *);
HRESULT WINAPI GetHandlerProperty2(UInt32, PROPID, PROPVARIANT *);
}
static thread_local char error_text[512];
static int fail(const char *message, HRESULT code = E_FAIL) {
  std::snprintf(error_text, sizeof(error_text), "%s (0x%08x)", message, (unsigned)code);
  return 1;
}
static UString wide(const char *s) {
  UString value;
  if (!ConvertUTF8ToUnicode(AString(s ? s : ""), value)) throw std::invalid_argument("Invalid UTF-8");
  return value;
}
static std::string utf8(const wchar_t *s) {
  AString value; ConvertUnicodeToUTF8(UString(s ? s : L""), value);
  return std::string(value.Ptr(), value.Len());
}
static bool equal_ascii(const std::string &a, const char *b) {
  if (!b || a.size() != std::strlen(b)) return false;
  for (size_t i = 0; i < a.size(); ++i)
    if (std::tolower((unsigned char)a[i]) != std::tolower((unsigned char)b[i])) return false;
  return true;
}
static std::string format_name(UInt32 index) {
  CPropVariant p;
  if (GetHandlerProperty2(index, NArchive::NHandlerPropID::kName, &p) != S_OK || p.vt != VT_BSTR) return "";
  return utf8(p.bstrVal);
}
static bool format_guid(UInt32 index, GUID &guid) {
  CPropVariant p;
  if (GetHandlerProperty2(index, NArchive::NHandlerPropID::kClassID, &p) != S_OK ||
      p.vt != VT_BSTR || SysStringByteLen(p.bstrVal) != sizeof(guid)) return false;
  std::memcpy(&guid, p.bstrVal, sizeof(guid)); return true;
}
static bool safe_path(const char *name) {
  if (!name || !*name || *name == '/' || *name == '\\') return false;
  std::string path(name);
  if (path.find(':') != std::string::npos) return false;
  for (char &c : path) if (c == '\\') c = '/';
  size_t start = 0;
  while (start < path.size()) {
    size_t end = path.find('/', start);
    std::string part = path.substr(start, end == std::string::npos ? end : end - start);
    if (part == ".." || part == ".") return false;
    if (end == std::string::npos) break;
    start = end + 1;
  }
  return true;
}
class Input final : public IInStream, public CMyUnknownImp {
  Z7_IFACES_IMP_UNK_2(ISequentialInStream, IInStream)
public:
  const unsigned char *data; size_t size; UInt64 pos = 0;
  Input(const void *p, size_t n): data((const unsigned char *)p), size(n) {}
};
Z7_COM7F_IMF(Input::Read(void *out, UInt32 n, UInt32 *done)) {
  UInt32 amount = pos < size ? (UInt32)std::min<UInt64>(n, size - pos) : 0;
  if (amount) std::memcpy(out, data + (size_t)pos, amount);
  pos += amount; if (done) *done = amount; return S_OK;
}
Z7_COM7F_IMF(Input::Seek(Int64 offset, UInt32 origin, UInt64 *position)) {
  UInt64 base = origin == STREAM_SEEK_SET ? 0 : origin == STREAM_SEEK_CUR ? pos : size;
  if (origin > STREAM_SEEK_END || (offset < 0 && (UInt64)(-(offset + 1)) + 1 > base)) return E_INVALIDARG;
  if (offset >= 0 && (UInt64)offset > UINT64_MAX - base) return E_INVALIDARG;
  pos = offset < 0 ? base - ((UInt64)(-(offset + 1)) + 1) : base + (UInt64)offset;
  if (position) *position = pos; return S_OK;
}
class Output final : public IOutStream, public CMyUnknownImp {
  Z7_IFACES_IMP_UNK_2(ISequentialOutStream, IOutStream)
public:
  std::vector<unsigned char> bytes; UInt64 pos = 0; size_t limit;
  explicit Output(size_t n): limit(n) {}
};
Z7_COM7F_IMF(Output::Write(const void *p, UInt32 n, UInt32 *done)) {
  if (done) *done = 0;
  if (pos > limit || n > limit - (size_t)pos) return E_OUTOFMEMORY;
  try {
    size_t end = (size_t)pos + n;
    if (end > bytes.size()) bytes.resize(end);
    if (n) std::memcpy(bytes.data() + (size_t)pos, p, n);
    pos = end; if (done) *done = n; return S_OK;
  } catch (...) { return E_OUTOFMEMORY; }
}
Z7_COM7F_IMF(Output::Seek(Int64 offset, UInt32 origin, UInt64 *position)) {
  UInt64 base = origin == STREAM_SEEK_SET ? 0 : origin == STREAM_SEEK_CUR ? pos : bytes.size();
  if (origin > STREAM_SEEK_END || (offset < 0 && (UInt64)(-(offset + 1)) + 1 > base)) return E_INVALIDARG;
  UInt64 next = offset < 0 ? base - ((UInt64)(-(offset + 1)) + 1) : base + (UInt64)offset;
  if (offset >= 0 && (UInt64)offset > UINT64_MAX - base) return E_INVALIDARG;
  if (next > limit) return E_OUTOFMEMORY;
  pos = next; if (position) *position = pos; return S_OK;
}
Z7_COM7F_IMF(Output::SetSize(UInt64 n)) {
  if (n > limit) return E_OUTOFMEMORY;
  try { bytes.resize((size_t)n); return S_OK; } catch (...) { return E_OUTOFMEMORY; }
}
class OpenCallback final : public IArchiveOpenCallback, public ICryptoGetTextPassword, public CMyUnknownImp {
  Z7_IFACES_IMP_UNK_2(IArchiveOpenCallback, ICryptoGetTextPassword)
public:
  const char *password; explicit OpenCallback(const char *p): password(p) {}
};
Z7_COM7F_IMF(OpenCallback::SetTotal(const UInt64 *, const UInt64 *)) { return S_OK; }
Z7_COM7F_IMF(OpenCallback::SetCompleted(const UInt64 *, const UInt64 *)) { return S_OK; }
Z7_COM7F_IMF(OpenCallback::CryptoGetTextPassword(BSTR *p)) {
  if (!password) return E_ABORT;
  try { UString w = wide(password); *p = SysAllocString(w.Ptr()); return *p ? S_OK : E_OUTOFMEMORY; }
  catch (...) { return E_INVALIDARG; }
}
class ExtractCallback final : public IArchiveExtractCallback, public ICryptoGetTextPassword, public CMyUnknownImp {
  Z7_IFACES_IMP_UNK_2(IArchiveExtractCallback, ICryptoGetTextPassword)
  Z7_IFACE_COM7_IMP(IProgress)
public:
  CMyComPtr<IOutStream> out; const char *password; Int32 result = 0;
  ExtractCallback(Output *o, const char *p): out(o), password(p) {}
};
Z7_COM7F_IMF(ExtractCallback::SetTotal(UInt64)) { return S_OK; }
Z7_COM7F_IMF(ExtractCallback::SetCompleted(const UInt64 *)) { return S_OK; }
Z7_COM7F_IMF(ExtractCallback::GetStream(UInt32, ISequentialOutStream **p, Int32 mode)) {
  *p = nullptr;
  if (mode == NArchive::NExtract::NAskMode::kExtract) { *p = out; (*p)->AddRef(); }
  return S_OK;
}
Z7_COM7F_IMF(ExtractCallback::PrepareOperation(Int32)) { return S_OK; }
Z7_COM7F_IMF(ExtractCallback::SetOperationResult(Int32 r)) { if (r) result = r; return S_OK; }
Z7_COM7F_IMF(ExtractCallback::CryptoGetTextPassword(BSTR *p)) {
  if (!password) return E_ABORT;
  try { UString w = wide(password); *p = SysAllocString(w.Ptr()); return *p ? S_OK : E_OUTOFMEMORY; }
  catch (...) { return E_INVALIDARG; }
}
class UpdateCallback final : public IArchiveUpdateCallback, public ICryptoGetTextPassword2, public CMyUnknownImp {
  Z7_IFACES_IMP_UNK_2(IArchiveUpdateCallback, ICryptoGetTextPassword2)
  Z7_IFACE_COM7_IMP(IProgress)
public:
  const zs_input *files; const char *password; Int32 result = 0;
  UpdateCallback(const zs_input *f, const char *p): files(f), password(p) {}
};
Z7_COM7F_IMF(UpdateCallback::SetTotal(UInt64)) { return S_OK; }
Z7_COM7F_IMF(UpdateCallback::SetCompleted(const UInt64 *)) { return S_OK; }
Z7_COM7F_IMF(UpdateCallback::GetUpdateItemInfo(UInt32, Int32 *data, Int32 *props, UInt32 *old)) {
  *data = *props = 1; *old = (UInt32)-1; return S_OK;
}
Z7_COM7F_IMF(UpdateCallback::GetProperty(UInt32 i, PROPID id, PROPVARIANT *v)) {
  try {
    CPropVariant p;
    switch (id) {
      case kpidPath: p = wide(files[i].path_utf8); break;
      case kpidIsDir: p = (files[i].is_directory != 0); break;
      case kpidSize: p = (UInt64)(files[i].is_directory ? 0 : files[i].size); break;
      case kpidIsAnti: p = false; break;
      case kpidAttrib: p = (UInt32)(files[i].is_directory ? 0x10 : 0x20); break;
    }
    p.Detach(v); return S_OK;
  } catch (...) { return E_OUTOFMEMORY; }
}
Z7_COM7F_IMF(UpdateCallback::GetStream(UInt32 i, ISequentialInStream **p)) {
  *p = nullptr;
  if (files[i].is_directory) return S_OK;
  try { CMyComPtr<IInStream> in = new Input(files[i].data, files[i].size); *p = in.Detach(); return S_OK; }
  catch (...) { return E_OUTOFMEMORY; }
}
Z7_COM7F_IMF(UpdateCallback::SetOperationResult(Int32 r)) { if (r) result = r; return S_OK; }
Z7_COM7F_IMF(UpdateCallback::CryptoGetTextPassword2(Int32 *defined, BSTR *p)) {
  *defined = password ? 1 : 0; *p = nullptr;
  if (!password) return S_OK;
  try { UString w = wide(password); *p = SysAllocString(w.Ptr()); return *p ? S_OK : E_OUTOFMEMORY; }
  catch (...) { return E_INVALIDARG; }
}
struct zs_archive {
  CMyComPtr<IInArchive> reader; CMyComPtr<IInStream> input;
  std::string password; bool has_password = false; std::string name;
  ~zs_archive() { if (reader) reader->Close(); }
};
static int copy_output(const std::vector<unsigned char> &bytes, void **data, size_t *size) {
  void *p = std::malloc(bytes.empty() ? 1 : bytes.size());
  if (!p) return fail("Output allocation failed", E_OUTOFMEMORY);
  if (!bytes.empty()) std::memcpy(p, bytes.data(), bytes.size());
  *data = p; *size = bytes.size(); return 0;
}
extern "C" const char *zs_version(void) { return "7-Zip ZS 26.05 / Zstd 1.5.7 R1; C ABI 1"; }
extern "C" const char *zs_last_error(void) { return error_text; }
extern "C" void zs_free(void *p) { std::free(p); }
extern "C" int zs_formats_json(char **out) {
  if (!out) return fail("Null output"); *out = nullptr; error_text[0] = 0;
  try {
    UInt32 count = 0; if (GetNumberOfFormats(&count) != S_OK) return fail("Cannot enumerate formats");
    std::string json = "[";
    for (UInt32 i = 0; i < count; ++i) {
      if (i) json += ','; json += '"';
      for (char c : format_name(i)) { if (c == '"' || c == '\\') json += '\\'; json += c; }
      json += '"';
    }
    json += ']'; *out = (char *)std::malloc(json.size()+1);
    if (!*out) return fail("Allocation failed"); std::memcpy(*out,json.c_str(),json.size()+1); return 0;
  } catch (...) { return fail("Format enumeration failed"); }
}
extern "C" int zs_open(const char *format, const void *data, size_t size, const char *password, zs_archive **out) {
  if (!out || (!data && size)) return fail("Invalid open arguments"); *out = nullptr; error_text[0] = 0;
  try {
    UInt32 n = 0; GetNumberOfFormats(&n); HRESULT last = S_FALSE;
    for (UInt32 i = 0; i < n; ++i) {
      bool automatic = !format || equal_ascii(format, "auto");
      if (!automatic && !equal_ascii(format_name(i), format)) continue;
      if (automatic) {
        CPropVariant sig;
        GetHandlerProperty2(i, NArchive::NHandlerPropID::kSignature, &sig);
        if (sig.vt != VT_BSTR || !SysStringByteLen(sig.bstrVal)) continue;
      }
      GUID guid; if (!format_guid(i, guid)) continue;
      CMyComPtr<IInArchive> reader;
      if (CreateObject(&guid, &IID_IInArchive, (void **)&reader) != S_OK) continue;
      CMyComPtr<IInStream> input = new Input(data, size);
      CMyComPtr<IArchiveOpenCallback> cb = new OpenCallback(password);
      const UInt64 search = 1 << 20;
      last = reader->Open(input, &search, cb);
      if (last == S_OK) {
        zs_archive *a = new zs_archive;
        a->reader = reader; a->input = input; a->has_password = password != nullptr;
        if (password) a->password = password;
        *out = a; return 0;
      }
      reader->Close();
    }
    return fail("Cannot open archive (format/password/data)", last);
  } catch (...) { return fail("Archive open failed"); }
}
extern "C" void zs_close(zs_archive *a) { delete a; }
extern "C" int zs_entry_count(zs_archive *a, uint32_t *count) {
  if (!a || !count) return fail("Invalid count arguments");
  HRESULT r = a->reader->GetNumberOfItems(count); return r == S_OK ? 0 : fail("Cannot count entries", r);
}
extern "C" int zs_entry_info(zs_archive *a, uint32_t i, zs_entry *out) {
  if (!a || !out) return fail("Invalid entry arguments");
  try {
    UInt32 n = 0; a->reader->GetNumberOfItems(&n); if (i >= n) return fail("Entry index out of range");
    CPropVariant p; HRESULT r = a->reader->GetProperty(i, kpidPath, &p);
    if (r != S_OK) return fail("Cannot read path",r);
    a->name = p.vt == VT_BSTR ? utf8(p.bstrVal) : "[Content]";
    *out = {}; out->path_utf8 = a->name.c_str();
    p.Clear(); a->reader->GetProperty(i, kpidSize, &p);
    if (p.vt == VT_UI8) {out->size=p.uhVal.QuadPart;out->size_known=1;}
    else if (p.vt == VT_UI4) {out->size=p.ulVal;out->size_known=1;}
    p.Clear(); a->reader->GetProperty(i,kpidIsDir,&p); out->is_directory=p.vt==VT_BOOL && p.boolVal;
    return 0;
  } catch (...) { return fail("Entry metadata failed"); }
}
extern "C" int zs_extract_entry(zs_archive *a, uint32_t i, size_t limit, void **data, size_t *size) {
  if (!a || !data || !size || !limit) return fail("Invalid extract arguments"); *data=nullptr; *size=0;
  try {
    zs_entry entry; if (zs_entry_info(a,i,&entry)) return 1;
    if (entry.size_known && entry.size > limit) return fail("Entry exceeds output memory limit",E_OUTOFMEMORY);
    Output *output = new Output(limit); CMyComPtr<IOutStream> keep=output;
    ExtractCallback *callback = new ExtractCallback(output,a->has_password?a->password.c_str():nullptr);
    CMyComPtr<IArchiveExtractCallback> cb=callback;
    HRESULT r=a->reader->Extract(&i,1,0,cb);
    if (r != S_OK || callback->result) return fail("Extract failed (password/CRC/method/limit)",r != S_OK?r:E_FAIL);
    return copy_output(output->bytes,data,size);
  } catch (...) { return fail("Extract failed"); }
}
extern "C" int zs_create(const char *format, const char *method, uint32_t level, uint32_t threads,
    const char *password, const zs_input *files, uint32_t count, size_t limit, void **data, size_t *size) {
  if (!format || !data || !size || !limit || (!files && count) || level > 9 || !threads)
    return fail("Invalid create arguments");
  *data=nullptr;*size=0;error_text[0]=0;
#if defined(__EMSCRIPTEN__) && defined(Z7_ST)
  if (threads != 1) return fail("Single-thread WASM requires threads=1");
#elif defined(__EMSCRIPTEN__)
  if (threads > 4) return fail("WASM C API supports threads=1..4; CLI accepts explicit -mmt");
#endif
  try {
    for (uint32_t i=0;i<count;++i) {
      if (!safe_path(files[i].path_utf8) || (!files[i].data && files[i].size && !files[i].is_directory))
        return fail("Invalid input path or buffer");
      (void)wide(files[i].path_utf8);
    }
    UInt32 n=0;GetNumberOfFormats(&n);
    CMyComPtr<IOutArchive> writer;
    for (UInt32 i=0;i<n;++i) if (equal_ascii(format_name(i),format)) {
      GUID guid; if (format_guid(i,guid)) CreateObject(&guid,&IID_IOutArchive,(void **)&writer); break;
    }
    if (!writer) return fail("Format has no archive writer");
    CMyComPtr<ISetProperties> props;
    if (writer->QueryInterface(IID_ISetProperties,(void **)&props)==S_OK) {
      const wchar_t *names[4]; CPropVariant values[4]; unsigned used=0;
      if (!equal_ascii(format,"tar")) {names[used]=L"x";values[used++]=(UInt32)level;}
      if (!equal_ascii(format,"tar")) {names[used]=L"mt";values[used++]=(UInt32)threads;}
      if (method && *method) {names[used]=equal_ascii(format,"7z")?L"0":L"m";values[used++]=wide(method);}
      if (password && equal_ascii(format,"zip")) {names[used]=L"em";values[used++]=L"AES256";}
      HRESULT r=props->SetProperties(names,values,used);if(r!=S_OK)return fail("Unsupported format/method properties",r);
    }
    Output *output=new Output(limit);CMyComPtr<IOutStream> keep=output;
    UpdateCallback *callback=new UpdateCallback(files,password);CMyComPtr<IArchiveUpdateCallback> cb=callback;
    HRESULT r=writer->UpdateItems(output,count,cb);
    if(r!=S_OK||callback->result)return fail("Create archive failed",r!=S_OK?r:E_FAIL);
    return copy_output(output->bytes,data,size);
  }catch(...){return fail("Archive create failed");}
}
