#!/usr/bin/env python3
"""Audit target images and link both native library integration examples."""
import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from build_sdk import VERSION,digest


def validate(root,target,ffroot):
    sdk=root/'output'/('7zip-zs_'+VERSION+'_'+target+'_release')
    platform,cpu=target.split('-');records=[]
    sys.path.insert(0,'/opt/mycef/build-cef')
    if platform=='linux':
        from audit_elf import inspect,MACHINES,version_key
        for p in sorted(list((sdk/'bin').iterdir())+list((sdk/'lib').iterdir())):
            if not p.is_file() or p.is_symlink() or p.read_bytes()[:4]!=b'\x7fELF':continue
            info=inspect(p)
            if info['machine']!=MACHINES[cpu] or info['glibc_other_requirements'] or version_key(info['glibc_max_required'])>version_key('2.28'):
                raise RuntimeError('Linux architecture/glibc requirement differs: '+str(p))
            records.append({'file':p.relative_to(sdk).as_posix(),'sha256':digest(p),'elf':info})
    elif platform=='windows':
        llvm=ffroot/'toolchains/llvm-mingw/bin';machine={'x64':'AMD64','x86':'I386','arm64':'ARM64'}[cpu]
        system={'kernel32.dll','user32.dll','advapi32.dll','oleaut32.dll','msvcrt.dll','ntdll.dll','shell32.dll','gdi32.dll','ole32.dll','comctl32.dll','comdlg32.dll','psapi.dll','uuid.dll'}
        for p in sorted((sdk/'bin').iterdir()):
            if p.suffix.lower() not in ('.dll','.exe'):continue
            text=subprocess.check_output([str(llvm/'llvm-readobj'),'--file-headers','--coff-imports','--coff-exports',str(p)],text=True)
            if 'IMAGE_FILE_MACHINE_'+machine not in text:raise RuntimeError('PE architecture differs')
            imports=re.findall(r'^\s+Name: (\S+\.dll)\s*$',text,re.M|re.I)
            missing=[n for n in imports if n.lower() not in system and not (sdk/'bin'/n).exists() and not n.lower().startswith(('api-ms-win-','ext-ms-win-'))]
            if missing:raise RuntimeError('Private runtime DLL absent: '+repr(missing))
            if p.suffix.lower()=='.dll':
                for symbol in ['zs_create','zs_open','zs_extract_entry','CreateObject','GetNumberOfFormats']:
                    if not re.search(r'Name: '+symbol+r'\s*$',text,re.M):raise RuntimeError('DLL export absent: '+symbol)
            records.append({'file':p.relative_to(sdk).as_posix(),'sha256':digest(p),'machine':machine,'imports':imports})
    else:
        from audit_macho import inspect,version_tuple
        sys.path.insert(0,str(ffroot));from macho_adhoc import verify
        for p in sorted(list((sdk/'bin').iterdir())+list((sdk/'lib').iterdir())):
            if not p.is_file() or p.is_symlink() or p.read_bytes()[:4]!=b'\xcf\xfa\xed\xfe':continue
            info=inspect(p)
            if info['architecture']!=cpu or not info['versions'] or any(version_tuple(x['minimum'])>version_tuple('13.0') for x in info['versions']):raise RuntimeError('Mac CPU/deployment differs')
            for dependency in info['dylibs']:
                if not dependency['id'] and not dependency['name'].startswith(('/usr/lib/','/System/Library/')):raise RuntimeError('Unbundled Mac dependency')
            signature=verify(p,info['code_signature'])
            records.append({'file':p.relative_to(sdk).as_posix(),'sha256':digest(p),'macho':info,'adhoc':signature})
    if len(records)<2:raise RuntimeError('Target library and CLI were not inspected')
    cmake=ffroot/'host-tools/bin/cmake';work=root/'validation'/target;work.mkdir(parents=True,exist_ok=True)
    demos=[]
    for mode in ['shared','static']:
        build=work/(mode+'-example')
        cmd=[str(cmake),'-S',str(sdk/'examples'),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release',
             '-DCMAKE_TOOLCHAIN_FILE='+str(ffroot/'toolchains'/(target+'.cmake')),'-DZS_USE_STATIC='+('ON' if mode=='static' else 'OFF')]
        if platform=='windows':cmd+=['-DCMAKE_EXE_LINKER_FLAGS=-static']
        subprocess.run(cmd,check=True);subprocess.run([str(cmake),'--build',str(build),'-j','2'],check=True)
        binary=build/('zs-roundtrip.exe' if platform=='windows' else 'zs-roundtrip')
        demos.append({'mode':mode,'binary':str(binary),'sha256':digest(binary)})
    record={'target':target,'passed':True,'runtime_verified':False,'files':records,'examples':demos,
            'scope':'Actual target CPU/runtime dependencies and independently linked shared/static C API examples. Target execution is separately recorded; no Win7/ARM Windows/Mac runtime or distribution signing claim.'}
    p=root/'state'/('binary-audit-'+target+'.json');p.write_text(json.dumps(record,indent=2)+'\n');shutil.copy2(p,sdk/'validation/binary-audit.json')
    print('SEVENZIP_TARGET_BINARY_AND_C_API_LINKS_PASSED',target,flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--target',required=True)
    p.add_argument('--ffmpeg-root',type=Path,default=Path('/home/ubuntu/ffmpeg-build'))
    a=p.parse_args();validate(a.root.resolve(),a.target,a.ffmpeg_root)
