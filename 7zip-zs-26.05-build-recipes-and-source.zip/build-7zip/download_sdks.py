#!/usr/bin/env python3
"""Download each authenticated SDK once, then extract and check every payload."""
import argparse
import json
import os
from pathlib import Path,PurePosixPath
import subprocess
import sys
import tarfile

from build_sdk import TARGETS,VERSION,digest
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'build-cef'))
from minimize_sdk import zstd_reader


def extract(archive,sdk):
    manifest=None;seen={};links=[]
    if sdk.exists():
        receipt=sdk/'LOCAL-EXTRACTION.json'
        if receipt.exists() and json.loads(receipt.read_text())['archive_sha256']==digest(archive):return
        raise RuntimeError('Preserve partial extraction for inspection: '+str(sdk))
    sdk.mkdir(parents=True)
    with zstd_reader(archive) as reader,tarfile.open(fileobj=reader,mode='r|') as tar:
        for m in tar:
            path=PurePosixPath(m.name)
            if not path.parts or path.parts[0]!=sdk.name or path.is_absolute() or '..' in path.parts or '\\' in m.name or ':' in m.name:raise RuntimeError('Unsafe SDK member')
            relative=PurePosixPath(*path.parts[1:]).as_posix()
            if relative in seen:raise RuntimeError('Duplicate SDK member')
            dest=sdk.joinpath(*path.parts[1:])
            if m.isdir():dest.mkdir(parents=True,exist_ok=True);seen[relative]={'type':'directory','mode':m.mode}
            elif m.isfile():
                dest.parent.mkdir(parents=True,exist_ok=True)
                with tar.extractfile(m) as source,dest.open('wb') as out:
                    for b in iter(lambda:source.read(4*1024*1024),b''):out.write(b)
                os.chmod(dest,m.mode)
                seen[relative]={'type':'file','mode':m.mode,'bytes':m.size,'sha256':digest(dest)}
                if relative=='SHA256SUMS.json':manifest=json.loads(dest.read_text())
            elif m.issym():
                target=(dest.parent/m.linkname).resolve()
                if os.path.isabs(m.linkname) or sdk.resolve() not in target.parents:raise RuntimeError('Unsafe SDK symlink')
                links.append((dest,m.linkname));seen[relative]={'type':'symlink','mode':m.mode,'target':m.linkname}
            else:raise RuntimeError('Unexpected SDK entry type')
    payload={k:v for k,v in seen.items() if k!='SHA256SUMS.json'}
    if manifest!=payload:raise RuntimeError('SDK payload manifest differs from extracted bytes/modes/links')
    for path,target in links:path.symlink_to(target)
    (sdk/'LOCAL-EXTRACTION.json').write_text(json.dumps({'archive_sha256':digest(archive),'all_payloads_verified':True,'entries':len(seen)},indent=2)+'\n')


def download(destination,key,targets):
    destination.mkdir(parents=True,exist_ok=True)
    script="python3 - <<'PY'\nimport json,pathlib\np=pathlib.Path('/home/ubuntu/7zip-build/state')\nprint(json.dumps({x.stem.removeprefix('archive-'):json.loads(x.read_text()) for x in p.glob('archive-*.json')}))\nPY\n"
    r=subprocess.run(['ssh.exe','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=15','ubuntu@81.68.82.48','bash -s'],input=script.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
    records=json.loads(r.stdout.decode())
    for target in targets:
        if target not in records:continue
        item=records[target]
        if not item.get('sdk_complete') or not item.get('modes_symlinks_frame_and_all_file_hashes_verified'):raise RuntimeError('Server publication receipt incomplete')
        name='7zip-zs_'+VERSION+'_'+target+'_release.tar.zst';remote='/home/ubuntu/7zip-build/archives/'+name
        if item['archive']!=remote:raise RuntimeError('Unexpected remote artifact path')
        final=destination/name
        if not final.exists():
            partial=final.with_name(final.name+'.partial')
            batch='reget "'+remote+'" "'+partial.resolve().as_posix()+'"\n'
            print('DOWNLOAD_SEVENZIP',target,item['bytes'],flush=True)
            subprocess.run(['sftp.exe','-q','-b','-','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=15','ubuntu@81.68.82.48'],input=batch.encode(),check=True)
            if partial.stat().st_size!=item['bytes'] or digest(partial)!=item['archive_sha256']:raise RuntimeError('Downloaded archive bytes/hash differs')
            partial.replace(final)
        if final.stat().st_size!=item['bytes'] or digest(final)!=item['archive_sha256']:raise RuntimeError('Existing local SDK differs')
        local={**item,'local_download_verified':True,'local_path':str(final),'local_sha256':digest(final)}
        final.with_name(final.name+'.verified.json').write_text(json.dumps(local,indent=2)+'\n')
        final.with_name(final.name+'.sha256').write_text(local['local_sha256']+'  '+name+'\n')
        extract(final,destination/name.removesuffix('.tar.zst'))
        print('LOCAL_SEVENZIP_SDK_VERIFIED_AND_EXTRACTED',target,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);p.add_argument('--key',type=Path,required=True)
    p.add_argument('--targets',nargs='+',choices=TARGETS,default=TARGETS);a=p.parse_args()
    download(a.destination.resolve(),a.key,a.targets)
