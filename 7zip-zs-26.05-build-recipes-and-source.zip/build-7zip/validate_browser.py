#!/usr/bin/env python3
"""Execute both C library and CLI WASM entry points in a real local Chrome."""
import argparse
import functools
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
import json
from pathlib import Path
import threading

from playwright.sync_api import sync_playwright
from build_sdk import VERSION,digest
from probe_sdk import METHODS


def validate(destination,target):
    sdk=destination/('7zip-zs_'+VERSION+'_'+target+'_release');work=destination/'validation'/target;work.mkdir(parents=True,exist_ok=True)
    isolated=target=='wasm-threads'
    class Handler(SimpleHTTPRequestHandler):
        extensions_map={**SimpleHTTPRequestHandler.extensions_map,'.wasm':'application/wasm'}
        def log_message(self,*args):pass
        def end_headers(self):
            if isolated:
                self.send_header('Cross-Origin-Opener-Policy','same-origin');self.send_header('Cross-Origin-Embedder-Policy','require-corp')
            super().end_headers()
    server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Handler,directory=str(sdk)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    records=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='C:/Program Files/Google/Chrome/Application/chrome.exe',headless=True,args=['--disable-gpu'])
            page=browser.new_page();page.set_default_timeout(120000)
            page.goto('http://127.0.0.1:'+str(server.server_port)+'/examples/')
            page.wait_for_function("document.querySelector('#status').textContent.length>0")
            state=page.evaluate('({isolated:crossOriginIsolated,sharedArrayBuffer:typeof SharedArrayBuffer!=="undefined"})')
            if state['isolated']!=isolated or (isolated and not state['sharedArrayBuffer']) or (not isolated and state['sharedArrayBuffer']):
                raise RuntimeError('The intended single/non-isolated or pthread/isolated browser environment was not established')
            for method in METHODS:
                result=page.evaluate('''async ({method,threads}) => {
                  const payload=new Uint8Array(32768);for(let i=0;i<payload.length;i++)payload[i]=i&255;
                  const url=new URL('worker.js',location.href);url.searchParams.set('module',new URL('../lib/sevenzip.js',location.href).href);
                  const worker=new Worker(url);
                  return await new Promise((resolve,reject)=>{
                    const deadline=setTimeout(()=>{worker.terminate();reject(new Error('Browser C API timeout'));},90000);
                    worker.onerror=e=>{clearTimeout(deadline);worker.terminate();reject(new Error(e.message));};
                    worker.onmessage=e=>{
                      if(e.data.error){clearTimeout(deadline);worker.terminate();reject(new Error(e.data.error));}
                      if(e.data.done){
                        clearTimeout(deadline);
                        const data=new Uint8Array(e.data.results[0].data);
                        if(data.length!==payload.length||data.some((b,i)=>b!==payload[i])){worker.terminate();reject(new Error('Browser C API bytes differ'));return;}
                        worker.terminate();resolve({method,threads,passed:true,bytes:data.length,archive_bytes:e.data.archive.byteLength,version:e.data.version});
                      }
                    };
                    worker.postMessage({operation:'pack',method,threads,password:'口令-secret',files:[{name:'中文/数据.bin',data:payload.slice().buffer}]});
                  });
                }''',{'method':method,'threads':2 if isolated else 1})
                records.append(result);print('BROWSER_SEVENZIP_CODEC_PASSED',target,method,flush=True)
            cli=page.evaluate('''async ({threads})=>{
              const url=new URL('worker.js',location.href);url.searchParams.set('module',new URL('../bin/7zz.js',location.href).href);
              const worker=new Worker(url),payload=new Uint8Array([1,2,3,4,5,6,7,8]);
              return await new Promise((resolve,reject)=>{
                const deadline=setTimeout(()=>{worker.terminate();reject(new Error('Browser CLI timeout'));},90000);
                worker.onerror=e=>{clearTimeout(deadline);worker.terminate();reject(new Error(e.message));};
                worker.onmessage=e=>{
                  if(e.data.error){clearTimeout(deadline);worker.terminate();reject(new Error(e.data.error));}
                  if(e.data.done){clearTimeout(deadline);worker.terminate();const archive=new Uint8Array(e.data.results[0].data);if(archive.length<20)reject(new Error('No actual 7z output'));else resolve({passed:true,archive_bytes:archive.length});}
                };
                worker.postMessage({args:['a','-y','-m0=ZSTD','-mmt='+threads,'/browser.7z','/input.bin'],files:[{name:'/input.bin',data:payload.buffer}],outputs:['/browser.7z']});
              });
            }''',{'threads':2 if isolated else 1})
            inputs={p.relative_to(sdk).as_posix():digest(p) for folder in ['lib','bin'] for p in (sdk/folder).iterdir() if p.suffix in ('.js','.wasm')}
            inputs.update({p.relative_to(sdk).as_posix():digest(p) for p in [sdk/'examples/worker.js',sdk/'examples/index.html']})
            record={'target':target,'passed':True,'browser_version':browser.version,'environment':state,'c_api_tests':records,'cli':cli,
                    'inputs':inputs,'scope':'Real Chrome Worker C API encode/decode of all seven codecs with UTF-8/encryption plus actual CLI archive creation. Single-thread explicitly runs without isolation/SharedArrayBuffer; pthread ABI runs with COOP/COEP.'}
            (work/'browser-runtime.json').write_text(json.dumps(record,indent=2)+'\n');browser.close();return record
    finally:server.shutdown();server.server_close()


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--destination',type=Path,required=True);p.add_argument('--target',required=True)
    a=p.parse_args();validate(a.destination.resolve(),a.target)
