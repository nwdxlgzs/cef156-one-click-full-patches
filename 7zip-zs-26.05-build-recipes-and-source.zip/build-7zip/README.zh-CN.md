# 7-Zip ZS 九端构建

目标：Windows x64/x86/ARM64、Linux x64/ARM64、macOS ARM64/x64、WASM 单线程/线程版。版本、提交和完整源码摘要见 source-lock.json，source.tar.gz 是已校验的完整上游源归档。

build_sdk.py 复用已有的 LLVM-MinGW、旧 glibc sysroot、Apple SDK/Clang 和 Emscripten 7.0.0。它使用上游完整 Format7zF/Alone2 对象清单，构建共享/静态库、原生 CLI 或独立 WASM 库与 CLI。api 提供直接操作 IArchive 接口的 C ABI 便捷层，examples 提供 CMake 消费示例。

patch_source 从锁定源归档提取原始文件，在独立目录内生成兼容改动：WASM 默认线程数量和内存预算、单线程 zstdmt 同步帧调度、Brotli 单线程属性保护、Zstd nbWorkers=0，以及上游 ARM64 SHA512 探测缺失的 stdio 声明。单线程保留 Fast-LZMA2，但使用其 FL2_SINGLETHREAD 实现。

validate_native.py 检查目标文件架构、依赖、Linux glibc 上限、Mac 部署版本和 ad-hoc 代码页摘要，并分别交叉链接共享、静态 C 示例。validate_oldlinux.py 在 Linux 4.9/glibc 2.28 客户机运行库和 CLI；validate_local_windows.py 使用本机 MSVC 构建并运行 C API 消费者；validate_wasm.py 使用 Node 验证 WASM 库、CLI 与独立静态示例；validate_browser.py 验证单线程无 SharedArrayBuffer 和多线程隔离环境下的 Chrome 执行。

publish_sdk.py 仅在验证通过后归档，逐文件回读确认摘要、权限和符号链接后回收构建中间文件。download_sdks.py 支持断点续传，每份完整包下载一次；finalize_local.py 在本地更新示例/配方/运行报告后重新压缩，保留原始下载，编译机器码字节不变。audit_delivery.py 对全部九个最终包、解压内容与运行证据进行审核并生成 SDK-INDEX.json。

默认服务器目录 `/home/ubuntu/7zip-build`，工具链目录 `/home/ubuntu/ffmpeg-build`，构建脚本内的路径需要在其他主机部署时相应调整。Windows 静态库使用 MinGW C++ ABI，MSVC 使用 C ABI DLL 和配套 .lib。不包含 GUI/Explorer 扩展，不支持 RAR 编码；上游许可和 unRAR 限制保留于各 SDK 的 licenses 目录。
