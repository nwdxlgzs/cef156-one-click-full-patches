#include "sevenzip_zs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static int check(int rc) { if (rc) fprintf(stderr,"%s\n",zs_last_error()); return rc; }
int main(int argc,char **argv) {
  const char *method=argc>1?argv[1]:"ZSTD";
  const char *password=argc>2?argv[2]:NULL;
  uint32_t threads=argc>3?(uint32_t)atoi(argv[3]):1;
  static const char text[]="7-Zip ZS library: UTF-8, binary-safe, in-memory round-trip.\n";
  zs_input input[3]={{"docs",NULL,0,1},{"docs/hello.txt",text,sizeof(text)-1,0},{"empty.bin",NULL,0,0}};
  void *packed=NULL,*restored=NULL;size_t packed_size=0,restored_size=0;
  zs_archive *archive=NULL;uint32_t count=0;int found=0;
  puts(zs_version());
  if(check(zs_create("7z",method,3,threads,password,input,3,64*1024*1024,&packed,&packed_size)))return 1;
  if(check(zs_open("7z",packed,packed_size,password,&archive)))goto error;
  if(check(zs_entry_count(archive,&count))||count!=3)goto error;
  for(uint32_t i=0;i<count;++i){
    zs_entry entry;if(check(zs_entry_info(archive,i,&entry)))goto error;
    printf("%s (%llu bytes)\n",entry.path_utf8,(unsigned long long)entry.size);
    if(!strcmp(entry.path_utf8,"docs/hello.txt") || !strcmp(entry.path_utf8,"docs\\hello.txt")){
      if(check(zs_extract_entry(archive,i,1024,&restored,&restored_size)))goto error;
      if(restored_size!=sizeof(text)-1||memcmp(restored,text,restored_size))goto error;
      zs_free(restored);restored=NULL;found=1;
      if(zs_extract_entry(archive,i,1,&restored,&restored_size)==0){fprintf(stderr,"Output limit was not enforced\n");goto error;}
    }
  }
  if(!found)goto error;
  zs_close(archive);zs_free(packed);
  puts("ZS_C_API_ROUNDTRIP_OK");return 0;
error:
  zs_close(archive);zs_free(packed);zs_free(restored);return 1;
}
