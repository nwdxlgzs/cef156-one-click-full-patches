#!/usr/bin/env python3
"""Publish a validated SDK with a complete payload readback before recycling."""
import argparse
import datetime as dt
import json
from pathlib import Path
import shutil
import sys

from build_sdk import TARGETS,VERSION,HERE,digest


def publish(root,target,cleanup):
    sdk=root/'output'/('7zip-zs_'+VERSION+'_'+target+'_release');wasm=target.startswith('wasm-')
    gate=root/'state'/((('runtime-' if wasm or target.startswith('linux-') else 'binary-audit-')+target)+'.json')
    validation=json.loads(gate.read_text())
    if not validation.get('passed') or validation['target']!=target:raise RuntimeError('Target validation did not pass')
    if json.loads((root/'state'/('build-'+target+'.json')).read_text())['phase']!='compiled':raise RuntimeError('Build did not complete')
    for path in sdk.rglob('*'):
        if path.suffix.lower() in ('.pdb','.dwo','.dwp','.debug','.ilk'):raise RuntimeError('Debug artifact unexpectedly staged')
    for path in HERE.glob('*.py'):shutil.copy2(path,sdk/'build-recipes'/path.name)
    shutil.copytree(HERE/'api',sdk/'build-recipes/api',dirs_exist_ok=True)
    shutil.copytree(HERE/'examples',sdk/'build-recipes/examples',dirs_exist_ok=True)
    if wasm:shutil.copytree(HERE/'wasm',sdk/'build-recipes/wasm',dirs_exist_ok=True)
    info={'target':target,'version':VERSION,'configuration':'Release','shared_library':not wasm,'static_library':True,
          'c_abi':'sevenzip_zs.h ABI 1; UTF-8 memory create/open/list/extract with bounded outputs',
          'upstream_interfaces':'include/upstream/CPP/7zip/Archive/IArchive.h and original CreateObject/handler/codec/hash exports',
          'cli':'bin/7zz'+('.exe' if target.startswith('windows-') else ''),
          'software_codecs':['LZMA','LZMA2','FLZMA2','ZSTD','BROTLI','LZ4','LZ5','LIZARD','BZip2','PPMd','Deflate','Deflate64'],
          'rar':'RAR4/RAR5 decoding only; upstream has no RAR encoder',
          'encryption':'Upstream full crypto/handler sources retained. C convenience API: 7z and ZIP AES256 (upstream ZIP password ASCII restriction). Advanced CLI/COM properties retained.',
          'runtime_verified':bool(validation.get('runtime_verified')),
          'validation_scope':validation['scope'],'sdk_complete':True,
          'threading':('single; no SharedArrayBuffer; inline zstdmt frame jobs; FL2_SINGLETHREAD' if target=='wasm-single' else 'pthread; 16-worker pool, recommended 1..4 codec threads' if wasm else 'native multithreaded'),
          'platform_limits':('WASM32+SIMD, 2GiB module memory ceiling; browser virtual files; no OS DLL codec plugins or native GUI' if wasm else
                             'macOS 13.0 minimum; runtime/signing/notarization not executed on a Mac' if target.startswith('mac-') else
                             'Linux 4.9 and glibc 2.28 full-system guest tested' if target.startswith('linux-') else
                             'ARM64 Windows execution unverified' if target=='windows-arm64' else 'Windows local execution is a separate download gate; Win7 not runtime-certified')}
    (sdk/'FEATURES.json').write_text(json.dumps(info,indent=2)+'\n')
    readme=f'''# 7-Zip ZS {VERSION} — {target} Release SDK

本包同时支持应用开发与终端调用，包含完整归档引擎、扩展编解码器、库、头文件、示例、许可证及构建配方。

## 库开发

简便 C 接口见 `include/sevenzip_zs.h`：zs_create / zs_open / zs_entry_count / zs_entry_info / zs_extract_entry，输入输出都是内存缓冲区，UTF-8 文件名，设置硬性输出大小限制。返回的缓冲区通过 zs_free 释放；归档句柄借用输入内存，直到 zs_close 之前必须保持输入有效。同一句柄不并发使用。

这是直接的库调用；不启动子进程。原生动态库为 `bin/7z.dll`、`lib/lib7zipzs.so` 或 `lib/lib7zipzs.dylib`。原生静态库为 `lib/lib7zipzs.a`；使用静态库时必须保留注册对象，示例 CMake 已配置 whole-archive / force_load。

Windows MSVC 使用 `lib/7zipzs.lib` 配套 DLL，并将 7z.dll 放到 EXE 搜索路径。GNU/Clang 可用 `lib/lib7zipzs.dll.a`。静态 .a 是对应 Clang/MinGW C++ ABI，不能当作 MSVC C++ 静态库直接混用；MSVC 应通过 DLL 的 C ABI 调用。

高级流式 IO、进度回调、归档更新及自定义属性可使用上游 IArchive / IInStream / IOutStream 接口，头文件保留于 `include/upstream`。动态库保留 CreateObject、GetNumberOfFormats、GetHandlerProperty2、CreateEncoder、CreateDecoder、GetHashers 等原生导出。C++ 接口需匹配平台 ABI 与 wchar_t/接口声明；跨语言优先使用 C 接口。

```sh
cmake -S examples -B example-build -DCMAKE_BUILD_TYPE=Release
cmake --build example-build --config Release
# 静态链接：再加 -DZS_USE_STATIC=ON，并使用匹配的 Clang 工具链
```

## 命令行

```sh
bin/7zz i
bin/7zz a -t7z -m0=ZSTD archive.7z input
bin/7zz t archive.7z
bin/7zz x archive.7z -ooutput
```

Windows 使用 `bin/7zz.exe`。CLI 包含上游完整命令；库接口与 CLI 共用同一版本源码和编解码器。RAR 支持解压，不提供 RAR 压缩算法。扩展算法的 .7z 需要支持对应算法的解压器。

## WebAssembly

仅 WASM 目标：`lib/sevenzip.js` + `.wasm` 是可直接调用 C ABI 的库模块，工厂为 createSevenZipLibrary；`bin/7zz.js` + `.wasm` 是完整 CLI 模块，工厂为 createSevenZipCLI；`lib/lib7zipzs.a` 是 Emscripten 7.0.0 的静态开发库。

`python examples/serve.py` 后打开 localhost 页面运行浏览器示例。单线程可以加 `--no-isolation`，无需 SharedArrayBuffer；多线程要求 HTTPS/localhost、COOP: same-origin、COEP: require-corp 和 SharedArrayBuffer。两个包均使用 SIMD128，线性内存上限 2GiB，实际可用值受浏览器限制。输入、压缩结果、解压结果会产生多份内存占用，大文件使用上游流接口或分段设计。

浏览器通过 examples/worker.js 调用库或 CLI。每个任务使用独立 Worker，结束后 terminate。线程数建议 1..4；多线程模块预创建 16 个 Worker，耗尽会明确报错。单线程必须指定 threads=1 / -mmt=1；扩展帧任务同步执行，保留各编解码器及原有格式兼容性。

Node 终端：`node examples/node-cli.cjs bin/7zz.js a archive.7z input`，Linux/macOS 也可通过 bin/7zz 包装入口。Node 使用 NODEFS 访问真实当前目录；浏览器 CLI 使用虚拟文件系统。WASM 不加载原生 DLL/so 编解码插件，不包含桌面 GUI 或 Explorer 扩展。

WASM 静态 C 示例：`emcmake cmake -S examples -B example-build -DZS_USE_STATIC=ON`；多线程再加 `-DZS_WASM_THREADS=ON`，使用线程/SIMD/异常设置一致的 Emscripten 7.0.0。原生平台不受 WASM 的内存/浏览器要求影响。

## 验证与许可证

本目标验证范围：{validation['scope']}

具体状态见 FEATURES.json 和 validation，不能将交叉链接检查视为实机验证。上游版本、源码内容摘要及编译配方随包保留。licenses 与 docs 包含 LGPL、BSD、unRAR 限制等原始条款；使用时保留相应声明。Release 包不附带调试符号。
'''
    (sdk/'README.zh-CN.md').write_text(readme,encoding='utf-8')
    sys.path.insert(0,'/opt/mycef/build-cef');from archive_posix import create_archive,verify_archive,list_sdk
    archive=root/'archives'/(sdk.name+'.tar.zst');record=create_archive(sdk,archive)
    record.update(target=target,sdk_complete=True,validation_sha256=digest(gate),runtime_verified=info['runtime_verified'],
                  validation_scope=validation['scope'],published_utc=dt.datetime.now(dt.timezone.utc).isoformat())
    receipt=root/'state'/('archive-'+target+'.json');receipt.write_text(json.dumps(record,indent=2)+'\n')
    if cleanup:
        verify_archive(archive,sdk.name,list_sdk(sdk));objects=root/'objects'/target
        if objects.exists():
            if objects.is_symlink() or objects.resolve().parent!=(root/'objects').resolve():raise RuntimeError('Unsafe build cleanup path')
            shutil.rmtree(objects);record['recycled_intermediate_directories']=[str(objects)];receipt.write_text(json.dumps(record,indent=2)+'\n')
    print('SEVENZIP_SDK_ARCHIVE_VERIFIED',json.dumps(record),flush=True);return record


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--target',choices=TARGETS,required=True);p.add_argument('--cleanup',action='store_true')
    a=p.parse_args();publish(a.root.resolve(),a.target,a.cleanup)
