#!/usr/bin/env python3
"""Cache the exact Linux Rust package and install it with its original updater."""
from __future__ import annotations

import argparse
import ast
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

from archive_posix import digest_file
from prepare_macos_aux import download
from prepare_posix import Preparation, CHROMIUM_REV, write_json


def original(prep, relative, destination):
    data = subprocess.check_output(['git', '-C', str(prep.src), 'show', CHROMIUM_REV + ':' + relative], env=prep.env)
    blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
    expected = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', relative, capture=True).stdout.split()[2]
    if blob != expected:
        raise RuntimeError('Original Rust source input differs from its Git blob: ' + relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    return blob


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--jobs', type=int, default=16, choices=range(1, 25))
    args = parser.parse_args()
    prep = Preparation(args.root)
    research = prep.root / 'cache/rust-installer-research'
    deps = research / 'DEPS'
    deps_blob = original(prep, 'DEPS', deps)
    tree = ast.parse(deps.read_text())
    node = next(item.value for item in tree.body if isinstance(item, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == 'deps' for target in item.targets))
    entry = next(ast.literal_eval(value) for key, value in zip(node.keys, node.values)
                 if isinstance(key, ast.Constant) and key.value == 'src/third_party/rust-toolchain')
    pin = next(item for item in entry['objects'] if item['object_name'].startswith('Linux_x64/'))
    cache = prep.root / 'downloads/clang'
    archive = cache / pin['object_name']
    archive.parent.mkdir(parents=True, exist_ok=True)
    url = 'https://storage.googleapis.com/' + entry['bucket'] + '/' + pin['object_name']
    download(url, archive, pin['size_bytes'], pin['sha256sum'], args.jobs)
    print('ORIGINAL_RUST_ARCHIVE_VERIFIED', pin['sha256sum'], pin['size_bytes'], flush=True)
    inputs = {}
    for relative in ['tools/clang/scripts/update.py', 'tools/rust/update_rust.py']:
        inputs[relative] = original(prep, relative, research / relative)
    clang_spec = importlib.util.spec_from_file_location('update', research / 'tools/clang/scripts/update.py')
    clang_module = importlib.util.module_from_spec(clang_spec)
    clang_spec.loader.exec_module(clang_module)
    clang_module.CDS_URL = cache.as_uri()
    sys.modules['update'] = clang_module
    rust_spec = importlib.util.spec_from_file_location('mycef_original_rust_update', research / 'tools/rust/update_rust.py')
    rust_module = importlib.util.module_from_spec(rust_spec)
    rust_spec.loader.exec_module(rust_module)
    expected_name = 'rust-toolchain-' + rust_module.GetRustClangRevision() + '.tar.xz'
    if archive.name != expected_name:
        raise RuntimeError('The original Rust revision differs from the fixed DEPS archive')
    output = prep.src / 'third_party/rust-toolchain'
    previous = sys.argv
    sys.argv = ['update_rust.py', '--output-dir', str(output)]
    try:
        if rust_module.main() not in (None, 0):
            raise RuntimeError('The unchanged original Rust updater failed')
    finally:
        sys.argv = previous
    rustc = output / 'bin/rustc'
    version = prep.run([rustc, '--version', '--verbose'], capture=True).stdout
    if '1edd55d' not in version:
        raise RuntimeError('The actual Rust executable has an unexpected commit')
    targets = sorted(path.name for path in (output / 'lib/rustlib').iterdir() if path.is_dir())
    record = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'chromium_revision': CHROMIUM_REV,
              'original_deps_git_blob': deps_blob, 'original_installer_git_blobs': inputs,
              'url': url, 'upstream_object': pin, 'archive_sha256': digest_file(archive),
              'rustc_sha256': digest_file(rustc), 'rustc_version': version,
              'installed': str(output), 'installed_rustlib_directories': targets,
              'scope': 'Actual original Rust archive SHA256, unchanged upstream installation and rustc execution; full Chromium/CEF Rust compilation remains required.'}
    write_json(prep.root / 'state/rust-prefetched.json', record)
    print('ORIGINAL_RUST_PREFETCH_INSTALLED', flush=True)


if __name__ == '__main__':
    main()
