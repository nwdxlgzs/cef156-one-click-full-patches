#!/usr/bin/env python3
"""Verify a real Linux SDK, archive it, and optionally reclaim its intermediates."""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil

from archive_posix import create_archive, digest_file
from audit_elf import audit
from package_linux import full_dwarf
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json
from validate_linux_clients import development_inputs


def checked_report(path, digest=None):
    path = Path(path)
    if digest and digest_file(path) != digest:
        raise RuntimeError('Validation report changed: ' + str(path))
    return json.loads(path.read_text('utf-8'))


def verify_runtime(path, expected_hash, cpu, sandbox, old=False):
    report = checked_report(path)
    required = ['webgl_draw', 'video_frames', 'aac_samples', 'webrtc_h264', 'h264_encode_roundtrip']
    if sandbox:
        required.append('renderer_seccomp_sandbox')
    if report.get('mode') == 'gpu-disabled':
        required.append('software_renderer')
    if (report.get('passed') is not True or report.get('libcef_sha256') != expected_hash
            or report.get('cpu') != cpu or report.get('sandbox_requested') is not sandbox
            or any(report.get('checks', {}).get(name) is not True for name in required)):
        raise RuntimeError('Runtime evidence does not validate this SDK: ' + str(path))
    if old and (not report.get('kernel', '').startswith('4.9.') or report.get('glibc_runtime') != 'glibc 2.28'):
        raise RuntimeError('Old-kernel/userland evidence is missing: ' + str(path))
    return report


def cleanup(prep, target, receipt):
    archive = Path(receipt['archive']).resolve()
    if prep.root / 'packages' not in archive.parents or digest_file(archive) != receipt['archive_sha256']:
        raise RuntimeError('Retain intermediates: the final archive is absent or changed')
    compiled = checked_report(prep.root / 'state' / ('compiled-' + target + '.json'))
    prepared = checked_report(prep.root / 'state' / ('sdk-' + target + '-prepared.json'))
    output = Path(compiled['output'])
    staging = Path(prepared['staging'])
    client_root = prep.root / 'cache/independent-clients' / target
    if (output.is_symlink() or output.resolve().parent != prep.src / 'out'
            or staging.is_symlink() or staging.resolve() != prep.root / 'packages/staging' / target
            or client_root.is_symlink()):
        raise RuntimeError('Cleanup boundary validation failed; preserve all outputs')
    for binary in [output / 'libcef.so', Path(prepared['sdk']) / 'Release/libcef.so']:
        if binary.exists() and digest_file(binary) != receipt['sdk_libcef_sha256']:
            raise RuntimeError('Cleanup candidate changed after validation: ' + str(binary))
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            name = (process / 'comm').read_text().strip()
            if name not in ('ninja', 'siso', 'clang', 'clang++', 'ld.lld', 'rustc'):
                continue
            cwd = (process / 'cwd').resolve()
            command = (process / 'cmdline').read_bytes().decode(errors='replace')
            if cwd == output or output in cwd.parents or str(output) in command:
                raise RuntimeError('Cleanup refused while a build process still uses this output')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    # Retain independently compiled clients as small reproducible evidence;
    # the large copied runtime and wrapper objects can then be reclaimed.
    clients = checked_report(prep.root / 'state' / ('clients-' + target + '-verified.json'))
    saved = prep.root / 'cache/validated-clients' / target
    for client in clients['clients']:
        folder = saved / ('sandbox-' + client['sandbox'].lower())
        folder.mkdir(parents=True, exist_ok=True)
        for key in ['cefsimple', 'cefclient']:
            source = Path(client[key])
            if not source.exists():
                destination = folder / key
                if not destination.exists() or digest_file(destination) != client[key + '_sha256']:
                    raise RuntimeError('Independent client evidence is no longer available')
                continue
            if digest_file(source) != client[key + '_sha256']:
                raise RuntimeError('Independent client changed before cleanup')
            shutil.copy2(source, folder / key)
            if digest_file(folder / key) != client[key + '_sha256']:
                raise RuntimeError('Saved independent client readback failed')
    removed = []
    for path in [output, staging, client_root]:
        if path.exists():
            shutil.rmtree(path)
            removed.append(str(path))
    write_json(prep.root / 'state' / ('sdk-' + target + '-cleanup.json'), {
        'target': target, 'archive_sha256': receipt['archive_sha256'], 'removed': removed,
        'retained_clients': str(saved), 'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'available_bytes': shutil.disk_usage(prep.root).free,
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', choices=['linux-x64', 'linux-arm64'], required=True)
    parser.add_argument('--cleanup', action='store_true')
    args = parser.parse_args()
    prep = Preparation(args.root)
    verified_path = prep.root / 'state' / ('sdk-' + args.target + '-verified.json')
    if verified_path.exists():
        prior = checked_report(verified_path)
        if prior.get('passed') is not True or prior.get('target') != args.target:
            raise RuntimeError('Existing final SDK receipt is invalid')
        if digest_file(Path(prior['archive'])) != prior['archive_sha256']:
            raise RuntimeError('The verified archive changed')
        if args.cleanup:
            cleanup(prep, args.target, prior)
        print('EXISTING_LINUX_SDK_ARCHIVE_VERIFIED', args.target, flush=True)
        return
    prepared_path = prep.root / 'state' / ('sdk-' + args.target + '-prepared.json')
    prepared = checked_report(prepared_path)
    compiled = checked_report(prep.root / 'state' / ('compiled-' + args.target + '.json'))
    if (compiled['chromium_revision'] != CHROMIUM_REV or compiled['cef_revision'] != CEF_REV
            or prepared['compiled_receipt_sha256'] != digest_file(prep.root / 'state' / ('compiled-' + args.target + '.json'))):
        raise RuntimeError('The SDK and compile provenance differ')
    sdk = Path(prepared['sdk']).resolve()
    if prep.root / 'packages/staging' not in sdk.parents:
        raise RuntimeError('SDK escaped its package staging tree')
    library_hash = digest_file(sdk / 'Release/libcef.so')
    if library_hash != prepared['sdk_libcef_sha256'] or library_hash != compiled['cef_binary_sha256']:
        raise RuntimeError('The actual SDK library differs from the compiled/validated bytes')
    cpu = args.target[len('linux-'):]
    machine = 'x86_64' if cpu == 'x64' else 'aarch64'
    full_dwarf(sdk / 'Release/libcef.so')
    elf = audit(sdk, cpu, max_glibc='2.28')
    if not elf['passed']:
        raise RuntimeError('Final SDK ELF compatibility audit failed: ' + repr(elf['errors']))
    client_path = prep.root / 'state' / ('clients-' + args.target + '-verified.json')
    clients = checked_report(client_path)
    if (clients.get('passed') is not True or clients.get('sdk_libcef_sha256') != library_hash
            or clients.get('sdk_development_inputs') != development_inputs(sdk)
            or clients.get('prepared_receipt_sha256') != digest_file(prepared_path)):
        raise RuntimeError('Independent clients did not validate these SDK sources and binaries')
    if {entry['sandbox'] for entry in clients['clients']} != {'ON', 'OFF'}:
        raise RuntimeError('Independent client sandbox ON/OFF builds are incomplete')
    runtime_files = []
    if {(entry['sandbox'], entry['mode']) for entry in clients['runtime_reports']} != {
            ('ON', 'auto'), ('ON', 'gpu-disabled'), ('OFF', 'auto')}:
        raise RuntimeError('The three independent-client runtime modes were not all tested')
    for entry in clients['runtime_reports']:
        path = Path(entry['path'])
        checked_report(path, entry['sha256'])
        verify_runtime(path, library_hash, machine, entry['sandbox'] == 'ON')
        runtime_files.append(('independent-' + entry['sandbox'].lower() + '-' + entry['mode'], path))
    arch = 'amd64' if cpu == 'x64' else 'arm64'
    old_path = prep.root / 'state' / ('linux49-' + arch + '-cef.json')
    old = checked_report(old_path)
    if (old.get('passed') is not True or old.get('cef_runtime_verified') is not True
            or old.get('sdk_libcef_sha256') != library_hash or old.get('architecture') != arch):
        raise RuntimeError('Actual Linux 4.9/glibc 2.28 CEF runtime validation is missing')
    if {entry['name'] for entry in old['reports']} != {'auto-sandbox', 'gpu-disabled-sandbox', 'auto-no-sandbox'}:
        raise RuntimeError('Old-system runtime modes are incomplete')
    for entry in old['reports']:
        path = Path(entry['report'])
        checked_report(path, entry['report_sha256'])
        verify_runtime(path, library_hash, machine, entry['name'] != 'auto-no-sandbox', old=True)
        runtime_files.append(('linux49-' + entry['name'], path))
    snapshot = prep.root / 'cache/snapshot-tools' / args.target / compiled['snapshot_identity_sha256']
    manifest_path = snapshot / 'manifest.json'
    manifest = checked_report(manifest_path)
    if manifest['identity_sha256'] != compiled['snapshot_identity_sha256'] or not manifest.get('files'):
        raise RuntimeError('Required snapshot tool export is missing')
    for relative, info in manifest['files'].items():
        path = snapshot / 'files' / relative
        if snapshot.resolve() not in path.resolve().parents or digest_file(path) != info['sha256']:
            raise RuntimeError('Snapshot cache file changed: ' + relative)
    validation = sdk / 'validation'
    validation.mkdir(exist_ok=True)
    for name, path in runtime_files:
        shutil.copy2(path, validation / (name + '.json'))
    write_json(validation / 'elf-final.json', elf)
    metadata = checked_report(sdk / 'MYCEF_BUILD.json')
    runtime_scope = ('Independent ARM64 clients executed with target instructions in a Linux 4.9/glibc 2.28 QEMU TCG VM; no native ARM hardware, UOS product or hardware GPU claim.'
                     if clients.get('cross_compiled') else
                     'Native independent clients and real Linux 4.9/glibc 2.28 full-system VM; no UOS product or hardware GPU claim.')
    metadata.update(runtime_validation_completed=True, verified_runtime_scope=runtime_scope,
                    measured_max_required_glibc=elf['measured_max_required_glibc'])
    write_json(sdk / 'MYCEF_BUILD.json', metadata)
    archive = prep.root / 'packages' / (sdk.name + '.tar.zst')
    result = create_archive(sdk, archive)
    receipt = {**result, 'passed': True, 'target': args.target, 'sdk_libcef_sha256': library_hash,
               'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
               'prepared_receipt_sha256': digest_file(prepared_path),
               'independent_clients_receipt_sha256': digest_file(client_path),
               'oldlinux_receipt_sha256': digest_file(old_path),
               'snapshot_manifest_sha256': digest_file(manifest_path),
               'measured_max_required_glibc': elf['measured_max_required_glibc'],
               'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    write_json(verified_path, receipt)
    if args.cleanup:
        cleanup(prep, args.target, receipt)
    print('LINUX_RELEASE_SDK_ARCHIVED_AND_VERIFIED', json.dumps(receipt), flush=True)


if __name__ == '__main__':
    main()
