#!/usr/bin/env python3
"""Generate AppKit menu source from CEF's menu-only XIBs without ibtool.

Only the observed CEF menu schema is supported. Unknown UI objects, outlets,
actions or attributes fail explicitly instead of silently losing behavior.
Generated source still requires compilation and macOS runtime validation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET


def literal(value):
    # Octal escapes preserve UTF-8 and control-key bytes without C/C++'s
    # restrictions on universal character names below U+00A0.
    result = ''
    for value in value.encode('utf-8'):
        if value in (34, 92):
            result += '\\' + chr(value)
        elif 32 <= value < 127:
            result += chr(value)
        else:
            result += '\\%03o' % value
    return '@"' + result + '"'


RECENT_MENU = '''
// NSDocumentController supplies recent URLs through public AppKit APIs.
// Keep this delegate for the process lifetime because NSMenu.delegate is weak.
@interface MyCEFRecentMenuDelegate : NSObject <NSMenuDelegate>
@property(nonatomic, retain) NSMutableArray* insertedItems;
- (void)openRecentDocument:(NSMenuItem*)sender;
@end
@implementation MyCEFRecentMenuDelegate
- (void)menuNeedsUpdate:(NSMenu*)menu {
  for (NSMenuItem* item in self.insertedItems) {
    [menu removeItem:item];
  }
  self.insertedItems = [NSMutableArray array];
  NSArray* urls = [[NSDocumentController sharedDocumentController] recentDocumentURLs];
  NSInteger position = 0;
  for (NSURL* url in urls) {
    NSString* title = [[NSFileManager defaultManager] displayNameAtPath:[url path]];
    NSMenuItem* item = MYCEF_MENU_AUTORELEASE([[NSMenuItem alloc]
        initWithTitle:title action:@selector(openRecentDocument:) keyEquivalent:@""]);
    [item setTarget:self];
    [item setRepresentedObject:url];
    [menu insertItem:item atIndex:position++];
    [self.insertedItems addObject:item];
  }
  if (position != 0) {
    NSMenuItem* separator = [NSMenuItem separatorItem];
    [menu insertItem:separator atIndex:position];
    [self.insertedItems addObject:separator];
  }
}
- (void)openRecentDocument:(NSMenuItem*)sender {
  NSDocumentController* controller = [NSDocumentController sharedDocumentController];
  [controller openDocumentWithContentsOfURL:[sender representedObject]
      display:YES completionHandler:^(NSDocument* document, BOOL alreadyOpen, NSError* error) {
        (void)document;
        (void)alreadyOpen;
        if (error) {
          [NSApp presentError:error];
        }
      }];
}
#if !__has_feature(objc_arc)
- (void)dealloc {
  [_insertedItems release];
  [super dealloc];
}
#endif
@end
static NSMutableArray* mycef_recent_menu_delegates;
'''


def generate(source):
    source = Path(source)
    root = ET.parse(source).getroot()
    if root.tag != 'document' or root.get('targetRuntime') != 'MacOSX.Cocoa':
        raise RuntimeError('Expected a Cocoa menu XIB')
    objects = root.find('objects')
    if objects is None:
        raise RuntimeError('The XIB has no objects')
    menus = [item for item in objects if item.tag == 'menu']
    if len(menus) != 1 or menus[0].get('systemMenu') != 'main':
        raise RuntimeError('Expected exactly one top-level main menu')
    for item in objects:
        if item.tag == 'menu':
            continue
        if (item.tag == 'customObject' and item.get('id') in {'-1', '-2', '-3'}
                and not len(item)):
            continue
        if (item.tag == 'userDefaultsController' and item.get('representsSharedInstance') == 'YES'
                and not len(item)):
            continue
        raise RuntimeError('Unsupported top-level XIB object: ' + item.tag)
    lines = ['  (void)owner;']
    counters = {'menus': 0, 'items': 0, 'actions': 0}
    roles = {}
    help_menu = None

    def attributes(element, allowed):
        unknown = set(element.attrib) - set(allowed)
        if unknown:
            raise RuntimeError('Unsupported XIB attributes on ' + element.tag + ': ' + str(sorted(unknown)))

    def menu(element):
        nonlocal help_menu
        attributes(element, ['key', 'title', 'id', 'userLabel', 'systemMenu'])
        name = 'menu_' + str(counters['menus'])
        counters['menus'] += 1
        role = element.get('systemMenu')
        if role:
            if role not in {'main', 'apple', 'services', 'window', 'recentDocuments'} or role in roles:
                raise RuntimeError('Unsupported or duplicate system menu: ' + role)
            roles[role] = name
        if element.get('title') == 'Help':
            help_menu = name
        lines.append('  NSMenu* ' + name + ' = MYCEF_MENU_AUTORELEASE([[NSMenu alloc] initWithTitle:' + literal(element.get('title', '')) + ']);')
        if any(child.tag != 'items' for child in element) or len(element.findall('items')) > 1:
            raise RuntimeError('A menu may contain only one items list')
        items = element.find('items')
        for item in items if items is not None else ():
            if item.tag != 'menuItem':
                raise RuntimeError('Unsupported menu content: ' + item.tag)
            attributes(item, ['title', 'keyEquivalent', 'tag', 'id', 'isSeparatorItem', 'userLabel'])
            item_name = 'item_' + str(counters['items'])
            counters['items'] += 1
            if item.get('isSeparatorItem') == 'YES':
                if any(child.tag != 'modifierMask' for child in item):
                    raise RuntimeError('Unexpected separator behavior')
                lines.append('  NSMenuItem* ' + item_name + ' = [NSMenuItem separatorItem];')
            else:
                if item.get('isSeparatorItem') not in (None, 'NO'):
                    raise RuntimeError('Unknown separator value')
                lines.append('  NSMenuItem* ' + item_name + ' = MYCEF_MENU_AUTORELEASE([[NSMenuItem alloc] initWithTitle:'
                             + literal(item.get('title', '')) + ' action:NULL keyEquivalent:' + literal(item.get('keyEquivalent', '')) + ']);')
            if item.get('tag') is not None:
                if not re.fullmatch(r'-?\d+', item.get('tag')):
                    raise RuntimeError('Invalid numeric menu tag')
                lines.append('  [' + item_name + ' setTag:' + item.get('tag') + '];')
            for child in item:
                if child.tag == 'menu':
                    submenu = menu(child)
                    lines.append('  [' + item_name + ' setSubmenu:' + submenu + '];')
                elif child.tag == 'modifierMask':
                    attributes(child, ['key', 'shift', 'command', 'option', 'control', 'function'])
                    if child.get('key') != 'keyEquivalentModifierMask':
                        raise RuntimeError('Unsupported key modifier mask')
                    modifiers = []
                    for key, flag in [('shift', 'Shift'), ('command', 'Command'), ('option', 'Option'), ('control', 'Control'), ('function', 'Function')]:
                        value = child.get(key)
                        if value not in (None, 'YES', 'NO'):
                            raise RuntimeError('Unsupported key modifier value')
                        if value == 'YES':
                            modifiers.append('NSEventModifierFlag' + flag)
                    lines.append('  [' + item_name + ' setKeyEquivalentModifierMask:' + (' | '.join(modifiers) or '0') + '];')
                elif child.tag == 'connections':
                    if len(child) != 1 or child[0].tag != 'action':
                        raise RuntimeError('Only one action connection per menu item is supported')
                    action = child[0]
                    attributes(action, ['selector', 'target', 'id'])
                    selector = action.get('selector', '')
                    if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*:', selector) or action.get('target') not in {'-1', '-2'}:
                        raise RuntimeError('Unsupported action selector/target')
                    counters['actions'] += 1
                    target = 'owner' if action.get('target') == '-2' else 'nil'
                    if role == 'recentDocuments' and selector == 'clearRecentDocuments:':
                        target = '[NSDocumentController sharedDocumentController]'
                    lines.append('  [' + item_name + ' setAction:NSSelectorFromString(' + literal(selector) + ')];')
                    lines.append('  [' + item_name + ' setTarget:' + target + '];')
                else:
                    raise RuntimeError('Unsupported menu item child: ' + child.tag)
            lines.append('  [' + name + ' addItem:' + item_name + '];')
        return name

    menu(menus[0])
    lines.append('  [NSApp setMainMenu:' + roles['main'] + '];')
    for role, selector in [('services', 'setServicesMenu'), ('window', 'setWindowsMenu')]:
        if role in roles:
            lines.append('  [NSApp ' + selector + ':' + roles[role] + '];')
    if help_menu:
        lines.append('  [NSApp setHelpMenu:' + help_menu + '];')
    if 'recentDocuments' in roles:
        lines += ['  if (!mycef_recent_menu_delegates) {',
                  '    mycef_recent_menu_delegates = [[NSMutableArray alloc] init];', '  }',
                  '  MyCEFRecentMenuDelegate* recent = MYCEF_MENU_AUTORELEASE([[MyCEFRecentMenuDelegate alloc] init]);',
                  '  [mycef_recent_menu_delegates addObject:recent];',
                  '  [' + roles['recentDocuments'] + ' setDelegate:recent];']
    header = ('// Generated from the original menu-only CEF XIB; do not edit.\n'
              '#import <Cocoa/Cocoa.h>\n'
              '#if __has_feature(objc_arc)\n#define MYCEF_MENU_AUTORELEASE(value) (value)\n'
              '#else\n#define MYCEF_MENU_AUTORELEASE(value) [(value) autorelease]\n#endif\n')
    if 'recentDocuments' in roles:
        header += RECENT_MENU
    code = header + '\nextern "C" void MyCEFInstallMainMenu(id owner) {\n' + '\n'.join(lines) + '\n}\n'
    record = {'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
              'output_sha256': hashlib.sha256(code.encode()).hexdigest(), **counters,
              'system_roles': sorted(roles), 'compiled': False, 'macos_runtime_verified': False,
              'recent_documents': 'Public NSDocumentController URL list and open API; target runtime behavior still needs validation.'}
    return code, record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--receipt', type=Path)
    args = parser.parse_args()
    code, record = generate(args.input)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(code, encoding='utf-8', newline='\n')
    if args.receipt:
        args.receipt.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(record), flush=True)


if __name__ == '__main__':
    main()
