"""Read-only cache for Chromium's pinned Python wheel repository.

The only allowed upstream is the official Chromium Artifact Registry. curl
keeps HTTPS verification and can route this hostname to a verified reachable
Google frontend without modifying the server's global DNS or hosts file.
"""
import hashlib
import html
from pathlib import Path
import re
import shutil
import subprocess
import threading
import urllib.parse

ORIGIN = "https://us-python.pkg.dev/chrome-python-ar/chrome-python-ar/"
FRONTEND = "172.253.117.82"


class WheelMirror:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.directory.mkdir(exist_ok=True, parents=True)
        self.lock = threading.Lock()
        self.gates = {}

    def download(self, relative, destination, expected=None):
        if not re.fullmatch(r"[A-Za-z0-9_.+%/-]+", relative) or ".." in relative.split("/"):
            raise ValueError("Invalid wheel repository path")
        if destination.exists() and expected and hashlib.sha256(destination.read_bytes()).hexdigest() == expected:
            return
        curl = shutil.which("curl.exe") or shutil.which("curl")
        if not curl:
            raise RuntimeError("curl is required for wheel mirror downloads")
        temporary = destination.with_suffix(destination.suffix + ".partial")
        if expected and temporary.is_file() and hashlib.sha256(temporary.read_bytes()).hexdigest() == expected:
            temporary.replace(destination)
            return
        for route in [True, False]:
            command = [curl, "--fail", "--location", "--silent", "--show-error", "--connect-timeout", "10",
                       "--max-time", "1200" if expected else "180", "--output", str(temporary)]
            if expected:
                command += ['--continue-at', '-', '--speed-limit', '1024', '--speed-time', '120']
            if route:
                command += ["--resolve", "us-python.pkg.dev:443:" + FRONTEND]
            command += [ORIGIN + relative]
            result = subprocess.run(command, capture_output=True)
            if result.returncode == 0:
                break
            if result.returncode == 33:
                # A server without byte-range support must not cause an
                # existing prefix to be appended to a complete response.
                temporary.unlink(missing_ok=True)
        else:
            raise RuntimeError("Official wheel download failed: " + relative)
        if expected and hashlib.sha256(temporary.read_bytes()).hexdigest() != expected:
            temporary.unlink(missing_ok=True)
            raise ValueError("Official wheel SHA256 mismatch")
        temporary.replace(destination)

    def serve(self, handler):
        path = urllib.parse.urlsplit(handler.path).path
        match = re.fullmatch(r"/python/simple/([a-z0-9_.-]+)/?", path)
        base = f"http://127.0.0.1:{handler.server.server_port}"
        if match:
            package = re.sub(r"[-_.]+", "-", match[1])
            index = self.directory / (package + ".html")
            with self.lock:
                gate = self.gates.setdefault("index:" + package, threading.Lock())
            with gate:
                if not index.exists():
                    self.download("simple/" + package + "/", index)
                content = index.read_text("utf-8")
            def rewrite(found):
                url = html.unescape(found[1])
                if not url.startswith(ORIGIN):
                    raise ValueError("Wheel index linked an unsupported upstream")
                parsed = urllib.parse.urlsplit(url)
                digest = re.fullmatch(r"sha256=([a-f0-9]{64})", parsed.fragment)
                relative = parsed.path.removeprefix("/chrome-python-ar/chrome-python-ar/")
                if not digest or not relative.endswith(".whl") or parsed.query:
                    raise ValueError("Wheel index link lacks a fixed SHA256")
                return 'href="' + base + "/python/files/" + digest[1] + "/" + relative + "#sha256=" + digest[1] + '"'
            content = re.sub(r'href="([^"]+)"', rewrite, content)
            handler.respond(200, content.encode("utf-8"), "text/html; charset=utf-8")
            return
        match = re.fullmatch(r"/python/files/([a-f0-9]{64})/([A-Za-z0-9_.+%/-]+\.whl)", path)
        if match:
            digest, relative = match.groups()
            destination = self.directory / (digest + ".whl")
            with self.lock:
                gate = self.gates.setdefault(digest, threading.Lock())
            with gate:
                self.download(relative, destination, digest)
            print("PYTHON_WHEEL_VERIFIED " + relative + " " + digest, flush=True)
            handler.respond(200, destination.read_bytes(), "application/octet-stream")
            return
        handler.respond(404, b"Wheel cache path not found", "text/plain", 5)
