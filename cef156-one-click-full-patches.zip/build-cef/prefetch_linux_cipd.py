#!/usr/bin/env python3
"""Warm the shared verified mirror cache for fixed Linux DEPS packages.

Runs alongside the genuine gclient Git/GCS sync; never installs packages into
its worktree or writes a dependency-sync completion marker.
"""
from __future__ import annotations

import argparse
from collections.abc import Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys

from cipd_mirror import MirrorCache
from prepare_posix import Preparation, CHROMIUM_REV, DEPOT_REV, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--jobs', type=int, default=6, choices=range(1, 13))
    args = parser.parse_args()
    prep = Preparation(args.root)
    deps = prep.src / 'DEPS'
    data = deps.read_bytes()
    expected = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', 'DEPS', capture=True).stdout.split()[2]
    blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
    if blob != expected or prep.git(prep.depot, 'rev-parse', 'HEAD', capture=True).stdout.strip() != DEPOT_REV:
        raise RuntimeError('Original fixed DEPS/depot evaluator identity changed')
    sys.path.insert(0, str(prep.depot))
    import gclient_eval
    config = {}
    exec((prep.root / 'chromium/.gclient').read_text('utf-8'), {'__builtins__': {}}, config)
    custom = config['solutions'][0]['custom_vars']
    builtin = {'host_os': 'linux', 'host_cpu': 'x64'}
    for name in ['android', 'chromeos', 'fuchsia', 'ios', 'linux', 'mac', 'win', 'arm', 'arm64',
                 'x86', 'x64', 'mips', 'mips64', 'ppc', 'riscv64', 's390', 'loong64']:
        builtin['checkout_' + name] = name in config['target_os'] or name in config['target_cpu']
    parsed = gclient_eval.Exec(data.decode(), str(deps), vars_override=custom, builtin_vars=builtin)
    variables = {**parsed['vars'], **builtin, **custom}
    selected = {}
    for path, item in parsed['deps'].items():
        if not isinstance(item, Mapping) or item.get('dep_type') != 'cipd':
            continue
        if not gclient_eval.EvaluateCondition(item.get('condition', 'True'), variables):
            continue
        for pin in item['packages']:
            package = pin['package'].replace('${{platform}}', 'linux-amd64').replace('${{arch}}', 'amd64')
            package = package.replace('${platform}', 'linux-amd64').replace('${arch}', 'amd64')
            selected[package + '@' + pin['version']] = {'path': path, 'package': package, 'version': pin['version']}
    priority = ['cpython3', 'ninja', 'gn/gn/', 'gperf', 'typescript']
    entries = sorted(selected.values(), key=lambda item: next((i for i, value in enumerate(priority) if value in item['package']), len(priority)))
    cache = MirrorCache(prep.root / 'downloads/cipd-mirror')
    results, errors = [], []
    def one(item):
        entry = cache.resolve(item['package'], item['version'])
        print('LINUX_CIPD_PREFETCH_VERIFIED', item['package'], entry['sha256'], entry['size'], flush=True)
        return {**item, 'zip_sha256': entry['sha256'], 'bytes': entry['size'], 'instance_id': entry['instance_id']}
    with ThreadPoolExecutor(args.jobs) as pool:
        futures = {pool.submit(one, item): item for item in entries}
        for future in as_completed(futures):
            try:
                results.append(future.result())
            except Exception as error:
                errors.append({'package': futures[future], 'error': repr(error)})
                print('LINUX_CIPD_PREFETCH_ERROR', json.dumps(errors[-1]), flush=True)
    result = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'original_deps_git_blob': blob,
              'chromium_revision': CHROMIUM_REV, 'packages': results, 'errors': errors, 'passed': not errors,
              'worktree_packages_installed': False, 'gclient_sync_complete': False,
              'scope': 'Original fixed root DEPS Linux package archive prewarming in the same locked mirror cache. Genuine gclient still installs and verifies its own full dependency set.'}
    write_json(prep.root / 'state/linux-cipd-prefetched.json', result)
    if errors:
        raise RuntimeError('Some mirror prefetch packages failed; successful verified archives retained')


if __name__ == '__main__':
    main()
