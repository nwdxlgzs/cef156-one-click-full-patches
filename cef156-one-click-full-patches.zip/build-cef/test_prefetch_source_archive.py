import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import prefetch_source_archive as source


class RangeResumeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.parts = Path(self.temporary.name)

    def test_interrupted_valid_response_resumes_without_losing_bytes(self):
        ranges = []
        def curl(command, **_kwargs):
            requested = command[command.index('--range') + 1]
            ranges.append(requested)
            start, end = map(int, requested.split('-'))
            Path(command[command.index('--dump-header') + 1]).write_text(
                f'HTTP/1.1 206 Partial Content\r\nContent-Range: bytes {start}-{end}/{source.SIZE}\r\n')
            Path(command[command.index('--output') + 1]).write_bytes(b'abc' if start == 100 else b'def')
            return subprocess.CompletedProcess(command, 28 if start == 100 else 0, b'', b'timeout')
        with mock.patch.object(source.subprocess, 'run', side_effect=curl), mock.patch.object(source.time, 'sleep'):
            result = source.download_piece('curl', self.parts, 0, 100, 105)
        self.assertEqual(result.read_bytes(), b'abcdef')
        self.assertEqual(ranges, ['100-105', '103-105'])

    def test_wrong_content_range_is_never_appended(self):
        calls = []
        def curl(command, **_kwargs):
            calls.append(command)
            received = '0-5' if len(calls) == 1 else '100-105'
            Path(command[command.index('--dump-header') + 1]).write_text(
                f'Content-Range: bytes {received}/{source.SIZE}\n')
            Path(command[command.index('--output') + 1]).write_bytes(b'WRONG!' if len(calls) == 1 else b'abcdef')
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch.object(source.subprocess, 'run', side_effect=curl), mock.patch.object(source.time, 'sleep'):
            result = source.download_piece('curl', self.parts, 0, 100, 105)
        self.assertEqual(result.read_bytes(), b'abcdef')
        self.assertEqual([c[c.index('--range') + 1] for c in calls], ['100-105', '100-105'])

    def test_existing_receipt_requires_matching_prefix_hash(self):
        (self.parts / '0000.partial').write_bytes(b'bad')
        (self.parts / '0000.progress.json').write_text(json.dumps({
            'range': [100, 105, source.SIZE], 'stored': 3,
            'sha256': hashlib.sha256(b'abc').hexdigest(),
        }))
        def curl(command, **_kwargs):
            self.assertEqual(command[command.index('--range') + 1], '100-105')
            Path(command[command.index('--dump-header') + 1]).write_text(
                f'Content-Range: bytes 100-105/{source.SIZE}\n')
            Path(command[command.index('--output') + 1]).write_bytes(b'abcdef')
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch.object(source.subprocess, 'run', side_effect=curl):
            result = source.download_piece('curl', self.parts, 0, 100, 105)
        self.assertEqual(result.read_bytes(), b'abcdef')

    def test_small_requests_preserve_the_existing_piece_and_resume_identity(self):
        ranges = []
        payload = b'abcdefghi'
        def curl(command, **_kwargs):
            first, last = map(int, command[command.index('--range') + 1].split('-'))
            ranges.append((first, last))
            Path(command[command.index('--dump-header') + 1]).write_text(
                f'Content-Range: bytes {first}-{last}/{source.SIZE}\n')
            Path(command[command.index('--output') + 1]).write_bytes(payload[first-100:last-99])
            return subprocess.CompletedProcess(command, 0, b'', b'')
        with mock.patch.object(source, 'REQUEST_BYTES', 4), mock.patch.object(source.subprocess, 'run', side_effect=curl):
            result = source.download_piece('curl', self.parts, 0, 100, 108)
        self.assertEqual(result.read_bytes(), payload)
        self.assertEqual(ranges, [(100, 103), (104, 107), (108, 108)])
        self.assertFalse((self.parts / '0000.progress.json').exists())


if __name__ == '__main__':
    unittest.main()
