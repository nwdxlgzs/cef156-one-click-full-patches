#!/usr/bin/env python3
"""Compile the compact SDK's two real demo entries and run native x64 checks."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

from minimize_sdk import digest, write_json


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--target',choices=['linux-x64','linux-arm64'],required=True)
    a=p.parse_args();r=a.root.resolve()
    sdk=r/'packages/strip-lib'/('cef_156.0.8071.0_'+a.target+'_release')
    work=r/'cache/strip-validation'/a.target;work.mkdir(parents=True,exist_ok=True)
    toolchain=r/'cache/client-toolchains'/a.target/'toolchain.cmake'
    runs=[];clients=[]
    def run(args,log):
        with log.open('w') as f:
            v=subprocess.run(list(map(str,args)),stdout=f,stderr=subprocess.STDOUT)
        if v.returncode:raise RuntimeError(str(args)+' failed; see '+str(log))
    for mode in ['on','off']:
        out=work/mode
        run(['cmake','-S',sdk/'demos'/('sandbox-'+mode),'-B',out,'-G','Ninja',
             '-DCMAKE_BUILD_TYPE=Release','-DCMAKE_TOOLCHAIN_FILE='+str(toolchain)],work/(mode+'-configure.log'))
        run(['cmake','--build',out,'--target','cefsimple','-j','4'],work/(mode+'-build.log'))
        client=out/'sdk/demos/common/Release/cefsimple'
        if not client.is_file() or digest(client.parent/'libcef.so')!=digest(sdk/'Release/libcef.so'):
            raise RuntimeError('Demo output/deployed engine mismatch')
        clients.append({'sandbox':mode.upper(),'binary_sha256':digest(client),'binary':str(client)})
        if a.target=='linux-x64':
            helper=sdk/'Release/chrome-sandbox'
            installed=Path('/usr/local/libexec/mycef-strip-sandbox')/digest(helper)/'chrome-sandbox'
            subprocess.run(['sudo','-n','install','-D','-o','root','-g','root','-m','4755',str(helper),str(installed)],check=True)
            media=sorted((r/'validation/oldlinux').glob('amd64-runtime-cef-*/fixture.mp4'))[-1]
            for gpu in (['auto','gpu-disabled'] if mode=='on' else ['auto']):
                report=work/(mode+'-'+gpu+'.json')
                command=['xvfb-run','-a',sys.executable,Path(__file__).parent/'runtime_probe_posix.py',
                         '--sdk',sdk,'--client',client,'--media',media,'--output',report,'--mode',gpu]
                command+=['--sandbox-helper',installed] if mode=='on' else ['--no-sandbox']
                run(command,work/(mode+'-'+gpu+'-runtime.log'))
                value=json.loads(report.read_text())
                if not value['passed'] or value['libcef_sha256']!=digest(sdk/'Release/libcef.so'):
                    raise RuntimeError('Actual stripped runtime failed')
                runs.append({'sandbox':mode.upper(),'mode':gpu,'report':str(report),'sha256':digest(report)})
        print('COMPACT_DEMO_PASSED',a.target,mode,flush=True)
    result={'target':a.target,'demo_build_verified':True,'clients':clients,
            'runtime_verified_after_strip':a.target=='linux-x64','runtime_reports':runs}
    write_json(work/'result.json',result)
    print('COMPACT_VALIDATION_PASSED',json.dumps(result),flush=True)


if __name__=='__main__':main()
