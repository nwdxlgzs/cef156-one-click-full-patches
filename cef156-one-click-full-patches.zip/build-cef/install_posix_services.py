#!/usr/bin/env python3
"""Install restart-persistent preparation and sequential Release build units.

The actual checkpoints gate source preparation, builds, packaging, validation
and cleanup. Installed services do not by themselves prove an SDK is complete.
"""
from __future__ import annotations

import argparse
import getpass
import json
import os
from pathlib import Path
import pwd
import subprocess

from prepare_posix import Preparation

HERE = Path(__file__).resolve().parent


def systemd_word(value):
    # Systemd expands '%' specifiers even within a quoted argument.
    return json.dumps(str(value).replace('%', '%%'), ensure_ascii=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--user', default=os.environ.get('SUDO_USER') or getpass.getuser())
    parser.add_argument('--start', action='store_true')
    parser.add_argument('--compact-mac', action='store_true',
                        help='Also install the compact Mac SDK follower after full archive verification')
    args = parser.parse_args()
    if pwd.getpwnam(args.user).pw_uid == 0:
        parser.error('Select a normal unprivileged build account')
    prep = Preparation(args.root)
    mirror_port = 8765
    ready = prep.root / 'state/cipd-mirror.json'
    if ready.is_file():
        from urllib.parse import urlsplit
        mirror_port = urlsplit(json.loads(ready.read_text('utf-8'))['url']).port
        if not isinstance(mirror_port, int) or not 1024 <= mirror_port <= 65535:
            raise RuntimeError('Unexpected existing loopback mirror port')
    units = prep.root / 'state/systemd-units'
    units.mkdir(exist_ok=True)
    python = '/usr/bin/python3'
    specs = {
        'mycef-cipd-mirror': ('simple', 'cipd_mirror.py',
            ['--cache', prep.root / 'downloads/cipd-mirror', '--port', mirror_port,
             '--ready-file', prep.root / 'state/cipd-mirror.json'],
            [], 'cipd-mirror.log'),
        'mycef-source-archive': ('oneshot', 'prefetch_source_archive.py',
            ['--directory', prep.root / 'downloads/source-archive', '--jobs', '24'], [], 'source-archive.log'),
        'mycef-posix-bootstrap': ('oneshot', 'prepare_posix.py',
            ['--root', prep.root, '--stage', 'bootstrap'], ['mycef-cipd-mirror.service'], 'depot-bootstrap.log'),
        'mycef-posix-preparation': ('simple', 'posix_prepare_runner.py',
            ['--root', prep.root, '--through-linux-x64-build'], ['mycef-cipd-mirror.service', 'mycef-posix-bootstrap.service'], 'posix-preparation.log'),
        'mycef-linux-release-continuation': ('simple', 'linux_release_runner.py',
            ['--root', prep.root], ['mycef-posix-preparation.service'], 'linux-release-continuation.log'),
        'mycef-macos-release-continuation': ('simple', 'mac_release_runner.py',
            ['--root', prep.root], ['mycef-linux-release-continuation.service'], 'mac-release-continuation.log'),
    }
    if args.compact_mac:
        specs['mycef-compact-mac-continuation'] = (
            'simple', 'compact_mac_runner.py', ['--root', prep.root],
            ['mycef-macos-release-continuation.service'], 'compact-mac-continuation.log')
    for name, (kind, script, arguments, after, log) in specs.items():
        executable = ' '.join(systemd_word(word) for word in [python, HERE / script, *arguments])
        lines = ['[Unit]', 'Description=MyCEF 156 POSIX preparation: ' + name,
                 'Wants=network-online.target', 'After=network-online.target ' + ' '.join(after),
                 '[Service]', 'Type=' + kind, 'User=' + args.user,
                 'WorkingDirectory=' + str(prep.root).replace('%', '%%'),
                 'ExecStart=' + executable,
                 'Environment=PYTHONUNBUFFERED=1', 'TimeoutStartSec=infinity',
                 'StandardOutput=append:' + str(prep.root / 'logs' / log),
                 'StandardError=append:' + str(prep.root / 'logs' / log)]
        if kind == 'oneshot':
            lines.append('RemainAfterExit=yes')
            if name == 'mycef-source-archive':
                lines.extend(['Restart=on-failure', 'RestartSec=30'])
        elif name == 'mycef-cipd-mirror':
            lines.extend(['Restart=on-failure', 'RestartSec=10'])
        elif name == 'mycef-compact-mac-continuation':
            lines.extend(['Nice=10', 'CPUQuota=200%'])
        lines.extend(['[Install]', 'WantedBy=multi-user.target', ''])
        source = units / (name + '.service')
        source.write_text('\n'.join(lines), encoding='utf-8')
        subprocess.run(['sudo', 'install', '-m', '0644', str(source), '/etc/systemd/system/' + source.name], check=True)
        # A live systemd-run unit's fragment takes precedence over /etc. A
        # normal drop-in also applies to that transient fragment, so future
        # starts use the requested arguments and stable mirror port.
        override = ['[Service]', 'ExecStart=', 'ExecStart=' + executable, 'TimeoutStartSec=infinity']
        if name in ('mycef-source-archive', 'mycef-cipd-mirror'):
            override.extend(['Restart=on-failure', 'RestartSec=30'])
        override_source = units / (name + '-override.conf')
        override_source.write_text('\n'.join(override) + '\n', encoding='utf-8')
        override_directory = '/etc/systemd/system/' + name + '.service.d'
        subprocess.run(['sudo', 'install', '-d', '-m', '0755', override_directory], check=True)
        subprocess.run(['sudo', 'install', '-m', '0644', str(override_source), override_directory + '/override.conf'], check=True)
    subprocess.run(['systemd-analyze', 'verify', *[str(units / (name + '.service')) for name in specs]], check=True)
    subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=True)
    enabled = subprocess.run(['sudo', 'systemctl', 'enable', *[name + '.service' for name in specs]],
                             capture_output=True, text=True)
    if enabled.returncode:
        if 'transient or generated' not in enabled.stderr:
            raise RuntimeError(enabled.stderr)
        # A live systemd-run unit keeps its transient identity until it stops.
        # Install the normal [Install] links without interrupting its current
        # downloader or CIPD connection. The /etc units take over on reboot.
        wants = Path('/etc/systemd/system/multi-user.target.wants')
        subprocess.run(['sudo', 'mkdir', '-p', str(wants)], check=True)
        for name in specs:
            subprocess.run(['sudo', 'ln', '-sfn', '/etc/systemd/system/' + name + '.service',
                            str(wants / (name + '.service'))], check=True)
        subprocess.run(['sudo', 'systemctl', 'daemon-reload'], check=True)
        print('Persistent boot links installed; existing transient processes retained.', flush=True)
    if args.start:
        # Starting an already running unit retains its current process. It
        # neither starts a second downloader nor restarts the live mirror.
        subprocess.run(['sudo', 'systemctl', 'start', '--no-block', *[name + '.service' for name in specs]], check=True)
    print('POSIX_PREPARATION_SERVICES_INSTALLED', ','.join(specs), flush=True)


if __name__ == '__main__':
    main()
