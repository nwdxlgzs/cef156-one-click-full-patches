#!/usr/bin/env python3
"""Import genuine Git blobs from the verified official source archive.

The real commit and trees must already exist in a metadata-only clone. No
commit or source revision is manufactured. Each imported file is checked
against its exact Git tree entry, and every required blob is checked again
before a completed mirror record is written.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from prefetch_source_archive import MD5, SIZE
from complete_source_objects import present_blobs

COMMIT = "aa939feff52ea94f0ca07d8029086738c2683685"
PREFIX = "chromium-156.0.8071.0/"


def git(repository, *args, **kwargs):
    return subprocess.run(["git", "-C", str(repository), *args], check=True,
                          env={**os.environ, "GIT_NO_LAZY_FETCH": "1"}, **kwargs)


def seed(repository, archive, record):
    repository, archive, record = map(Path, (repository, archive, record))
    if archive.stat().st_size != SIZE:
        raise ValueError("Official source archive size mismatch")
    digest = hashlib.md5()
    with archive.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != MD5:
        raise ValueError("Official source archive MD5 mismatch")
    actual = git(repository, "rev-parse", "refs/tags/156.0.8071.0^{commit}", capture_output=True).stdout.decode().strip()
    if actual != COMMIT:
        raise ValueError("Metadata clone does not contain the locked Chromium tag")
    tree = git(repository, "ls-tree", "-r", "-z", "--full-tree", COMMIT, capture_output=True).stdout
    entries = {}
    required = set()
    for entry in tree.split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        mode, kind, oid = metadata.decode("ascii").split()
        if kind == "blob":
            entries[path.decode("utf-8")] = (mode, oid)
            required.add(oid)
    print(f"ARCHIVE_GIT_TREE {len(entries)} paths {len(required)} unique blobs", flush=True)
    seen, mismatches = set(), []
    log = record.with_suffix(".import.log")
    with log.open("wb") as output:
        process = subprocess.Popen(["git", "-C", str(repository), "fast-import", "--quiet"],
            stdin=subprocess.PIPE, stdout=output, stderr=subprocess.STDOUT,
            env={**os.environ, "GIT_NO_LAZY_FETCH": "1"})
        try:
            process.stdin.write(b"feature done\n")
            with tarfile.open(archive, "r|xz") as source:
                for item in source:
                    if not item.name.startswith(PREFIX):
                        continue
                    path = item.name[len(PREFIX):]
                    expected = entries.get(path)
                    if expected is None or expected[1] in seen:
                        continue
                    mode, oid = expected
                    if item.issym() and mode == "120000":
                        payload = item.linkname.encode("utf-8")
                        size = len(payload)
                        stream = None
                    elif item.isfile() and mode != "120000":
                        size = item.size
                        stream = source.extractfile(item)
                    else:
                        mismatches.append({"path": path, "reason": "Archive file type differs from Git mode"})
                        continue
                    header = f"blob {size}\0".encode("ascii")
                    h = hashlib.sha1(header)
                    process.stdin.write(f"blob\ndata {size}\n".encode("ascii"))
                    if stream is None:
                        h.update(payload)
                        process.stdin.write(payload)
                    else:
                        remaining = size
                        with stream:
                            while remaining:
                                block = stream.read(min(1024 * 1024, remaining))
                                if not block:
                                    raise ValueError("Truncated archive file: " + path)
                                h.update(block)
                                process.stdin.write(block)
                                remaining -= len(block)
                    process.stdin.write(b"\n")
                    if h.hexdigest() == oid:
                        seen.add(oid)
                    else:
                        mismatches.append({"path": path, "expected": oid, "actual": h.hexdigest()})
                    if len(seen) and len(seen) % 10000 == 0:
                        print(f"ARCHIVE_GIT_IMPORT {len(seen)}/{len(required)}", flush=True)
            process.stdin.write(b"done\n")
            process.stdin.close()
            if process.wait() != 0:
                raise RuntimeError("Git blob import failed; inspect " + str(log))
        except BaseException:
            if not process.stdin.closed:
                process.stdin.close()
            process.wait()
            raise
    present = present_blobs(repository, required, {**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    missing = required - present
    details = {"commit": COMMIT, "archive": str(archive), "archive_md5": MD5,
               "tracked_paths": len(entries), "required_blobs": len(required),
               "verified_blobs": len(present), "archive_content_mismatches": mismatches,
               "missing_paths": [path for path, (_, oid) in entries.items() if oid in missing]}
    if missing:
        failure = record.with_suffix(".incomplete.json")
        failure.write_text(json.dumps(details, indent=2), "utf-8")
        raise RuntimeError(f"Archive supplied verified blobs but {len(missing)} are still missing; see {failure}")
    record.write_text(json.dumps(details, indent=2), "utf-8")
    print("CHROMIUM_GIT_OBJECTS_COMPLETE " + str(record), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--archive", required=True)
    parser.add_argument("--record", required=True)
    args = parser.parse_args()
    seed(args.repository, args.archive, args.record)


if __name__ == "__main__":
    main()
