#!/usr/bin/env python3
"""Build independent CMake clients and exercise a real native Linux CEF SDK.

The client defaults to the pinned target sysroot and compiler. Native host
execution does not establish old-userland or old-kernel compatibility.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys

from archive_posix import digest_file
from audit_elf import inspect, MACHINES
from prepare_posix import Preparation, write_json
from runtime_probe import FIXTURE_SHA256
from linux_client_toolchain import prepare as prepare_client_toolchain

HERE = Path(__file__).resolve().parent


def development_inputs(sdk):
    return {path.relative_to(sdk).as_posix(): digest_file(path)
            for path in sorted(sdk.rglob('*')) if path.is_file() and not path.is_symlink()
            and path.relative_to(sdk).parts[0] not in ('Release', 'Resources', 'Debug', 'validation')
            and path.name not in ('MYCEF_BUILD.json', 'SHA256SUMS.json')}


def share_library_copy(source, destination):
    """Deduplicate a CMake copy only after proving that its bytes match."""
    if source.is_file() and destination.is_file() and not destination.is_symlink():
        if digest_file(source) != digest_file(destination):
            raise RuntimeError('Independent client deployment differs from SDK: ' + str(destination))
        if source.stat().st_dev == destination.stat().st_dev and not os.path.samefile(source, destination):
            temporary = destination.with_name(destination.name + '.mycef-link')
            if temporary.exists():
                raise RuntimeError('Interrupted client deduplication requires inspection: ' + str(temporary))
            os.link(source, temporary)
            temporary.replace(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', choices=['linux-x64', 'linux-arm64'], required=True)
    parser.add_argument('--media', type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=8, choices=range(1, 25))
    parser.add_argument('--use-sysroot', action='store_true', default=True,
                        help='Build independent clients with the locked target sysroot (default)')
    parser.add_argument('--cross-compile', action='store_true',
                        help='Build ARM64 clients on x64 Linux; target execution is a separate VM validation stage')
    args = parser.parse_args()
    expected_cpu = 'x86_64' if args.target == 'linux-x64' else 'aarch64'
    native = platform.machine() == expected_cpu
    if platform.system() != 'Linux' or os.geteuid() == 0:
        parser.error('Build client validation as a normal Linux user')
    if not native and not (args.cross_compile and platform.machine() == 'x86_64' and args.target == 'linux-arm64'):
        parser.error('For ARM64 client linking on x64, explicitly select --cross-compile')
    prep = Preparation(args.root)
    prepared_path = prep.root / 'state' / ('sdk-' + args.target + '-prepared.json')
    prepared = json.loads(prepared_path.read_text('utf-8'))
    sdk = Path(prepared['sdk']).resolve()
    if prep.root / 'packages/staging' not in sdk.parents or prepared['target'] != args.target:
        raise RuntimeError('The prepared SDK belongs to a different target or directory')
    if digest_file(sdk / 'Release/libcef.so') != prepared['sdk_libcef_sha256']:
        raise RuntimeError('The SDK library changed since package preparation')
    if digest_file(args.media) != FIXTURE_SHA256:
        raise RuntimeError('The real media fixture does not match the fixed sample')
    reports = prep.root / 'validation' / ('clients-' + args.target)
    reports.mkdir(parents=True, exist_ok=True)
    inputs = development_inputs(sdk)
    toolchain = None
    if args.use_sysroot or not native:
        toolchain = prepare_client_toolchain(prep, args.target[len('linux-'):], smoke=True)
    helper_hash = digest_file(sdk / 'Release/chrome-sandbox')
    helper_dir = Path('/usr/local/libexec/mycef-sandbox') / (args.target + '-' + helper_hash)
    helper = helper_dir / 'chrome-sandbox'
    if native:
        prep.run(['sudo', '-n', 'install', '-d', '-o', 'root', '-g', 'root', '-m', '0755', helper_dir])
        prep.run(['sudo', '-n', 'install', '-o', 'root', '-g', 'root', '-m', '4755', sdk / 'Release/chrome-sandbox', helper])
        metadata = helper.stat()
        if digest_file(helper) != helper_hash or metadata.st_uid != 0 or stat.S_IMODE(metadata.st_mode) != 0o4755:
            raise RuntimeError('Installed sandbox helper permissions or SDK identity do not match')
    clients, runs = [], []
    for sandbox in ['ON', 'OFF']:
        output = prep.root / 'cache/independent-clients' / args.target / ('sandbox-' + sandbox.lower())
        output.mkdir(parents=True, exist_ok=True)
        configure = ['cmake', '-S', sdk, '-B', output, '-G', 'Ninja',
                     '-DCMAKE_BUILD_TYPE=Release', '-DUSE_SANDBOX=' + sandbox]
        if toolchain:
            configure.append('-DCMAKE_TOOLCHAIN_FILE=' + toolchain['toolchain'])
        prep.run(configure)
        prep.run(['cmake', '--build', output, '--target', 'cefsimple', 'cefclient', '-j', str(args.jobs)])
        client = output / 'tests/cefsimple/Release/cefsimple'
        large_client = output / 'tests/cefclient/Release/cefclient'
        for binary in [client, large_client]:
            elf = inspect(binary)
            if not elf or elf['machine'] != MACHINES[args.target[len('linux-'):]]:
                raise RuntimeError('The independent executable has the wrong CPU: ' + str(binary))
        deployed = client.parent / 'libcef.so'
        if digest_file(deployed) != prepared['sdk_libcef_sha256']:
            raise RuntimeError('CMake deployed a different CEF library')
        for name in ['libcef.so', 'libvk_swiftshader.so', 'libvulkan.so.1', 'libEGL.so', 'libGLESv2.so', 'libstdc++.so.6']:
            if name == 'libstdc++.so.6':
                prior_stub = prep.root / 'state/sdk-migrations' / ('linker-only-cxx-' + args.target[len('linux-'):] + '.so')
                for deployment in (client.parent / name, large_client.parent / name):
                    source = sdk / 'Release' / name
                    if deployment.is_file() and digest_file(deployment) != digest_file(source):
                        if (deployment.is_symlink() or not prior_stub.is_file()
                                or digest_file(deployment) != digest_file(prior_stub)):
                            raise RuntimeError('Unknown old C++ client runtime: ' + str(deployment))
                        # CMake POST_BUILD copies may not run on an unchanged
                        # executable. Migrate only the known failed stub.
                        import shutil
                        pending = deployment.with_name(name + '.runtime-pending')
                        shutil.copy2(source, pending)
                        pending.replace(deployment)
            share_library_copy(sdk / 'Release' / name, client.parent / name)
            share_library_copy(sdk / 'Release' / name, large_client.parent / name)
        cache = (output / 'CMakeCache.txt').read_text('utf-8')
        if 'USE_SANDBOX:BOOL=' + sandbox not in cache or 'CMAKE_BUILD_TYPE:STRING=Release' not in cache:
            raise RuntimeError('The independent CMake cache lost its sandbox or Release setting')
        clients.append({'sandbox': sandbox, 'cefsimple': str(client), 'cefsimple_sha256': digest_file(client),
                        'cefclient': str(large_client), 'cefclient_sha256': digest_file(large_client),
                        'cmake_cache_sha256': digest_file(output / 'CMakeCache.txt'),
                        'sdk_libcef_sha256': digest_file(deployed),
                        'configure_command': list(map(str, configure))})
        if not native:
            continue
        for mode in (['auto', 'gpu-disabled'] if sandbox == 'ON' else ['auto']):
            path = reports / (sandbox.lower() + '-' + mode + '.json')
            command = ['xvfb-run', '-a', sys.executable, HERE / 'runtime_probe_posix.py',
                       '--sdk', sdk, '--client', client, '--media', args.media.resolve(),
                       '--output', path, '--mode', mode]
            if sandbox == 'OFF':
                command.append('--no-sandbox')
            else:
                command.extend(['--sandbox-helper', helper])
            prep.run(command)
            runtime = json.loads(path.read_text('utf-8'))
            if (not runtime.get('passed') or runtime.get('libcef_sha256') != prepared['sdk_libcef_sha256']
                    or runtime.get('client_sha256') != digest_file(client)
                    or runtime.get('cpu') != expected_cpu or not runtime.get('independent_client_requested')
                    or runtime.get('sandbox_requested') is not (sandbox == 'ON')):
                raise RuntimeError('The native runtime report does not match the independent client and SDK')
            runs.append({'sandbox': sandbox, 'mode': mode, 'path': str(path), 'sha256': digest_file(path)})
    if development_inputs(sdk) != inputs:
        raise RuntimeError('The SDK development sources changed during independent compilation')
    suffix = '-verified.json' if native else '-built.json'
    write_json(prep.root / 'state' / ('clients-' + args.target + suffix), {
        'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'target': args.target,
        'sdk_libcef_sha256': prepared['sdk_libcef_sha256'], 'clients': clients, 'runtime_reports': runs,
        'prepared_receipt_sha256': digest_file(prepared_path), 'passed': native,
        'compilation_linking_passed': True, 'runtime_verified': native,
        'cross_compiled': not native, 'client_toolchain': toolchain,
        'sdk_development_inputs': inputs,
        'sandbox_helper': str(helper) if native else None, 'sandbox_helper_sha256': helper_hash,
        'scope': ('Actual independent Release CMake cefsimple/cefclient builds with sandbox ON/OFF, and three native cefsimple graphics/media/sandbox runs. Old userland/kernel and hardware GPU coverage remain separate.'
                  if native else 'Actual independent ARM64 Release CMake cefsimple/cefclient cross-compilation/linking with sandbox ON/OFF. No target runtime or final SDK verification has been performed.'),
    })
    print('LINUX_INDEPENDENT_CLIENTS_' + ('AND_NATIVE_RUNTIME_VERIFIED' if native else 'CROSS_COMPILED_RUNTIME_PENDING'), args.target, flush=True)


if __name__ == '__main__':
    main()
