#!/usr/bin/env python3
"""Wait for verified Linux archives, then finish macOS ARM64 followed by x64."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

from archive_posix import digest_file
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent


def complete(prep, target):
    path = prep.root / 'state' / ('sdk-' + target + '-verified.json')
    if not path.is_file():
        return False
    value = json.loads(path.read_text('utf-8'))
    archive = Path(value['archive']).resolve()
    if (value.get('passed') is not True or value['target'] != target
            or value['chromium_revision'] != CHROMIUM_REV or value['cef_revision'] != CEF_REV
            or prep.root / 'packages' not in archive.parents
            or digest_file(archive) != value['archive_sha256']):
        raise RuntimeError('A previous SDK archive no longer matches its verified identity: ' + target)
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--wait-hours', type=float, default=72)
    args = parser.parse_args()
    prep = Preparation(args.root)

    def record(phase, **extra):
        value = {'phase': phase, 'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                 'all_four_sdks_archived': False, 'macos_runtime_verified': False, **extra}
        write_json(prep.root / 'state/mac-release-status.json', value)
        print('MAC_RELEASE_CONTINUATION', json.dumps(value), flush=True)

    def execute(script, *values):
        prep.run([sys.executable, HERE / script, '--root', prep.root, *values])

    try:
        deadline = time.monotonic() + args.wait_hours * 3600
        # Wait cheaply for both publication receipts. Authenticate each full
        # archive once Linux has stopped, rather than hashing a multi-GB x64
        # archive every 30 seconds throughout the ARM64 compile.
        while not all((prep.root / 'state' / ('sdk-' + target + '-verified.json')).is_file()
                      for target in ('linux-x64', 'linux-arm64')):
            service = subprocess.run(['systemctl', 'show', 'mycef-linux-release-continuation.service',
                                      '-p', 'ActiveState', '--value'], capture_output=True, text=True)
            status = prep.root / 'state/linux-release-status.json'
            current = json.loads(status.read_text('utf-8')) if status.is_file() else {}
            if (service.returncode == 0 and service.stdout.strip() not in ('active', 'activating', 'reloading')
                    and current.get('phase') == 'failed'):
                raise RuntimeError('Linux continuation stopped; preserve and fix its failure first: ' + current.get('error', 'unknown'))
            if time.monotonic() >= deadline:
                raise TimeoutError('Linux verified archives are not ready; preserve all work')
            record('waiting_for_linux_archives', linux_service_active_state=service.stdout.strip())
            time.sleep(30)
        # Linux may write the final archive receipt immediately before cleanup;
        # let its original service finish reclaiming output before using disk.
        while True:
            result = subprocess.run(['systemctl', 'show', 'mycef-linux-release-continuation.service',
                                     '-p', 'ActiveState', '--value'], capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError('Cannot confirm Linux continuation completion')
            if result.stdout.strip() not in ('active', 'activating', 'reloading'):
                break
            if time.monotonic() >= deadline:
                raise TimeoutError('Linux cleanup is still active; preserve work')
            time.sleep(30)
        linux = json.loads((prep.root / 'state/linux-release-status.json').read_text('utf-8'))
        if linux.get('phase') != 'both_linux_release_archives_verified':
            raise RuntimeError('Linux archive/cleanup continuation did not complete successfully')
        if not all(complete(prep, target) for target in ('linux-x64', 'linux-arm64')):
            raise RuntimeError('The published Linux archive identities did not verify')
        for target in ('mac-arm64', 'mac-x64'):
            if complete(prep, target):
                execute('finalize_macos.py', '--target', target, '--cleanup')
                continue
            for phase, script in (('configuring', 'configure_posix.py'),
                                  ('compiling', 'compile_posix.py'),
                                  ('preparing_sdk', 'package_macos.py'),
                                  ('building_public_sdk_clients', 'validate_macos_clients.py'),
                                  ('archiving_and_reclaiming', 'finalize_macos.py')):
                record(phase, target=target)
                values = ['--target', target]
                if script == 'finalize_macos.py':
                    values.append('--cleanup')
                execute(script, *values)
        if not all(complete(prep, target) for target in ('linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64')):
            raise RuntimeError('The four SDK archive identities did not all verify')
        record('four_release_sdk_archives_verified', all_four_sdks_archived=True,
               verified_targets=['linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64'],
               scope='Real builds, complete symbols, public SDK clients and verified archives; Linux old-kernel/userland runtime tested separately. macOS target execution and Apple distribution signing remain unverified.')
    except Exception as error:
        record('failed', error=repr(error))
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
