# macOS Release SDK

固定 Chromium 156.0.8071.0 与配套 CEF 适配。只包含 Release；完整调试符号位于 `Symbols/`，每个运行库、示例和 Helper 的 Mach-O CPU / UUID、原始 DWARF 内容及 DWARF 语义检查均须通过后才完成 SDK 暂存。

`Release/Chromium Embedded Framework.framework` 为开发所需引擎，`include/`、`libcef_dll/`、`cmake/` 和 CMake 工程用于编译自己的程序。`Examples/` 是已编译的 cefsimple / cefclient 及 Helper 示例；业务程序无需携带这两个示例。多进程 Helper 和框架内的沙箱库属于应用部署结构，按自己的 CEF 工程配置处理。

开启 H.264 / AAC、OpenH264 / WebRTC H.264、PDF、打印、扩展和软件图形回退相关代码；具体生成配置见 `MYCEF_FEATURES.json`。不附带独立 libx264 或 Widevine 商业二进制，编译开关不等于所有功能均已在目标 Mac 上运行通过。

SDK 面向单独的 ARM64 或 x64 架构；当前引擎部署门槛为 macOS 13.0，实际最低版本由 Mach-O 审计记录；SDK CMake 和示例 plist 同步使用引擎的实际门槛。Linux 的 glibc / Linux 4.9 兼容性承诺不适用于 macOS。

完整状态见 `MYCEF_BUILD.json` 及 `validation/`。Linux 交叉编译、链接和符号检查与 macOS 实机运行是不同验证；未验证项目不会写成已通过。发布业务应用时，使用自己的应用标识、签名及适用的分发流程。
