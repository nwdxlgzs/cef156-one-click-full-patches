#!/usr/bin/env python3
"""Refresh compact SDK documentation/evidence and verify its final archive."""
import argparse
import json
import os
from pathlib import Path

from minimize_sdk import archive_sdk, configure, digest, write_json


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--sdk',type=Path,required=True)
    p.add_argument('--evidence',type=Path)
    a=p.parse_args();sdk=a.sdk.resolve()
    manifest=json.loads((sdk/'STRIP_MANIFEST.json').read_text('utf-8'))
    configure(sdk,manifest['target'])
    if a.evidence:
        evidence=json.loads(a.evidence.read_text('utf-8'))
        if evidence['target']!=manifest['target']:raise RuntimeError('Wrong demo validation target')
        if 'sdk_inputs' in evidence:
            from compact_demo_inputs import verify_portable
            verify_portable(sdk,manifest,evidence)
        else:
            for client in evidence.get('clients',[]):
                if digest(Path(client['binary']))!=client['binary_sha256']:
                    raise RuntimeError('Demo binary changed after validation')
        write_json(sdk/'docs/demo-validation.json',evidence)
        manifest.update(demo_build_verified=evidence['demo_build_verified'],
                        runtime_verified_after_strip=evidence.get('runtime_verified_after_strip',False),
                        demo_validation='docs/demo-validation.json')
    # Runtime files must equal the verified original or actual stripped identity.
    stripped={x['file']:x['stripped_sha256'] for x in manifest['elf_strip']}
    for name,item in manifest['selected_original_files'].items():
        if not name.startswith('Release/') or 'symlink' in item:continue
        if digest(sdk/name)!=stripped.get(name,item['source_sha256']):
            raise RuntimeError('Unknown runtime file modification: '+name)
    write_json(sdk/'STRIP_MANIFEST.json',manifest)
    checks={x.relative_to(sdk).as_posix():({'symlink':os.readlink(x)} if x.is_symlink() else
            {'bytes':x.stat().st_size,'sha256':digest(x)}) for x in sorted(sdk.rglob('*'))
            if (x.is_file() or x.is_symlink()) and x.name!='SHA256SUMS.json'}
    write_json(sdk/'SHA256SUMS.json',checks)
    archive=sdk.with_name(sdk.name+('.zip' if manifest['target'].startswith('windows-') else '.tar.zst'))
    previous=archive.with_name(archive.name+'.previous')
    if previous.exists():raise RuntimeError('Previous archive backup already exists')
    if archive.exists():archive.rename(previous)
    result=archive_sdk(sdk,archive)
    write_json(sdk.with_name(sdk.name+'.verified.json'),result)
    if previous.exists():previous.unlink()
    print('FINAL_COMPACT_SDK_VERIFIED',json.dumps(result),flush=True)


if __name__=='__main__':main()
