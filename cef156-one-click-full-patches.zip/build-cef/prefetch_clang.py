#!/usr/bin/env python3
"""Resume the pinned official Linux Clang archive and use its real installer."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

from prepare_posix import Preparation, CHROMIUM_REV, write_json

VERSION = 'llvmorg-24-init-7747-g62397f8b-29'
FILENAME = 'clang-' + VERSION + '.tar.xz'
SIZE = 57238740
MD5 = '143d57a4eb0647731d1dff0bf5b255e5'
URL = 'https://storage.googleapis.com/chromium-browser-clang/Linux_x64/' + FILENAME


def file_digest(path, algorithm):
    digest = hashlib.new(algorithm)
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--installer', required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    installer = Path(args.installer).resolve()
    data = installer.read_bytes()
    blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
    expected = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', 'tools/clang/scripts/update.py', capture=True).stdout.split()[2]
    if blob != expected:
        raise RuntimeError('Clang installer differs from the actual Chromium Git tree')
    directory = prep.root / 'downloads/clang/Linux_x64'
    directory.mkdir(parents=True, exist_ok=True)
    archive = directory / FILENAME
    partial = archive.with_suffix('.xz.partial')
    if not archive.is_file() or archive.stat().st_size != SIZE or file_digest(archive, 'md5') != MD5:
        if not partial.is_file() or partial.stat().st_size != SIZE:
            errors = []
            for route in [True, False, True]:
                command = ['curl', '--fail', '--location', '-sS', '--connect-timeout', '15', '--max-time', '3600',
                           '--speed-limit', '1024', '--speed-time', '120', '--continue-at', '-', '-o', str(partial)]
                if route:
                    command.extend(['--resolve', 'storage.googleapis.com:443:172.253.117.82'])
                result = subprocess.run([*command, URL])
                if result.returncode == 0:
                    break
                errors.append(result.returncode)
            else:
                raise RuntimeError('Pinned Clang archive download incomplete; valid prefix retained: ' + repr(errors))
        if partial.stat().st_size != SIZE or file_digest(partial, 'md5') != MD5:
            raise RuntimeError('Pinned Clang archive integrity check failed; do not install it')
        partial.replace(archive)
    spec = importlib.util.spec_from_file_location('mycef_upstream_clang_update', installer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.PACKAGE_VERSION != VERSION:
        raise RuntimeError('The locked Clang package version changed')
    # Use the unchanged upstream install/extract/stamp implementation. This
    # download prefix is a verified local cache, not a different toolchain.
    module.CDS_URL = directory.parent.as_uri()
    original = sys.argv
    sys.argv = [str(installer), '--host-os', 'linux', '--output-dir',
                str(prep.src / 'third_party/llvm-build/Release+Asserts')]
    try:
        if module.main() not in (None, 0):
            raise RuntimeError('The original Clang installer failed')
    finally:
        sys.argv = original
    compiler = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
    version = prep.run([compiler, '--version'], capture=True).stdout
    if 'clang version 24' not in version:
        raise RuntimeError('The actual Clang executable has an unexpected version')
    write_json(prep.root / 'state/clang-prefetched.json', {
        'package_version': VERSION, 'url': URL, 'gcs_generation': '1789426559193435',
        'archive_bytes': SIZE, 'archive_md5': MD5, 'archive_sha256': file_digest(archive, 'sha256'),
        'upstream_installer_git_blob': blob, 'compiler_sha256': file_digest(compiler, 'sha256'),
        'compiler_version': version, 'installed': True,
    })
    print('OFFICIAL_CLANG_PREFETCH_VERIFIED', version.splitlines()[0], flush=True)


if __name__ == '__main__':
    main()
