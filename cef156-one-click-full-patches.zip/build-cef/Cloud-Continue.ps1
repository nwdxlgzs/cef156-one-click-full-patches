#requires -Version 5.1
[CmdletBinding()]
param([string]$Root='C:\cef156', [ValidateRange(1,64)][int]$Jobs=14)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$env:PSModulePath=$PSHOME+'\Modules;'+$env:PSModulePath
if($Root -notmatch '^[C-Zc-z]:\\[A-Za-z0-9_-]+(?:\\[A-Za-z0-9_-]+)*\\?$'){throw 'Dedicated short build root required'}
$Root=[IO.Path]::GetFullPath($Root).TrimEnd('\')
$env:TEMP=Join-Path $Root 'tmp'
$env:TMP=$env:TEMP
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
$env:DEPOT_TOOLS_WIN_TOOLCHAIN='0'
$env:DEPOT_TOOLS_UPDATE='0'
$env:DEPOT_TOOLS_WIN_TOOLCHAIN_ROOT=$Root
$env:CEF_ENABLE_ARM64='1'
$env:GIT_TERMINAL_PROMPT='0'
$env:GIT_CONFIG_GLOBAL=Join-Path $Root 'gitconfig'
$env:vs2026_install=Join-Path $Root 'VS2026'
$env:GYP_MSVS_VERSION='2026'
$env:WindowsSdkDir=(Join-Path $Root 'WindowsKits\10')+'\'
$depot=Join-Path $Root 'depot_tools'
$env:PATH=$depot+';'+(Join-Path $Root 'Git\cmd')+';'+$env:PATH
$portable=Join-Path $Root 'Python311-portable\python.exe'
$ready=Join-Path $Root ('state\cloud-mirror-'+[guid]::NewGuid().ToString('N')+'.json')
$mirror=$null
$exitCode=1
try{
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'HANDOFF.zh-CN.md') -Destination (Join-Path $Root 'HANDOFF.zh-CN.md') -Force
    $arguments='"'+(Join-Path $PSScriptRoot 'cipd_mirror.py')+'" --cache "'+(Join-Path $Root 'downloads\cipd-mirror')+'" --ready-file "'+$ready+'" --log-file "'+(Join-Path $Root 'logs\cloud-cipd-mirror.log')+'"'
    $mirror=Start-Process -FilePath $portable -ArgumentList $arguments -WindowStyle Hidden -PassThru
    for($attempt=0;$attempt -lt 30 -and -not(Test-Path -LiteralPath $ready);$attempt++){
        if($mirror.HasExited){throw 'Cloud mirror metadata process exited'}
        Start-Sleep -Seconds 1
    }
    if(-not(Test-Path -LiteralPath $ready)){throw 'Cloud mirror metadata service did not become ready'}
    $env:CIPD_SERVICE_URL=(Get-Content -LiteralPath $ready -Raw | ConvertFrom-Json).url
    $env:VPYTHON_AR_URL=$env:CIPD_SERVICE_URL+'/python/simple/'
    $env:BOTO_CONFIG=Join-Path $Root 'state\public-gcs.boto'
    & (Join-Path $depot 'python-bin\python3.bat') (Join-Path $PSScriptRoot 'cloud_runner.py') --root $Root --jobs $Jobs
    $exitCode=$LASTEXITCODE
}catch{
    $_ | Out-String | Add-Content -LiteralPath (Join-Path $Root 'logs\cloud-launch-errors.log') -Encoding UTF8
}finally{
    if($null -ne $mirror -and -not $mirror.HasExited){& "$env:SystemRoot\System32\taskkill.exe" /PID $mirror.Id /T /F | Out-Null}
}
exit $exitCode
