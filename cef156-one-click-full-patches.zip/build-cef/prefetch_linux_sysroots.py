#!/usr/bin/env python3
"""Cache and install the exact upstream low-glibc Linux sysroots."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

from prepare_posix import Preparation, CHROMIUM_REV, write_json

HERE = Path(__file__).resolve().parent


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', required=True, choices=['prefetch', 'install'])
    args = parser.parse_args()
    prep = Preparation(args.root)
    lock = json.loads((HERE / 'linux-sysroots-lock.json').read_text('utf-8'))
    if lock['chromium_revision'] != CHROMIUM_REV:
        raise RuntimeError('Unexpected sysroot version lock')
    blob = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', lock['upstream_file'], capture=True).stdout.split()[2]
    if blob != lock['upstream_git_blob']:
        raise RuntimeError('Sysroot lock does not match the actual Chromium Git tree')
    directory = prep.root / 'downloads/linux-sysroots'
    directory.mkdir(exist_ok=True)
    def fetch(item):
        arch, info = item
        path = directory / info['Tarball']
        expected = info['Sha256Sum']
        if not path.is_file() or sha256(path) != expected:
            temporary = path.with_suffix(path.suffix + '.partial')
            prep.run(['curl', '--fail', '--location', '-sS', '--connect-timeout', '15',
                      '--resolve', 'storage.googleapis.com:443:172.253.117.82',
                      '--max-time', '3600', '--continue-at', '-', '-o', temporary,
                      'https://storage.googleapis.com/chrome-linux-sysroot/' + expected])
            if sha256(temporary) != expected:
                raise RuntimeError('Official sysroot archive SHA256 mismatch: ' + arch)
            temporary.replace(path)
        print('SYSROOT_ARCHIVE_VERIFIED', arch, expected, flush=True)
        return arch, {'archive': str(path), 'sha256': expected, 'bytes': path.stat().st_size,
                      'canonical_url': info['URL'] + '/' + expected, 'directory_name': info['SysrootDir']}
    with ThreadPoolExecutor(2) as pool:
        outcomes = [pool.submit(fetch, item) for item in lock['sysroots'].items()]
        records, errors = {}, []
        for future in outcomes:
            try:
                arch, report = future.result()
                records[arch] = report
            except Exception as error:
                errors.append(repr(error))
        if errors:
            raise RuntimeError('Sysroot prefetch incomplete: ' + '; '.join(errors))
    if args.stage == 'install':
        source = prep.src / lock['upstream_file']
        if source.is_file():
            manifest_data = source.read_bytes()
        else:
            # Install the exact ignored sysroot directory while the main
            # checkout is still fetching omitted blobs. Authenticate the
            # manifest directly from its already verified Git object.
            manifest_data = subprocess.check_output(
                ['git', '-C', str(prep.src), 'show', CHROMIUM_REV + ':' + lock['upstream_file']], env=prep.env)
        if hashlib.sha256(manifest_data).hexdigest() != lock['upstream_sha256']:
            raise RuntimeError('Checked-out upstream sysroot manifest has changed')
        for arch, record in records.items():
            target = prep.src / 'build/linux' / record['directory_name']
            stamp = target / '.stamp'
            if target.exists():
                if stamp.is_file() and stamp.read_text() == record['canonical_url']:
                    record['installed'] = str(target)
                    continue
                # Genuine first-class GCS sync replaces early prefetch installs
                # and removes their old .stamp. Convert only the exact pinned
                # upstream object via the unchanged original installer, mapping
                # its canonical download to the already SHA256-verified cache.
                gcs = target / ('.' + record['sha256'] + '_is_first_class_gcs')
                object_hash = target / ('.' + record['sha256'] + '_hash')
                if gcs.is_file() and object_hash.is_file() and object_hash.read_text().strip() == record['sha256']:
                    installer = prep.src / 'build/linux/sysroot_scripts/install-sysroot.py'
                    payload = installer.read_bytes()
                    actual_blob = hashlib.sha1(('blob ' + str(len(payload)) + '\0').encode() + payload).hexdigest()
                    expected_blob = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--',
                                             'build/linux/sysroot_scripts/install-sysroot.py', capture=True).stdout.split()[2]
                    if actual_blob != expected_blob:
                        raise RuntimeError('Original sysroot installer differs from its fixed Git blob')
                    spec = importlib.util.spec_from_file_location('mycef_original_sysroot_installer_' + arch, installer)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    def cached_open(url):
                        if url != record['canonical_url'] or sha256(Path(record['archive'])) != record['sha256']:
                            raise RuntimeError('Original sysroot installer requested a different archive')
                        return Path(record['archive']).open('rb')
                    module.urlopen = cached_open
                    module.InstallSysroot(lock['upstream_file'], 'bullseye', arch)
                    if not stamp.is_file() or stamp.read_text() != record['canonical_url'] or gcs.exists():
                        raise RuntimeError('Original sysroot installer did not finish the cache conversion')
                    record['installed'] = str(target)
                    record['original_installer_git_blob'] = actual_blob
                    record['first_class_gcs_converted_using_verified_cache'] = True
                    continue
                raise RuntimeError('Existing sysroot requires inspection; refusing to overwrite: ' + str(target))
            staging = target.with_name(target.name + '.mycef-pending')
            if staging.exists():
                raise RuntimeError('Interrupted sysroot installation retained: ' + str(staging))
            staging.mkdir(parents=True)
            prep.run(['tar', 'mxf', record['archive'], '-C', staging])
            (staging / '.stamp').write_text(record['canonical_url'], encoding='utf-8')
            staging.replace(target)
            record['installed'] = str(target)
    write_json(prep.root / 'state/linux-sysroots.json', {
        'chromium_revision': CHROMIUM_REV, 'upstream_manifest_sha256': lock['upstream_sha256'],
        'sysroots': records, 'installed': args.stage == 'install',
        'scope': 'Exact upstream sysroot archives. The final SDK glibc dependency and old-kernel runtime still require independent validation.',
    })


if __name__ == '__main__':
    main()
