#!/usr/bin/env python3
"""Reserve temporary link swap on small Linux hosts; safely reclaim it later."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import stat

from prepare_posix import Preparation, write_json

PATH = Path('/swap-mycef-link')
SIZE = 32 * 1024**3


def memory():
    return {k: int(v.split()[0]) * 1024 for k, v in
            (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}


def swaps():
    result = []
    for line in Path('/proc/swaps').read_text().splitlines()[1:]:
        name, kind, size, used, priority = line.split()
        result.append({'name': name, 'size': int(size) * 1024, 'used': int(used) * 1024})
    return result


def check_file():
    info = PATH.lstat()
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0
            or stat.S_IMODE(info.st_mode) != 0o600 or info.st_size != SIZE):
        raise RuntimeError('Unexpected file at the dedicated temporary link-swap path')
    return info


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', choices=('ensure', 'release'), required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    if not Path('/proc/meminfo').is_file():
        raise RuntimeError('The temporary link-swap helper requires a Linux host')
    def run(command):
        return prep.run((['sudo', '-n'] if os.geteuid() else []) + command)
    active = swaps()
    selected = next((item for item in active if item['name'] == str(PATH)), None)
    if args.stage == 'ensure':
        mem = memory()
        if mem['MemTotal'] >= 48 * 1024**3 or sum(s['size'] for s in active) >= 64 * 1024**3:
            print('Existing memory/swap capacity retained.', flush=True)
            return
        if PATH.exists() or PATH.is_symlink():
            check_file()
            kind = prep.run(['sudo', '-n', 'blkid', '-p', '-s', 'TYPE', '-o', 'value', PATH], capture=True).stdout.strip()
            if kind != 'swap':
                raise RuntimeError('Existing dedicated link-swap file is not an initialized swap area')
        else:
            if shutil.disk_usage(PATH.parent).free < SIZE + 16 * 1024**3:
                raise RuntimeError('Insufficient room for temporary link swap while retaining output headroom')
            # Never truncate an existing path. The exclusive creation is owned
            # by root before allocation, formatting and activation.
            run(['python3', '-c',
                 'import os; f=os.open("/swap-mycef-link",os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600); os.close(f)'])
            run(['fallocate', '-l', str(SIZE), PATH])
            run(['mkswap', PATH])
            check_file()
        if selected is None:
            run(['swapon', PATH])
        selected = next(item for item in swaps() if item['name'] == str(PATH))
        write_json(prep.root / 'state/temporary-link-swap.json', {
            'path': str(PATH), 'bytes': SIZE, 'active': True, 'actual': selected,
            'persistent_fstab_modified': False,
            'scope': 'Temporary reserve for full-symbol CEF links on small hosts; original swap areas are preserved.'})
        print('TEMPORARY_LINK_SWAP_ACTIVE', SIZE, flush=True)
        return
    if not PATH.exists() and not PATH.is_symlink():
        return
    info = check_file()
    # Deactivation is only attempted after all actual linkers have exited and
    # physical memory can absorb this area's swapped pages with headroom.
    for process in Path('/proc').iterdir():
        try:
            if (process / 'comm').read_text().strip() in ('ld.lld', 'ld64.lld', 'dsymutil'):
                print('Temporary link swap retained while a linker/debug tool is active.', flush=True)
                return
        except (OSError, ValueError):
            pass
    if selected is not None:
        if memory()['MemAvailable'] < selected['used'] + 2 * 1024**3:
            print('Temporary link swap retained until physical memory has sufficient headroom.', flush=True)
            return
        run(['swapoff', PATH])
    if any(item['name'] == str(PATH) for item in swaps()):
        raise RuntimeError('Do not delete an active temporary swap file')
    if check_file().st_ino != info.st_ino:
        raise RuntimeError('Temporary swap identity changed before reclamation')
    run(['rm', '--', PATH])
    write_json(prep.root / 'state/temporary-link-swap.json', {
        'path': str(PATH), 'bytes': SIZE, 'active': False, 'reclaimed': True,
        'persistent_fstab_modified': False, 'original_swap_areas_preserved': True})
    print('TEMPORARY_LINK_SWAP_RECLAIMED', SIZE, flush=True)


if __name__ == '__main__':
    main()
