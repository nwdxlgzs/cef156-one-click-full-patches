#!/usr/bin/env python3
"""Check real Linux-to-macOS C/Objective-C++ compilation and framework linking.

This is a compiler/SDK preflight. It never marks a CEF macOS SDK or native
macOS execution successful.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import plistlib
import re
import struct
import subprocess
import time

from prepare_posix import Preparation, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--sdk', required=True)
    parser.add_argument('--wait-minutes', type=int, default=90)
    parser.add_argument('--with-debug-tools', action='store_true',
                        help='Also compile DWARF, generate dSYM and verify matching UUIDs with prepared auxiliary tools')
    parser.add_argument('--report-name', default='mac-cross-compiler-smoke.json')
    args = parser.parse_args()
    if not re.fullmatch(r'[a-z][a-z0-9-]{0,80}\.json', args.report_name):
        parser.error('Use a plain lowercase JSON report name')
    prep = Preparation(args.root)
    sdk = Path(args.sdk).resolve()
    settings = plistlib.loads((sdk / 'SDKSettings.plist').read_bytes())
    if not {'x86_64', 'arm64'} <= set(settings['SupportedTargets']['macosx']['Archs']):
        raise RuntimeError('The actual SDK does not declare both requested CPU architectures')
    deadline = time.monotonic() + args.wait_minutes * 60
    receipt = prep.root / 'state/clang-prefetched.json'
    while not receipt.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError('The actual pinned Clang package did not finish before the preflight deadline')
        print('MAC_PREFLIGHT_WAITING_FOR_PINNED_CLANG', flush=True)
        time.sleep(30)
    clang_info = json.loads(receipt.read_text('utf-8'))
    tools = prep.src / 'third_party/llvm-build/Release+Asserts/bin'
    clang = tools / 'clang'
    if hashlib.sha256(clang.read_bytes()).hexdigest() != clang_info['compiler_sha256']:
        raise RuntimeError('The verified Clang compiler has changed')
    directory = prep.root / 'validation' / ('mac-compiler-smoke-' + settings['Version'])
    directory.mkdir(parents=True, exist_ok=True)
    c = directory / 'probe.c'
    c.write_text('#include <CoreFoundation/CoreFoundation.h>\nint main(void) { CFShow(CFSTR("MyCEF cross compiler probe")); return 0; }\n')
    objc = directory / 'probe.mm'
    objc.write_text('#import <Cocoa/Cocoa.h>\nint main() { @autoreleasepool { NSLog(@"MyCEF Objective-C++ cross compiler probe"); } return 0; }\n')
    cpp = directory / 'probe.cpp'
    cpp.write_text('#include <string>\n#include <vector>\n#include <memory>\n#include <numeric>\n#include <span>\n#include <cstdio>\n'
                   'int main(int argc, char**) { auto text=std::make_unique<std::string>(static_cast<unsigned>(argc)+200,\'x\'); '
                   'std::vector<int> numbers(text->size(),argc); std::span<const int> view(numbers); '
                   'std::printf("%s %d\\n",text->c_str(),std::accumulate(view.begin(),view.end(),0)); return numbers.empty(); }\n')
    results = []
    for cpu, machine in [('arm64', 0x0100000c), ('x86_64', 0x01000007)]:
        for language, source, framework in [('c', c, 'CoreFoundation'), ('objcxx', objc, 'Cocoa'), ('cpp', cpp, None)]:
            output = directory / (language + '-' + cpu)
            driver = tools / 'clang++' if language == 'cpp' else clang
            command = [str(driver), '-target', cpu + '-apple-macos13.0', '-isysroot', str(sdk),
                       '-fuse-ld=lld', str(source), '-o', str(output)]
            if framework:
                command.extend(['-framework', framework])
            if language == 'objcxx':
                command.extend(['-std=c++23', '-fobjc-arc', '-fblocks'])
            elif language == 'cpp':
                command.append('-std=c++20')
            run = subprocess.run(command, capture_output=True, text=True)
            record = {'cpu': cpu, 'language': language, 'command': command,
                      'returncode': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr, 'passed': False}
            if run.returncode == 0:
                data = output.read_bytes()
                header = struct.unpack('<8I', data[:32])
                if header[0] != 0xfeedfacf or header[1] != machine or header[3] != 2:
                    raise RuntimeError('The linked result is not the requested real Mach-O executable')
                record.update(passed=True, sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                              output=str(output), macho_machine=header[1])
            results.append(record)
            print('MAC_CROSS_COMPILER_PROBE', cpu, language, 'passed=' + str(record['passed']), run.stderr, flush=True)
    debug_results = []
    if args.with_debug_tools:
        auxiliary = json.loads((prep.root / 'state/mac-aux-tools-verified.json').read_text('utf-8'))
        for name, tool in auxiliary['tools'].items():
            if (hashlib.sha256(Path(tool['path']).read_bytes()).hexdigest() != tool['wrapper_sha256']
                    or hashlib.sha256(Path(tool['executable']).read_bytes()).hexdigest() != tool['executable_sha256']):
                raise RuntimeError('The verified auxiliary tool changed: ' + name)
        for cpu in ['arm64', 'x86_64']:
            obj, binary = directory / ('debug-' + cpu + '.o'), directory / ('debug-' + cpu)
            bundle = directory / ('debug-' + cpu + '.dSYM')
            driver = tools / 'clang++'
            base = [str(driver), '-target', cpu + '-apple-macos13.0', '-isysroot', str(sdk)]
            commands = [
                [*base, '-std=c++20', '-g', '-gdwarf-4', '-c', str(cpp), '-o', str(obj)],
                [*base, '-fuse-ld=lld', str(obj), '-o', str(binary)],
                [auxiliary['tools']['dsymutil']['path'], '--linker=classic',
                 '--allow-section-header-offset-overflow', '-o', str(bundle), str(binary)],
                [auxiliary['tools']['llvm-dwarfdump']['path'], '--uuid', str(binary), str(bundle)],
                [auxiliary['tools']['llvm-dwarfdump']['path'], '--verify', str(bundle)],
                [auxiliary['tools']['llvm-otool']['path'], '-L', str(binary)],
            ]
            outputs = []
            for command in commands:
                run = subprocess.run(command, capture_output=True, text=True)
                outputs.append({'command': command, 'returncode': run.returncode,
                                'stdout': run.stdout, 'stderr': run.stderr})
                if run.returncode:
                    break
            uuids = re.findall(r'UUID: ([A-Fa-f0-9-]+) \(([^)]+)\)', outputs[3]['stdout']) if len(outputs) >= 4 else []
            passed = (len(outputs) == 6 and all(item['returncode'] == 0 for item in outputs)
                      and len(uuids) == 2 and uuids[0] == uuids[1] and uuids[0][1] == cpu
                      and 'No errors.' in outputs[4]['stdout'])
            dwarf = bundle / 'Contents/Resources/DWARF' / binary.name
            debug_results.append({'cpu': cpu, 'commands': outputs, 'passed': passed, 'uuids': uuids,
                                  'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest() if binary.is_file() else None,
                                  'dwarf_sha256': hashlib.sha256(dwarf.read_bytes()).hexdigest() if dwarf.is_file() else None})
            print('MAC_CROSS_DSYM_PROBE', cpu, 'passed=' + str(passed), flush=True)
    report = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'sdk': str(sdk), 'sdk_version': settings['Version'],
              'sdk_build': plistlib.loads((sdk / 'System/Library/CoreServices/SystemVersion.plist').read_bytes())['ProductBuildVersion'],
              'compiler': clang_info,
              'results': results, 'debug_results': debug_results,
              'passed': all(item['passed'] for item in [*results, *debug_results]),
              'scope': 'Actual C/Objective-C++/C++20 compilation, Apple framework and SDK libc++ linking, Mach-O CPU checks, and optional recorded dSYM/UUID/DWARF roundtrip on Linux. Not Chromium embedded libc++ integration, full CEF compilation/symbols, signing, application packaging or actual macOS runtime.'}
    write_json(prep.root / 'state' / args.report_name, report)
    if not report['passed']:
        raise RuntimeError('macOS compiler preflight needs adaptation; see the recorded real compiler errors')


if __name__ == '__main__':
    main()
