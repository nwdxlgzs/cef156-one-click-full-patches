# 本地验证记录

11 月 9 日新增：四目标实际 GN / 快照依赖图全部通过，保留当前正在编译的 Linux x64 计划；macOS ARM64 开发输入预检完成 ON/OFF 两套 wrapper、主程序与八个 Helper（十个实际 Mach-O），并检查了沙箱初始化符号差异。两 CPU 的 CMake C++20/AppKit 工具链通过。预检未提供或加载 CEF 引擎，正式 SDK / 目标运行验证仍待完成；相关真实回执现已随 validation 提供。新 macOS 串行服务实际启用并等待 Linux，两套最终归档后接续编译与回收。

2026-11-09 POSIX 进展：Linux 全部真实 gclient sync / hooks 完成，POSIX 补丁与 Linux x64 GN 已通过并正在真实 C++ / Rust 编译。两套 macOS 的完整 GN 在该编译期间通过；ARM64 / x64 Ninja 完整输入图 67,836 / 65,713 项均已解析，尚未制作任何 POSIX SDK。新增安全追加补丁迁移的四项实际 Git 测试在 Windows / Ubuntu 均通过。最新回执见 `validation/`，下方 Windows 记录保留。

验证日期：2026-11-07 至 2026-11-08。Windows x64、x86、ARM64 三套 Release SDK 均已完成编译、链接、压缩及逐文件校验，保留完整 PDB。x64、x86 原生示例与外部 CMake 沙箱客户端通过 WinServer 2025 上的软件 WebGL 和实际 H.264/AAC/编码回环检查，并有本机硬件 / 软件路径及沙箱开关验证。ARM64 完整符号与独立 CMake 客户端交叉编译 / 链接检查通过；真实 Windows on ARM 和 Win7 运行尚未验证。此前启动的 x64 Debug 已按要求停止并清理，不计入交付目标。

## 最终 Windows 交付复核（2026-11-08 21:00，UTC+08:00）

- ARM64 Release 完成：1,649,332,024 字节、1,424 个文件，ZIP SHA256 为 `906ef91513d4ee822b5b97f0288e885daf79926ccb7aa448d189dadad2981c65`；libcef.dll SHA256 为 `17ef9ee219c9c93fbbe934fe133b219780f1aa8526ac8cf8ca520bf593a532b3`。DLL / PDB GUID/Age 匹配，libcef、bootstrap、bootstrapc 的完整符号均未剥离；独立 MSVC / CMake ARM64 沙箱客户端 220 个编译 / 链接步骤全部通过。
- ARM64 实际构建包含 BoringSSL、CPU 频率查询、libwebp 与 cpuinfo 四项架构修复，并完成快照生成、旧 SwiftShader GL、ANGLE、bootstrap 与完整 libcef 链接；没有跳过失败编译目标来写完成标记。
- 最终另外重新计算三套 ZIP 的 SHA256，对照完成标记、SHA 文件、云端验证回执和总完成记录；检查归档文件清单、固定源码提交、Release / 符号 / 媒体 GN 参数、所需 SDK / 运行文件及其 PE 架构，全部匹配。x64、x86 的原包哈希保持不变。
- 对照三套各自的完整 PDB 身份回执，以及 x64 / x86 的实际 WebGL / 媒体 / 编码和独立客户端运行记录；ARM64 单独核验外部客户端 DLL 架构。复核结果为 `validation/windows-release-final-audit.json`，最终 ARM64 回执与总完成记录同目录保存。
- 已确认 `Release_GN_x64`、`Release_GN_x86`、`Release_GN_arm64` 与逐架构 SDK 暂存目录均不存在；云端主编译任务已正常退出，C 盘剩余约 234.5 GiB。保留源码、工具链、日志、成品和验证记录。
- 按用户要求进入 Windows 阶段交接，后续等待 Linux 服务器及 goal 恢复；顺序与快照工具缓存设计见 `NEXT-BUILDS.zh-CN.md`。ARM64 真机运行、Win7 运行以及未来 Linux / macOS 的验证仍不得冒充已完成。

下方为各阶段的历史过程记录，早期“尚未完成”等描述对应当时进度。

实际执行进度（2026-11-08）：

- 在 CVM 配置后台构建任务，SSH 断开不会终止任务。
- Git 官方安装包直连反复中断，已将本机 Git 2.53.0 的运行文件通过 SSH 传入；运行包哈希校验通过，git.exe 签名有效且实际运行成功。最新一键脚本仍保留自动安装 Git 的逻辑。
- 下载改为 curl 流式下载、断点续传与停滞超时，保留 SHA256 和签名检查。
- 修正 Windows PowerShell 5.1 在中文系统下读取 VS UTF-8 JSON 清单时的编码错误。
- VS 18.11.12328.437 官方 catalog 地址返回 18,407,518 字节、SHA256 `417b8d3fee577bdb0e192835692446de51b4626526e4b555162fd9c2fca7dff1`，与 channel 声明的 31,256,199 字节/哈希不同。本机和 CVM 独立取得的文件一致，固定到 `toolchain-lock.json`；仅在 URL 和 VS 版本完全匹配时使用这个固定哈希，其他版本仍要求上游原哈希。安装器各自的 SHA256 与 Authenticode 检查继续执行。
- SDK 26100 已安装，x86/x64 `d3dcompiler_47.dll` 10.0.26100.9457 已保存并记录哈希。SDK 28000.2705 和 x86/x64/ARM64 调试工具已安装，三种架构的 kernel32.lib 均存在。
- VS 2026 Build Tools 已实际安装至 `C:\cef156\VS2026`，vswhere 对 C++ x86/x64、ARM64、ATL/MFC、ARM64 MFC 的组件检查通过。
- 修复将自动页面文件切换为手动管理后需重新查询实例的错误；实际已将 `C:\pagefile.sys` 设置为 32 GiB。CVM 已重启，并确认运行中的页面文件容量为 32,768 MiB。
- Chromium 固定标签对应提交 `aa939feff52ea94f0ca07d8029086738c2683685` 已由服务器查询确认，后台预取已启动；尚未进入 CEF 编译。
- CEF 固定提交 `a26ddfd2792604564986b31ea298e30b09bd9b3f` 已完整拉取并检出，`git rev-list --count HEAD` 为 3634；Chromium 主仓库仍在接收数据。
- 默认增加镜像模式：华为 Python 3.11.9 便携 ZIP 的固定 SHA256 已核对，服务器上的 python.exe/python311.dll 均为有效 Python 官方签名。便携 Python 已实际运行 gclient.py。
- Flutter 中国镜像已在本机和 CVM 实测取得指定 CIPD 客户端包，ZIP SHA256 为 `dbd2c84eda881adfd53155f2b8e7e811a4323f6e8d9470ff9a4a5b5ceaf5f9bd`；包中 cipd.exe SHA256 为 `9c4873c55a480eced9309eb2567ad852cec72aa13eb7d348029584054075483a`，匹配 depot_tools 的官方 bootstrap digests。未把镜像首页可打开当成依赖可用。
- 新增本机只读 CIPD 元数据适配，让原版 CIPD/vpython 从镜像安装依赖。服务器真实执行 CIPD ensure 成功安装 GN `git_revision:127dd2a6d582528d6d61c4d838dc17385ef31abd`，运行输出 `2574 (127dd2a6d582)`；CIPD selfupdate 使用官方 digests 检查成功。depot_tools 其余依赖仍在下载。
- 17 项既有构建编排测试通过；4 项镜像测试通过，覆盖固定 instance ID、包身份、同标签内容变化拒绝、客户端官方哈希门槛、二进制 pRPC、下载范围及客户端 SHA256 aliases。真实 GN 安装作为额外集成检查，未替代完整依赖同步或 CEF 编译。
- 镜像 URL 替换启用后，源码续跑按 Git 配置中保存的原始 origin 校验；不把 `git remote get-url` 展开后的镜像地址误认为源仓库被更换。空目录拉取/续跑测试已改为实际使用 URL 替换并通过。
- Windows 顶层 DEPS 的 CIPD 预取已由原版 gclient 完成；这在单独的临时依赖目录进行，不是实际 Chromium 构建目录的完整同步。主源码和 Git/GCS 依赖仍需完成同步。原版 gclient 帮助命令成功运行；显式 vpython 3.11 配置在 CVM 上输出 Python 3.11.9。
- 修正新 depot_tools 已无 `python3.bat` 的启动方式。便携 Python 仅用于镜像元数据启动；实际构建编排统一使用 `vpython3.bat -vpython-spec=build.vpython.toml`，明确要求完整 Python 3.11，避免默认 Python 3.8 无法运行较新 pathlib API，也避免嵌入版隔离路径影响 CEF/Chromium 脚本的同目录模块导入。使用原生 TOML 配置，避免 vpython 自动转换并删除旧式配置文件后导致续跑失败。
- gsutil 5.35 的官方 ZIP 已在本机/CVM 分别下载，SHA256 均为 `93f4729b3972a512fca030d0ed45a1be7a4d1a44b4465bf8a8842fee42bae264`，MD5 匹配官方对象头。新增 Python wheel 只读缓存，实际取得 `crcmod-1.7+chromium.4-cp311-cp311-win_amd64.whl`，SHA256 为 `dfa5bb22d8ac31f7f98647a650833ec6d985dd6d13a6854c91aca8510c4dba06`，匹配官方索引/锁文件；实际 UV 安装成功，Windows 顶层 GCS 依赖预取已完成 45 项。它仍在独立的临时依赖目录，正式构建目录的完整同步尚未完成。
- 官方 `chromium-156.0.8071.0.tar.xz` 归档已取得，4,416,395,880 字节，MD5 `8cfe678a480b592dc24d53e0b5d53518` 匹配官方对象头。它省略了大量测试文件，并修改了少数发行用文件，因此逐项 Git 检查没有放行“完整源码”：从归档导入了 272,739 个匹配的 blob，仍缺 199,065 个。包内 `complete_source_objects.py` 可用 Git 验证中断数据包中的可恢复对象，并按精确 blob ID 补取余项；只有全部真实 Git 树所需对象存在才写完成标记。中断数据包恢复的非零返回值不会作为完成依据。
- 上述源码补齐已在 CVM 完成：固定提交的 507,337 个文件路径涉及 471,804 个不同 blob，全部存在，missing_paths 为空，`git fsck --full --no-dangling` 返回 0。随后本地 fetch 已将 517,112 个对象、约 1.37 GiB 数据导入实际构建源码仓库；实际工作树检出及后续完整依赖同步仍在进行。该归档/真实对象补齐流程已接入镜像模式首次创建源码目录的主脚本，具体首次整包从零执行尚需继续验证。
- 9 个预取的大型 Git 依赖已全部完成，逐个核对到固定 gitlink：ANGLE、Dawn、Skia、SwiftShader、V8、FFmpeg、WebRTC、ICU、PDFium。其他依赖仍由完整 gclient 同步处理。
- 实际工作树已完成 507,610 项检出，HEAD 为 `aa939feff52ea94f0ca07d8029086738c2683685`，已启动完整 gclient sync。同步的 `--revision` 改传这个完整 SHA，避免仅传版本标签时触发远端分支查询和多余 fetch；标签与提交的双重核对保留。
- 2026-11-08 在实际构建目录完成完整 `gclient sync --nohooks --no-history -j 8 --revision src@aa939feff52ea94f0ca07d8029086738c2683685`，未排除 Git、GCS 或 CIPD 类型。CIPD 嵌套新增的 Go、esbuild、Agility SDK 包也已从镜像取得。CEF `runhooks.patch` 已在实际源文件上应用，后续 `gclient runhooks` 正在运行；此时尚未进入 C++ 编译。
- 实际 runhooks 在 `generate_location_tags.py` 失败，原因是 `build/find_depot_tools.py` 优先调用源码中固定的另一份 depot_tools，其 dirmd 尚未完成 CIPD 初始化。脚本已增加嵌套 depot_tools 的官方客户端哈希校验、镜像地址适配及其固定 manifest 安装，再调用该 dirmd 做实际启动检查。
- 修正同步与钩子的续跑边界：`dependencies-synced.json` 在完整同步成功后独立保存，钩子失败后重跑不再对已应用 runhooks.patch 的源树执行 gclient sync。对旧流程已完成的实际同步，检查 gclient 只在成功结束后写入的 `.gclient_previous_sync_commits`，逐个核对其中 156 个仓库的实际 HEAD，确认 runhooks.patch 的反向检查通过后恢复了这个检查点；未 reset、stash 或丢弃补丁。
- CIPD 文件缓存增加进程间文件锁和索引重新读取/合并，避免嵌套客户端启动器与常驻元数据服务同时访问时重复下载、覆盖缓存索引。6 项镜像测试通过，其中新增两个独立缓存实例交替写入/读取的回归检查。
- 增加真实编排路径的钩子失败续跑测试：两次故意失败的 runhooks 只执行一次完整 gclient sync，固定 SHA 参数正确，未提前写 sync-and-hooks/prepared 完成标记。该新增测试通过；不把此模拟故障测试当成实际下载钩子已成功。
- 嵌套 depot_tools 的官方 CIPD 客户端 SHA256 `453cc58cc06b84f0d6566c112b8e86a4784db391388dd1870065c55e8c369ebf` 已匹配其源码记录；13 个 Windows 主机工具包的固定 instance ID 已全部下载校验，原版 CIPD 安装成功，固定 dirmd.exe 的 `-help` 实际运行返回 0。runhooks 已继续重跑。
- 2026-11-08 03:25（北京时间），实际构建目录的全部 runhooks 已成功结束；345 个 Win7 补丁全部正式应用并写入逐项日志，CEF patcher 输出 `117 patches total (116 applied, 1 skipped, 0 failed)`（已提前应用的 runhooks.patch 正常识别跳过）。Windows 沙箱修正及 WebGL 自定义补丁已实际应用，`state/prepared.json` 写入真实源码文件哈希和固定版本。GN、编译与运行验证仍未完成。
- 当前另外通过 5 项镜像测试及 2 项源码缓存测试，包含 Python wheel 哈希保留、UV 使用的 HEAD 请求、真实 Git 小仓库的归档导入/截断数据包恢复，以及已校验归档的离线续跑和精确临时文件清理。17 项既有编排测试已通过，随后针对 URL 替换后的实际 Git 拉取/续跑及两项 PowerShell 启动检查复查通过。
- Chromium 固定的 depot_tools 为 `910f54316dac310fadee0c453c4d460c0c446189`，其 gsutil 同样为 5.35。构建辅助程序在完整同步后，将同一份已校验官方 gsutil ZIP 准备到该嵌套目录，避免 runhooks 再次卡在不可达的启动元数据端点。
- 在 CVM 的 SYSTEM 账号下，已实际安装并运行 depot_tools `vpython.toml` 的完整 Python 环境；Python 为 3.11.9，`python3` 指向其完整虚拟环境，所需 Python wheel 均通过本机缓存按官方索引哈希取得。
- 首次 x64 Release GN 启动暴露 `python3_bin_reldir.txt` 缺失：固定 depot_tools 时关闭自动更新，也跳过了旧 Python shim 的初始化。脚本已显式调用外层和嵌套目录的官方 `bootstrap/win_tools.bat`；两份固定 CPython 3.11.8 均已从 Flutter 中国镜像取得并通过 CIPD 安装，Python shim 实际导入 ssl/sqlite3 成功。实际 `buildtools/win/gn.exe gen out/Release_GN_x64 --fail-on-unused-args` 已启动，CEF 117 项补丁再次检查为全部已应用、0 失败，GN 后续检查仍在进行。
- 本轮补齐官方 bootstrap 环境模拟、固定 Python 版本映射和补丁清单增补迁移后，完整重跑 28 项本地测试，全部通过（56.701 秒）。模拟六配置完成输出不代表服务器实际产物已生成。
- 嵌套旧 depot_tools 的 bootstrap 清单仅保存 Python 版本标签，没有固定 instance ID；外层官方 `bootstrap/manifest.versions` 为同一版本给出固定 ID。将该映射保存到 `network-lock.json`，标签请求直接按官方 ID 读取已校验缓存，避免重复下载，也继续执行包内容哈希检查。7 项镜像测试通过，新增覆盖官方版本映射的缓存复用和错误内容拒绝。
- x64 Release GN 首次成功输出 `Done. Made 36178 targets from 5074 files in 67033ms`，Ninja 实际启动 60,180 个任务；已成功执行部分 C++/Rust 编译任务。首次停止原因是中文 Windows 的 icacls 输出与 Python UTF-8 模式冲突，新增 `windows-build/localized-acls.patch`，只为该原生命令指定 Windows ANSI 解码。CVM 在 `PYTHONUTF8=1` 下重新执行原始权限设置入口返回 0，未绕过 ACL 步骤。
- 首个 x64 Release 编译到 CEF 自身代码时发现固定 CEF 与 Chromium 156 的权限枚举差异：`permission_prompt.cc` 引用了已从 `components/permissions/request_type.h` 删除的 `kAmbientLogin`。新增 `windows-build/cef-permission-request-type.patch` 删除无对应请求类型的旧映射；对实际 Chromium 源树执行 `git apply --check` 通过，未改变其他权限映射。原编译输出保留，修正后增量续跑。
- 上述 permission_prompt.obj 已在 CVM 实际编译通过。旧 SwiftShader 的 `swiftshader/libEGL.dll`、`swiftshader/libGLESv2.dll` 以及 bootstrap/bootstrapc 已实际链接成功。随后 CEF setting_helper.obj 暴露下一处类型差异：Chromium 8071 的两个有效内容设置与 CEF NEXT 中 deprecated API 名称不同。新增 `cef-setting-helper-content-type.patch` 为 Storage Access Header Origin Trial 和 Direct Sockets Private Network Access 保留双向映射，不新增/调整 CEF 公开 ABI 槽位。实际源树正向检查通过，修正后的完整构建仍需验证。
- 对已准备源码新增 Windows 构建补丁时，保存原补丁清单的精确字节与 SHA256；仅允许新增 windows-build/history 文件，原有清单中每一项的哈希必须保持一致。新增迁移边界测试通过，修改既有补丁或加入其他类型补丁会拒绝续跑。实际 prepared.json 已成功迁移并新增 common.py 的源码哈希；无重新同步或清空构建目录。
- x64 Release 已推进到 20,000 余个任务，WebGL 修改涉及的 gl_features.obj、gpu_util.obj 以及 OpenH264 代码均已实际编译成功。读取实际 GN/媒体构建标记和 Chrome/win/x64 FFmpeg 配置，H.264/AAC 解码、MOV/MP4 解封装、OpenH264、proprietary codecs 均为启用；这仍不能代替真实媒体播放和 WebGL 回退运行测试。
- 本台 CVM 编译时实测 CPU 使用率约 76%、空闲物理内存约 25 GiB，最多观察到的 clang 工作集约 604 MiB。将后台任务参数从 Jobs 10 改为 14，原对象文件保留并按 Ninja 日志增量续跑；新机器的一键脚本默认仍为 10。SDK 元数据增加实际 build_jobs 记录。
- 补充独立的 `runtime_probe.py`，为产物完成后实际验证做准备：回环 HTTP 页面进行 WebGL 像素绘制、H.264 MP4 播放、Web Audio AAC 解码、WebRTC H.264 查询，结果绑定 libcef.dll SHA256 与主机 Windows 版本。媒体 fixture 由固定源码提供，715,963 字节、SHA256 `bcb75d3db0a1a5056f4cd5c770ceccdb4cae920f21abb8139b29cd9ad39e3857`，源码 README 确认其 H264 high profile + AAC。Python 和页面 JavaScript 语法检查通过；尚无真实 CEF 产物运行结果，不计为运行验证通过。
- x64 Release 已完成链接和 SDK 制作：ZIP 1,622,241,007 字节、1,420 个文件，SHA256 `2bc22921ffa43e7fcf86711961be9b1d83e142fc25ed63a9dd822af39cb08e51`。libcef.dll 314,673,152 字节，libcef.dll.pdb 5,789,917,184 字节。ZIP 逐文件解压核对原始 SHA256/CRC 成功后写完成标记；Release_GN_x64 已清理，Debug_GN_x64 随后开始编译。
- 从上述已校验 ZIP 提取 240 个运行所需文件，每个文件再次核对 SDK 清单哈希；保留完整压缩包，不通过公网下载大包。首次运行探测因独立 Resources/ 中的 ICU 数据尚未部署到 EXE 旁而失败，修正探测工具按示例 CMake 方式合并资源到临时应用目录，不改 SDK 源文件。
- x64 Release 在 CVM WinServer 2025 (10.0.26100) 的默认模式及 `--disable-gpu` 模式均实际运行通过：WebGL1/2 报告 Google SwiftShader、绿色像素正确且 GL error 为 0；H.264 视频 1280×720、已解码帧且播放时间推进，AAC 解码为双声道 44.1 kHz 的 120,832 个采样帧，WebRTC 宣告 H.264。绑定的 libcef.dll SHA256 `eb1508d6b94f5cba545844de878882507d0d58bb2d8b36eb0e40b25fb24085c7`。完整 JSON 见 validation/runtime-x64-Release-auto-deployed.json、runtime-x64-Release-software.json；此结果证明本台机器的软件路径，不证明硬件 GPU 或 Win7/ARM64 环境。
- 为核实编码功能，增加 WebCodecs `avc1.42001E` 编码→解码像素闭环。x64 Release 在 `--disable-gpu`、编码/解码均指定 `prefer-software` 时实际输出一个 39 字节的视频编码块，解码像素为 `[0,255,0,255]`，通过 `--require-h264-encoder` 门槛；原有 WebGL、视频播放、AAC 和 WebRTC 检查同时通过。证据见 validation/runtime-x64-Release-h264-encoder.json。此项证明实际 H.264 编码可工作，未将单帧检查视为长期稳定性或编码性能测试。
- 从已完成 x64 Release ZIP 单独流式提取 libcef.dll.pdb 并核对清单 SHA256，再用固定工具链的 llvm-pdbutil dump --summary 读取，确认 Has Debug Info/Types/IDs/Globals/Publics 均为 true、Is stripped 为 false、无 conflicting types。VS dumpbin 读取 DLL CodeView 信息，其 GUID `{E6FEA077-EE47-7549-4C4C-44205044422E}`、Age 1 与实际 PDB 完全匹配。证据见 validation/runtime-x64-Release-symbols.json；临时提取的约 5.4 GiB PDB 已删除，原 ZIP 保留。

已通过：

- 17 项自动化测试：ZIP64 与逐文件哈希、清理边界、补丁路径修正、重复应用、CEF 无前缀补丁、10 个适配补丁的格式/哈希、六配置顺序与清理、完成状态续跑/损坏检测、打包失败保留输出、空目录 Git 拉取、含空格 Windows BAT 调用、完整本地补丁清单、文件缺失/修改/混入检测和官方补丁安装保留适配版本。其中部分项目在同一测试内覆盖。
- 本次新增的三项检查：345 个 Win7 补丁全部通过 Git 格式解析；用真实三提交 Git 仓库验证 CEF 完整历史拉取及已有浅克隆的续跑修复；执行实际 SDK 文件装配和 ZIP 校验流程，确认 PDB 通过移动进入 SDK、临时符号目录被清理、软件 WebGL DLL 保留。文件装配测试中的 PE/PDB 为小型模拟数据，make_distrib 的入口被替换，未运行真实 CEF 分发。
- Windows PowerShell 5.1 实际执行 `-PlanOnly`，PowerShell AST 语法检查。
- 2026-11-08 适配只有 C 盘的服务器：默认目录改为 `C:\cef156`，允许 C 至 Z 卷的专用目录，拒绝卷根目录、重复分隔符、`..`、空格和 UNC 路径。新增测试验证默认 C 盘计划、计划模式不创建工作目录及非法路径拒绝。通过 SSH 读取实际 CVM 的卷信息：C 为 NTFS，容量约 349.90 GiB、空闲约 329.29 GiB；D 显示容量 0。此次适配没有修改补丁内容、构建顺序或媒体参数。
- Python 语法编译，运行检查页面的 JavaScript 语法检查。
- 使用固定 CEF 的 `gn_args.py` 检查 x64/x86/ARM64 的 Release/Debug 六个配置；均为非 component 的 official 配置，全符号，Debug 启用 DCHECK。
- 从 Chromium `156.0.8071.0` 取得 CEF 补丁涉及的实际源文件，补齐对应 ANGLE/Dawn/V8 依赖源文件。按补丁仓库的逆序规则应用涉及这些文件的 50 个 Win7 补丁，无失败。
- 2026-11-08 补齐 Win7 补丁涉及的所有缺失原始文件，包括两个 ETW 二进制文件和 Rust backtrace 子模块的精确提交。在 1,051 个原始文件组成的检查目录中，按逆序完整应用全部 345 个 Win7 补丁，**345 成功、0 失败、没有排除路径**。逐文件 SHA256 和完整应用清单见 `validation/source-audit.json`。这证明补丁在所涉及原始文件上的应用通过，仍不能称为完整 Chromium/CEF 编译或 Win7 运行验证。
- 原始 CEF 补丁在该组合上发现 10 个冲突，随附完整替换补丁及原始/适配文件 SHA256。将完整 Win7 应用结果叠加到之前核对的 CEF 相关源文件后，首轮得到 `116 applied, 1 skipped, 0 failed`。随后取得 Chromium DEPS 固定的 depot_tools gclient.py，补齐唯一缺少的 tarball 补丁目标，复查得到 `117 patches total (1 applied, 116 skipped, 0 failed)`；这 116 项均为首轮已应用的正常识别跳过，最终没有目标目录缺失。117 个配置项已在相关原始文件上实际应用过，但仍只是源文件子集检查。Windows 构建修正和 WebGL 自定义补丁的正向应用及反向检查也通过。
- WebGL 自定义补丁已作为 `patches/webgl/webgl-fallback.patch` 实体文件随包携带；对实际 Win7 补丁后的源文件执行应用，再次应用可正确识别为已打补丁。运行时直接读取该文件。
- 新增 `windows-build/portable-processor-number.patch`，移除通用 Windows 沙箱辅助函数中的 x86 汇编，并替换未同步的初始化标记。对实际 Win7 补丁后的源文件应用和反向检查均通过；未运行 ARM64 C++ 编译。
- 包内包含 Win7 REWORK 该版本的 345 个原始 `.diff`、固定 CEF 的完整官方补丁目录（118 个文件，117 个配置项）、10 个 CEF 适配替换补丁、Windows 构建修正及 WebGL 补丁。全部文件列入 SHA256 清单，PowerShell 在开始安装前完成校验；Win7 补丁不再通过 Git 下载。

尚未验证：

- 在全新机器上从 ZIP 一次性完整执行全部安装/下载流程；本台 CVM 已完成镜像模式的实际全依赖同步及补丁应用。
- ARM64 Release 的完整编译、链接和 SDK 制作。
- Windows 7 x86/x64 运行与 Windows on ARM 运行。
- 可用硬件 GPU 环境的 WebGL 路径、第三方宿主应用集成；本台 CVM 的软件 WebGL 和 H.264/AAC 运行检查已通过。

通过补丁应用检查不能证明 C++ API 兼容或运行兼容。上述脚本会在实际执行中检查失败、记录日志并保留当前状态。

2026-11-08 外部 SDK 接入复核：

- 从已校验的 x64 Release ZIP 提取除 PDB 外的完整 SDK，1,407 个文件核对清单通过。以独立 VS 2026/MSVC、CMake 4.3.1 和 Ninja 编译官方 cefsimple，`USE_SANDBOX=ON` 的包装层及应用 DLL 已实际链接成功。
- 检查发现上游 CMake 复制清单未包含本组合恢复的 ANGLE DLL 和旧 SwiftShader 目录。打包工具现会将这些项目加入 SDK 的 `CEF_BINARY_FILES`。更新后的打包逻辑及原有构建工具测试共 19 项通过；修正后的真实外部项目运行仍待验证。
- bootstrap 真实启动发生 0xC0000005。使用 ZIP 中哈希匹配的 bootstrap PDB 定位到 `content::InitializeSandboxInfo`：它读取尚未初始化的 `base::CommandLine::ForCurrentProcess()`。新增 `bootstrap-sandbox-command-line.patch`，显式传入 bootstrap 的局部命令行，不更改进程分类或关闭沙箱。补丁的实际编译、链接和运行验证尚未完成。

2026-11-08 09:08（UTC+08:00）云端交接：

- 用户取消 Debug 后，已停止原主任务；原 `Debug_GN_x64` 由新云端接续器在边界校验后清理，释放磁盘空间。三套 Release 顺序、旧计划精确迁移、打包和 PowerShell 计划模式四项测试通过。
- 注册并实际启动 `MyCEF156-Cloud`，SYSTEM / ServiceAccount / 最高权限 / 开机触发 / 无执行时限；失败最多重试三次、间隔三分钟。旧 `MyCEF156-Build` 已停用。实际任务状态为 Running，云端 Python PID 7428，正在以独立 Ninja 进程增量重编 Release bootstrap，日志 `cloud-20261108-090741.log`。
- 云端接续器在打包后校验匹配的完整 PDB，编译外部 CMake 客户端，并对 x64/x86 实际运行 WebGL/媒体检查；ARM64 只做编译、链接、PE 架构和 PDB 校验，明确保留目标设备运行验证边界。PE debug-directory / PDB GUID-Age 解析已对真实 x64 bootstrap 文件实际通过。
- 修正 CMake 复制清单后的独立普通 EXE 已在 CVM 通过实际 WebGL 绘制、H.264 播放/编码回环、AAC 解码和 WebRTC H.264 检查；云端 bootstrap 完整运行验证仍待重编完成。

- 09:16 云端已成功链接修复后的 bootstrap/bootstrapc，三份主要 DLL/EXE 的 PDB 身份和完整性检查通过；SYSTEM 计划任务下默认及禁用 GPU 的实际 WebGL/媒体/编码回环检查均通过。外部 CMake 入口随后暴露 cmd.exe 参数的引号错误，已改为完整命令行字符串，并在 CVM 实际验证 vcvars64 环境捕获成功（x64，VS 18.11.3）。续跑保留已编译对象。

- 09:20 修复后的 bootstrap 已由独立 CMake 编译的 cefsimple.dll 实际加载并运行，WebGL 绘制、H.264 播放/编码回环、AAC、WebRTC 声明全部通过，未关闭沙箱。结果见 `validation/cloud-x64-Release-bootstrap-runtime.json`；原生示例默认/禁用 GPU 的结果同目录保存。
- 09:22 完成 x64 Release ZIP 刷新并逐文件读取核对：1,622,247,117 字节、1,421 个文件，SHA256 `110e1955c90508d8aff7666a498cf7ce6b2458cdebe926a84ba948d60cac0ff8`。刷新只替换 bootstrap/bootstrapc 及对应 PDB、CMake 运行文件复制清单和构建溯源；libcef.dll/PDB 保持前述已验证哈希，并在元数据中分别记录原 libcef 构建补丁清单和本次修复清单。完整验证回执为 `validation/cloud-verified-x64-Release.json`，绑定新 ZIP SHA256。
- 09:23 云端构建计划已精确迁移为三套 Release，原计划历史留存；x64 Refresh 暂存目录、重编目录和 Debug 构建目录已清理，`src/out` 仅剩正在生成的 `Release_GN_x86`。x86 将使用同一补丁清单与媒体配置。

2026-11-08 15:35（UTC+08:00）重启后复核：

- x86 Release 已完成压缩和逐文件校验：1,531,215,739 字节、1,419 个文件，SHA256 `2f70672593ae9e48b1b412b7b773b97228433434d61c4e39598f346c62d93dc5`。重新连接后又在服务器直接计算 ZIP SHA256，匹配完成标记及验证回执。
- x86 的 libcef.dll、bootstrap.exe、bootstrapc.exe 与各自完整 PDB 的 GUID/Age 匹配，均具有完整调试信息且未剥离。证据为 `validation/cloud-verified-x86-Release.json`，其中回执绑定该 ZIP 的 SHA256。
- x86 实际运行在默认和禁用 GPU 两种模式下均通过 WebGL1/2 绿色像素绘制、H.264 1280×720 视频播放、AAC 双声道 44.1 kHz 解码、WebRTC H.264 声明和 H.264 软件编码→解码像素回环；独立 MSVC/CMake 编译的沙箱客户端也通过相同检查。三个运行报告为 `validation/cloud-x86-Release-{auto,software,bootstrap}-runtime.json`，绑定同一 libcef.dll 哈希。这些结果仍限本台 Server 2025 的软件路径。
- 服务器于 15:30:14 启动，SYSTEM 开机任务自动启动。15:34 实际 ARM64 GN 输出 `43727 targets` 并启动 Ninja，实际参数确认 `target_cpu="arm64"`、Release、非 component、完整符号、proprietary codecs、OpenH264 和 SwiftShader。x64/x86 中间目录均已清理；此时 ARM64 尚未完成。
- ARM64 编译首个错误来自 REWORK 修改后的 BoringSSL `thread_win.cc`：原始替代 once 实现主动拒绝非 x86/x64，且替代 push lock 也假设 x86 内存顺序。新增 `boringssl-arm64-synchronization.patch`，在 `OPENSSL_AARCH64` 分支恢复固定上游的 INIT_ONCE 类型、InitOnceExecuteOnce 和 SRWLOCK；x86/x64 保持原兼容代码。修复及补丁清单已随包保存，编译验证仍待续跑。云端接续器只允许这个哈希固定的 ARM64 补丁增量沿用已验证 x64 ZIP，保留该 SDK 的原始清单与哈希；未知变更仍拒绝。
- 15:40 BoringSSL `thread_win.obj` 已实际编译成功，补丁反向检查通过。随后 ARM64 在 `base/power_monitor/cpu_frequency_utils.cc` 的另一个未隔离 x86 汇编中停止。新增 `arm64-processor-number.patch`，只对 `ARCH_CPU_ARM64` 直接调用原生 GetCurrentProcessorNumber，其他架构保留原兼容代码。云端接续器的例外清单增加这一精确补丁哈希，仍保留所有旧 SDK 的构建溯源；待继续编译验证。
- 15:44 CPU 频率采样对象已编译成功。15:48 ARM64 在 libwebp 的旧版线程模拟代码中遇到未定义的 INT_MAX；该线程锁也来自相同的旧式替代实现。新增 `libwebp-arm64-synchronization.patch`，仅在 `_M_ARM64` 分支恢复固定上游的 CONDITION_VARIABLE、SRWLOCK 和对应等待/唤醒函数，x86/x64 原分支保留。多线程功能不关闭，修改后的对象尚待续编核实。
- 15:52 libwebp 的 thread_utils.obj 已实际编译成功。新增四项云端续跑测试，覆盖允许的 ARM64 补丁增量保持 x64 ZIP/完成标记逐字节不变、未知增量拒绝、同名补丁内容变化拒绝、既有 bootstrap 补丁变化拒绝；四项均通过。补丁清单完整性与增补迁移边界两项测试也通过。
- 16:04 ARM64 在 cpuinfo 初始化停止：补丁将共享 init_guard 改为 volatile long，但 ARM64 仍调用要求 INIT_ONCE 指针的 InitOnceExecuteOnce。新增 `cpuinfo-arm64-once.patch`，仅为 CPUINFO_ARCH_ARM64 恢复匹配的 INIT_ONCE 静态初始化，保留其他架构原分支。待续编核实。
- 16:09 cpuinfo 的 ARM64 init.obj 已实际编译成功，后续 FFmpeg/TFLite/ANGLE/Dawn 等编译继续进行。

2026-11-08 本机开发接入复核：

- 用户下载到 `build/` 的 x64/x86 ZIP 均与云端成品 SHA256 一致，分别流式解压并验证 1,421/1,419 个文件的完整 SHA256/CRC；完整 PDB 和 x86/x64 PE 架构均通过核对。SDK 解压到 `build/cef-sdk-x64`、`build/cef-sdk-x86`。
- 使用本机 VS 2022 MSVC 14.44.35207、CMake 3.31.3、Ninja 1.12.1、C++20，在 `USE_SANDBOX=ON` 下独立编译并链接两架构的 libcef_dll_wrapper、cefsimple、cefclient，均成功。修正本机 CMake 对 UTF-8 中文 MSVC include-prefix 的误读后重新编译，Ninja 实际记录 cef_message_router.cc.obj 的 77 项头文件依赖；修正放在本机独立 CMake include 文件中，SDK 源码不修改。
- 初始隐藏/遮挡窗口的硬件视频预加载检查超时，WebGL/AAC/编码检查正常；诊断页面确认 document.visibilityState 为 hidden。显示/最大化测试窗口并关闭测试进程的后台节流后，x64/x86 重编沙箱客户端均通过硬件 WebGL（RTX 3060/D3D11）、H.264 1280×720 视频播放、AAC、WebRTC H.264 与软件编码回环。没有禁用默认 GPU 或视频解码路径。软件 WebGL 路径另行验证。
- `runtime_probe.py` 增加显式 `--show-window` 测试选项及窗口模式记录；默认云端隐藏窗口流程保持原样。完整本机报告在 `build/development-validation`，最终验证摘要另随一键包保存。
- 最终本机验证已完成：两个架构的默认硬件 GPU 与禁用 GPU 软件模式共四份报告全部通过，重新构建入口也确认 `ninja: no work to do`；独立应用 DLL、bootstrap 的架构及哈希核对通过。逐项结果与应用 DLL 哈希见 `validation/local-development-development-readiness.json`，四份实际运行报告及下载完整性报告同目录保存。
- 16:47 按用户要求补充 ON/OFF 实际编译演示：相同 SDK 和源码，VS 2022 分别在 x64/x86 下以 `USE_SANDBOX=OFF` 编译并链接 cefsimple/cefclient，均成功生成业务 EXE，未生成同名业务 DLL；与既有 ON 的 bootstrap EXE + 业务 DLL 对照核实。四配置 CMakeCache、PE 架构、ON EXE 等于 bootstrap、OFF EXE 不等于 bootstrap、对应架构 libcef.dll 哈希一致均通过，说明切换客户端模式无需重编引擎。两个 OFF cefsimple 的硬件 WebGL、H.264 播放与软件编码回环、AAC、WebRTC 检查通过；ON 模式的先前运行报告同样通过。结果见 `validation/sandbox-on-off-demo.json` 和 `validation/local-development-{x64,x86}-no-sandbox-runtime.json`。演示窗口直接启动核实标题成功，两种模式的启动脚本在本机 `build/sandbox-demo`。

## 2026-11-08：Linux / macOS 新 goal 的实际预检

- 实际 Ubuntu 主机的 23 项准备工具测试通过；真实 tar.zst 回读验证覆盖执行权限、framework 符号链接、每个文件 SHA256 和 zstd frame，损坏及越界链接被拒绝。记录 `validation/posix-helper-validation-current.json`。
- 固定 CEF 的真实 Python 参数策略已分别用于四个目标，检查 Release-only、完整符号、媒体开关、受控 Linux sysroot 及宿主环境隔离；记录 `validation/posix-gn-policy-preflight.json`。这不是 `gn gen` 或 C++ 编译成功记录。
- 官方 117 个 CEF 补丁在干净 8071 输入上由原始 patcher 严格通过，外加两个 CEF 共用 C++ 修复、WebGL 和完整 DWARF 压缩补丁；`validation/posix-source-patch-audit.json` 的范围继续仅为应用检查。
- Chromium 固定版本的原始 Linux build-deps 脚本已实际成功安装宿主依赖，两个原始 sysroot archive 的 SHA256 也已通过；见 `validation/chromium-build-deps.json` 与 `validation/linux-sysroots.json`。不能据此宣称 CEF 的最终 glibc 最低版本。
- x64 / ARM64 的 Debian 4.9.228 内核都实际在完整 QEMU VM 中启动。x64 已在该旧内核中执行 glibc 2.28 用户态；ARM64 已在自己的旧内核 VM 中完成 buster 第二阶段配置并执行 glibc 2.28。三份 `validation/linux49-vm-*-boot.json` 均通过；CEF / 沙箱 / 图形 / 媒体的目标验证仍待产物编译完成。
- Apple SDK-only 包已按官方公开目录的 XAR TOC 摘要和全部成员摘要验证；`validation/apple-sdk-*-verified.json` 记录实际完整包 SHA256。27.2 SDK 已解压，26.6 对应的 SDK 包已缓存；不伪造匹配上游默认 SDK 的版本，也不把库头文件存在当成完整 macOS CEF 支持。

Linux x64 正式 GN / 编译仍待源码对象及依赖同步、hooks 完成；后台流程已接上真实 hooks、配置、快照预编译、CEF 编译及快照导出，错误不会被跳过。新 `configure_posix.py` / `compile_posix.py` 等命令的完整路径尚待跑通，不能把该接续配置当作产物完成。当前进度见 `LINUX-HANDOFF.zh-CN.md` 和云端 `state/posix-preparation-status.json`。

- 23:28（UTC+08:00）固定 Clang 24 下载、官方 MD5 / SHA256 及原始安装器 Git blob 核验通过，已实际执行版本检查；`validation/clang-prefetched.json`。macOS ARM64 / x86_64 的 C / CoreFoundation、Objective-C++ / Cocoa 四项真实交叉编译和链接通过，Mach-O 架构匹配；`validation/mac-cross-compiler-smoke.json`。尚不代表完整 CEF、C++ 库集成、资源 / Helper、符号或 macOS 运行通过。
- 23:35 两种完整 Linux 4.9 VM 均用实际 glibc 2.28 / Python 3.7 导入当前运行探针，并以普通用户启动 Xvfb 成功；`validation/linux49-{amd64,arm64}-tools-preflight.json`。`linux49_runtime_vm.py` 增加 SDK 只读共享和真实 CEF 三模式验证入口，但 SDK 尚未存在，CEF 运行分支尚未执行。
- 新 `package_linux.py` 接在 x64 后台编译之后，强制完整 Release DWARF、标准 SDK 文件和 glibc 需求审计；实际打包待真实编译完成。WebGL GTest 现在要求四项指定测试实际执行且无失败 / disabled，零项测试不算通过。运行探针记录实际 glibc、客户端文件 SHA256，并支持传入独立客户端。
- 23:41 macOS 两种 CPU 新增 C++20 / SDK libc++ 编译和链接通过，预检现共六项。固定 Clang 的原版本 macOS compiler-rt 运行库已缓存且官方 MD5 通过；`validation/clang-mac-runtime-cached.json`。尚未代表完整 Chromium / CEF 或 dSYM。
- 23:53 完整 4,416,395,880 字节官方源码归档 MD5 通过；`validation/source-archive-verified.json`。主源码与九个依赖已开始实际 Git blob 导入。下载器改用 1 MiB HTTP 请求，原 16 MiB 分片及回执身份保持；四项下载测试在 Windows / Ubuntu 均通过。新的独立客户端、旧系统 CEF 运行、归档 / 清理入口已接入或准备，真实 SDK 执行仍待编译完成。
- 11 月 9 日：macOS 辅助工具的官方 LLVM Release 签名 / package index / SHA256 校验通过，独立提取并实际运行 dsymutil / llvm-otool / llvm-dwarfdump；原主 Clang SHA256 不变，原版本 Darwin compiler-rt 已由上游安装器装好。两架构真实小程序的 dSYM UUID 和 DWARF verify 均通过，见 `validation/mac-aux-tools-verified.json` 与 `validation/mac-cross-compiler-smoke.json`。不代表完整 CEF 或 macOS 实机验证。
- Linux 归档新增中断后恢复验证：已有归档必须逐文件回读与当前 SDK 完全一致才复用；SDK 内容变化会拒绝且保留原归档。与原有测试合计三项在 Ubuntu 实际通过。此时主源码的遗漏 Git 对象与依赖仍在抓取，CEF 尚未开始正式编译。
- 11 月 9 日：原 CLT 26.6 SDK 包已实际解出 SDK 26.5 / 25F70，匹配固定源码 universal 配置；两种 CPU 的 C / Objective-C++ / C++20 编译、链接与 dSYM / UUID / DWARF 检查均通过。独立回执 `validation/mac-cross-compiler-universal-smoke.json` 保留 27.2 路线的先前证据。九个主要依赖完成真正 Git 对象 / fsck / 固定提交检出，主仓库遗漏对象仍在抓取。
- 11 月 9 日：两个固定 sysroot 均已真正安装。`linux_client_toolchain.py` 使用固定 Clang / sysroot 实际 CMake 编译、链接 C++20 / GTK 小程序，两种架构均在自己的 Linux 4.9 / glibc 2.28 完整 VM 中执行成功；对应 `validation/client-toolchain-linux-*.json` 和 `validation/linux49-*-tools-preflight.json`。小程序实测 glibc 需求 x64 2.2.5、ARM64 2.17，不能当作 CEF 引擎最终需求。
- Linux 连续构建服务已安装并实际等待现有 x64 服务；后续按真实运行 / 归档 / 清理关口接 ARM64，尚未执行完整 CEF 流程。客户端交叉构建、VM 中独立客户端身份校验，以及链接后的实际模块生成头文件审计已加入代码；没有真实 SDK 时不写其成功记录。
- 11 月 9 日 00:36：主仓库全部 471,804 个真实 Git blob 与 fsck 通过，固定提交已实际检出，进入真正 gclient sync。中断首次检出的恢复逐文件核对了 200,824 个原文件并保留一个中断空文件的备份；恢复 / 类型冲突拒绝两项实测通过，Ubuntu 当前准备工具测试总计 27 项通过。`validation/source-objects-complete.json`、`validation/chromium-checkout.json` 和 `validation/source-initial-checkout-recovery.json` 记录实际范围。
- 固定 nested depot_tools 的原始 CIPD ensure 已实际完成。原始 Rust 包 276,524,576 字节 SHA256 与原始安装器 Git blob 验证通过，已实际执行锁定 rustc；`validation/nested-depot-bootstrap.json`、`validation/rust-prefetched.json`。Linux MIG 已生成两架构 user / server stub 并实际编译成 Mach-O 对象；`validation/mac-mig-compiler-smoke.json`。这些都是工具和依赖证据，尚无 POSIX CEF SDK 编译 / 运行成品。
- 11 月 9 日 01:00 左右：修正仅构建目录 CIPD wrapper 的普通 ensure / resolve 路由后，原 CIPD 客户端实际经 loopback 镜像安装固定 GN，并运行得到 `2574 (127dd2a6d582)`。新增 macOS SDK / CLT / dSYM 接入补丁已对真实固定源码通过应用检查，五个 GN 文件经该真实 GN 解析 / 格式化通过；`validation/mac-cross-sdk-source-patch.json`。SDK 元数据已从原始 Apple 包 / SDK 读取并保留完整目录清单；`validation/mac-sdk-metadata.json`。完整 GN、CEF 编译和 macOS 运行仍待完成；当时早期工具链目录已被初始同步替换，因此后续 hooks 会经原安装器复用缓存，不将旧预取回执当作当前文件仍存在的证据。
- 11 月 9 日：重新由真实 GCS 同步安装的 Clang SHA256 与预取记录一致。四份原 CEF 菜单 XIB 经 `mac_menu_source.py` 生成完整 AppKit 代码，在 ARM64/x64、ARC/手动计数下共 16 份 Mach-O 对象编译通过；从适配后 CEF BUILD 提取的同一模板也已实际 GN gen → Ninja 编译四份菜单和四份 owner 对象，证明 action 依赖和 public config 宏传播；四套 plist 除 MainMenu 自动加载键外逐字段保持一致。`validation/mac-menu-{source-smoke,gn-preflight,source-patch}.json` 记录范围。完整 CEF GN / 链接及 macOS UI、Recent Documents 和沙箱运行仍未验证。
- 11 月 9 日 04:42：Linux x64 编译对象已经完成，`libcef.so` 完整链接报压缩调试段解压错误；没有内核 OOM 记录。抽查报错对象的 zlib 段完整解压通过，191 个 CEF 包装对象的多组实际链接也通过，不能据此判定对象损坏。当前没有 POSIX CEF SDK 成品。32 GiB 专用临时链接 swap 的实际创建、启用和安全回收已通过；正式构建入口已接入按需启用和成功后回收。
- 11 月 9 日：完整串行链接诊断因持续换页而中止，未当作链接通过。GDB 索引调整先经 GN / Ninja dry-run 拒绝了会导致大量 Rust 相关重编的全局方案，现由追加补丁恢复全局参数，仅在 `libcef.so` 末尾覆盖 `--no-gdb-index`。完整 DWARF 与代表性 CEF 编译命令保留，实际 Ninja 计划只剩 57 项（38 项资源依赖增量编译）；正式构建与两项平台接续服务已启动。尚不代表主库链接或 SDK 验证通过。
- 同期修正 `Preparation` 对已有根标记的重复截断写入：首次由完整临时文件原子发布，已有标记只读验证。Ubuntu 的 12 线程 / 96 次并发初始化及错误标记拒绝检查通过，避免接续器启动时误读空标记。x64 两个快照工具实际 Ninja 复查均为 no work；正式主库链接实际 response 中已经包含 `--no-gdb-index`。
- 11 月 9 日 05:01：无 GDB 索引的正式主库链接仍在 CEF 包装对象的压缩段报同类错误，故不能将关闭索引认作完整修复。追加 `linux-cef-uncompressed-objects.patch`，只为 libcef 包装对象增加末尾 `-gz=none`，保留完整 DWARF 与主库 zlib 输出压缩；实际 GN 中覆盖顺序已确认，继续真实增量编译和链接。其他 Chromium 对象保留，不重置源码或修改 Ninja 时间戳。
- 11 月 9 日 05:11：192 项包装层对象重编通过后，原压缩段错误转到静态实现对象；完整串行链接未再报该错误，但确认 DWARF32 的 32 位调试重定位超出 4 GiB。现追加 `linux-full-dwarf64-serial-link.patch`，Clang 和 Rust 使用 DWARF64 偏移，主库 `--threads=1`，恢复包装对象 zlib 压缩并保留完整 DWARF v4。两个 CPU 的真实 C++ / 压缩共享 ELF 均已读取到 64-bit CU，固定 Rust 真实对象同样是 64-bit CU / R_X86_64_64 调试重定位。GN 再次生成并启动正式服务；检查主库直接输入图未发现遗漏的 minimal-symbols DWARF32 目标，实际最终链接 / SDK 验证仍待完成。
- 11 月 9 日 05:16：正式编译新生成的 protobuf `importer.o` 与 BoringSSL `x509name.o` 已实际读取其 ELF / zlib 内容，确认压缩调试段中是 DWARF v4 / 64 位偏移，不只检查 GN 参数；见 `validation/linux-dwarf64-actual-objects.json`。根标记的并发初始化 / 已有标记不重写 / 错误标记拒绝已加入回归测试，四项准备工具测试在 Windows 和 Ubuntu 均通过。完整主库及 SDK 尚未完成。
- 11 月 9 日：实际新生成的本地 Rust `core`、`std` 归档各抽查一份对象，均读到 DWARF v4 / 64 位偏移；见 `validation/linux-dwarf64-rust-sysroot.json`。在 x64 编译持续运行期间，以低优先级 / 单 CPU 配额完成 Linux ARM64、macOS ARM64、macOS x64 的真实 GN 重新生成及快照依赖计划更新；三份计划与配置哈希重新核验通过，正在运行的 x64 args 和快照计划完整哈希保持一致。记录 `validation/remaining-gn-dwarf64-refresh.json`、`validation/remaining-snapshot-plans-prepared.json` 只证明配置 / 图 / 依赖计划，不代表后续生成器已经编译、可以跨目标复用，或完整 SDK 已完成。
- 11 月 9 日 06:30：DWARF64 配置下 Linux x64 的快照生成器依赖阶段实际完成 30,080 项，最后 `v8_context_snapshot_generator` 真实链接通过。两个工具分别约 497 MB / 2.72 GB，实际 x86_64 ELF 及完整 debug_info / debug_line 段已读取核验；见 `validation/linux-dwarf64-snapshot-tools-linked.json`。服务随后已实际启动 CEF 主目标 Ninja；该记录不代表主库、SDK、旧 Linux 运行或其他 CPU 已完成。
- 11 月 9 日 07:39：Linux x64 主目标 22,223 项全部链接通过，`libcef.so` 4,698,927,208 字节，真实 ELF version-needs 最高 GLIBC_2.25，完整 debug_info / debug_line 段存在；见 `validation/linux-x64-main-library-linked.json`。4 项自定义 WebGL 策略 GTest 实际全部执行通过。Chromium 测试启动器把聚合 XML 写进了原请求的 JSON 路径，脚本读取 JSON 时失败；现显式请求 XML，验证全部四个准确用例、suite、run 状态和无失败 / 跳过。对真实原报告校验通过，正常及失败 / 缺失 / 跳过 / 重复用例拒绝测试在 Windows 和 Ubuntu 均通过。服务已恢复以复用全部链接产物，完整 SDK / 独立客户端 / Linux 4.9 实测仍待后续。
- 11 月 9 日 07:43：实际快照导出 55 个文件共 3,537,760,637 字节并逐文件回读；Linux x64 SDK 暂存完成，整包 ELF 审计通过且最高 GLIBC_2.25。独立 SDK 沙箱 ON 的 cefsimple / cefclient 编译链接通过；首次启动被临时部署目录中优先级更高的普通 `chrome-sandbox` 副本阻止。修正仅在临时部署目录将此入口换为已校验的 root / 4755 helper 符号链接，SDK 文件与引擎不修改、不关闭沙箱。续跑时对完全相同的编译记录保留原时间戳，避免只因重写时间造成 SDK 身份失效。运行复验和 OFF 客户端仍待实际结果。
- 11 月 9 日 07:50：修正临时 helper 部署后，独立 SDK 客户端已真实执行 WebGL1/2 绘制、H.264 帧解码、AAC 采样、WebRTC H.264 能力和 OpenH264 软件编码 / 解码回环；Linux process-title 把 argv 合并导致探针漏识别 renderer。按实际命令行修正后，两个 renderer 均确认为 Seccomp=2 / NoNewPrivs=1，ON / auto 诊断运行全部通过，见 `validation/linux-x64-on-auto-diagnostic.json`。完整三模式、OFF 客户端和旧内核运行仍待后续，不用此诊断代替最终验证。
- 11 月 9 日 07:53：独立 SDK 的 ON / OFF 两种模式 cefsimple、cefclient 编译链接及宿主三种运行检查全部通过。真实 Linux 4.9 / glibc 2.28 VM 发现客户端需要旧发行版不提供的 GLIBCXX_3.4.26。最初误用 Chromium sysroot 的 libstdc++，静态审计虽通过但该库已被上游移除 .text 等实现段，不能部署；宿主实测失败后已修正。`prepare_linux_cxx_runtime.py` 使用 Debian 签名 Release → SHA256 Packages.xz → libstdc++6 与精确匹配 gcc-10-base 包的摘要链，提取两架构完整运行库和版权通知，并检查 .text / CPU / glibc。SDK 只允许以备份方式替换此前哈希匹配且未发布的错误副本，不覆盖其他未知库；补充运行库的 CMake 复制清单和说明，不修改系统库。整包 ELF 审计再次通过，主库字节保持一致；新版客户端三模式和旧 VM 验证继续进行。
- 完整 Debian C++ 运行库加入后，独立 SDK 客户端的三种宿主模式已重新实际全部通过，回执与新 SDK 开发文件和 prepared 记录匹配；旧 VM 运行已重新启动。CMake POST_BUILD 未执行时，只迁移哈希匹配的此前错误运行库副本并复核字节，不覆盖未知文件。真正旧内核结果仍以对应 VM 回执为准。
- 旧 Linux VM 加入完整运行库后，实际 WebGL、H.264、AAC、WebRTC 和编码回环均通过；renderer 的 Seccomp=2，但 Linux 4.9 的 procfs 尚无 NoNewPrivs（4.10 才加入），探针原先以 -1 拒绝。现保留真实 -1 并明确不声称直接读取此标志；仅对 4.9 且该字段缺失时，另外要求实际 seccomp filter、四项零 capabilities、四个非 root UID、嵌套 PID namespace、无 tracer、无 --no-sandbox。现代内核继续要求直接读取到 NoNewPrivs=1。正常 / 缺失 / root / capabilities / tracer / 无 PID 隔离 / 禁沙箱等拒绝用例在 Windows 和 Ubuntu 均通过。三模式旧 VM 重新验证中。
- 11 月 9 日 08:10：Linux x64 在真正 Linux 4.9.228 / glibc 2.28 VM 中的 auto-sandbox、gpu-disabled-sandbox、auto-no-sandbox 三种运行全部通过，报告逐文件摘要和实际 CPU / 内核 / glibc / libcef 身份核验通过。SDK 已归档 4,546,522,175 字节，1,400 项 / 1,333 个文件，SHA256 `dfd5dbf32cb141dec03e1fa4cb8bf73cd506d17c70db47a536bd663d5d9b460c`；压缩帧、权限、完整文件清单和逐文件解压回读哈希全部通过。最终整包最高 GLIBC_2.25，保留完整 DWARF、独立客户端、完整 C++ 运行库及许可证。08:11 清理 x64 out / SDK 暂存 / 独立客户端大目录，快照缓存和小型已验证客户端保留；随后 Linux ARM64 正式服务已接续。归档摘要、全部核心回执绑定和目录确已删除又独立复核通过；见 `validation/sdk-linux-x64-{verified,cleanup}.json` 和 `validation/linux49-amd64-cef.json`。这不代表 UOS 实机、硬件 GPU 或其余三目标已完成。
- Linux ARM64 编译期间，新增真实 C++20 / filesystem / exceptions 小程序，实际确认需要 GLIBCXX_3.4.26，再携带经签名摘要链校验的完整 ARM64 C++ 运行库，在 ARM64 指令的真正 Linux 4.9 / glibc 2.28 VM 中以普通用户运行成功。此预检使用低优先级 / 单 CPU 配额，结束后已核验 VM 日志摘要和实际成功标记；见 `validation/cxx-runtime-probe-arm64.json`、`validation/linux49-arm64-cxx-runtime-preflight.json`。仅证明 ARM64 客户端工具链及完整运行库可执行，不代表 ARM64 CEF 编译或图形 / 沙箱运行已通过。

- 2026-11-09 15:01 CST: macOS ARM64 completed all 64,077 actual Ninja steps, full framework dSYM generation, and the target feature audit. Snapshot export then rejected an absent output from an unused host run_mksnapshot action. snapshot_tools.py now selects only snapshot actions reachable from the actual CEF build targets. Three selection/refusal tests passed on Windows and Ubuntu; the real ARM64 export passed with five files / 310,553,330 bytes under identity 5fcb8b2a35b4a1ffaec7fb5519a730ac269f1eb2315ca78634b23df77862e050. The continuation service was restarted to reuse existing Ninja outputs and proceed through the normal compile receipt and SDK validation gates; no SDK completion claim yet.

- 2026-11-09: User-requested compact Release SDKs are prepared and locally verified for Windows x64/x86/ARM64, Linux x64/ARM64 and macOS ARM64 under build/strip-lib. Original symbol-rich archives are retained. Required runtimes/resources are merged into Release; public headers, wrapper, CMake, licenses and sandbox ON/OFF source entries remain. Windows runtime/import-library bytes are unchanged, with external PDBs omitted. Linux LLVM strip preserves every ELF program header and all SHF_ALLOC content, including dynamic symbols/version data; libcef is 296,119,448 bytes (x64) and 277,548,256 bytes (ARM64). Both real compact demo entries compile on Windows x64/x86 and Linux x64/ARM64; Windows ARM64 source is included but this local host lacks its C++ toolchain, so its compact demo is not claimed compiled. Linux x64 stripped-engine runtime passed ON auto, ON GPU-disabled and OFF auto, including WebGL/H.264/AAC/WebRTC/encoding checks. Mac ARM64 compact demos and Helpers cross-compile/link for both sandbox modes; target Mac execution/signing is unverified. Archive readback and local directory hashes passed. Six current local SDK records are in validation/compact-local-sdk-index.json.
- macOS ARM64 full SDK is now actually archived, verified and cleaned; full archive SHA256 9edc0b4fc6d518070a23943f9473eedead2a2a6908aa569178eeba7d6b7fd4ec, 2,540,253,755 bytes, also downloaded locally with independent SHA readback. macOS x64 continuation is live. compact_mac_runner waits for each full verified archive and cleanup, then prepares and validates its compact SDK. Its persistent systemd follower was installed without restarting the running engine build. All packaging/validation changes are included in the one-click bundle.
