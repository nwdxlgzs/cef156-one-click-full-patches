#!/usr/bin/env python3
"""Inspect the remaining three generated GN snapshot graphs during x64 build.

The active Linux x64 snapshot plan is preserved. This discovers dependencies
and records actual inputs/commands; it does not compile or restore tools.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from archive_posix import digest_file
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    current_path = prep.root / 'state/snapshot-plan-linux-x64.json'
    original_hash = digest_file(current_path) if current_path.exists() else None
    plans = {}
    for target in ('linux-arm64', 'mac-arm64', 'mac-x64'):
        config_path = prep.root / 'state' / ('gn-' + target + '.json')
        config = json.loads(config_path.read_text('utf-8'))
        output = Path(config['output']).resolve()
        if (config['target'] != target or not config.get('gn_generated')
                or prep.src / 'out' not in output.parents
                or digest_file(output / 'args.gn') != config['args_gn_sha256']):
            raise RuntimeError('Generate the real locked configuration first: ' + target)
        prep.run([sys.executable, HERE / 'snapshot_tools.py', '--root', prep.root,
                  '--target', target, '--stage', 'plan', '--output', output,
                  '--gn', prep.depot / 'gn'])
        path = prep.root / 'state' / ('snapshot-plan-' + target + '.json')
        plan = json.loads(path.read_text('utf-8'))
        plans[target] = {'path': str(path), 'sha256': digest_file(path),
                         'identity_sha256': plan['identity_sha256'],
                         'tools': list(plan['identity']['snapshot_tools']),
                         'actions': list(plan['identity']['snapshot_actions'])}
    if (digest_file(current_path) if current_path.exists() else None) != original_hash:
        raise RuntimeError('The active Linux x64 plan changed during remaining graph preparation')
    write_json(prep.root / 'state/remaining-snapshot-plans-prepared.json', {
        'plans': plans, 'active_linux_x64_plan_preserved': True,
        'active_linux_x64_plan_sha256': original_hash, 'passed': True,
        'scope': 'Actual remaining three GN snapshot graphs, input hashes and generation commands. No tools built/exported, cross-target reuse, Ninja timestamp modification or SDK completion claim.'})
    print('REMAINING_THREE_SNAPSHOT_GRAPHS_PREPARED', flush=True)


if __name__ == '__main__':
    main()
