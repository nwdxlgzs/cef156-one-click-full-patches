#!/usr/bin/env python3
"""Seed locked dependency Git objects from the same verified source archive.

Download dependency commit/tree metadata first. Import exact matching blobs
from one streaming archive pass, then fetch omitted blobs and run git fsck.
No dependency-sync or build-completion marker is fabricated.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile

from complete_source_objects import required_blobs, missing_blobs
from prefetch_source_archive import MD5, SIZE
from prepare_posix import CHROMIUM, CHROMIUM_REV, ROOT_MARKER, write_json

HERE = Path(__file__).resolve().parent
PREFIX = 'chromium-' + CHROMIUM + '/'


class Dependencies:
    def __init__(self, root):
        self.root = Path(root).resolve()
        if (self.root / '.mycef-build-root').read_text().strip() != ROOT_MARKER:
            raise RuntimeError('Unrecognized dedicated POSIX build root')
        if (self.root / 'state/prepared-posix.json').exists():
            raise RuntimeError('Do not seed/sync dependencies over a patched build tree')
        self.src = self.root / 'chromium/src'
        self.env = {**os.environ, 'GIT_CONFIG_GLOBAL': str(self.root / 'gitconfig'),
                    'GIT_TERMINAL_PROMPT': '0', 'GIT_NO_LAZY_FETCH': '1'}
        self.pins = json.loads((HERE / 'dependency-pins.json').read_text('utf-8'))

    def run(self, command, **kwargs):
        return subprocess.run(list(map(str, command)), env=self.env, check=True, **kwargs)

    def metadata(self, jobs):
        def one(item):
            path, pin = item
            relative = path.removeprefix('src/')
            url, revision = pin.rsplit('@', 1)
            expected = self.run(['git', '-C', self.src, 'ls-tree', CHROMIUM_REV, '--', relative],
                                capture_output=True, text=True).stdout.strip()
            if not expected.startswith('160000 commit ' + revision + '\t'):
                raise RuntimeError('Dependency lock differs from actual Chromium gitlink: ' + path)
            folder = self.src / relative
            if self.src not in folder.resolve().parents or folder.is_symlink():
                raise RuntimeError('Unsafe dependency folder: ' + path)
            folder.mkdir(parents=True, exist_ok=True)
            log_path = self.root / 'logs' / ('dependency-metadata-' + relative.replace('/', '_') + '.log')
            with log_path.open('ab') as log:
                def git(*args, capture=False):
                    return self.run(['git', '-C', folder, *args],
                                    stdout=subprocess.PIPE if capture else log, stderr=log)
                if not (folder / '.git').exists():
                    if any(folder.iterdir()):
                        raise RuntimeError('Unrecognized nonempty dependency directory: ' + path)
                    git('init')
                    git('remote', 'add', 'origin', url)
                actual = git('config', '--get', 'remote.origin.url', capture=True).stdout.decode().strip()
                if actual != url:
                    raise RuntimeError('Unexpected dependency origin: ' + path)
                git('config', 'remote.origin.promisor', 'true')
                git('config', 'remote.origin.partialclonefilter', 'blob:none')
                git('-c', 'http.lowSpeedLimit=1024', '-c', 'http.lowSpeedTime=180', 'fetch',
                    '--depth=1', '--filter=blob:none', '--no-tags', 'origin', revision)
                actual = git('rev-parse', revision + '^{commit}', capture=True).stdout.decode().strip()
                if actual != revision:
                    raise RuntimeError('Incorrect dependency metadata: ' + path)
            print('DEPENDENCY_METADATA_VERIFIED', path, revision, flush=True)
            return {'path': path, 'url': url, 'revision': revision}
        with ThreadPoolExecutor(jobs) as pool:
            futures = [pool.submit(one, item) for item in self.pins.items()]
            outcomes, errors = [], []
            for future in futures:
                try:
                    outcomes.append(future.result())
                except Exception as error:
                    errors.append(str(error))
            write_json(self.root / 'state/dependency-metadata.json', {'repositories': outcomes, 'errors': errors})
            if errors:
                raise RuntimeError('Dependency metadata failures: ' + '; '.join(errors))

    def seed(self):
        archive = self.root / 'downloads/source-archive' / ('chromium-' + CHROMIUM + '.tar.xz')
        if archive.stat().st_size != SIZE:
            raise RuntimeError('Incorrect official archive size')
        digest = hashlib.md5()
        with archive.open('rb') as stream:
            for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                digest.update(block)
        if digest.hexdigest() != MD5:
            raise RuntimeError('Incorrect official archive MD5')
        repositories = {}
        processes, logs = [], []
        try:
            for path, pin in self.pins.items():
                relative = path.removeprefix('src/')
                revision = pin.rsplit('@', 1)[1]
                folder = self.src / relative
                required = required_blobs(folder, self.env, revision)
                by_path = {name: oid for oid, names in required.items() for name in names}
                log = (self.root / 'logs' / ('dependency-seed-' + relative.replace('/', '_') + '.log')).open('ab')
                logs.append(log)
                process = subprocess.Popen(['git', '-C', str(folder), 'fast-import', '--quiet'],
                                           stdin=subprocess.PIPE, stdout=log, stderr=log, env=self.env)
                processes.append(process)
                process.stdin.write(b'feature done\n')
                repositories[relative] = {'process': process, 'required': required, 'paths': by_path,
                                          'seen': set(), 'mismatches': [], 'revision': revision}
            prefixes = sorted(repositories, key=len, reverse=True)
            matched = 0
            with tarfile.open(archive, 'r|xz') as source:
                for item in source:
                    if not item.name.startswith(PREFIX):
                        continue
                    name = item.name[len(PREFIX):]
                    prefix = next((p for p in prefixes if name.startswith(p + '/')), None)
                    if prefix is None:
                        continue
                    repository = repositories[prefix]
                    path = name[len(prefix) + 1:]
                    oid = repository['paths'].get(path)
                    if not oid or oid in repository['seen']:
                        continue
                    if item.issym():
                        payload = item.linkname.encode('utf-8')
                    elif item.isfile():
                        payload = source.extractfile(item).read()
                    else:
                        continue
                    actual = hashlib.sha1(f'blob {len(payload)}\0'.encode('ascii') + payload).hexdigest()
                    if actual != oid:
                        repository['mismatches'].append(path)
                        continue
                    stream = repository['process'].stdin
                    stream.write(f'blob\ndata {len(payload)}\n'.encode('ascii'))
                    stream.write(payload)
                    stream.write(b'\n')
                    repository['seen'].add(oid)
                    matched += 1
                    if matched % 10000 == 0:
                        print('DEPENDENCY_ARCHIVE_MATCHED', matched, flush=True)
            for process in processes:
                process.stdin.write(b'done\n')
                process.stdin.close()
            for process in processes:
                if process.wait() != 0:
                    raise RuntimeError('Dependency fast-import failed; inspect dependency-seed logs')
            outcomes = []
            for prefix, info in repositories.items():
                missing = missing_blobs(self.src / prefix, info['required'], self.env)
                outcomes.append({'path': 'src/' + prefix, 'revision': info['revision'],
                                 'archive_matched_blobs': len(info['seen']),
                                 'required_blobs': len(info['required']), 'remaining_blobs': len(missing),
                                 'archive_mismatches': info['mismatches']})
            write_json(self.root / 'state/dependency-archive-seed.json', {'archive_md5': MD5, 'repositories': outcomes})
        finally:
            for process in processes:
                if process.poll() is None:
                    if not process.stdin.closed:
                        process.stdin.close()
                    process.wait()
            for log in logs:
                log.close()

    def complete(self, jobs):
        def one(item):
            path, pin = item
            revision = pin.rsplit('@', 1)[1]
            relative = path.removeprefix('src/')
            folder = self.src / relative
            record = self.root / 'state' / ('dependency-objects-' + relative.replace('/', '_') + '.json')
            self.run([sys.executable, HERE / 'complete_source_objects.py', '--repository', folder,
                      '--record', record, '--revision', revision, '--jobs', '2'])
            self.run(['git', '-C', folder, 'checkout', '--detach', revision])
            return json.loads(record.read_text())
        with ThreadPoolExecutor(jobs) as pool:
            futures = [pool.submit(one, item) for item in self.pins.items()]
            outcomes, errors = [], []
            for future in futures:
                try:
                    outcomes.append(future.result())
                except Exception as error:
                    errors.append(str(error))
            write_json(self.root / 'state/dependency-objects-complete.json', {'repositories': outcomes, 'errors': errors})
            if errors:
                raise RuntimeError('Dependency object completion failures: ' + '; '.join(errors))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', choices=('metadata', 'seed', 'complete'), required=True)
    parser.add_argument('--jobs', type=int, choices=range(1, 5), default=2)
    args = parser.parse_args()
    dependencies = Dependencies(args.root)
    if args.stage == 'seed':
        dependencies.seed()
    else:
        getattr(dependencies, args.stage)(args.jobs)


if __name__ == '__main__':
    main()
