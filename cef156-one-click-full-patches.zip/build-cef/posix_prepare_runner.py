#!/usr/bin/env python3
"""Continue source/dependency preparation after the independent downloads.

This service survives the controlling SSH session. Its terminal checkpoint
means a real gclient sync completed, never that a CEF SDK was built.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import json
from pathlib import Path
import sys
import time
import traceback

from prepare_posix import Preparation, write_json
from seed_posix_dependencies import Dependencies


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--wait-hours', type=float, default=48)
    parser.add_argument('--through-linux-x64-build', action='store_true')
    args = parser.parse_args()
    prep = Preparation(args.root)
    status = prep.root / 'state/posix-preparation-status.json'
    def record(phase, **extra):
        value = {'phase': phase, 'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                 'sdk_build_complete': False, **extra}
        write_json(status, value)
        print('POSIX_PREPARATION ' + json.dumps(value), flush=True)
    try:
        # A reboot must not rebuild x64 after its verified archive was already
        # published and its output reclaimed, while the continuation starts ARM.
        published = prep.root / 'state/sdk-linux-x64-verified.json'
        if published.is_file():
            from archive_posix import digest_file
            from prepare_posix import CHROMIUM_REV, CEF_REV
            prior = json.loads(published.read_text('utf-8'))
            archive = Path(prior['archive']).resolve()
            if (prior.get('passed') is not True or prior.get('target') != 'linux-x64'
                    or prior.get('chromium_revision') != CHROMIUM_REV
                    or prior.get('cef_revision') != CEF_REV
                    or prep.root / 'packages' not in archive.parents
                    or digest_file(archive) != prior['archive_sha256']):
                raise RuntimeError('Previously published Linux x64 archive changed; preserve the current work')
            record('linux_x64_archive_already_verified', retained_archive=str(archive), sdk_build_complete=True)
            return
        synced = prep.root / 'state/posix-dependencies-synced.json'
        already_synced = synced.is_file()
        if already_synced:
            prior = json.loads(synced.read_text('utf-8'))
            from prepare_posix import CHROMIUM_REV
            if prior.get('chromium_revision') != CHROMIUM_REV:
                raise RuntimeError('Existing dependency sync belongs to a different source revision')
            record('source_sync_complete', retained_existing_checkout=True)
            if not args.through_linux_x64_build:
                return
        prerequisites = [
            prep.root / 'downloads/source-archive/chromium-156.0.8071.0.tar.xz.verified.json',
            prep.root / 'state/posix-tools-checkout.json',
            prep.root / 'state/depot-bootstrap.json',
            prep.root / 'state/dependency-metadata.json',
        ]
        deadline = time.monotonic() + args.wait_hours * 3600
        while not already_synced:
            missing = [str(p) for p in prerequisites if not p.is_file()]
            if not missing:
                break
            record('waiting_for_downloads', missing=missing)
            if time.monotonic() >= deadline:
                raise TimeoutError('Preparation prerequisites did not finish; existing downloads and logs retained')
            time.sleep(30)
        if not already_synced:
            metadata = json.loads((prep.root / 'state/dependency-metadata.json').read_text())
            if metadata.get('errors') or len(metadata.get('repositories', [])) != 9:
                raise RuntimeError('Dependency metadata checkpoint is incomplete')
            # Refresh the actual loopback service address after a possible restart.
            prep = Preparation(args.root)
            dependencies = Dependencies(args.root)
            record('importing_and_completing_source_objects')
            def dependency_objects():
                existing = prep.root / 'state/dependency-objects-complete.json'
                if existing.is_file():
                    completed = json.loads(existing.read_text('utf-8'))
                    if completed.get('errors') or len(completed.get('repositories', [])) != len(dependencies.pins):
                        raise RuntimeError('The existing dependency object audit is incomplete')
                    for path, pin in dependencies.pins.items():
                        actual = dependencies.run(['git', '-C', prep.root / 'chromium' / path, 'rev-parse', 'HEAD'],
                                                  capture_output=True, text=True).stdout.strip()
                        if actual != pin.rsplit('@', 1)[1]:
                            raise RuntimeError('An existing completed dependency revision changed: ' + path)
                    print('Existing genuinely verified dependency checkouts retained.', flush=True)
                    return
                dependencies.seed()
                dependencies.complete(2)
            with ThreadPoolExecutor(2) as pool:
                stages = [pool.submit(prep.source), pool.submit(dependency_objects)]
                errors = []
                for future in stages:
                    try:
                        future.result()
                    except Exception as error:
                        errors.append(repr(error))
                if errors:
                    raise RuntimeError('Object preparation failed: ' + '; '.join(errors))
            record('syncing_all_dependencies')
            prep.sync()
        record('source_sync_complete', next_required=['chromium_hooks', 'posix_patches', 'gn_and_snapshot_preflight'])
        if args.through_linux_x64_build:
            prep = Preparation(args.root)
            here = Path(__file__).resolve().parent
            for phase, script in [('chromium_hooks', 'prepare_posix_hooks.py'),
                                  ('configuring_linux_x64', 'configure_posix.py'),
                                  ('compiling_linux_x64', 'compile_posix.py')]:
                record(phase)
                command = [sys.executable, here / script, '--root', prep.root]
                if script != 'prepare_posix_hooks.py':
                    command.extend(['--target', 'linux-x64'])
                prep.run(command)
            record('preparing_linux_x64_sdk')
            prep.run([sys.executable, here / 'package_linux.py', '--root', prep.root, '--target', 'linux-x64'])
            record('validating_linux_x64_independent_clients_and_native_runtime')
            prep.run([sys.executable, here / 'validate_linux_clients.py', '--root', prep.root,
                      '--target', 'linux-x64', '--media', prep.src / 'media/test/data/bear-1280x720.mp4', '--use-sysroot'])
            record('linux_x64_sdk_prepared_and_native_clients_verified', next_required=[
                'linux49_glibc228_runtime', 'verified_archive', 'cleanup_before_linux_arm64'])
    except Exception as error:
        record('failed', error=repr(error))
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
