#!/usr/bin/env python3
"""Prepare and exercise CMake C++20/GTK client toolchains using pinned sysroots."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import shlex
import subprocess

from archive_posix import digest_file
from audit_elf import inspect, MACHINES, version_key
from prepare_posix import Preparation, write_json


def prepare(prep, cpu, smoke=False):
    arch = 'amd64' if cpu == 'x64' else 'arm64'
    triple = 'x86_64-linux-gnu' if cpu == 'x64' else 'aarch64-linux-gnu'
    installed = json.loads((prep.root / 'state/linux-sysroots.json').read_text('utf-8'))
    if not installed['installed']:
        raise RuntimeError('Install the exact upstream sysroots before client toolchain preparation')
    sysroot = Path(installed['sysroots'][arch]['installed']).resolve()
    if sysroot.parent != prep.src / 'build/linux' or (sysroot / '.stamp').read_text() != installed['sysroots'][arch]['canonical_url']:
        raise RuntimeError('The installed sysroot does not match its pinned provenance')
    clang = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
    if digest_file(clang) != json.loads((prep.root / 'state/clang-prefetched.json').read_text())['compiler_sha256']:
        raise RuntimeError('The pinned client compiler changed')
    directory = prep.root / 'cache/client-toolchains' / ('linux-' + cpu)
    directory.mkdir(parents=True, exist_ok=True)
    wrapper = directory / 'pkg-config'
    libraries = ':'.join(str(sysroot / path) for path in [
        'usr/lib/pkgconfig', 'usr/share/pkgconfig', 'usr/lib/' + triple + '/pkgconfig'])
    wrapper.write_text('#!/bin/sh\nexec env ' + shlex.quote('PKG_CONFIG_SYSROOT_DIR=' + str(sysroot)) + ' '
                       + shlex.quote('PKG_CONFIG_LIBDIR=' + libraries) + ' PKG_CONFIG_PATH= /usr/bin/pkg-config "$@"\n')
    wrapper.chmod(0o755)
    def quoted(value):
        return '"' + str(value).replace('\\', '/').replace('"', '\\"') + '"'
    toolchain = directory / 'toolchain.cmake'
    settings = {
        'CMAKE_SYSTEM_NAME': 'Linux', 'CMAKE_SYSTEM_PROCESSOR': 'x86_64' if cpu == 'x64' else 'aarch64',
        'CMAKE_C_COMPILER': clang, 'CMAKE_CXX_COMPILER': clang.with_name('clang++'),
        'CMAKE_C_COMPILER_TARGET': triple, 'CMAKE_CXX_COMPILER_TARGET': triple,
        'CMAKE_SYSROOT': sysroot, 'CMAKE_FIND_ROOT_PATH': sysroot,
        'CMAKE_C_FLAGS_INIT': '--gcc-install-dir=' + str(sysroot / 'usr/lib/gcc' / triple / '10'),
        'CMAKE_CXX_FLAGS_INIT': '--gcc-install-dir=' + str(sysroot / 'usr/lib/gcc' / triple / '10'),
        'CMAKE_EXE_LINKER_FLAGS_INIT': '-fuse-ld=lld', 'CMAKE_SHARED_LINKER_FLAGS_INIT': '-fuse-ld=lld',
        'CMAKE_FIND_ROOT_PATH_MODE_PROGRAM': 'NEVER', 'CMAKE_FIND_ROOT_PATH_MODE_LIBRARY': 'ONLY',
        'CMAKE_FIND_ROOT_PATH_MODE_INCLUDE': 'ONLY', 'CMAKE_FIND_ROOT_PATH_MODE_PACKAGE': 'ONLY',
    }
    text = '\n'.join('set(' + key + ' ' + quoted(value) + ')' for key, value in settings.items())
    text += '\nset(PROJECT_ARCH ' + quoted('x86_64' if cpu == 'x64' else 'arm64') + ' CACHE STRING "CEF target architecture" FORCE)\n'
    text += 'set(ENV{PKG_CONFIG} ' + quoted(wrapper) + ')\n'
    text += 'set(ENV{PKG_CONFIG_SYSROOT_DIR} ' + quoted(sysroot) + ')\n'
    text += 'set(ENV{PKG_CONFIG_LIBDIR} ' + quoted(libraries) + ')\nset(ENV{PKG_CONFIG_PATH} "")\n'
    toolchain.write_text(text)
    receipt = {'target_cpu': cpu, 'toolchain': str(toolchain), 'toolchain_sha256': digest_file(toolchain),
               'pkg_config_wrapper': str(wrapper), 'pkg_config_wrapper_sha256': digest_file(wrapper),
               'clang_sha256': digest_file(clang), 'sysroot': str(sysroot),
               'sysroot_provenance': installed['sysroots'][arch], 'smoke_build_passed': False}
    if smoke:
        source = directory / 'smoke-source'
        source.mkdir(exist_ok=True)
        (source / 'CMakeLists.txt').write_text('cmake_minimum_required(VERSION 3.20)\nproject(MyCefClientToolchain LANGUAGES C CXX)\n'
            'set(CMAKE_CXX_STANDARD 20)\nfind_package(PkgConfig REQUIRED)\n'
            'pkg_check_modules(GTK REQUIRED IMPORTED_TARGET gtk+-3.0)\n'
            'add_executable(client_toolchain_probe probe.cpp)\ntarget_link_libraries(client_toolchain_probe PRIVATE PkgConfig::GTK)\n')
        (source / 'probe.cpp').write_text('#include <gtk/gtk.h>\n#include <vector>\n#include <span>\n#include <string>\n#include <cstdio>\n'
            'int main(int argc,char**){ std::vector<int> values(200,argc);std::span<const int> view(values);'
            'std::string s(view.size(),\'x\');std::printf("MyCEF GTK %u.%u C++20 %zu\\n",'
            'gtk_get_major_version(),gtk_get_minor_version(),s.size());return 0;}\n')
        output = directory / 'smoke-build'
        prep.run(['cmake', '-S', source, '-B', output, '-G', 'Ninja', '-DCMAKE_BUILD_TYPE=Release',
                  '-DCMAKE_TOOLCHAIN_FILE=' + str(toolchain)])
        prep.run(['cmake', '--build', output, '-j', '4'])
        binary = output / 'client_toolchain_probe'
        elf = inspect(binary)
        if elf['machine'] != MACHINES[cpu] or (elf['glibc_max_required'] and version_key(elf['glibc_max_required']) > version_key('2.28')):
            raise RuntimeError('The actual client toolchain smoke binary has incompatible ELF requirements')
        receipt.update(smoke_build_passed=True, binary=str(binary), binary_sha256=digest_file(binary), elf=elf,
                       observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                       scope='Actual CMake C++20/GTK compile/link using pinned target sysroot; not CEF client compilation or target runtime.')
    write_json(prep.root / 'state' / ('client-toolchain-linux-' + cpu + '.json'), receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--cpu', choices=['x64', 'arm64'], required=True)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    print(json.dumps(prepare(Preparation(args.root), args.cpu, args.smoke), indent=2), flush=True)


if __name__ == '__main__':
    main()
