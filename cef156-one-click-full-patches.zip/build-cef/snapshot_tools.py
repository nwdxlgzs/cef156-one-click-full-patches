#!/usr/bin/env python3
"""Discover and preserve the snapshot tools actually used by a GN target.

The export is an evidence-backed cache, not an instruction to bypass Ninja.
Restore/reuse must separately integrate valid prebuilt dependencies. This
tool never changes timestamps or pretends that deleted objects were built.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess

from prepare_posix import CHROMIUM_REV, CEF_REV, ROOT_MARKER, write_json


def sha256(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(data)
    return result.hexdigest()


def source_path(src, out, value):
    if value.startswith('//'):
        return src / value[2:]
    path = Path(value)
    return path if path.is_absolute() else out / path


def required_snapshot_labels(v8_labels, context_labels, dependencies):
    # Host toolchains also define unused run_mksnapshot actions. Their outputs
    # are not produced by the CEF build and describe the host OS/CPU instead.
    # Retain only actions reachable from the actual requested CEF targets.
    return {label for label in [*v8_labels, *context_labels]
            if label in dependencies and (
                label.split('(', 1)[0].startswith('//v8:run_mksnapshot')
                or label.split('(', 1)[0] ==
                '//tools/v8_context_snapshot:generate_v8_context_snapshot')}


def plan(root, output, target, gn):
    root, output = Path(root).resolve(), Path(output).resolve()
    if (root / '.mycef-build-root').read_text().strip() != ROOT_MARKER:
        raise RuntimeError('Unrecognized dedicated build root')
    src = root / 'chromium/src'
    if src / 'out' not in output.parents or output.is_symlink():
        raise RuntimeError('Expected an actual generated descendant of src/out')
    prepared = root / 'state/prepared-posix.json'
    if not prepared.is_file():
        raise RuntimeError('A validated prepared POSIX source checkpoint is required')
    def run(*arguments):
        return subprocess.check_output([gn, *map(str, arguments)], cwd=src, text=True)
    effective = json.loads(run('args', output, '--list', '--json'))
    v8_labels = run('ls', output, '//v8:*', '--all-toolchains').splitlines()
    context_labels = run('ls', output, '//tools/v8_context_snapshot:*', '--all-toolchains').splitlines()
    build_targets = ['//cef:cefsimple', '//cef:cefclient']
    build_targets += (['//sandbox/linux:chrome_sandbox', '//gpu:gpu_unittests']
                      if target.startswith('linux-') else ['//cef:cef_sandbox'])
    build_dependencies = set()
    for label in build_targets:
        build_dependencies.update(run('desc', output, label, 'deps', '--all').splitlines())
    labels = required_snapshot_labels(v8_labels, context_labels, build_dependencies)
    if not labels:
        raise RuntimeError('No V8 snapshot actions found in the generated build graph')
    actions, all_dependencies = {}, set()
    for label in sorted(labels):
        actions.update(json.loads(run('desc', output, label, '--format=json')))
        all_dependencies.update(run('desc', output, label, 'deps', '--all').splitlines())
    tools = {}
    # An exact GN label selects only the default toolchain even with
    # --all-toolchains. Enumerate wildcard results before selecting the actual
    # executable, including x64 host tools that generate ARM64 snapshots.
    for candidates, wanted in ((v8_labels, '//v8:mksnapshot'),
                               (context_labels, '//tools/v8_context_snapshot:v8_context_snapshot_generator')):
        for label in candidates:
            if label.split('(', 1)[0] == wanted and label in all_dependencies:
                tools.update(json.loads(run('desc', output, label, '--format=json')))
    if not any(label.startswith('//v8:mksnapshot(') or label == '//v8:mksnapshot' for label in tools):
        raise RuntimeError('Could not identify the actual mksnapshot executable dependencies')
    commands = {}
    for label, item in actions.items():
        action_command = None
        for value in item.get('outputs', []):
            path = source_path(src, output, value)
            if output not in path.resolve().parents:
                raise RuntimeError('Snapshot action output escaped its build directory')
            relative = path.relative_to(output).as_posix()
            # Only this action's command is needed here. Including every
            # dependency emits megabytes and may include non-UTF8 source paths.
            # A single GN action produces all its outputs with the same
            # command. Avoid reparsing the entire Ninja graph for each sibling
            # output; action_foreach still needs an individual lookup.
            if action_command is None or item.get('type') != 'action':
                action_command = subprocess.check_output(
                    ['ninja', '-C', str(output), '-t', 'commands', '-s', relative]
                ).decode('utf-8', errors='surrogateescape')
            commands[relative] = action_command
    inputs = {}
    for label, item in {**actions, **tools}.items():
        for value in [*item.get('sources', []), *item.get('inputs', [])]:
            path = source_path(src, output, value)
            if path.is_file() and output not in path.resolve().parents:
                inputs[value] = sha256(path)
    def revision(folder):
        return subprocess.check_output(['git', '-C', str(folder), 'rev-parse', 'HEAD'], text=True).strip()
    source_state = json.loads(prepared.read_text('utf-8'))
    if revision(src) != CHROMIUM_REV or revision(src / 'cef') != CEF_REV:
        raise RuntimeError('Snapshot source checkout has changed')
    tools_identity = {}
    for relative in ['third_party/llvm-build/Release+Asserts/bin/clang',
                     'third_party/llvm-build/Release+Asserts/bin/ld.lld',
                     'third_party/rust-toolchain/bin/rustc']:
        path = src / relative
        if path.is_file():
            tools_identity[relative] = sha256(path)
    platform_inputs = {}
    for relative in ['build/linux/sysroot_scripts/sysroots.json',
                     'build/linux/debian_bullseye_amd64-sysroot/.stamp',
                     'build/linux/debian_bullseye_arm64-sysroot/.stamp']:
        path = src / relative
        if path.is_file():
            platform_inputs[relative] = sha256(path)
    for filename in ['apple-sdk-package-verified.json', 'apple-sdk-universal-package-verified.json',
                     'apple-sdk-extracted.json', 'mac-sdk-prepared.json', 'linux-sysroots.json']:
        path = root / 'state' / filename
        if path.is_file():
            platform_inputs['state/' + filename] = json.loads(path.read_text('utf-8'))
    if target.startswith('linux-') and 'build/linux/sysroot_scripts/sysroots.json' not in platform_inputs:
        raise RuntimeError('Pinned Linux sysroot provenance is missing')
    source_diffs = {}
    for name, folder in [('chromium', src), ('v8', src / 'v8'), ('cef', src / 'cef')]:
        diff = subprocess.check_output(['git', '-C', str(folder), 'diff', '--binary', 'HEAD', '--'])
        source_diffs[name] = hashlib.sha256(diff).hexdigest()
    identity = {
        'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV, 'v8_revision': revision(src / 'v8'),
        'posix_patch_bundle_sha256': source_state['posix_patch_bundle_sha256'],
        'host_os': platform.system(), 'host_cpu': platform.machine(), 'target': target,
        'effective_gn_arguments': effective, 'args_gn_sha256': sha256(output / 'args.gn'),
        'compiler_executables': tools_identity, 'source_action_inputs': inputs,
        'sdk_and_sysroot_provenance': platform_inputs, 'tracked_source_diff_sha256': source_diffs,
        'snapshot_actions': actions, 'snapshot_tools': tools, 'generation_commands': commands,
    }
    key = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    record = {'format': 1, 'identity_sha256': key, 'identity': identity, 'output': str(output),
              'root': str(root), 'generated_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'reuse_integrated_with_ninja': False}
    write_json(root / 'state' / ('snapshot-plan-' + target + '.json'), record)
    print('SNAPSHOT_PLAN', target, len(tools), 'tools', key, flush=True)
    return record


def export(root, target):
    root = Path(root).resolve()
    if (root / '.mycef-build-root').read_text().strip() != ROOT_MARKER:
        raise RuntimeError('Unrecognized dedicated build root')
    record = json.loads((root / 'state' / ('snapshot-plan-' + target + '.json')).read_text('utf-8'))
    src, output = root / 'chromium/src', Path(record['output'])
    if src / 'out' not in output.resolve().parents:
        raise RuntimeError('Snapshot output escaped the dedicated build tree')
    if sha256(output / 'args.gn') != record['identity']['args_gn_sha256']:
        raise RuntimeError('GN arguments changed since snapshot discovery')
    destination = root / 'cache/snapshot-tools' / target / record['identity_sha256']
    destination.mkdir(parents=True, exist_ok=True)
    copied = {}
    def preserve(path):
        path = path.resolve()
        if output not in path.parents or not path.is_file():
            raise RuntimeError('Required snapshot runtime/data file is absent or outside out: ' + str(path))
        relative = path.relative_to(output).as_posix()
        digest = sha256(path)
        if relative in copied:
            return
        target_path = destination / 'files' / relative
        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target_path)
        if sha256(target_path) != digest:
            raise RuntimeError('Snapshot cache readback mismatch: ' + relative)
        copied[relative] = {'sha256': digest, 'bytes': path.stat().st_size,
                            'mode': path.stat().st_mode & 0o777}
    runtime_dependencies = {}
    for label, info in record['identity']['snapshot_tools'].items():
        for value in info.get('outputs', []):
            preserve(source_path(src, output, value))
        gn = shutil.which('gn')
        if not gn:
            raise RuntimeError('Use the same pinned depot_tools environment to export runtime dependencies')
        runtime = subprocess.check_output([gn, 'desc', str(output), label, 'runtime_deps'], cwd=src, text=True).splitlines()
        runtime_dependencies[label] = runtime
        for value in runtime:
            preserve(source_path(src, output, value))
    for info in record['identity']['snapshot_actions'].values():
        for value in [*info.get('outputs', []), *info.get('sources', []), *info.get('inputs', [])]:
            path = source_path(src, output, value)
            if output in path.resolve().parents:
                preserve(path)
    # Keep actual commands and all effective GN args so a later restore can
    # judge source/config/input equality and implement proper prebuilt edges.
    record.update(files=copied, runtime_dependencies=runtime_dependencies,
                  exported_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                  total_bytes=sum(item['bytes'] for item in copied.values()),
                  scope='Verified export of built tools and snapshot data. Cross-target equality, running the tools, and valid Ninja prebuilt integration are separate requirements; this tool does not restore or skip builds.')
    write_json(destination / 'manifest.json', record)
    print('SNAPSHOT_TOOLS_EXPORTED', target, len(copied), record['total_bytes'], destination, flush=True)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=('linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64'))
    parser.add_argument('--stage', choices=('plan', 'export'), required=True)
    parser.add_argument('--output')
    parser.add_argument('--gn', default='gn')
    args = parser.parse_args()
    if args.stage == 'plan':
        if not args.output:
            parser.error('--output is required to inspect the real GN graph')
        plan(args.root, args.output, args.target, args.gn)
    else:
        export(args.root, args.target)


if __name__ == '__main__':
    main()
