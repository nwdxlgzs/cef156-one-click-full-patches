#!/usr/bin/env python3
"""Validate real Apple SDK/debug-tool inputs for later macOS GN generation.

Does not run GN, build CEF, or issue a mac-sdk-prepared success receipt.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import tarfile

from archive_posix import digest_file
from mac_cross_sdk_info import load
from mac_sdk_metadata import collect
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent


def prepare(prep):
    sdk = collect(prep)
    menu_receipt = prep.root / 'state/mac-menu-source-smoke.json'
    if not menu_receipt.is_file():
        raise RuntimeError('Run probe_macos_menus.py with the real compiler/SDK before macOS GN inputs')
    menus = json.loads(menu_receipt.read_text('utf-8'))
    if (menus.get('passed') is not True or len(menus.get('results', [])) != 16
            or not all(item.get('passed') is True for item in menus['results'])
            or menus['generator_sha256'] != digest_file(HERE / 'mac_menu_source.py')):
        raise RuntimeError('The actual original-menu compiler preflight is incomplete or changed')
    for name, info in menus['inputs'].items():
        path = prep.src / 'cef/tests' / name / 'mac/English.lproj/MainMenu.xib'
        if digest_file(path) != info['input_sha256']:
            raise RuntimeError('The original menu XIB changed: ' + name)
    tree_path = Path(sdk['sdk_tree_manifest'])
    tree = json.loads(tree_path.read_text('utf-8'))
    root = Path(sdk['sdk_path'])
    # Recheck the original observed tree, including links, before publishing
    # the smaller GN metadata file. GN then checks its explicit tool inputs.
    for relative, entry in tree['files'].items():
        path = root / relative
        if entry['type'] == 'symlink':
            if not path.is_symlink() or os.readlink(path) != entry['target']:
                raise RuntimeError('Original SDK link changed: ' + relative)
        elif not path.is_file() or path.stat().st_size != entry['bytes'] or digest_file(path) != entry['sha256']:
            raise RuntimeError('Original SDK file changed: ' + relative)
    auxiliary_path = prep.root / 'state/mac-aux-tools-verified.json'
    auxiliary = json.loads(auxiliary_path.read_text('utf-8'))
    if auxiliary.get('auxiliary_execution_verified') is not True:
        raise RuntimeError('Actual auxiliary tool execution preflight is missing')
    if digest_file(HERE / 'mac-aux-lock.json') != auxiliary['lock_sha256']:
        raise RuntimeError('The signed auxiliary tool lock changed')
    files = {str(auxiliary_path): digest_file(auxiliary_path),
             str(menu_receipt): digest_file(menu_receipt),
             str(prep.root / 'state/mac-sdk-metadata.json'): digest_file(prep.root / 'state/mac-sdk-metadata.json'),
             str(root / 'SDKSettings.plist'): sdk['sdk_settings_sha256'],
             str(root / 'System/Library/CoreServices/SystemVersion.plist'):
                 digest_file(root / 'System/Library/CoreServices/SystemVersion.plist')}
    for info in auxiliary['tools'].values():
        for path_key, hash_key in [('path', 'wrapper_sha256'), ('executable', 'executable_sha256')]:
            path = Path(info[path_key])
            if digest_file(path) != info[hash_key]:
                raise RuntimeError('Verified auxiliary executable/wrapper changed: ' + str(path))
            files[str(path)] = info[hash_key]
    executable = Path(auxiliary['tools']['dsymutil']['executable'])
    library = executable.parents[2] / 'x86_64-linux-gnu/libLLVM.so.24.0'
    if digest_file(library) != auxiliary['llvm_shared_library_sha256']:
        raise RuntimeError('Verified auxiliary LLVM shared library changed')
    files[str(library)] = auxiliary['llvm_shared_library_sha256']
    compiler = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
    if digest_file(compiler) != auxiliary['main_clang_sha256']:
        raise RuntimeError('Original Chromium Clang changed')
    files[str(compiler)] = auxiliary['main_clang_sha256']
    lock = json.loads((HERE / 'mac-aux-lock.json').read_text('utf-8'))
    runtime = lock['mac_compiler_rt']
    archive = prep.root / 'downloads/clang/Mac' / runtime['url'].rsplit('/', 1)[1]
    if digest_file(archive) != runtime['sha256']:
        raise RuntimeError('The original Darwin compiler-rt archive changed')
    with tarfile.open(archive) as package:
        count = 0
        for member in package:
            if not member.isfile():
                continue
            path = (compiler.parent.parent / member.name).resolve()
            if compiler.parent.parent.resolve() not in path.parents:
                raise RuntimeError('Darwin compiler-rt archive path escaped the toolchain')
            expected = hashlib.sha256(package.extractfile(member).read()).hexdigest()
            if not path.is_file() or digest_file(path) != expected:
                raise RuntimeError('Original Darwin compiler-rt is absent or changed; run prepare_macos_aux.py after source sync/hooks: ' + member.name)
            files[str(path)] = expected
            count += 1
        if count == 0:
            raise RuntimeError('The original Darwin compiler-rt archive has no regular payload')
    metadata = {name: sdk[name] for name in ['sdk_path', 'sdk_version', 'sdk_build', 'clt_package_version',
                                           'clt_compat_version_int', 'clt_build_token']}
    metadata.update({'format': 1, 'host_os': 'linux', 'xcode_installed': False,
                     'dsymutil_path': auxiliary['tools']['dsymutil']['path'],
                     'otool_path': auxiliary['tools']['llvm-otool']['path'], 'verified_files': files})
    destination = prep.root / 'cache/mac-gn/verified-cross-metadata.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    write_json(destination, metadata)
    load(destination)
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'gn_arguments': {'mycef_mac_cross_sdk_metadata': str(destination)},
               'metadata_path': str(destination), 'metadata_sha256': digest_file(destination),
               'sdk_version': sdk['sdk_version'], 'sdk_build': sdk['sdk_build'],
               'gn_generated': False, 'cef_built': False,
               'scope': 'Verified real CLT SDK and executable Linux debug-tool inputs only; GN/CEF integration and macOS runtime remain pending.'}
    write_json(prep.root / 'state/mac-gn-inputs-prepared.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(Preparation(args.root)), indent=2), flush=True)


if __name__ == '__main__':
    main()
