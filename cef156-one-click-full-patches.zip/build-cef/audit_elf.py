#!/usr/bin/env python3
"""Audit actual shipped ELF architecture, version needs and dynamic libraries.

Only ELF version *needs* are counted. Exported version definitions and text
strings are not evidence that the target needs that version of glibc.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import re
import struct
import subprocess

MACHINES = {'x64': 62, 'arm64': 183}


def needed_versions(text):
    in_needs = False
    versions = set()
    for line in text.splitlines():
        if line.startswith('Version needs section'):
            in_needs = True
        elif line.startswith('Version ') and ' section ' in line:
            in_needs = False
        if in_needs:
            match = re.search(r'\bName:\s+(\S+)', line)
            if match:
                versions.add(match[1])
    return sorted(versions)


def version_key(value):
    return tuple(map(int, value.split('.')))


def inspect(path, readelf='readelf'):
    with path.open('rb') as stream:
        header = stream.read(20)
    if header[:4] != b'\x7fELF':
        return None
    if len(header) < 20 or header[4] not in (1, 2) or header[5] not in (1, 2):
        raise ValueError('Invalid ELF header: ' + str(path))
    machine = struct.unpack('<H' if header[5] == 1 else '>H', header[18:20])[0]
    def read(*arguments):
        return subprocess.check_output([readelf, '--wide', *arguments, str(path)], text=True,
                                       encoding='utf-8', errors='replace')
    versions = needed_versions(read('--version-info'))
    numeric = [v.removeprefix('GLIBC_') for v in versions if re.fullmatch(r'GLIBC_\d+(?:\.\d+)+', v)]
    dynamic = read('--dynamic')
    notes = read('--notes')
    return {
        'machine': machine, 'bits': 64 if header[4] == 2 else 32,
        'endianness': 'little' if header[5] == 1 else 'big',
        'version_needs': versions,
        'glibc_max_required': max(numeric, key=version_key) if numeric else None,
        'glibc_other_requirements': [v for v in versions if v.startswith('GLIBC_') and v.removeprefix('GLIBC_') not in numeric],
        'needed_libraries': re.findall(r'\(NEEDED\).*?\[([^\]]+)\]', dynamic),
        'rpath': re.findall(r'\((?:RPATH|RUNPATH)\).*?\[([^\]]+)\]', dynamic),
        'build_id': (re.findall(r'Build ID:\s*(\S+)', notes) or [None])[0],
        'notes': notes.strip(),
    }


def audit(directory, cpu, max_glibc='2.28', readelf='readelf'):
    root = Path(directory).resolve()
    results, errors, links = [], [], []
    for path in sorted(root.rglob('*')):
        if path.is_symlink():
            resolved = path.resolve()
            links.append({'path': path.relative_to(root).as_posix(), 'target': str(path.readlink())})
            if resolved != root and root not in resolved.parents:
                errors.append('SDK symlink escapes the SDK: ' + str(path))
            elif not resolved.exists():
                errors.append('Broken SDK symlink: ' + str(path))
            continue
        if not path.is_file():
            continue
        record = inspect(path, readelf)
        if record is None:
            continue
        relative = path.relative_to(root).as_posix()
        record['path'] = relative
        results.append(record)
        if record['machine'] != MACHINES[cpu] or record['bits'] != 64 or record['endianness'] != 'little':
            errors.append('Wrong ELF target architecture: ' + relative)
        maximum = record['glibc_max_required']
        if maximum and version_key(maximum) > version_key(max_glibc):
            errors.append(f'{relative} requires GLIBC_{maximum}, above compatibility ceiling {max_glibc}')
        if record['glibc_other_requirements']:
            errors.append(relative + ': unreviewed glibc ABI requirements ' + ', '.join(record['glibc_other_requirements']))
        for runpath in record['rpath']:
            if any(component.startswith('/') for component in runpath.split(':')):
                errors.append('Absolute SDK RPATH / RUNPATH needs review: ' + relative)
    if not results:
        errors.append('No ELF files found')
    maximums = [r['glibc_max_required'] for r in results if r['glibc_max_required']]
    return {
        'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'directory': str(root),
        'target_cpu': cpu, 'compatibility_ceiling_glibc': max_glibc,
        'measured_max_required_glibc': max(maximums, key=version_key) if maximums else None,
        'elf_files': results, 'symlinks': links, 'errors': errors, 'passed': not errors,
        'scope': 'Static ELF audit only. This does not establish a kernel minimum, UOS product validation, GPU/driver compatibility or successful runtime.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', required=True)
    parser.add_argument('--cpu', required=True, choices=tuple(MACHINES))
    parser.add_argument('--max-glibc', default='2.28')
    parser.add_argument('--readelf', default='readelf')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    report = audit(args.directory, args.cpu, args.max_glibc, args.readelf)
    Path(args.report).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: report[key] for key in ('passed', 'measured_max_required_glibc', 'errors')}, indent=2))
    raise SystemExit(0 if report['passed'] else 1)


if __name__ == '__main__':
    main()
