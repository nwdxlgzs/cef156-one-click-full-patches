#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$Root = 'C:\cef156',
    [ValidateRange(1, 64)][int]$Jobs = 10,
    [ValidateRange(0, 128)][int]$PageFileGB = 32,
    [ValidateRange(100, 2048)][int]$InitialFreeGB = 200,
    [ValidateRange(30, 1024)][int]$BuildFreeGB = 80,
    [string]$ProxyUrl = '',
    [ValidateSet('Mirror', 'Upstream')][string]$DependencySource = 'Mirror',
    [switch]$KeepIntermediates,
    [switch]$PlanOnly,
    [switch]$SkipInstall
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
# Windows PowerShell can inherit PowerShell 7's module search path when a
# launcher is an intermediate CMD/Python process. Prefer its own built-ins.
if ($PSVersionTable.PSEdition -eq 'Desktop') {
    $env:PSModulePath = $PSHOME + '\Modules;' + $env:PSModulePath
}
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

if ($Root -notmatch '^[C-Zc-z]:\\[A-Za-z0-9_-]+(?:\\[A-Za-z0-9_-]+)*\\?$') {
    throw 'Use a dedicated short ASCII folder, for example C:\cef156. Drive roots, spaces, UNC and special characters are not supported.'
}
$Root = [IO.Path]::GetFullPath($Root).TrimEnd('\')
$driveRoot = [IO.Path]::GetPathRoot($Root)
if (-not (Test-Path -LiteralPath $driveRoot)) { throw "Build drive does not exist: $driveRoot." }
if (-not [Environment]::Is64BitOperatingSystem -or -not [Environment]::Is64BitProcess) {
    throw 'Run this script using 64-bit Windows PowerShell.'
}
$helper = Join-Path $PSScriptRoot 'build_cef.py'
if (-not (Test-Path -LiteralPath $helper)) { throw 'Extract the whole build-cef folder before running Build-CEF.cmd.' }
$patchRoot = Join-Path $PSScriptRoot 'patches'
$patchManifestPath = Join-Path $patchRoot 'manifest.json'
if (-not (Test-Path -LiteralPath $patchManifestPath)) { throw 'Missing patches\manifest.json. Extract the whole full-patches ZIP.' }
$patchManifest = [IO.File]::ReadAllText($patchManifestPath) | ConvertFrom-Json
if ($patchManifest.chromium_version -ne '156.0.8071.0' -or $patchManifest.win7_revision -ne 'b4d1c429f461bd756443ea0b68270d0bdb1c5536' -or $patchManifest.cef_revision -ne 'a26ddfd2792604564986b31ea298e30b09bd9b3f') {
    throw 'Bundled patch versions do not match this script.'
}
$patchBoundary = [IO.Path]::GetFullPath($patchRoot).TrimEnd('\') + '\'
foreach ($entry in $patchManifest.files.PSObject.Properties) {
    $patchPath = [IO.Path]::GetFullPath((Join-Path $patchRoot $entry.Name))
    if (-not $patchPath.StartsWith($patchBoundary, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $patchPath -PathType Leaf)) {
        throw ('Missing or invalid bundled patch file: ' + $entry.Name)
    }
    if ((Get-FileHash -LiteralPath $patchPath -Algorithm SHA256).Hash -ne $entry.Value) { throw ('Bundled patch checksum mismatch: ' + $entry.Name) }
}
Write-Host 'Bundled patches verified: 345 Win7, CEF official set + 10 adaptations, Windows build fix, WebGL fallback.'
if ($PlanOnly) {
    Write-Host "Root: $Root; jobs: $Jobs; page file request: ${PageFileGB}GB"
    Write-Host 'Chromium: 156.0.8071.0; CEF: a26ddfd2792604564986b31ea298e30b09bd9b3f (upstream compatibility: 156.0.8078.0).'
    Write-Host 'Order: x64 Release, x86 Release, arm64 Release. Debug configurations are not built.'
    Write-Host 'Each configuration: build -> SDK + PDB ZIP64 -> verify ZIP and SHA256 -> remove its generated output.'
    Write-Host 'Release packages retain full PDBs. Read README.zh-CN.md for the compatibility limits.'
    Write-Host "Dependency source: $DependencySource. Mirror mode uses Huawei Python, Flutter China CIPD files and selected official GitHub source mirrors; remaining repositories/GCS/Microsoft downloads use their upstream endpoints."
    Write-Host 'PlanOnly performs no installation, source checkout or system configuration.'
    exit 0
}

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '" -Root "' + $Root + '" -Jobs ' + $Jobs + ' -PageFileGB ' + $PageFileGB + ' -InitialFreeGB ' + $InitialFreeGB + ' -BuildFreeGB ' + $BuildFreeGB + ' -DependencySource ' + $DependencySource
    if ($ProxyUrl) {
        if ($ProxyUrl -match '["\r\n]') { throw 'Invalid proxy URL.' }
        $arguments += ' -ProxyUrl "' + $ProxyUrl + '"'
    }
    if ($KeepIntermediates) { $arguments += ' -KeepIntermediates' }
    if ($SkipInstall) { $arguments += ' -SkipInstall' }
    $elevated = Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -ArgumentList $arguments -Verb RunAs -Wait -PassThru
    exit $elevated.ExitCode
}

$volume = Get-Volume -DriveLetter $driveRoot.Substring(0, 1)
if ($volume.FileSystem -ne 'NTFS') { throw 'The build volume must use NTFS.' }
$isNew = -not (Test-Path -LiteralPath (Join-Path $Root '.mycef-build-root'))
if ($isNew -and (Test-Path -LiteralPath $Root) -and @(Get-ChildItem -LiteralPath $Root -Force).Count -gt 0) {
    throw 'The initial build root must be empty. Choose a dedicated folder.'
}
if ($isNew -and $volume.SizeRemaining -lt ($InitialFreeGB * 1GB)) {
    throw "Need at least $InitialFreeGB GiB free before starting. Current free: $([math]::Round($volume.SizeRemaining / 1GB, 1)) GiB."
}
New-Item -ItemType Directory -Path $Root -Force | Out-Null
$rootMarker = Join-Path $Root '.mycef-build-root'
if (-not (Test-Path -LiteralPath $rootMarker)) { [IO.File]::WriteAllText($rootMarker, 'mycef-156.0.8071.0-v1') }
if ([IO.File]::ReadAllText($rootMarker) -ne 'mycef-156.0.8071.0-v1') { throw 'Unrecognized build-root marker.' }
foreach ($subdir in @('logs', 'downloads', 'tmp', 'state', 'packages')) {
    New-Item -ItemType Directory -Path (Join-Path $Root $subdir) -Force | Out-Null
}
$transcript = Join-Path $Root ('logs\bootstrap-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
Start-Transcript -Path $transcript | Out-Null
$exitCode = 1
$mirrorProcess = $null
try {
    $env:TEMP = Join-Path $Root 'tmp'
    $env:TMP = $env:TEMP
    $env:PYTHONUTF8 = '1'
    $env:PYTHONIOENCODING = 'utf-8'
    $env:DEPOT_TOOLS_WIN_TOOLCHAIN = '0'
    $env:DEPOT_TOOLS_UPDATE = '0'
    $env:DEPOT_TOOLS_WIN_TOOLCHAIN_ROOT = $Root
    $env:CEF_ENABLE_ARM64 = '1'
    $env:GIT_TERMINAL_PROMPT = '0'
    if ($ProxyUrl) {
        $env:HTTP_PROXY = $ProxyUrl
        $env:HTTPS_PROXY = $ProxyUrl
        [Net.WebRequest]::DefaultWebProxy = New-Object Net.WebProxy($ProxyUrl)
    }
    New-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' -Name LongPathsEnabled -Value 1 -PropertyType DWord -Force | Out-Null

    function Get-Download([string]$Url, [string]$Path, [string]$Sha256 = '') {
        if ((Test-Path -LiteralPath $Path) -and $Sha256 -and (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash -eq $Sha256) { return }
        $partial = $Path + '.part'
        for ($attempt = 1; $attempt -le 4; $attempt++) {
            try {
                Write-Host "Downloading $([IO.Path]::GetFileName($Path)) (attempt $attempt)..."
                $curlCommand = Get-Command curl.exe -ErrorAction SilentlyContinue
                if ($curlCommand) {
                    # Stream large payloads to disk and retain interrupted bytes.
                    # TLS verification stays enabled; a stalled connection must
                    # fail instead of leaving an apparently idle download forever.
                    & $curlCommand.Source --fail --location --silent --show-error --connect-timeout 30 --max-time 1800 --speed-limit 1024 --speed-time 90 --continue-at - --output $partial $Url
                    $downloadExit = $LASTEXITCODE
                    if ($downloadExit -eq 33 -or $downloadExit -eq 36) {
                        # The server may not support resuming an existing file.
                        if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
                    }
                    if ($downloadExit -ne 0) { throw "Download failed with curl exit code ${downloadExit}: $Path" }
                } else {
                    Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $partial -TimeoutSec 1800
                }
                if ($Sha256 -and (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash -ne $Sha256) {
                    Remove-Item -LiteralPath $partial -Force
                    throw "SHA256 mismatch: $Path"
                }
                Move-Item -LiteralPath $partial -Destination $Path -Force
                return
            } catch {
                if ($attempt -eq 4) { throw }
                Start-Sleep -Seconds (3 * $attempt)
            }
        }
    }
    function Invoke-Installer([string]$Path, [string]$Arguments) {
        $signature = Get-AuthenticodeSignature -LiteralPath $Path
        if ($signature.Status -ne 'Valid') { throw "Installer signature validation failed: $Path ($($signature.Status))" }
        $process = Start-Process -FilePath $Path -ArgumentList $Arguments -WindowStyle Hidden -PassThru
        while (-not $process.WaitForExit(30000)) { Write-Host "Installer is running: $([IO.Path]::GetFileName($Path))..." }
        if ($process.ExitCode -eq 3010 -or $process.ExitCode -eq 1641) {
            throw 'The installer requires a reboot. Reboot manually, then run Build-CEF.cmd again; completed build stages are retained.'
        }
        if ($process.ExitCode -ne 0) { throw "Installer failed with exit code $($process.ExitCode): $Path" }
    }
    function Invoke-Git([string[]]$GitArguments) {
        & $script:git @GitArguments
        if ($LASTEXITCODE -ne 0) { throw "git failed with exit code $LASTEXITCODE" }
    }

    # Install Git separately; depot_tools no longer reliably bundles it.
    $gitCommand = Get-Command git.exe -ErrorAction SilentlyContinue
    if (-not $gitCommand) {
        $installedGit = Join-Path $Root 'Git\cmd\git.exe'
        if (Test-Path -LiteralPath $installedGit) { $gitCommand = Get-Item -LiteralPath $installedGit }
    }
    if (-not $gitCommand) {
        if ($SkipInstall) { throw 'Git is missing and -SkipInstall was specified.' }
        $gitRelease = Invoke-RestMethod -Uri 'https://api.github.com/repos/git-for-windows/git/releases/latest' -Headers @{'User-Agent'='MyCEF-Builder'}
        $asset = @($gitRelease.assets | Where-Object { $_.name -match '^Git-.*-64-bit\.exe$' })[0]
        $gitInstaller = Join-Path $Root 'downloads\git-installer.exe'
        $expectedHash = ''
        if ($asset.PSObject.Properties.Name -contains 'digest' -and $asset.digest -match '^sha256:(.+)$') { $expectedHash = $Matches[1] }
        Get-Download $asset.browser_download_url $gitInstaller $expectedHash
        Invoke-Installer $gitInstaller ('/VERYSILENT /NORESTART /NOCANCEL /SP- /DIR="' + (Join-Path $Root 'Git') + '"')
        $script:git = Join-Path $Root 'Git\cmd\git.exe'
    } else {
        if ($gitCommand.PSObject.Properties.Name -contains 'Source') { $script:git = $gitCommand.Source } else { $script:git = $gitCommand.FullName }
    }
    $env:PATH = (Split-Path $script:git) + ';' + $env:PATH

    # These settings apply only to new repositories created below this root.
    $gitConfig = Join-Path $Root 'gitconfig'
    [IO.File]::WriteAllText($gitConfig, "[core]`n    longpaths = true`n    autocrlf = false`n    filemode = false`n    preloadindex = true`n    fscache = true`n[http]`n    version = HTTP/1.1`n")
    $env:GIT_CONFIG_GLOBAL = $gitConfig
    $networkLock = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'network-lock.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($DependencySource -eq 'Mirror') {
        foreach ($mapping in $networkLock.git_mirrors) {
            Invoke-Git @('config', '--file', $gitConfig, '--add', ('url.' + $mapping[1] + '.insteadOf'), $mapping[0])
        }
        foreach ($gitHost in $networkLock.google_git_hosts) {
            Invoke-Git @('config', '--file', $gitConfig, '--add', 'http.curloptResolve', ($gitHost + ':443:' + $networkLock.google_git_frontend))
        }
    }

    $vsPath = Join-Path $Root 'VS2026'
    $hasRequiredComponents = $false
    $vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if (Test-Path -LiteralPath $vswhere) {
        $existing = & $vswhere -latest -products '*' -version '[18.0,19.0)' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 Microsoft.VisualStudio.Component.VC.Tools.ARM64 Microsoft.VisualStudio.Component.VC.ATLMFC Microsoft.VisualStudio.Component.VC.MFC.ARM64 -property installationPath
        if ($existing) {
            $vsPath = [string]($existing | Select-Object -First 1)
            $hasRequiredComponents = $true
        }
    }
    $sdkRoot = Join-Path $Root 'WindowsKits\10'
    $sdkRegistry = 'HKLM:\SOFTWARE\Microsoft\Windows Kits\Installed Roots'
    if (Test-Path -LiteralPath $sdkRegistry) {
        $sdkProps = Get-ItemProperty -Path $sdkRegistry
        if ($sdkProps.PSObject.Properties.Name -contains 'KitsRoot10') { $sdkRoot = [string]$sdkProps.KitsRoot10 }
    }
    $sdkHeaders = Join-Path $sdkRoot 'Include\10.0.28000.0\um\Windows.h'
    $sdkDebuggers = Join-Path $sdkRoot 'Debuggers\x64\dbghelp.dll'
    $legacyRuntimeMarker = Join-Path $Root 'state\runtime-sdk26100.json'
    $vsReady = Test-Path -LiteralPath (Join-Path $vsPath 'VC\Auxiliary\Build\vcvarsall.bat')
    $installState = Join-Path $Root 'state\toolchain-installed.json'
    if (-not $hasRequiredComponents -or -not $vsReady -or -not (Test-Path -LiteralPath $sdkHeaders) -or -not (Test-Path -LiteralPath $sdkDebuggers) -or -not (Test-Path -LiteralPath $legacyRuntimeMarker)) {
        if ($SkipInstall) { throw 'VS 2026 C++/ARM64/ATL/MFC or SDK 28000/debuggers are missing.' }
        Write-Host 'Installing the toolchain required by Chromium 156 (VS 2026 and Windows SDK 28000).'
        $channelPath = Join-Path $Root 'downloads\vs-channel.json'
        if (-not (Test-Path -LiteralPath $channelPath)) { Get-Download 'https://aka.ms/vs/18/stable/channel' $channelPath }
        $channel = Get-Content -Raw -Encoding UTF8 -LiteralPath $channelPath | ConvertFrom-Json
        $catalogPayload = @($channel.channelItems | Where-Object { $_.type -eq 'Manifest' })[0].payloads[0]
        $catalogPath = Join-Path $Root 'downloads\vs-catalog.json'
        $catalogHash = $catalogPayload.sha256
        $toolchainLock = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'toolchain-lock.json') | ConvertFrom-Json
        if ($catalogPayload.url -eq $toolchainLock.catalog_url -and $channel.info.buildVersion -eq $toolchainLock.channel_build_version) {
            # This fixed Microsoft endpoint serves different bytes from the
            # channel's advertised length/hash. Pin the exact independently
            # retrieved payload; never accept an arbitrary hash mismatch.
            $catalogHash = $toolchainLock.catalog_sha256
        }
        Get-Download $catalogPayload.url $catalogPath $catalogHash
        $catalog = Get-Content -Raw -Encoding UTF8 -LiteralPath $catalogPath | ConvertFrom-Json
        if (-not (Test-Path -LiteralPath $legacyRuntimeMarker)) {
            # Capture SDK 26100's Win7-compatible shader compiler before the
            # SDK 28000 installer updates the shared Redist/D3D directory.
            $legacyPackage = @($catalog.packages | Where-Object { $_.id -eq 'Win11SDK_10.0.26100' })[0]
            $legacyPayload = @($legacyPackage.payloads | Where-Object { $_.fileName -eq 'winsdksetup.exe' })[0]
            $legacyInstaller = Join-Path $Root 'downloads\winsdksetup-26100.exe'
            Get-Download $legacyPayload.url $legacyInstaller $legacyPayload.sha256
            Invoke-Installer $legacyInstaller ('/quiet /norestart /ceip off /installpath "' + $sdkRoot.TrimEnd('\') + '" /features OptionId.DesktopCPPx64 OptionId.DesktopCPPx86')
            $runtimeManifest = @{}
            foreach ($legacyArch in @('x64', 'x86')) {
                $destinationDir = Join-Path $Root "runtime26100\$legacyArch"
                $savedRuntime = Join-Path $destinationDir 'd3dcompiler_47.dll'
                $candidates = @(Get-ChildItem -LiteralPath (Join-Path $sdkRoot 'Redist\D3D') -Recurse -File -Filter d3dcompiler_47.dll | Where-Object { $_.Directory.Name -eq $legacyArch -and $_.VersionInfo.FileBuildPart -eq 26100 })
                if ((Test-Path -LiteralPath $savedRuntime) -and (Get-Item -LiteralPath $savedRuntime).VersionInfo.FileBuildPart -eq 26100) {
                    $candidates = @((Get-Item -LiteralPath $savedRuntime))
                }
                if ($candidates.Count -eq 0) { throw "Cannot find SDK 26100 d3dcompiler_47.dll for $legacyArch. An existing newer SDK may own the shared DLL. Preserve a 26100 Redist/D3D copy under $Root\runtime26100\$legacyArch before retrying." }
                New-Item -ItemType Directory -Path $destinationDir -Force | Out-Null
                if ($candidates[0].FullName -ine $savedRuntime) { Copy-Item -LiteralPath $candidates[0].FullName -Destination $savedRuntime -Force }
                $runtimeManifest[$legacyArch] = @{version=$candidates[0].VersionInfo.FileVersion;sha256=(Get-FileHash -LiteralPath (Join-Path $destinationDir 'd3dcompiler_47.dll') -Algorithm SHA256).Hash}
            }
            [IO.File]::WriteAllText($legacyRuntimeMarker, ($runtimeManifest | ConvertTo-Json -Depth 4))
        }
        $sdkPackage = @($catalog.packages | Where-Object { $_.id -eq 'Win11SDK_10.0.28000' })[0]
        $sdkPayload = @($sdkPackage.payloads | Where-Object { $_.fileName -eq 'winsdksetup.exe' })[0]
        $sdkInstaller = Join-Path $Root 'downloads\winsdksetup.exe'
        Get-Download $sdkPayload.url $sdkInstaller $sdkPayload.sha256
        # Standalone SDK installation includes debuggers on the build volume.
        Invoke-Installer $sdkInstaller ('/quiet /norestart /ceip off /installpath "' + $sdkRoot.TrimEnd('\') + '" /features OptionId.DesktopCPPx64 OptionId.DesktopCPPx86 OptionID.DesktopCPPARM64 OptionId.WindowsDesktopDebuggers')
        $bootstrapPayload = @($channel.channelItems | Where-Object { $_.type -eq 'Bootstrapper' })[0].payloads[0]
        $vsInstaller = Join-Path $Root 'downloads\vs_Setup.exe'
        Get-Download $bootstrapPayload.url $vsInstaller $bootstrapPayload.sha256
        $vsArgs = '--quiet --wait --norestart --nocache --productId Microsoft.VisualStudio.Product.BuildTools --channelUri "' + $channelPath + '" --installPath "' + $vsPath + '" --path shared="' + (Join-Path $Root 'VSShared') + '" --path cache="' + (Join-Path $Root 'VSCache') + '" --add Microsoft.VisualStudio.Workload.VCTools --add Microsoft.VisualStudio.Component.VC.ATLMFC --add Microsoft.VisualStudio.Component.VC.Tools.ARM64 --add Microsoft.VisualStudio.Component.VC.MFC.ARM64 --add Microsoft.VisualStudio.Component.Windows11SDK.28000 --includeRecommended'
        if (-not $hasRequiredComponents) {
            if ($vsReady) { $vsArgs = 'modify ' + $vsArgs }
            Invoke-Installer $vsInstaller $vsArgs
        }
        [IO.File]::WriteAllText($installState, (@{vs=$vsPath;sdk=$sdkRoot} | ConvertTo-Json))
    }
    if (-not (Test-Path -LiteralPath (Join-Path $vsPath 'VC\Auxiliary\Build\vcvarsall.bat'))) { throw 'VS 2026 C++ tools were not found after installation.' }
    foreach ($arch in @('x86', 'x64', 'arm64')) {
        if (-not (Test-Path -LiteralPath (Join-Path $sdkRoot "Lib\10.0.28000.0\um\$arch\kernel32.lib"))) { throw "Missing SDK library for $arch under $sdkRoot" }
        if (-not (Test-Path -LiteralPath (Join-Path $sdkRoot "Debuggers\$arch\dbghelp.dll"))) { throw "Missing SDK debugging tools for $arch under $sdkRoot" }
    }
    $env:vs2026_install = $vsPath
    $env:GYP_MSVS_VERSION = '2026'
    $env:WindowsSdkDir = $sdkRoot.TrimEnd('\') + '\'

    # Use the build volume for the page file; retain settings on other volumes.
    if ($PageFileGB -gt 0) {
        $pagePath = $driveRoot + 'pagefile.sys'
        $pageSetting = @(Get-CimInstance Win32_PageFileSetting | Where-Object { $_.Name -ieq $pagePath })
        if ($pageSetting.Count -eq 0 -or [int]$pageSetting[0].MaximumSize -lt ($PageFileGB * 1024)) {
            Get-CimInstance Win32_ComputerSystem | Set-CimInstance -Property @{AutomaticManagedPagefile=$false} | Out-Null
            # Disabling automatic management can create a page-file setting
            # from the previously automatic C: page file. Refresh before
            # choosing between create and update.
            $pageSetting = @(Get-CimInstance Win32_PageFileSetting | Where-Object { $_.Name -ieq $pagePath })
            if ($pageSetting.Count -eq 0) {
                New-CimInstance -ClassName Win32_PageFileSetting -Property @{Name=$pagePath;InitialSize=[uint32]($PageFileGB*1024);MaximumSize=[uint32]($PageFileGB*1024)} | Out-Null
            } else {
                $pageSetting[0] | Set-CimInstance -Property @{InitialSize=[uint32]($PageFileGB*1024);MaximumSize=[uint32]($PageFileGB*1024)} | Out-Null
            }
        }
        $activePage = @(Get-CimInstance Win32_PageFileUsage | Where-Object { $_.Name -ieq $pagePath -and $_.AllocatedBaseSize -ge ($PageFileGB * 1024) })
        if ($activePage.Count -eq 0) { throw "A ${PageFileGB}GB page file has been configured on $driveRoot. Reboot manually, then run Build-CEF.cmd again. No reboot is started automatically." }
    }

    $depot = Join-Path $Root 'depot_tools'
    if (-not (Test-Path -LiteralPath (Join-Path $depot '.git'))) {
        New-Item -ItemType Directory -Path $depot -Force | Out-Null
        Invoke-Git @('-C', $depot, 'init')
        Invoke-Git @('-C', $depot, 'remote', 'add', 'origin', 'https://chromium.googlesource.com/chromium/tools/depot_tools.git')
    }
    & $script:git -C $depot rev-parse --verify --quiet HEAD | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Invoke-Git @('-C', $depot, 'fetch', '--depth=1', 'origin', 'HEAD')
        Invoke-Git @('-C', $depot, 'checkout', '--detach', 'FETCH_HEAD')
    }
    $env:PATH = $depot + ';' + $env:PATH
    $depotCommit = & $script:git -C $depot rev-parse HEAD
    if ($LASTEXITCODE -ne 0) { throw 'Invalid depot_tools checkout.' }
    $depotLock = Join-Path $Root 'state\depot-tools-revision.txt'
    if (Test-Path -LiteralPath $depotLock) {
        if ([IO.File]::ReadAllText($depotLock).Trim() -ne $depotCommit.Trim()) { throw 'depot_tools revision changed. Restore the revision recorded in state\depot-tools-revision.txt.' }
    } else { [IO.File]::WriteAllText($depotLock, $depotCommit.Trim()) }
    if ($DependencySource -eq 'Mirror') {
        $pythonDir = Join-Path $Root 'Python311-portable'
        $python = Join-Path $pythonDir 'python.exe'
        $pythonZip = Join-Path $Root 'downloads\python-3.11.9-embed-amd64.zip'
        Get-Download $networkLock.python_url $pythonZip $networkLock.python_sha256
        if (-not (Test-Path -LiteralPath $python)) {
            Expand-Archive -LiteralPath $pythonZip -DestinationPath $pythonDir -Force
        }
        foreach ($binary in @($python, (Join-Path $pythonDir 'python311.dll'))) {
            if ((Get-AuthenticodeSignature -LiteralPath $binary).Status -ne 'Valid') { throw "Python signature validation failed: $binary" }
        }
        # Keep the portable bootstrap interpreter isolated from system Python.
        [IO.File]::WriteAllText((Join-Path $pythonDir 'python311._pth'), "python311.zip`r`n.`r`n$depot`r`n$PSScriptRoot`r`nLib\site-packages`r`n")
        New-Item -ItemType Directory -Path (Join-Path $pythonDir 'Lib\site-packages') -Force | Out-Null
        $mirrorHelper = Join-Path $PSScriptRoot 'cipd_mirror.py'
        $mirrorCache = Join-Path $Root 'downloads\cipd-mirror'
        & $python $mirrorHelper --cache $mirrorCache --bootstrap-depot $depot
        if ($LASTEXITCODE -ne 0) { throw 'Mirror CIPD client bootstrap failed; inspect the official digest check above.' }
        $readyFile = Join-Path $Root ('state\cipd-mirror-' + [guid]::NewGuid().ToString('N') + '.json')
        $mirrorArgs = '"' + $mirrorHelper + '" --cache "' + $mirrorCache + '" --ready-file "' + $readyFile + '" --log-file "' + (Join-Path $Root 'logs\cipd-mirror.log') + '"'
        $mirrorProcess = Start-Process -FilePath $python -ArgumentList $mirrorArgs -WindowStyle Hidden -PassThru
        for ($wait = 0; $wait -lt 30 -and -not (Test-Path -LiteralPath $readyFile); $wait++) {
            if ($mirrorProcess.HasExited) { throw 'CIPD mirror metadata service exited before it became ready.' }
            Start-Sleep -Seconds 1
        }
        if (-not (Test-Path -LiteralPath $readyFile)) { throw 'CIPD mirror metadata service did not start.' }
        $env:CIPD_SERVICE_URL = (Get-Content -LiteralPath $readyFile -Raw -Encoding UTF8 | ConvertFrom-Json).url
        $env:VPYTHON_AR_URL = $env:CIPD_SERVICE_URL + '/python/simple/'
        $health = Invoke-WebRequest -UseBasicParsing -Uri ($env:CIPD_SERVICE_URL + '/health') -TimeoutSec 10
        if ($health.Content -ne 'mycef-cipd-mirror-v1') { throw 'Unexpected CIPD mirror health response.' }
        # Bootstrap the exact official gsutil directly from its public bucket.
        # Its normal bootstrap queries www.googleapis.com metadata, which is
        # unreachable from this build host. Keep the locked archive digest.
        $gsutilSource = [IO.File]::ReadAllText((Join-Path $depot 'gsutil.py'))
        if (-not $gsutilSource.Contains('VERSION = "' + $networkLock.gsutil_version + '"')) { throw 'gsutil version changed; update its reviewed download lock first.' }
        $gsutilZip = Join-Path $Root ('downloads\gsutil_' + $networkLock.gsutil_version + '.zip')
        Get-Download $networkLock.gsutil_url $gsutilZip $networkLock.gsutil_sha256
        $gsutilDir = Join-Path $depot ('external_bin\gsutil\gsutil_' + $networkLock.gsutil_version)
        $gsutilFlag = Join-Path $gsutilDir 'gsutil\install.flag'
        if (-not (Test-Path -LiteralPath $gsutilFlag)) {
            Expand-Archive -LiteralPath $gsutilZip -DestinationPath $gsutilDir -Force
            if (-not (Test-Path -LiteralPath (Join-Path $gsutilDir 'gsutil\gsutil'))) { throw 'Official gsutil archive is incomplete.' }
            [IO.File]::WriteAllText($gsutilFlag, 'This flag file is dropped by gsutil.py')
        }
        $env:BOTO_CONFIG = Join-Path $Root 'state\public-gcs.boto'
        [IO.File]::WriteAllText($env:BOTO_CONFIG, "[GSUtil]`nprefer_api = xml`n[Boto]`nhttps_validate_certificates = True`nhttp_socket_timeout = 30`nnum_retries = 4`n")
        # cipd.bat hardcodes the upstream for self-update. Allow the original
        # client to use the same local mirror metadata endpoint as gclient.
        $cipdBat = Join-Path $depot 'cipd.bat'
        $cipdText = [IO.File]::ReadAllText($cipdBat)
        if (-not $cipdText.Contains('if defined CIPD_SERVICE_URL set CIPD_BACKEND=')) {
            $original = 'set CIPD_BACKEND=https://chrome-infra-packages.appspot.com'
            if (-not $cipdText.Contains($original)) { throw 'Unsupported depot_tools cipd.bat; mirror adaptation requires review.' }
            $cipdText = $cipdText.Replace($original, $original + "`r`nif defined CIPD_SERVICE_URL set CIPD_BACKEND=%CIPD_SERVICE_URL%")
            [IO.File]::WriteAllText($cipdBat, $cipdText, [Text.ASCIIEncoding]::new())
        }
        Write-Host 'CIPD mirror active: original CIPD client, HTTPS mirror downloads, pinned instance checks retained.'
    }
    # Automatic depot_tools updates are disabled to preserve the locked commit.
    # Initialize its separate Python shim explicitly: vpython/gclient alone no
    # longer does this, but gn/autoninja still use python-bin/python3.bat.
    & (Join-Path $depot 'bootstrap\win_tools.bat')
    if ($LASTEXITCODE -ne 0) { throw 'depot_tools pinned Python bootstrap failed.' }
    & (Join-Path $depot 'python-bin\python3.bat') -c 'import ssl, sqlite3, sys; assert sys.version_info[:2] == (3, 11); print(sys.executable, sys.version)'
    if ($LASTEXITCODE -ne 0) { throw 'depot_tools Python shim verification failed.' }
    & (Join-Path $depot 'gclient.bat') --help
    if ($LASTEXITCODE -ne 0) { throw 'depot_tools bootstrap failed. Inspect logs\cipd-mirror.log and the source/download logs.' }
    $buildArgs = @($helper, '--root', $Root, '--jobs', [string]$Jobs, '--build-free-gb', [string]$BuildFreeGB)
    if ($KeepIntermediates) { $buildArgs += '--keep-intermediates' }
    # The embedded interpreter only bootstraps the mirror service. Chromium's
    # Python hooks need a full interpreter with normal script import paths.
    & (Join-Path $depot 'vpython3.bat') ('-vpython-spec=' + (Join-Path $PSScriptRoot 'build.vpython.toml')) @buildArgs
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) { throw "Build stopped with exit code $exitCode. Re-run the same command to resume. Logs: $Root\logs" }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($_.InvocationInfo.PositionMessage) { Write-Host $_.InvocationInfo.PositionMessage }
    Write-Host "Bootstrap log: $transcript"
    $exitCode = 1
} finally {
    if ($null -ne $mirrorProcess -and -not $mirrorProcess.HasExited) {
        # Also stop curl children so a failed run cannot keep writing a
        # partial archive while the next invocation resumes that same file.
        & "$env:SystemRoot\System32\taskkill.exe" /PID $mirrorProcess.Id /T /F | Out-Null
    }
    Stop-Transcript | Out-Null
}
exit $exitCode
