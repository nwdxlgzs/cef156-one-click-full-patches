#!/usr/bin/env python3
"""Extract a previously verified Apple SDK-only package without executing it."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import lzma
from pathlib import Path
import plistlib
import re
import struct
import subprocess

from apple_sdk_package import verify
from archive_posix import digest_file
from prepare_posix import Preparation, write_json


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--name', required=True, help='Dedicated SDK cache name, e.g. universal')
    args = parser.parse_args()
    if not re.fullmatch('[a-z][a-z0-9-]{0,40}', args.name):
        parser.error('Use a short lowercase cache name')
    prep = Preparation(args.root)
    receipt = json.loads(args.receipt.read_text('utf-8'))
    package = Path(receipt['path']).resolve()
    if prep.root / 'downloads/apple-sdk' not in package.parents or digest_file(package) != receipt['sha256']:
        raise RuntimeError('The SDK package escaped its cache or changed since verification')
    verified = verify(package, receipt['catalog_xar_toc_sha1'], receipt['bytes'])
    destination = prep.root / 'cache/apple-research' / ('extracted-sdk-' + args.name)
    report_path = prep.root / 'state' / ('apple-sdk-extracted-' + args.name + '.json')
    if destination.exists():
        if destination.is_symlink() or not report_path.exists():
            raise RuntimeError('Existing SDK extraction requires inspection; preserve it')
        prior = json.loads(report_path.read_text('utf-8'))
        if prior['package']['sha256'] != receipt['sha256']:
            raise RuntimeError('Existing SDK belongs to another verified package')
        for item in prior['sdks']:
            if digest_file(Path(item['settings'])) != item['settings_sha256']:
                raise RuntimeError('Extracted SDK settings changed')
        print('EXISTING_VERIFIED_APPLE_SDK_RETAINED', destination, flush=True)
        return
    payload = next(item for item in verified['members'] if item['name'] == 'Payload')
    cpio = prep.root / 'downloads/apple-sdk' / ('sdk-payload-' + args.name + '.cpio')
    count, total = 0, 0
    with package.open('rb') as source, cpio.open('wb') as target:
        source.seek(payload['offset'])
        if source.read(4) != b'pbzx':
            raise RuntimeError('Unsupported Apple SDK payload format')
        limit = struct.unpack('>Q', source.read(8))[0]
        if not 0 < limit <= 64 * 1024 * 1024:
            raise RuntimeError('Unexpected Apple pbzx block size')
        end = payload['offset'] + payload['length']
        while source.tell() < end:
            raw, packed = struct.unpack('>QQ', source.read(16))
            if packed > end - source.tell() or raw > limit:
                raise RuntimeError('SDK payload block exceeds its verified member')
            data = source.read(packed)
            decoded = lzma.decompress(data) if data.startswith(b'\xfd7zXZ\x00') else data
            if len(decoded) != raw:
                raise RuntimeError('SDK decompressed payload length mismatch')
            target.write(decoded)
            count, total = count + 1, total + raw
    listing = subprocess.check_output(['bsdtar', '-tf', str(cpio)], text=True).splitlines()
    if not listing or any(Path(name).is_absolute() or '..' in Path(name).parts for name in listing):
        raise RuntimeError('SDK cpio contains an unexpected path')
    destination.mkdir()
    prep.run(['bsdtar', '-xf', cpio, '-C', destination])
    sdks = []
    for path in sorted(destination.rglob('SDKSettings.plist')):
        settings = plistlib.loads(path.read_bytes())
        system = path.parent / 'System/Library/CoreServices/SystemVersion.plist'
        version = plistlib.loads(system.read_bytes())
        sdks.append({'root': str(path.parent), 'settings': str(path), 'settings_sha256': digest_file(path),
                     'version': settings['Version'], 'product_build': version['ProductBuildVersion'],
                     'architectures': settings['SupportedTargets']['macosx']['Archs']})
    if not sdks:
        raise RuntimeError('The verified SDK-only package contained no macOS SDK settings')
    write_json(report_path, {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                            'package': verified, 'destination': str(destination), 'sdks': sdks,
                            'cpio_entries': len(listing), 'pbzx_blocks': count, 'uncompressed_bytes': total,
                            'scope': 'Original verified SDK files extracted; no package scripts, version rewriting, GN or CEF build.'})
    cpio.unlink()
    print('ORIGINAL_APPLE_SDK_EXTRACTED', json.dumps(sdks), flush=True)


if __name__ == '__main__':
    main()
