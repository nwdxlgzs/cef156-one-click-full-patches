#!/usr/bin/env python3
"""Prepare verified Linux macOS debug helpers and exact Clang Darwin runtimes.

The main Chromium compiler is never replaced by the auxiliary LLVM package.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

from archive_posix import digest_file
from prepare_posix import Preparation, CHROMIUM_REV, write_json
from prefetch_clang import VERSION

HERE = Path(__file__).resolve().parent


def download(url, destination, size, expected, jobs):
    if destination.is_file() and destination.stat().st_size == size and digest_file(destination) == expected:
        return
    parts = destination.with_name(destination.name + '.ranges')
    parts.mkdir(exist_ok=True)
    def piece(first):
        last = min(size - 1, first + 1024 * 1024 - 1)
        path = parts / str(first)
        header = path.with_suffix('.headers')
        def valid():
            return (path.is_file() and path.stat().st_size == last - first + 1 and header.is_file()
                    and f'content-range: bytes {first}-{last}/{size}' in header.read_text().lower())
        if valid():
            return path
        for attempt in range(8):
            command = ['curl', '--fail', '-sS', '--connect-timeout', '10', '--max-time', '120',
                       '--speed-limit', '1024', '--speed-time', '20', '--range', f'{first}-{last}',
                       '-D', str(header), '-o', str(path)]
            if url.startswith('https://storage.googleapis.com/'):
                command += ['--resolve', 'storage.googleapis.com:443:172.253.117.82']
            result = subprocess.run([*command, url], capture_output=True)
            # A one-piece small object may be served as HTTP 200 without a
            # range header. Its final locked SHA256 remains mandatory.
            whole = (first == 0 and last == size - 1 and path.is_file() and path.stat().st_size == size)
            if result.returncode == 0 and (valid() or whole):
                return path
            time.sleep(min(attempt + 1, 5))
        raise RuntimeError('Auxiliary package range incomplete; data retained: ' + url)
    with ThreadPoolExecutor(jobs) as pool:
        chunks = list(pool.map(piece, range(0, size, 1024 * 1024)))
    pending = destination.with_suffix(destination.suffix + '.verified-pending')
    with pending.open('wb') as stream:
        for chunk in chunks:
            stream.write(chunk.read_bytes())
    if pending.stat().st_size != size or digest_file(pending) != expected:
        raise RuntimeError('Auxiliary package SHA256 differs from its immutable lock')
    pending.replace(destination)
    for part in parts.iterdir():
        if part.is_file():
            part.unlink()
    parts.rmdir()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--installer', type=Path,
                        help='Original update.py research copy before the full source tree exists')
    parser.add_argument('--jobs', type=int, default=16, choices=range(1, 25))
    args = parser.parse_args()
    prep = Preparation(args.root)
    lock = json.loads((HERE / 'mac-aux-lock.json').read_text('utf-8'))
    if lock['clang_package_version'] != VERSION or lock['clang_compiler_replacement_allowed'] is not False:
        raise RuntimeError('The auxiliary lock changed the main Chromium compiler policy')
    provenance = HERE / lock['provenance_directory']
    for name, expected in lock['metadata'].items():
        if digest_file(provenance / name) != expected:
            raise RuntimeError('Bundled signed LLVM metadata changed: ' + name)
    cache = prep.root / 'cache/llvm-aux-research'
    cache.mkdir(exist_ok=True)
    keyring = cache / 'verified-llvm-key.gpg'
    prep.run(['gpg', '--batch', '--yes', '--dearmor', '--output', keyring, provenance / 'llvm-snapshot.asc'])
    fingerprints = prep.run(['gpg', '--show-keys', '--with-colons', keyring], capture=True).stdout
    if 'fpr:::::::::' + lock['llvm_signing_fingerprint'] + ':' not in fingerprints:
        raise RuntimeError('The LLVM repository signing key changed')
    release = cache / 'verified-Release'
    verified = prep.run(['gpgv', '--keyring', keyring, '--output', '-', provenance / 'InRelease'], capture=True)
    release_data = verified.stdout.encode('utf-8')
    if hashlib.sha256(release_data).hexdigest() != lock['metadata']['Release']:
        raise RuntimeError('LLVM signed release differs from the locked provenance')
    release.write_bytes(release_data)
    release_text = release.read_text('utf-8')
    if not re.search(re.escape(lock['metadata']['Packages.gz']) + r'\s+\d+\s+main/binary-amd64/Packages.gz', release_text):
        raise RuntimeError('The package index is not bound to the verified signed release')
    index = gzip.decompress((provenance / 'Packages.gz').read_bytes()).decode('utf-8')
    packages = {}
    for block in index.split('\n\n'):
        entry = dict(line.split(': ', 1) for line in block.splitlines() if ': ' in line and not line.startswith(' '))
        if entry.get('Package') in {p['Package'] for p in lock['packages']}:
            packages[entry['Package']] = entry
    for pin in lock['packages']:
        actual = packages.get(pin['Package'], {})
        if any(actual.get(key) != value for key, value in pin.items()):
            raise RuntimeError('LLVM package differs from the signed index: ' + pin['Package'])
        archive = cache / Path(pin['Filename']).name
        download(lock['llvm_repository'] + pin['Filename'], archive, int(pin['Size']), pin['SHA256'], args.jobs)
        prep.run(['dpkg-deb', '-x', archive, cache / 'extracted'])
    extracted = cache / 'extracted'
    prep.run(['sudo', '-n', 'env', 'DEBIAN_FRONTEND=noninteractive', 'NEEDRESTART_MODE=l',
              'apt-get', 'install', '-y', '--no-install-recommends', 'libz3-4', 'libpfm4'])
    library = extracted / 'usr/lib/x86_64-linux-gnu'
    tools = extracted / 'usr/lib/llvm-24/bin'
    wrapper = prep.root / 'cache/mac-aux/bin'
    wrapper.mkdir(parents=True, exist_ok=True)
    info = {}
    for name in ['dsymutil', 'llvm-otool', 'llvm-dwarfdump']:
        path = tools / name
        if not path.is_file():
            raise RuntimeError('Required auxiliary executable is missing: ' + name)
        entry = wrapper / name
        entry.write_text('#!/bin/sh\nexec env ' + shlex.quote('LD_LIBRARY_PATH=' + str(library))
                         + ' ' + shlex.quote(str(path)) + ' "$@"\n', encoding='utf-8')
        entry.chmod(0o755)
        version = prep.run([entry, '--version'], capture=True).stdout
        info[name] = {'path': str(entry), 'wrapper_sha256': digest_file(entry),
                      'executable': str(path.resolve()), 'executable_sha256': digest_file(path), 'version': version}
    runtime = lock['mac_compiler_rt']
    archive = prep.root / 'downloads/clang/Mac' / runtime['url'].rsplit('/', 1)[1]
    archive.parent.mkdir(parents=True, exist_ok=True)
    download(runtime['url'], archive, runtime['bytes'], runtime['sha256'], args.jobs)
    if hashlib.md5(archive.read_bytes()).hexdigest() != runtime['md5']:
        raise RuntimeError('Pinned original macOS compiler-rt GCS MD5 changed')
    installer = args.installer.resolve() if args.installer else prep.src / 'tools/clang/scripts/update.py'
    data = installer.read_bytes()
    blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
    expected = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', 'tools/clang/scripts/update.py', capture=True).stdout.split()[2]
    if blob != expected:
        raise RuntimeError('The original Clang runtime installer does not match the actual Git tree')
    compiler = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
    expected_compiler = json.loads((prep.root / 'state/clang-prefetched.json').read_text('utf-8'))['compiler_sha256']
    if digest_file(compiler) != expected_compiler:
        raise RuntimeError('The original locked Chromium compiler changed')
    spec = importlib.util.spec_from_file_location('mycef_original_mac_runtime_update', installer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.PACKAGE_VERSION != VERSION:
        raise RuntimeError('The Darwin runtime and actual Clang package versions differ')
    module.CDS_URL = (prep.root / 'downloads/clang').as_uri()
    module.DownloadAndUnpackClangMacRuntime(str(compiler.parent.parent))
    if digest_file(compiler) != expected_compiler:
        raise RuntimeError('Auxiliary installation unexpectedly replaced the main compiler')
    dependencies = prep.run(['dpkg-query', '-W', '-f=${Package} ${Version}\n', 'libz3-4', 'libpfm4'], capture=True).stdout
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'lock_sha256': digest_file(HERE / 'mac-aux-lock.json'),
               'tools': info, 'llvm_shared_library_sha256': digest_file(library / 'libLLVM.so.24.0'),
               'host_dependencies': dependencies, 'main_clang_sha256': expected_compiler,
               'darwin_runtime_archive_sha256': digest_file(archive), 'original_runtime_installer_git_blob': blob,
               'auxiliary_execution_verified': True, 'full_cef_build_verified': False,
               'scope': 'Signed LLVM package provenance, Linux debug/inspection tools execution, and exact original compiler-rt installation. Separate Mach-O/dSYM roundtrip and full CEF build/runtime remain required.'}
    write_json(prep.root / 'state/mac-aux-tools-verified.json', receipt)
    print('MACOS_AUXILIARY_TOOLS_AND_ORIGINAL_RUNTIME_PREPARED', flush=True)


if __name__ == '__main__':
    main()
