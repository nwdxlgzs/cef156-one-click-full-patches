# macOS CEF 构建预研

11 月 9 日后续进展（Linux 始终在实际编译）：新增 `package_macos.py`、`validate_macos_clients.py`、`finalize_macos.py` 和 `mac_release_runner.py`，串接真实分发器、所有运行库 / Helper 的 UUID 与完整 dSYM 校验、独立公共 SDK 客户端、归档逐文件回读和清理。macOS 后续服务已安装并运行，等待 Linux 两套最终归档和回收后，才编 ARM64 → x64。完整 CEF SDK 尚未打包，不能用这些入口文件代替产物完成证据。

两种 CPU 的独立 CMake C++20 / AppKit 工具链实际编译 / 链接通过。另从真实 CEF 源码、真实 GN 生成头文件和原分发器 CMake / transfer 逻辑准备开发输入，ARM64 沙箱 ON / OFF 两套公共 wrapper、主程序及八个 Helper 共十个 Mach-O 已实际编译 / 链接；用符号表确认只有 ON 版本链接沙箱初始化。该预检没有 CEF 引擎，不是成品 SDK 或 macOS 运行验证。回执 `validation/mac-public-client-development-preflight.json`。过程修正了显式 Objective-C++20、原模板 12.0 与本引擎 13.0 的部署版本不一致，以及 Chromium 工具包没有 llvm-ranlib 别名的问题；后者使用原 llvm-ar 的真实 ranlib 调用方式，不跳过索引生成。

打包会把原分发器之外的 ANGLE / Vulkan / 示例 / Helper dSYM 一并保留，按运行库 CPU / UUID 匹配并执行 DWARF 语义校验；随后对实际 SDK 再独立编译公共客户端。macOS 实机执行和 Apple 分发签名不由 Linux 交叉编译冒充，归档回执会明确保留这两项未验证状态。


2026-11-09 最新实测：Linux x64 正在真实 Ninja 编译期间，两套 macOS（ARM64 / x64）完整 GN 均已通过。使用原 SDK 26.5 / 25F70、Clang 24 和真实 Linux 辅助工具；`mac-sdk-prepared.json` 现在仅表示 GN 接入已通过，`cef_built` 仍为 false。ARM64 / x64 完整 Ninja dry-run 的 67,836 / 65,713 项输入均已解析成功；这些不是 CEF 编译完成记录。后文为前期研究历史，以本段和最新 validation 回执为准。

新增 `mac-linux-host-tools.patch` 只提供一个专用 Linux host toolchain 文件，保持 macOS 目标的 CDM host verification / storage ID / RLZ 要求，同时禁止这些仅 Mac/Windows 的设置流入 Linux 上运行的构建工具；macOS GN 显式使用 `use_system_xcode=false`。Linux 当前构建的任何既有源文件和参数均未因这个新增文件改动。已准备的树允许校验原始完整清单、原有文件不变后追加补丁；原清单、原源码哈希和旧回执继续保留，四项实际 Git 的迁移 / 拒绝测试在 Windows 和 Ubuntu 均通过。

记录日期：2026-11-09。本文件记录 macOS 构建的可行性研究，完整 CEF 支持尚未跑通。Windows 三套已完成，用户已提供 Linux 服务器并恢复新 goal，顺序仍为 Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64；接续、估时和快照缓存见 `NEXT-BUILDS.zh-CN.md`，实际状态见 `LINUX-HANDOFF.zh-CN.md`。

目前已提前从 Apple 公开更新源取得并验证 CLT 27.2 / 26.6 的 SDK-only 包，27.2 SDK 已解出。固定 Clang 已实际安装；ARM64 / x86_64 两种 CPU 的 C / CoreFoundation、Objective-C++ / Cocoa、C++20 / SDK libc++ 编译和链接六项均通过，Mach-O CPU 已检查，回执为 `validation/mac-cross-compiler-smoke.json`。CEF 的目标参数策略也已按四个目标检查，Python 宿主平台保持原值。这里是基础工具链预备，不改变四套正式 SDK 的发布顺序；CEF、Chromium 自带 libc++ 集成、资源 / Helper、符号与 macOS 实机运行仍未验证。

用户约束：目前无法租赁 Mac 服务器。因此后续可行性优先按只有 Windows / Linux 服务器评估，不把购置、借到或租到 Mac 主构建机作为前提。

用户于 11 月 9 日要求 Linux 优先：以下预备成果保留，新的 macOS 预研等 Linux 正式编译期间再做。已新增但未接入最终包的 `audit_macho.py`，在实际 ARM64/x64 小程序 / 匹配 dSYM 上验证了 CPU、UUID、完整 DWARF 段、最低版本与错误输入拒绝；见 `validation/macho-audit-preflight.json`。`macos_distrib.py --policy-only` 已对固定原 CEF 分发器的真实参数策略检查两架构，不修改 Python 宿主平台，选择明确 macOS 目标和实际 `_mac` 构建目录；见 `validation/mac-distributor-policy-*.json`。尚未执行真实 CEF SDK 分发、完整符号 / 独立客户端 / macOS 运行验证。

Linux 主包缺少的 dsymutil / llvm-otool 已由独立辅助工具补上：`prepare_macos_aux.py` 验证包的 LLVM 官方 Release 签名、索引和固定 SHA256，不改变主 Clang。与其版本完全相同的 Darwin compiler-rt 也已通过原始 Chromium 安装器装好。两种 CPU 的真实小程序已实际生成 dSYM，UUID 匹配、DWARF 验证、依赖读取均通过，记录在 `validation/mac-cross-compiler-smoke.json` 的 debug_results。正式 CEF 的 GN 接入、大体积符号和 Framework / Helper 打包仍待处理。

CLT 26.6 的 SDK-only 包已实际解出 SDK **26.5 / 25F70**，与固定源码的 universal SDK 配置完全一致；两种 CPU 的六项编译 / 链接和两项 dSYM / UUID / DWARF 预检均通过。原始 SDK 文件未改写，记录在 `validation/apple-sdk-extracted-universal.json` 和 `validation/mac-cross-compiler-universal-smoke.json`。优先核查这条原版本匹配路线，保留已验证的 27.2 SDK 作研究缓存；完整 GN / CLT 元数据接入仍未完成。

`mac_sdk_metadata.py` 已从原始 PackageInfo / SDK / 编译和 dSYM 回执取得真实元数据，并保留完整 SDK 文件 / 链接清单；重复执行会拒绝已观察目录的变化。新增 `prepare_macos_gn_inputs.py` 校验 SDK、原 Clang 和独立 LLVM 辅助工具，再生成明确的 GN 输入。`mac-linux-cross-sdk.patch` 已对真实固定源码通过应用检查，五个 GN 文件经固定 GN 2574 实际解析和格式化；回执 `validation/mac-cross-sdk-source-patch.json`。它在 Linux 分支按 CLT 兼容版本选择上游 module map，并使用真实 Linux dsymutil / otool；原生 macOS 仍走原 Xcode 路线。产物 plist 的 SDK / CLT 字段与实际来源一致，省略未知的 DTXcode / DTXcodeBuild。

这次仅完成 SDK 源码接入的应用 / 语法检查；完整 `gn gen` 仍待 Linux 源码同步和 hooks。初始同步会替换早期安装的工具链目录，新的 hooks 入口会用已验证缓存经原安装器复原 Clang / Rust。不能用旧预取回执跳过实际工具检查。尚未生成 `mac-gn-inputs-prepared.json` 或 `mac-sdk-prepared.json`；framework / Helper 打包、签名和 macOS 目标运行仍未完成。

菜单资源已有实际预检：`mac_menu_source.py` 严格读取四个原始 menu-only XIB，保留菜单 / 项目 / selector / 目标 / tag / 快捷键、Services / Window / Help 注册；Recent Documents 用公开 NSDocumentController API 生成。未知界面对象 / outlet 会明确拒绝。固定 Clang / SDK 26.5 下，两种 CPU × ARC / 手动内存管理 × 四个原始输入共 **16** 份实际 Mach-O 对象编译通过，回执 `validation/mac-menu-source-smoke.json`。`mac-linux-menu-resources.patch` 接入 Linux 分支的实际 CEF GN 模板，以真实 action → source_set 依赖生成编译菜单，并仅在该分支去掉 plist 的 MainMenu 自动加载键、显式安装菜单；原生 CMake 仍使用原 XIB / ibtool。隔离提取的同一 GN 模板已实际生成 Ninja 并编译四份菜单 / 四份依赖宏的 owner 对象，四套原 plist 除 MainMenu 键外全部字段一致；见 `validation/mac-menu-gn-preflight.json`、`validation/mac-menu-source-patch.json`。这些不是完整 CEF GN 或 macOS 菜单实际运行结果，Recent Documents 等目标行为仍待实机验证。

- 需要覆盖 Intel x86_64 与 Apple Silicon arm64。固定 Chromium 156.0.8071.0 的 `docs/mac_arm64.md` 明确支持在 Intel Mac 上构建 arm64，也支持在 ARM64 Mac 上构建 x64；编译本身不需要 Rosetta。
- 固定 CEF 提交 `a26ddfd2792604564986b31ea298e30b09bd9b3f` 的 `docs/automated_build_setup.md` 同时列出两条交叉架构路线。在 ARM64 Mac 构建 x64 使用 `CEF_ENABLE_AMD64=1` 和 `--x64-build`；在 Intel Mac 构建 arm64 使用 `CEF_ENABLE_ARM64=1` 和 `--arm64-build`。这些是官方流程的参考开关，不是本项目当前可执行的一键命令；实际开工仍要固定工具链、适配补丁并取消不需要的 Debug。
- 如果以后已有 Mac，单台主机就可顺序构建两套，无需两种 CPU 各租一台。CEF 文档列出的 Mac 构建下限是 16 GB 内存 / 200 GB 可用空间，本项目完整符号的峰值尚未实测；当前不按此路线采购。
- 构建产物可分别发布 x64 / arm64 SDK。Chromium 也支持将同一源码版本的两套 `.app` 合并为 universal；CEF 产品若采用 Universal 2，需要连同 Framework、Helper 和其他本机依赖完整处理，再验证并签名，不能只合并业务主程序。CEF SDK 通用合并流程在本项目尚未实现。
- 跨 CPU 与跨操作系统分别评估。固定 Chromium 156.0.8071.0 的 `build/config/BUILDCONFIG.gn` 在 `target_os == "mac"` 时明确允许 `host_os == "mac" || host_os == "linux"`，因此 Linux 到 macOS 并非只有理论上的 Clang 支持，已有上游构建基础；Windows 宿主不在允许范围。Apple 工具链也有按 Linux 宿主选择 bundle 复制命令的分支。
- 后续优先研究在 x64 Linux 主机构建 macOS x64 / arm64：准备匹配 SDK、Linux 可执行的 Clang / LLD 及辅助工具；先检查 GN、资源与 Framework / Helper 打包，再完整构建 SDK。OSXCross 可作为辅助工具来源，不预先认定必须用它替换 Chromium 自带工具链。CEF 的 `gn_args.py` 当前按 `sys.platform` 判断平台，CEF hook / SDK 打包需要逐项确认目标平台与宿主平台是否分离。上游 GN 允许这条路线，不代表本项目已经验证完整 CEF 构建成功。
- CEF 官方自动构建说明的 macOS 一节使用 macOS + Xcode，不能将该文档直接当成 Linux 跨系统的一键教程。Linux 跨系统构建仍需实测；Apple SDK 或某个打包工具不可获取 / 不可执行时，应记录具体问题，不把未知问题提前表述为必须购买 Mac。
- 固定 Chromium 的 `build/config/mac/mac_sdk.gni` 默认 `mac_deployment_target` 和 `mac_min_system_version` 都是 13.0。支持两种 CPU 不代表支持所有旧版 macOS。若以后需要降低系统版本，应另立具体兼容目标并适配、实测，不能只修改版本数字或套用 Win7 补丁。
- x64 构建完成与在原生 Intel Mac 上运行通过是不同证据；ARM64 同理。正式发布仍需覆盖两种 CPU，以及计划承诺的 macOS 版本和图形 / 媒体 / 沙箱功能。

来源（固定版本优先）：

- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/docs/mac_arm64.md
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/docs/mac_build_instructions.md
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/build/config/mac/mac_sdk.gni
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/build/config/BUILDCONFIG.gn
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/build/toolchain/apple/toolchain.gni
- https://raw.githubusercontent.com/chromiumembedded/cef/a26ddfd2792604564986b31ea298e30b09bd9b3f/docs/automated_build_setup.md
- https://raw.githubusercontent.com/chromiumembedded/cef/a26ddfd2792604564986b31ea298e30b09bd9b3f/tools/gn_args.py
- https://raw.githubusercontent.com/tpoechtrager/osxcross/master/README.md
- https://developer.apple.com/documentation/apple-silicon/building-a-universal-macos-binary
