#!/usr/bin/env python3
"""Verify an Apple SDK-only XAR package using its software-update catalog.

The catalog's Digest identifies the compressed XAR table of contents. Verify
that digest, the stored TOC digest and every archived member checksum before
writing a local whole-file SHA256 receipt. Never execute package scripts.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET
import zlib


def verify(path, expected_toc_sha1, expected_size):
    path = Path(path)
    if path.stat().st_size != expected_size:
        raise ValueError('Apple SDK package length differs from the catalog')
    with path.open('rb') as stream:
        header = stream.read(28)
        magic, header_size, version, compressed_size, raw_size, algorithm = struct.unpack('>IHHQQI', header)
        if magic != 0x78617221 or version != 1 or header_size != 28 or algorithm != 1:
            raise ValueError('Unsupported XAR header or TOC checksum algorithm')
        if compressed_size > 16 * 1024 * 1024 or raw_size > 64 * 1024 * 1024:
            raise ValueError('Unreasonable XAR TOC length')
        compressed = stream.read(compressed_size)
        digest = hashlib.sha1(compressed).hexdigest()
        if len(compressed) != compressed_size or digest != expected_toc_sha1:
            raise ValueError('XAR TOC differs from the official software-update catalog Digest')
        raw = zlib.decompress(compressed)
        if len(raw) != raw_size:
            raise ValueError('XAR decompressed TOC length mismatch')
        toc = ET.fromstring(raw).find('toc')
        if toc is None:
            raise ValueError('XAR table of contents missing')
        heap = header_size + compressed_size
        checksum = toc.find('checksum')
        if checksum is None or checksum.get('style') != 'sha1' or checksum.findtext('size') != '20':
            raise ValueError('Unexpected XAR TOC checksum layout')
        stream.seek(heap + int(checksum.findtext('offset')))
        if stream.read(20).hex() != digest:
            raise ValueError('Stored XAR TOC checksum mismatch')
        members = []
        for entry in toc.findall('file'):
            name = entry.findtext('name')
            if name not in ('Payload', 'Bom', 'PackageInfo'):
                raise ValueError('Unexpected SDK-only XAR entry: ' + str(name))
            metadata = entry.find('data')
            if metadata is None:
                raise ValueError('Missing XAR archived member data')
            checksum = metadata.find('archived-checksum')
            if checksum is None or checksum.get('style') not in ('sha1', 'sha256'):
                raise ValueError('Unsupported XAR member checksum')
            offset, length = int(metadata.findtext('offset')), int(metadata.findtext('length'))
            if offset < 0 or length < 0 or heap + offset + length > expected_size:
                raise ValueError('XAR member outside the package')
            stream.seek(heap + offset)
            h = hashlib.new(checksum.get('style'))
            remaining = length
            while remaining:
                chunk = stream.read(min(4 * 1024 * 1024, remaining))
                if not chunk:
                    raise ValueError('Truncated XAR archived member')
                h.update(chunk)
                remaining -= len(chunk)
            if h.hexdigest() != checksum.text:
                raise ValueError('XAR member checksum mismatch: ' + name)
            members.append({'name': name, 'offset': heap + offset, 'length': length,
                            'checksum_algorithm': checksum.get('style'), 'checksum': checksum.text})
        if {m['name'] for m in members} != {'Payload', 'Bom', 'PackageInfo'}:
            raise ValueError('SDK-only package entries are incomplete')
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return {'path': str(path.resolve()), 'bytes': expected_size, 'sha256': h.hexdigest(),
            'catalog_xar_toc_sha1': digest, 'members': members,
            'scope': 'Official HTTPS catalog TOC digest, stored TOC digest and every archived member checksum match. No package scripts executed; SDK contents and compiler compatibility are separate checks.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--package', required=True)
    parser.add_argument('--catalog-toc-sha1', required=True)
    parser.add_argument('--catalog-bytes', required=True, type=int)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    report = verify(args.package, args.catalog_toc_sha1, args.catalog_bytes)
    report['observed_utc'] = dt.datetime.now(dt.timezone.utc).isoformat()
    Path(args.report).write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print('APPLE_SDK_XAR_VERIFIED ' + report['sha256'], flush=True)


if __name__ == '__main__':
    main()
