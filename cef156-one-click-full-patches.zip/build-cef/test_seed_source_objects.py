"""Exercise real Git blob imports from a tiny archive, including failures."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
from unittest import mock

import seed_source_objects as seed
import complete_source_objects as snapshot
import prefetch_source_archive as archive_cache


class SeedTests(unittest.TestCase):
    def test_missing_promisor_blob_is_audited_without_an_implicit_fetch(self):
        with tempfile.TemporaryDirectory(prefix='mycef-promisor-audit-') as temporary:
            root = Path(temporary)
            repository = root / 'metadata.git'
            subprocess.run(['git', 'init', '--bare', '-q', str(repository)], check=True)
            for key, value in [('remote.origin.url', 'http://127.0.0.1:9/mycef-no-network'),
                               ('remote.origin.promisor', 'true'),
                               ('extensions.partialClone', 'origin')]:
                subprocess.run(['git', '-C', str(repository), 'config', key, value], check=True)
            blob = subprocess.check_output(['git', '-C', str(repository), 'hash-object', '-w', '--stdin'],
                                           input=b'present fixture').decode().strip()
            trace = root / 'git-trace.log'
            required = {blob: ['present.txt'], '1' * 40: ['omitted.txt']}
            missing = snapshot.missing_blobs(repository, required,
                {**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_TRACE': trace.as_posix()})
            self.assertEqual(missing, ['1' * 40])
            self.assertNotIn('fetch', trace.read_text(encoding='utf-8'))

    def test_verified_archive_cache_skips_network_and_only_cleans_known_pieces(self):
        with tempfile.TemporaryDirectory(prefix='mycef-archive-cache-tests-') as temporary:
            root = Path(temporary)
            output = root / 'chromium-156.0.8071.0.tar.xz'
            output.write_bytes(b'verified archive fixture')
            parts = root / 'chromium-official-parts'
            parts.mkdir()
            (parts / '0000.part').write_bytes(b'old piece')
            (parts / 'unrelated.txt').write_bytes(b'keep')
            with mock.patch.multiple(archive_cache, SIZE=output.stat().st_size,
                                     MD5=hashlib.md5(output.read_bytes()).hexdigest()), \
                 mock.patch('sys.argv', ['prefetch_source_archive.py', '--directory', str(root)]), \
                 mock.patch.object(archive_cache.subprocess, 'run') as download:
                archive_cache.main()
                archive_cache.main()
                download.assert_not_called()
            self.assertFalse((parts / '0000.part').exists())
            self.assertEqual((parts / 'unrelated.txt').read_bytes(), b'keep')
            self.assertTrue(output.with_suffix('.xz.verified.json').exists())

    def test_real_commit_is_preserved_and_incomplete_archive_is_rejected(self):
        with tempfile.TemporaryDirectory(prefix="mycef-seed-tests-") as temporary:
            root = Path(temporary)
            original = root / "original"
            original.mkdir()
            def git(path, *args, **kwargs):
                return subprocess.run(["git", "-C", str(path), *args], check=True,
                                      capture_output=True, **kwargs).stdout
            git(original, "init", "-q")
            (original / "one.txt").write_bytes(b"one\n")
            (original / "two.txt").write_bytes(b"two\n")
            git(original, "add", ".")
            git(original, "-c", "user.name=Fixture", "-c", "user.email=fixture@example.invalid", "commit", "-qm", "fixture")
            commit = git(original, "rev-parse", "HEAD").decode().strip()
            tree = git(original, "rev-parse", "HEAD^{tree}").decode().strip()
            repository = root / "metadata.git"
            repository.mkdir()
            git(repository, "init", "--bare", "-q")
            for kind, oid in [("tree", tree), ("commit", commit)]:
                body = git(original, "cat-file", kind, oid)
                actual = git(repository, "hash-object", "-t", kind, "-w", "--stdin", input=body).decode().strip()
                self.assertEqual(actual, oid)
            git(repository, "update-ref", "refs/tags/156.0.8071.0", commit)
            archive = root / "source.tar.xz"
            record = root / "complete.json"
            for complete in [False, True]:
                with tarfile.open(archive, "w:xz") as tar:
                    for name, body in [("one.txt", b"one\n"), ("two.txt", b"two\n" if complete else b"WRONG\n")]:
                        item = tarfile.TarInfo(seed.PREFIX + name)
                        item.size = len(body)
                        tar.addfile(item, io.BytesIO(body))
                with mock.patch.multiple(seed, COMMIT=commit, SIZE=archive.stat().st_size,
                                         MD5=hashlib.md5(archive.read_bytes()).hexdigest()):
                    if complete:
                        seed.seed(repository, archive, record)
                    else:
                        with self.assertRaisesRegex(RuntimeError, "still missing"):
                            seed.seed(repository, archive, record)
                        self.assertFalse(record.exists())
                self.assertEqual(git(repository, "rev-parse", "refs/tags/156.0.8071.0").decode().strip(), commit)
            result = json.loads(record.read_text("utf-8"))
            self.assertEqual(result["verified_blobs"], 2)
            self.assertEqual(result["missing_paths"], [])
            # A failed network pack can contain usable, genuine objects.
            # Recovery's nonzero status must never substitute for checking
            # the real commit's entire required object set.
            recovered = root / 'recovered.git'
            recovered.mkdir()
            git(recovered, 'init', '--bare', '-q')
            for kind, oid in [('tree', tree), ('commit', commit)]:
                git(recovered, 'hash-object', '-t', kind, '-w', '--stdin',
                    input=git(original, 'cat-file', kind, oid))
            broken = root / 'interrupted.pack'
            broken.write_bytes(git(original, 'pack-objects', '--revs', '--all', '--stdout', input=b'')[:-20])
            recovered_record = root / 'recovered.json'
            with mock.patch.object(snapshot, 'COMMIT', commit), mock.patch('sys.argv', [
                'complete_source_objects.py', '--repository', str(recovered),
                '--record', str(recovered_record), '--recover-pack', str(broken)]):
                snapshot.main()
            result = json.loads(recovered_record.read_text('utf-8'))
            self.assertNotEqual(result['recovery_exit'], 0)
            self.assertEqual(result['verified_blobs'], 2)
            self.assertEqual(result['missing_paths'], [])


if __name__ == "__main__":
    unittest.main()
