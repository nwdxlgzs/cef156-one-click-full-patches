#!/usr/bin/env python3
"""Create an independent Release development SDK; never modify its source archive."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import datetime as dt
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import plistlib
import shutil
import stat
import struct
import subprocess
import tarfile
import zipfile

VERSION = '156.0.8071.0'
HERE = Path(__file__).resolve().parent
BAD_SUFFIXES = ('.pdb', '.debug', '.dwo', '.dwp', '.ilk', '.exp', '.map')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


@contextmanager
def zstd_reader(path):
    try:
        import zstandard
    except ImportError:
        proc = subprocess.Popen(['zstd', '-dc', str(path)], stdout=subprocess.PIPE)
        try:
            yield proc.stdout
        finally:
            proc.stdout.close()
            if proc.wait():
                raise RuntimeError('zstd decompression failed')
    else:
        with path.open('rb') as f, zstandard.ZstdDecompressor().stream_reader(f) as reader:
            yield reader


@contextmanager
def zstd_writer(path):
    try:
        import zstandard
    except ImportError:
        with path.open('wb') as f:
            proc = subprocess.Popen(['zstd', '-8', '-T2', '-c'], stdin=subprocess.PIPE, stdout=f)
            try:
                yield proc.stdin
            finally:
                proc.stdin.close()
                if proc.wait():
                    raise RuntimeError('zstd compression failed')
    else:
        with path.open('wb') as f, zstandard.ZstdCompressor(level=8, threads=2).stream_writer(f) as writer:
            yield writer


def selected(name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name:
        raise RuntimeError('Unsafe archive entry: ' + name)
    if not p.parts:
        return None
    if any(part.endswith('.dSYM') for part in p.parts) or name.lower().endswith(BAD_SUFFIXES):
        return None
    first = p.parts[0]
    if first in ('include', 'libcef_dll', 'cmake', 'licenses'):
        # Bazel recipes refer to the original large sample tree.
        if p.name in ('BUILD.bazel', 'MODULE.bazel'):
            return None
        return name
    if first == 'tests' and len(p.parts) > 2 and p.parts[1] == 'cefsimple':
        if p.name == 'BUILD.bazel':
            return None
        return 'demos/common/' + '/'.join(p.parts[2:])
    if first in ('Release', 'Resources'):
        if p.name in ('cefsimple', 'cefclient', 'cefsimple.exe', 'cefclient.exe'):
            return None
        if p.suffix == '.lib' and p.name != 'libcef.lib':
            return None
        if first == 'Resources':
            return 'Release/' + '/'.join(p.parts[1:])
        return name
    if len(p.parts) == 1 and (p.name in ('LICENSE', 'LICENSE.txt', 'CREDITS.html')
                            or p.name in ('MYCEF_BUILD.json', 'MYCEF_FEATURES.json', 'MYCEF_args.gn')):
        return name
    return None


def extract(archive, sdk):
    files, links = {}, []

    def copy(name, stream, mode, link=None):
        relative = selected(name)
        if relative is None:
            return
        destination = sdk / relative
        if relative in files:
            raise RuntimeError('Duplicate/merged archive destination: ' + relative)
        destination.parent.mkdir(parents=True, exist_ok=True)
        if link is not None:
            link_path = PurePosixPath(relative).parent / link
            # Framework aliases use relative .. links within the SDK tree.
            resolved = (destination.parent / link).resolve()
            if sdk.resolve() not in resolved.parents or os.path.isabs(link):
                raise RuntimeError('Symlink escaped SDK: ' + relative)
            links.append((destination, link))
            files[relative] = {'source': name, 'symlink': link}
            return
        with destination.open('wb') as output:
            shutil.copyfileobj(stream, output, 8 * 1024 * 1024)
        os.chmod(destination, mode & 0o777)
        files[relative] = {'source': name, 'source_bytes': destination.stat().st_size,
                           'source_sha256': digest(destination), 'mode': mode & 0o777}

    if archive.suffix == '.zip':
        with zipfile.ZipFile(archive) as z:
            for entry in z.infolist():
                if entry.is_dir() or selected(entry.filename) is None:
                    continue
                mode = entry.external_attr >> 16
                with z.open(entry) as f:
                    copy(entry.filename, f, mode or 0o644)
    else:
        # Streaming avoids creating the original multi-GB debug-only tar file.
        with zstd_reader(archive) as reader:
            with tarfile.open(fileobj=reader, mode='r|') as tar:
                prefix = None
                for entry in tar:
                    parts = PurePosixPath(entry.name).parts
                    if not parts:
                        continue
                    if prefix is None:
                        prefix = parts[0]
                    if parts[0] != prefix:
                        raise RuntimeError('Unexpected multiple SDK roots')
                    relative = '/'.join(parts[1:])
                    if not relative or entry.isdir():
                        continue
                    if entry.issym():
                        copy(relative, None, entry.mode, entry.linkname)
                    elif entry.isfile():
                        if selected(relative) is not None:
                            copy(relative, tar.extractfile(entry), entry.mode)
                    elif entry.islnk() and selected(relative) is not None:
                        raise RuntimeError('Hardlinks need explicit resolution: ' + relative)
    for path, link in links:
        path.symlink_to(link, target_is_directory=(path.parent / link).is_dir())
    return files


def elf_runtime(path):
    """Hash every allocatable section and loader contract, excluding debug metadata."""
    with path.open('rb') as f:
        header = f.read(64)
        if header[:6] != b'\x7fELF\x02\x01':
            raise RuntimeError('Expected little-endian ELF64: ' + str(path))
        fields = struct.unpack('<16sHHIQQQIHHHHHH', header)
        _, kind, machine, version, entry, phoff, shoff, flags, _, phsize, phnum, shsize, shnum, shstr = fields
        f.seek(shoff)
        raw = [f.read(shsize) for _ in range(shnum)]
        sections = [struct.unpack('<IIQQQQIIQQ', s[:64]) for s in raw]
        names_header = sections[shstr]
        f.seek(names_header[4]); names = f.read(names_header[5])
        allocated, debug = [], []
        for s in sections:
            name = names[s[0]:].split(b'\0', 1)[0].decode()
            if name.startswith(('.debug', '.zdebug')) or name == '.gdb_index':
                debug.append(name)
            if s[2] & 2:  # SHF_ALLOC, including dynamic symbols and version needs
                f.seek(s[4])
                h = hashlib.sha256()
                if s[1] != 8:  # NOBITS has no file payload
                    remaining = s[5]
                    while remaining:
                        block = f.read(min(remaining, 8 * 1024 * 1024))
                        if not block:
                            raise RuntimeError('Truncated ELF')
                        h.update(block); remaining -= len(block)
                allocated.append((name, s[1], s[2], s[3], s[5], s[8], s[9], h.hexdigest()))
        f.seek(phoff)
        programs = [struct.unpack('<IIQQQQQQ', f.read(phsize)[:56]) for _ in range(phnum)]
        return {'header': [kind, machine, version, entry, flags],
                'program_headers': programs, 'allocated_sections': allocated}, debug


def strip_linux(sdk, objcopy):
    reports = []
    for path in sorted((sdk / 'Release').rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        with path.open('rb') as f:
            magic = f.read(4)
        if magic != b'\x7fELF':
            continue
        before, _ = elf_runtime(path)
        original_bytes, original_sha = path.stat().st_size, digest(path)
        subprocess.run([str(objcopy), '--strip-unneeded', str(path)], check=True)
        after, debug = elf_runtime(path)
        if before != after or debug:
            raise RuntimeError('Strip changed loader contract/allocated data or left debug sections: ' + str(path))
        reports.append({'file': path.relative_to(sdk).as_posix(), 'original_bytes': original_bytes,
                        'original_sha256': original_sha, 'stripped_bytes': path.stat().st_size,
                        'stripped_sha256': digest(path), 'all_allocated_sections_unchanged': True,
                        'program_headers_unchanged': True, 'debug_sections': debug})
    if not any(p['file'] == 'Release/libcef.so' for p in reports):
        raise RuntimeError('No libcef.so stripped')
    return reports


ROOT_CMAKE = '''cmake_minimum_required(VERSION 3.21)
project(MyCefMinimalDemo LANGUAGES C CXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(APPLE)
  enable_language(OBJC OBJCXX)
endif()
set(CEF_ROOT "${CMAKE_CURRENT_SOURCE_DIR}")
list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")
find_package(CEF REQUIRED)
if(NOT CMAKE_CONFIGURATION_TYPES AND NOT CMAKE_BUILD_TYPE STREQUAL "Release")
  message(FATAL_ERROR "This SDK contains only Release. Set CMAKE_BUILD_TYPE=Release.")
endif()
set(CMAKE_CONFIGURATION_TYPES Release CACHE STRING "Available configuration" FORCE)
add_subdirectory("${CEF_LIBCEF_DLL_WRAPPER_PATH}" libcef_dll_wrapper)
add_subdirectory(demos/common)
PRINT_CEF_CONFIG()
'''


def configure(sdk, target):
    docs = sdk / 'docs'
    docs.mkdir(exist_ok=True)
    build_metadata = sdk / 'MYCEF_BUILD.json'
    original_metadata = docs / 'source-build.json'
    if build_metadata.exists() and not original_metadata.exists():
        build_metadata.rename(original_metadata)
    write_json(build_metadata, {'target': target, 'chromium_version': VERSION,
               'configuration': 'Release', 'distribution_variant': 'stripped-development',
               'debug_symbols_included': False, 'original_build_metadata': 'docs/source-build.json',
               'current_package_manifest': 'STRIP_MANIFEST.json'})
    variables = sdk / 'cmake/cef_variables.cmake'
    text = variables.read_text('utf-8')
    text = text.replace('"${_CEF_ROOT}/Resources"', '"${_CEF_ROOT}/Release"')
    if '# This development SDK deliberately contains a Release engine only.' not in text:
        text += '\n# This development SDK deliberately contains a Release engine only.\n'
        text += 'set(CEF_BINARY_DIR "${_CEF_ROOT}/Release")\nset(CEF_RESOURCE_DIR "${_CEF_ROOT}/Release")\n'
    variables.write_text(text, encoding='utf-8')
    common = sdk / 'demos/common'
    if not (common / 'CMakeLists.txt').is_file():
        raise RuntimeError('Original minimal demo source is missing')
    for path in common.rglob('*'):
        if path.is_file() and path.suffix in ('.cc', '.h', '.mm', '.txt', '.rc'):
            text = path.read_text('utf-8').replace('tests/cefsimple/', 'demos/common/')
            if path.name == 'CMakeLists.txt':
                # Original mac template sets an undefined ${target} before the app exists.
                text = text.replace('    set_target_properties(${target} PROPERTIES\n      CLANG_ENABLE_OBJC_ARC "YES"\n      )', '')
            path.write_text(text, encoding='utf-8')
    if target.startswith('mac-'):
        from mac_menu_source import generate
        code, _ = generate(common / 'mac/English.lproj/MainMenu.xib')
        (common / 'menu.mm').write_text(code, encoding='utf-8')
        cmake = common / 'CMakeLists.txt'
        text = cmake.read_text('utf-8')
        if '  menu.mm\n' not in text:
            text = text.replace('  cefsimple_mac.mm\n', '  cefsimple_mac.mm\n  menu.mm\n')
        text = text.replace('  mac/English.lproj/MainMenu.xib\n', '')
        if 'target_compile_definitions(cefsimple PRIVATE MYCEF_PROGRAMMATIC_MENU)' not in text:
            text += '\nif(OS_MAC)\n  target_compile_definitions(cefsimple PRIVATE MYCEF_PROGRAMMATIC_MENU)\nendif()\n'
        cmake.write_text(text, encoding='utf-8')
        info = common / 'mac/Info.plist.in'
        values = plistlib.loads(info.read_bytes())
        values.pop('NSMainNibFile', None)
        info.write_bytes(plistlib.dumps(values, sort_keys=False))
    (sdk / 'CMakeLists.txt').write_text(ROOT_CMAKE, encoding='utf-8')
    for mode in ('sandbox-on', 'sandbox-off'):
        folder = sdk / 'demos' / mode
        folder.mkdir(exist_ok=True)
        value = 'ON' if mode.endswith('-on') else 'OFF'
        (folder / 'CMakeLists.txt').write_text(
            'cmake_minimum_required(VERSION 3.21)\nproject(MyCefDemo LANGUAGES C CXX)\n'
            f'set(USE_SANDBOX {value} CACHE BOOL "Sandbox selection" FORCE)\n'
            'add_subdirectory("${CMAKE_CURRENT_LIST_DIR}/../.." sdk)\n', encoding='utf-8')
        (folder / 'README.md').write_text(f'# Sandbox {value}\n\n'
            '源码共用 `../common/`，这里固定沙箱开关。\n\n'
            f'在 SDK 根目录执行：\n```sh\ncmake -S demos/{mode} -B out/{mode} -DCMAKE_BUILD_TYPE=Release\n'
            f'cmake --build out/{mode} --config Release --target cefsimple -j 8\n```\n', encoding='utf-8')
    presets = []
    for value in ('on', 'off'):
        presets.append({'name': 'sandbox-' + value, 'generator': 'Ninja',
                        'binaryDir': '${sourceDir}/out/sandbox-' + value,
                        'cacheVariables': {'CMAKE_BUILD_TYPE': 'Release', 'USE_SANDBOX': value.upper(), 'USE_ATL': 'OFF'}})
    write_json(sdk / 'CMakePresets.json', {'version': 3, 'configurePresets': presets,
               'buildPresets': [{'name': p['name'], 'configurePreset': p['name'], 'targets': ['cefsimple']} for p in presets]})
    readme = f'''# CEF {VERSION} 精简开发 SDK：{target}

本目录独立使用，包含 Release 引擎、链接库、全部头文件、C++ wrapper 源码、CMake、许可证和两个沙箱模式的 demo 源码。
`Release/` 合并了运行库、资源包、locales 与快照，发布时复制该目录内的运行文件到应用旁边。
`include/`、`libcef_dll/`、`cmake/` 只用于开发，不需要随业务程序分发。
保留所有 locale、ANGLE、SwiftShader、Vulkan、编解码相关运行文件，不通过删功能缩小体积。
完整 PDB / dSYM / ELF 调试信息、预编译 cefclient / cefsimple、单元测试及构建补丁已移除。原始 SDK 另行保留，可用于崩溃符号化。
这里没有另一个 Debug 引擎；自己的应用可单独调试，但不要把缺失的 Debug 引擎目录当作可用配置。

## 最小示例

`demos/common/` 是实际可编辑的 cefsimple 最小浏览器源码；`demos/sandbox-on/`、`demos/sandbox-off/` 是分别固定开关的独立 CMake 入口。
两种模式共享一份源码和运行库，无需重新编译 CEF。

已安装 CMake、Ninja 和目标架构编译器后，在 SDK 根目录执行：
```sh
cmake --preset sandbox-on
cmake --build --preset sandbox-on
cmake --preset sandbox-off
cmake --build --preset sandbox-off
```
也可通过 `cmake -S demos/sandbox-on -B out/on -DCMAKE_BUILD_TYPE=Release` 使用普通 CMake。
输出在相应构建目录的 `demos/common/Release/`，独立入口则在 `sdk/demos/common/Release/`。
示例默认打开浏览器页面，可用 `--url=file:///绝对路径/index.html` 指定本地页面。两种模式分别使用独立构建目录。

## Windows

使用 Visual Studio 2022 C++ Build Tools / Windows SDK，C++20；在匹配 x64、x86 或 ARM64 的开发者命令行中使用 Ninja 预设。
使用 VS 生成器时添加 `-A x64`、`-A Win32` 或 `-A ARM64`，并在构建时指定 `--config Release`。
ON 生成 `cefsimple.dll`，将同版 `bootstrap.exe` 复制为 `cefsimple.exe`，运行该 EXE。
OFF 直接生成 `cefsimple.exe`。bootstrap 是 Windows 开启沙箱的入口，不能从 ON 发行目录移除。
bootstrapc 是控制台应用可选入口；`libcef.lib` 仅供链接，PDB 不影响程序运行。
图形回退相关 DLL、chrome_elf、各资源和 locales 需要随程序部署。源码的 Win7 兼容补丁保留在原始制作包中。

## Linux

目标架构的 GCC / Clang C++20、CMake、Ninja 及 X11 开发库用于编译示例。应用应由普通用户运行。
ON 要求系统允许用户命名空间，或正确安装同包的 `chrome-sandbox` setuid helper：
```sh
sudo install -D -o root -g root -m 4755 Release/chrome-sandbox /usr/local/libexec/mycef/chrome-sandbox
export CHROME_DEVEL_SANDBOX=/usr/local/libexec/mycef/chrome-sandbox
```
若示例输出目录存在普通 chrome-sandbox 副本，将其换成上述已安装 helper 的符号链接，或由安装器配置正确权限。
OFF 源码会设置 `settings.no_sandbox=true`；客户端关闭沙箱无需另做引擎。
保留随包完整 `libstdc++.so.6` 及许可证，不替换系统库。引擎已在 Linux 4.9 / glibc 2.28 虚拟机中验证；实际 SDK 最高 GLIBC 需求见原始审计。
自己编译的应用也需要使用合适的旧 sysroot，才能保持旧 glibc 兼容。

## macOS

在对应架构 macOS 13+ 上使用 Xcode / Command Line Tools、CMake 和 Ninja；需要时添加 `-DCMAKE_OSX_ARCHITECTURES=arm64` 或 `x86_64`。
运行 `cefsimple.app`，保留 app 内 CEF framework 和所有 Helper 子应用。沙箱 ON/OFF 都需要 Helper。
Framework 目录结构及相对符号链接应保留；建议在 macOS/Linux 用 `tar --zstd -xf 包名.tar.zst` 解压。
macOS SDK 的交叉编译、链接和结构核验不代表 Mac 实机执行或 Apple 分发签名已验证；业务应用自行设置标识并签名。

`STRIP_MANIFEST.json` 记录原包摘要、精简前后库摘要和检查范围；`SHA256SUMS.json` 是本目录最终文件清单。
'''
    (sdk / 'README.zh-CN.md').write_text(readme, encoding='utf-8')


def archive_sdk(sdk, archive):
    temporary = archive.with_name(archive.name + '.pending')
    paths = sorted(p for p in sdk.rglob('*') if p.is_file() or p.is_symlink())
    if archive.suffix == '.zip':
        with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as z:
            for path in paths:
                z.write(path, sdk.name + '/' + path.relative_to(sdk).as_posix())
        with zipfile.ZipFile(temporary) as z:
            for path in paths:
                h = hashlib.sha256()
                with z.open(sdk.name + '/' + path.relative_to(sdk).as_posix()) as f:
                    for b in iter(lambda: f.read(8 * 1024 * 1024), b''):h.update(b)
                if h.hexdigest() != digest(path):raise RuntimeError('Archive readback mismatch')
    else:
        with zstd_writer(temporary) as w:
            with tarfile.open(fileobj=w, mode='w|', dereference=False) as tar:
                tar.add(sdk, arcname=sdk.name)
        checked = set()
        with zstd_reader(temporary) as reader:
            with tarfile.open(fileobj=reader, mode='r|') as tar:
                for entry in tar:
                    if entry.isdir():continue
                    relative = str(PurePosixPath(entry.name).relative_to(sdk.name))
                    path = sdk / relative
                    if entry.issym():
                        if entry.linkname != os.readlink(path):raise RuntimeError('Archive symlink mismatch')
                    elif entry.isfile():
                        h=hashlib.sha256(); f=tar.extractfile(entry)
                        for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
                        if h.hexdigest()!=digest(path):raise RuntimeError('Archive readback mismatch')
                    else:raise RuntimeError('Unexpected compact archive entry')
                    checked.add(relative)
        if checked != {p.relative_to(sdk).as_posix() for p in paths}:raise RuntimeError('Archive file list mismatch')
    if archive.exists():raise RuntimeError('Archive exists; preserve both results')
    temporary.rename(archive)
    sha = digest(archive)
    archive.with_name(archive.name+'.sha256').write_text(sha+'  '+archive.name+'\n', encoding='ascii')
    return {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha,
            'file_count': len(paths), 'complete_archive_readback_passed': True}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--target',required=True,choices=('windows-x64','windows-x86','windows-arm64','linux-x64','linux-arm64','mac-arm64','mac-x64'))
    parser.add_argument('--destination',type=Path,required=True)
    parser.add_argument('--source-sha256',required=True)
    parser.add_argument('--objcopy',type=Path)
    parser.add_argument('--archive',action='store_true')
    args=parser.parse_args()
    source=args.source.resolve(); dest=args.destination.resolve()
    if digest(source)!=args.source_sha256:raise RuntimeError('Source archive SHA256 mismatch')
    dest.mkdir(parents=True,exist_ok=True)
    sdk=dest/('cef_'+VERSION+'_'+args.target+'_release')
    if sdk.exists():raise RuntimeError('Output exists; retain it and inspect its receipt')
    sdk.mkdir()
    print('EXTRACTING_REQUIRED_FILES',args.target,flush=True)
    files=extract(source,sdk)
    print('EXTRACTED',len(files),flush=True)
    strips=[]
    if args.target.startswith('linux-'):
        if not args.objcopy:raise RuntimeError('Pinned LLVM objcopy required')
        strips=strip_linux(sdk,args.objcopy)
    elif args.target.startswith('mac-'):
        # Mach-O symbols are separated by the original link into dSYM bundles.
        # Never strip signed framework images with a generic ELF/COFF command.
        for path in (sdk/'Release').rglob('*'):
            if path.is_file() and not path.is_symlink():
                with path.open('rb') as f:magic=f.read(4)
                if magic==b'\xcf\xfa\xed\xfe':
                    from audit_macho import inspect
                    if any(x['name'].startswith('__debug') for x in inspect(path)['sections']):
                        raise RuntimeError('Unexpected embedded Mach-O DWARF')
    configure(sdk,args.target)
    if not (sdk/'Release').is_dir() or not (sdk/'include/cef_app.h').is_file():raise RuntimeError('Incomplete SDK')
    for p in sdk.rglob('*'):
        if p.name.endswith('.dSYM') or p.name.lower().endswith(BAD_SUFFIXES):raise RuntimeError('Debug artifact remains')
    manifest={'target':args.target,'source_archive':source.name,'source_archive_sha256':args.source_sha256,
              'configuration':'Release','debug_symbols_removed':True,'original_archive_unchanged':digest(source)==args.source_sha256,
              'selected_original_files':files,'elf_strip':strips,'demo_modes':['sandbox-on','sandbox-off'],
              'runtime_verified_after_strip':False,'demo_build_verified':False,
              'created_utc':dt.datetime.now(dt.timezone.utc).isoformat()}
    write_json(sdk/'STRIP_MANIFEST.json',manifest)
    checks={p.relative_to(sdk).as_posix():({'symlink':os.readlink(p)} if p.is_symlink() else
            {'bytes':p.stat().st_size,'sha256':digest(p)}) for p in sorted(sdk.rglob('*')) if p.is_file() or p.is_symlink()}
    write_json(sdk/'SHA256SUMS.json',checks)
    print('MINIMAL_SDK_PREPARED',sdk, sum(v.get('bytes',0) for v in checks.values()),flush=True)
    if args.archive:
        a=dest/(sdk.name+('.zip' if args.target.startswith('windows-') else '.tar.zst'))
        result=archive_sdk(sdk,a);write_json(dest/(sdk.name+'.verified.json'),result)
        print('MINIMAL_SDK_ARCHIVED',json.dumps(result),flush=True)


if __name__=='__main__':main()
