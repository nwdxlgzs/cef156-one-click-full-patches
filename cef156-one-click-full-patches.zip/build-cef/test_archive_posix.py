import os
from pathlib import Path
import stat
import tempfile
import unittest

from archive_posix import create_archive, digest_file, list_sdk, verify_archive


@unittest.skipIf(os.name == 'nt', 'POSIX modes and real framework symlinks are verified on Linux')
class PosixArchiveTests(unittest.TestCase):
    def test_real_archive_preserves_executables_framework_links_and_payloads(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk = root / 'cef_sdk'
            (sdk / 'Release/Framework.framework/Versions/A').mkdir(parents=True)
            (sdk / 'Release/Framework.framework/Versions/A/library').write_bytes(b'actual binary fixture\x00\xff')
            (sdk / 'Release/Framework.framework/Versions/Current').symlink_to('A', target_is_directory=True)
            (sdk / 'Release/Framework.framework/library').symlink_to('Versions/Current/library')
            executable = sdk / 'Release/cefsimple'
            executable.write_bytes(b'#!/bin/sh\nexit 0\n')
            executable.chmod(0o755)
            archive = root / 'sdk.tar.zst'
            report = create_archive(sdk, archive)
            self.assertTrue(report['modes_symlinks_frame_and_all_file_hashes_verified'])
            self.assertEqual(report['archive_sha256'], digest_file(archive))
            self.assertEqual(report['symlinks'], 2)
            expected = list_sdk(sdk)
            self.assertEqual(expected['Release/cefsimple']['mode'], 0o755)
            expected['Release/cefsimple']['sha256'] = '0' * 64
            with self.assertRaisesRegex(RuntimeError, 'readback SHA256 mismatch'):
                verify_archive(archive, sdk.name, expected)

    def test_outside_symlink_is_rejected_before_compression(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk = root / 'sdk'
            sdk.mkdir()
            (root / 'outside').write_bytes(b'not part of SDK')
            (sdk / 'escape').symlink_to('../outside')
            with self.assertRaisesRegex(RuntimeError, 'escapes the SDK'):
                create_archive(sdk, root / 'sdk.tar.zst')

    def test_completed_archive_can_be_recovered_but_changed_sdk_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sdk = root / 'sdk'
            sdk.mkdir()
            binary = sdk / 'client'
            binary.write_bytes(b'original verified client')
            archive = root / 'sdk.tar.zst'
            initial = create_archive(sdk, archive)
            recovered = create_archive(sdk, archive)
            self.assertEqual(initial['archive_sha256'], recovered['archive_sha256'])
            binary.write_bytes(b'changed client')
            with self.assertRaisesRegex(RuntimeError, 'contents changed'):
                create_archive(sdk, archive)
            self.assertEqual(initial['archive_sha256'], digest_file(archive))


if __name__ == '__main__':
    unittest.main()
