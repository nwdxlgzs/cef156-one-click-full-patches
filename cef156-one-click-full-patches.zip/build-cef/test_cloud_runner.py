"""Resume checks for retaining SDKs when only ARM64 branches are added."""
import argparse
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import zipfile

import build_cef as build
import cloud_runner as cloud


class CloudResumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='mycef-cloud-tests-')
        self.root = Path(self.temp.name)
        self.builder = build.Builder(argparse.Namespace(
            root=str(self.root), jobs=2, build_free_gb=0,
            keep_intermediates=False))
        self.builder.state.mkdir(parents=True)
        self.builder.patch_root = self.root / 'patches'
        (self.builder.patch_root / 'history').mkdir(parents=True)
        self.previous_hash = 'a43a4efc73d3139da466e13b4e2c73458ccd848720375727033eea1d29341d31'
        previous = (build.PATCHES_DIR / 'history' /
                    (self.previous_hash + '.json')).read_bytes()
        (self.builder.patch_root / 'history' /
         (self.previous_hash + '.json')).write_bytes(previous)
        self.current = build.read_json(build.PATCHES_DIR / 'manifest.json')
        self.archive = self.root / 'completed-x64.zip'
        with zipfile.ZipFile(self.archive, 'w') as package:
            package.writestr('MYCEF_BUILD.json', json.dumps({
                'patch_bundle_sha256': self.previous_hash}))
        self.original_archive = self.archive.read_bytes()
        self.marker = self.builder.state / 'complete-x64-Release.json'
        build.write_json(self.marker, {
            'path': str(self.archive), 'sha256': build.sha256(self.archive)})
        self.original_marker = self.marker.read_bytes()

    def tearDown(self):
        self.temp.cleanup()

    def write_manifest(self):
        build.write_json(self.builder.patch_root / 'manifest.json', self.current)

    def test_arm64_fixes_retain_verified_x64_archive_and_provenance(self):
        self.write_manifest()
        with mock.patch.object(self.builder, 'prepare_sources') as prepare:
            cloud.refresh_existing_x64(self.builder)
            prepare.assert_not_called()
        self.assertEqual(self.archive.read_bytes(), self.original_archive)
        self.assertEqual(self.marker.read_bytes(), self.original_marker)

    def test_unrecognized_additive_code_requires_x64_review(self):
        self.current['files']['windows-build/unreviewed.patch'] = '0' * 64
        self.write_manifest()
        with self.assertRaisesRegex(RuntimeError, 'Unrecognized old x64 archive'):
            cloud.refresh_existing_x64(self.builder)

    def test_allowed_name_with_different_content_requires_x64_review(self):
        self.current['files']['windows-build/libwebp-arm64-synchronization.patch'] = '0' * 64
        self.write_manifest()
        with self.assertRaisesRegex(RuntimeError, 'Unrecognized old x64 archive'):
            cloud.refresh_existing_x64(self.builder)

    def test_changed_existing_patch_is_rejected(self):
        self.current['files']['windows-build/bootstrap-sandbox-command-line.patch'] = '0' * 64
        self.write_manifest()
        with self.assertRaisesRegex(RuntimeError, 'existing prepared patch'):
            cloud.refresh_existing_x64(self.builder)


if __name__ == '__main__':
    unittest.main()
