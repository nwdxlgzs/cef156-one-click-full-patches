#!/usr/bin/env python3
"""Actually compile generated menus from all four original CEF XIBs.

This is a Mach-O compiler preflight, not a macOS UI/runtime validation.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import struct
import xml.etree.ElementTree as ET

from archive_posix import digest_file
from mac_menu_source import generate
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    compiler = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang++'
    expected = json.loads((prep.root / 'state/clang-prefetched.json').read_text('utf-8'))['compiler_sha256']
    if digest_file(compiler) != expected:
        raise RuntimeError('The actual original compiler changed')
    sdk = Path(json.loads((prep.root / 'state/mac-sdk-metadata.json').read_text('utf-8'))['sdk_path'])
    stage = prep.root / 'validation/mac-menu-source-smoke'
    stage.mkdir(exist_ok=True)
    results, inputs = [], {}
    for name in ['cefsimple', 'cefclient', 'cefsimple_capi', 'ceftests']:
        xib = prep.src / 'cef/tests' / name / 'mac/English.lproj/MainMenu.xib'
        source, info = generate(xib)
        tree = ET.parse(xib)
        for key, tag in [('items', 'menuItem'), ('menus', 'menu'), ('actions', 'action')]:
            if info[key] != len(tree.findall('.//' + tag)):
                raise RuntimeError('The generator did not preserve every original ' + tag)
        original = stage / (name + '.mm')
        original.write_text(source, encoding='utf-8')
        inputs[name] = info
        for cpu, machine in [('arm64', 0x0100000c), ('x86_64', 0x01000007)]:
            for arc in [True, False]:
                output = stage / (name + '-' + cpu + ('-arc' if arc else '-mrc') + '.o')
                command = [compiler, '-target', cpu + '-apple-macos13.0', '-isysroot', sdk,
                           '-std=c++20', '-fblocks', '-Wall', '-Wextra', '-Werror',
                           '-fobjc-arc' if arc else '-fno-objc-arc', '-c', original, '-o', output]
                prep.run(command)
                magic, actual = struct.unpack_from('<II', output.read_bytes())
                if magic != 0xfeedfacf or actual != machine:
                    raise RuntimeError('The compiled menu object has a different Mach-O architecture')
                results.append({'client': name, 'cpu': cpu, 'arc': arc, 'object_sha256': digest_file(output), 'passed': True})
    record = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'generator_sha256': digest_file(HERE / 'mac_menu_source.py'), 'compiler_sha256': expected,
              'sdk_version': '26.5', 'sdk_build': '25F70', 'inputs': inputs,
              'results': results, 'passed': True, 'macos_runtime_verified': False, 'cef_gn_integration_verified': False,
              'scope': 'All four original menu-only CEF XIBs reconstructed as AppKit source; ARM64/x64 and ARC/manual reference counting actually compiled to matching Mach-O objects. No ibtool stub, CEF GN integration or macOS runtime/menu behavior claim.'}
    write_json(prep.root / 'state/mac-menu-source-smoke.json', record)
    print('MAC_MENU_OBJECTS_ACTUALLY_COMPILED', len(results), flush=True)


if __name__ == '__main__':
    main()
