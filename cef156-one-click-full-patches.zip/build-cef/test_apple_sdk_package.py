import hashlib
from pathlib import Path
import struct
import tempfile
import unittest
import zlib

from apple_sdk_package import verify


def fixture():
    entries, payload = [], bytearray()
    for name, data in [('Payload', b'fixture SDK payload'), ('Bom', b'fixture bill of materials'), ('PackageInfo', b'<pkg-info/>')]:
        offset = 20 + len(payload)
        entries.append(f'<file><name>{name}</name><data><offset>{offset}</offset><length>{len(data)}</length>'
                       f'<archived-checksum style="sha1">{hashlib.sha1(data).hexdigest()}</archived-checksum></data></file>')
        payload.extend(data)
    raw = ('<xar><toc><checksum style="sha1"><offset>0</offset><size>20</size></checksum>' + ''.join(entries) + '</toc></xar>').encode()
    compressed = zlib.compress(raw)
    digest = hashlib.sha1(compressed).digest()
    header = struct.pack('>IHHQQI', 0x78617221, 28, 1, len(compressed), len(raw), 1)
    return header + compressed + digest + payload, digest.hex()


class AppleSdkPackageTests(unittest.TestCase):
    def test_catalog_digest_identifies_toc_then_all_members_are_checked(self):
        data, toc = fixture()
        self.assertNotEqual(hashlib.sha1(data).hexdigest(), toc)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'fixture.pkg'
            path.write_bytes(data)
            report = verify(path, toc, len(data))
        self.assertEqual(report['sha256'], hashlib.sha256(data).hexdigest())
        self.assertEqual(len(report['members']), 3)

    def test_payload_corruption_fails_even_when_catalog_toc_is_intact(self):
        data, toc = fixture()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'fixture.pkg'
            path.write_bytes(data[:-1] + bytes([data[-1] ^ 1]))
            with self.assertRaisesRegex(ValueError, 'member checksum mismatch'):
                verify(path, toc, len(data))

    def test_wrong_catalog_digest_is_rejected(self):
        data, _toc = fixture()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'fixture.pkg'
            path.write_bytes(data)
            with self.assertRaisesRegex(ValueError, 'catalog Digest'):
                verify(path, '0' * 40, len(data))


if __name__ == '__main__':
    unittest.main()
