# Windows ARM64 完成后的接续安排

记录日期：2026-11-08。此文件记录用户明确要求的阶段边界、顺序与容量规划，不是 Linux / macOS 构建入口已实现的声明。

实际进展：Windows x64 / x86 / ARM64 Release 已完成且中间目录已回收，最终审计见 `validation/windows-release-final-audit.json`。用户随后提供 Ubuntu 主机并启动新的 Linux / macOS goal；旧阶段的暂停要求已经履行，新 goal 当前处于 active。Linux 源码与全部真实依赖同步已完成，hooks / POSIX 补丁 / Linux x64 GN 已通过，目前正在实际编译 Linux x64。两套 macOS 的完整 GN 已在 Linux 编译期间通过；POSIX 四套 SDK 产物仍未完成。

## 阶段边界

1. 先完成当前 Windows ARM64 Release：实际编译 / 链接、完整 SDK 压缩与逐文件校验、DLL / PDB GUID/Age 和完整符号检查、独立 ARM64 CMake 客户端链接、成品及验证记录同步。
2. 核对三套 Windows Release 的完成标记与压缩包，清理已验证成功的 ARM64 中间目录；保留源码、工具链、成品、日志及验证记录。Windows on ARM / Win7 目标设备未实测的边界继续明确。
3. 上述完成后按用户要求把当前 goal 设为 paused，报告状态，停止目标工作，等待用户开好 Linux 服务器并恢复任务。现在不暂停正在运行的 Windows 编译，也不创建代替本次交接的自动化任务。

## 后续顺序

仅制作 Release，逐套完成、压缩、验证并回收中间目录，按以下顺序：

| 顺序 | 目标 | 构建方向 |
| --- | --- | --- |
| 1 | Linux x64 | x64 Linux 主机本地构建；受控旧 glibc sysroot |
| 2 | Linux ARM64 | 同一 x64 Linux 主机交叉编译；单独验证架构和 libc / 内核要求 |
| 3 | macOS ARM64 | 优先研究从同一 Linux 主机交叉编译；完整 CEF 工具链 / 打包适配尚待验证 |
| 4 | macOS x64 | 接续使用已验证的 macOS 交叉构建流程，配置与快照按该目标独立处理 |

Linux 仍覆盖 UOS 桌面教育版 V20 E，并尽量降低真实 glibc 需求，Linux 4.9+ 为独立测试要求。macOS 的具体最低系统版本按匹配 SDK 和最终产物验证，不因为与 Linux 共用主机而宣称 Linux 用户态 / 内核目标适用于 macOS。

## 首轮时间估算

按 x64 Linux 主机、16–24 vCPU、32 GB RAM、SSD、约 10–14 路编译、关闭 PGO / ThinLTO、保留 Release 优化及完整符号估算。范围是本项目基于现有 Windows 构建量的工程预算，并非本版本 Linux / macOS 已测得的基准；24 vCPU / 32 GB 不保证比 16 vCPU 线性加速。

| 目标 | 工具链和平台适配已可用后的编译 / 链接 / 打包估算 |
| --- | --- |
| Linux x64 | 4–8 小时 |
| Linux ARM64 | 6–12 小时 |
| macOS ARM64 | 5–10 小时 |
| macOS x64 | 4–8 小时 |

合计约 19–38 小时，可按约 20–40 小时预算。首次源码 / 依赖 / SDK 准备另计，暂按 3–12 小时留量，取决于实际网络 / 镜像。平台适配、降低 glibc 要求、Linux 4.9 / UOS 验证、macOS 工具链障碍不含在纯编译估算内，不能承诺一两天内全部完成；首次可先预留 3–5 天，macOS 首次适配仍可能更久。

## 快照工具提前准备与保留

- 在首轮 Linux 源码 / 工具链准备阶段，一次梳理四个目标的完整 GN / V8 配置、快照工具链、依赖闭包和所需运行数据，建立每目标缓存清单与空间预算。按发布顺序生成必要工具，不为准备四个目标同时保留四个完整 out 目录。
- 每个实际需要的 `mksnapshot`、`v8_context_snapshot_generator` 等构建工具首次生成后，在清理该目标 out 前，把可执行文件、所需动态库 / 数据、匹配的输入 / 输出快照及配置溯源复制到独立缓存目录，并校验副本。缓存归档必须记录精确源码 / V8 / CEF 提交、补丁状态、host / target OS 和 CPU、GN 有效参数、Clang / SDK / sysroot 版本、生成命令和文件 SHA256；工具能运行且配置与输入匹配后才允许复用。
- 工具复用必须接入构建依赖判断。仅把 exe / ELF 放回 out 并修改时间戳，不能让 Ninja 在缺少前置依赖时可靠跳过构建；后续要有明确的预构建输入 / 依赖规则或完整有效缓存集成，不能用伪造完成标记、删依赖边或强制更新时间宣称已复用。
- 架构相同、宿主都是 x64 并不表示工具配置相同。Linux x64、Linux ARM64、macOS ARM64、macOS x64 的工具或数据不能直接通用；完全相同的有效输入可以共享存储，跨目标可复用范围以实际依赖 / 配置证据为准。Windows exe 不作为 Linux 宿主工具复用。
- 固定 Chromium 的 `tools/v8_context_snapshot/v8_context_snapshot.gni` 默认在 Linux 到 macOS 的跨系统构建中关闭 **Blink V8 context snapshot**。这与 V8 的其他启动快照不是同一个开关；实际 CEF / GN 配置可能另有覆盖，正式生成后再核对。对不使用该优化的目标，不预先编译无用的整套 Blink 快照生成器；不为了省时擅自关闭其他已有功能或启动快照。
- 快照工具缓存有明确大小清单。必要工具 / 数据优先保留，大型 obj / PDB / dSYM / 全量编译缓存不无限保留；符号进入交付包，已验证的 out 才回收。磁盘不足时先检查可回收的已完成中间目录，不删除未完成构建或唯一成品。
- 当前只完成了此缓存设计，未宣称已在未来 Linux 服务器构建、导出或验证四套缓存。工具链能运行时尽早做小目标检查，再开始各套完整构建。

## 参考源码

- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/tools/v8_context_snapshot/v8_context_snapshot.gni
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/tools/v8_context_snapshot/BUILD.gn
- https://raw.githubusercontent.com/v8/v8/aacbfce243e57d643ee36e966e5db7352c635269/gni/snapshot_toolchain.gni
- https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/docs/linux/build_instructions.md
