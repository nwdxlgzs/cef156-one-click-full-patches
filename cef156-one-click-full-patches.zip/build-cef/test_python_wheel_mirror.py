import hashlib
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

from python_wheel_mirror import WheelMirror


class WheelResumeTests(unittest.TestCase):
    def test_timeout_preserves_prefix_then_verifies_completed_wheel(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mirror = WheelMirror(root)
            output = root / 'fixture.whl'
            calls = []
            def curl(command, **_kwargs):
                self.assertIn('--continue-at', command)
                path = Path(command[command.index('--output') + 1])
                calls.append(command)
                if len(calls) == 1:
                    path.write_bytes(b'abc')
                    return subprocess.CompletedProcess(command, 28)
                self.assertEqual(path.read_bytes(), b'abc')
                with path.open('ab') as target:
                    target.write(b'def')
                return subprocess.CompletedProcess(command, 0)
            with mock.patch('python_wheel_mirror.subprocess.run', side_effect=curl):
                mirror.download('fixture/fixture.whl', output, hashlib.sha256(b'abcdef').hexdigest())
            self.assertEqual(output.read_bytes(), b'abcdef')

    def test_resumed_content_still_requires_the_original_digest(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mirror = WheelMirror(root)
            output = root / 'fixture.whl'
            def curl(command, **_kwargs):
                Path(command[command.index('--output') + 1]).write_bytes(b'wrong bytes')
                return subprocess.CompletedProcess(command, 0)
            with mock.patch('python_wheel_mirror.subprocess.run', side_effect=curl):
                with self.assertRaisesRegex(ValueError, 'SHA256 mismatch'):
                    mirror.download('fixture/fixture.whl', output, '0' * 64)
            self.assertFalse(output.exists())
            self.assertFalse(output.with_suffix('.whl.partial').exists())


if __name__ == '__main__':
    unittest.main()
