#!/usr/bin/env python3
"""Compile real C++20/filesystem/exception probes for the packaged runtimes."""
import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess

from archive_posix import digest_file
from audit_elf import inspect, MACHINES, version_key
from prepare_posix import Preparation, write_json


def prepare(prep, cpu):
    runtime = json.loads((prep.root / 'state/linux-cxx-runtime.json').read_text('utf-8'))['targets'][cpu]
    library = Path(runtime['library'])
    if digest_file(library) != runtime['library_sha256']:
        raise RuntimeError('Authenticated complete C++ runtime changed')
    tools = json.loads((prep.root / 'state' / ('client-toolchain-linux-' + cpu + '.json')).read_text('utf-8'))
    output = prep.root / 'cache/cxx-runtime-probe' / cpu
    source = output / 'source'
    source.mkdir(parents=True, exist_ok=True)
    (source / 'CMakeLists.txt').write_text(
        'cmake_minimum_required(VERSION 3.20)\nproject(MyCefCxxRuntime LANGUAGES CXX)\n'
        'set(CMAKE_CXX_STANDARD 20)\nadd_executable(cxx_runtime_probe probe.cc)\n', encoding='utf-8')
    (source / 'probe.cc').write_text(
        '#include <filesystem>\n#include <sstream>\n#include <iostream>\n#include <stdexcept>\n'
        'int main(){auto p=std::filesystem::canonical(".");'
        'std::ostringstream s;s << p.string();if(s.str().empty())return 2;'
        'try{throw std::runtime_error("mycef-exception-ok");}'
        'catch(const std::exception& e){if(std::string(e.what())!="mycef-exception-ok")return 3;}'
        'std::cout << "MYCEF_COMPLETE_CXX_RUNTIME_OK " << s.str() << std::endl;return 0;}\n', encoding='utf-8')
    prep.run(['cmake', '-S', source, '-B', output / 'build', '-G', 'Ninja',
              '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TOOLCHAIN_FILE=' + tools['toolchain']])
    prep.run(['cmake', '--build', output / 'build', '-j', '1'])
    binary = output / 'build/cxx_runtime_probe'
    elf = inspect(binary)
    if (elf['machine'] != MACHINES[cpu] or elf['glibc_other_requirements']
            or version_key(elf['glibc_max_required']) > version_key('2.28')
            or 'GLIBCXX_3.4.26' not in elf['version_needs']):
        raise RuntimeError('C++ runtime probe did not exercise the required old-system ABI case')
    report = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'target_cpu': cpu,
              'binary': str(binary), 'binary_sha256': digest_file(binary), 'elf': elf,
              'runtime': runtime, 'compilation_linking_passed': True,
              'scope': 'Actual C++20/filesystem/exception client requiring GLIBCXX_3.4.26. Target execution is separately required.'}
    write_json(prep.root / 'state' / ('cxx-runtime-probe-' + cpu + '.json'), report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--cpu', required=True, choices=('x64', 'arm64'))
    args = parser.parse_args()
    print(json.dumps(prepare(Preparation(args.root), args.cpu), indent=2), flush=True)
