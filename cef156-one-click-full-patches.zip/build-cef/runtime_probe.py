#!/usr/bin/env python3
"""Run a packaged CEF sample against loopback WebGL and real media checks.

Uses only the standard library. The media fixture is supplied explicitly and
is not redistributed. Run on the intended target OS/CPU for runtime evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import http.server
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse

FIXTURE_SHA256 = 'bcb75d3db0a1a5056f4cd5c770ceccdb4cae920f21abb8139b29cd9ad39e3857'


def file_hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


PAGE = r'''<!doctype html><meta charset="utf-8"><title>MyCEF runtime probe</title>
<pre id="result">Running...</pre><script>
async function timeout(promise,ms,label){
  let timer;
  try{return await Promise.race([promise,new Promise((_,reject)=>{
    timer=setTimeout(()=>reject(new Error(label+' timed out')),ms);
  })]);}finally{clearTimeout(timer);}
}
async function probe(){
  const result={userAgent:navigator.userAgent,started:new Date().toISOString(),webgl:{}};
  for(const type of ['webgl','webgl2']){
    try{
      const canvas=document.createElement('canvas');canvas.width=canvas.height=4;
      const gl=canvas.getContext(type,{failIfMajorPerformanceCaveat:false,preserveDrawingBuffer:true});
      if(!gl){result.webgl[type]={available:false};continue;}
      const ext=gl.getExtension('WEBGL_debug_renderer_info');
      gl.clearColor(0,1,0,1);gl.clear(gl.COLOR_BUFFER_BIT);
      const pixel=new Uint8Array(4);gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);
      result.webgl[type]={available:true,version:gl.getParameter(gl.VERSION),
        renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),
        pixel:[...pixel],greenPixelDrawn:pixel[0]===0&&pixel[1]===255&&pixel[2]===0&&pixel[3]===255,
        error:gl.getError()};
      gl.getExtension('WEBGL_lose_context')?.loseContext();
    }catch(error){result.webgl[type]={error:String(error)};}
  }
  const mediaUrl=new URL('fixture.mp4',location.href).href;
  const video=document.createElement('video');video.muted=true;video.playsInline=true;
  video.width=320;video.height=180;document.body.append(video);
  result.mediaCapabilities={h264:video.canPlayType('video/mp4; codecs="avc1.42E01E"'),
    aac:video.canPlayType('audio/mp4; codecs="mp4a.40.2"')};
  try{
    const ready=new Promise((resolve,reject)=>{
      video.addEventListener('loadeddata',resolve,{once:true});
      video.addEventListener('error',()=>reject(new Error('media error '+video.error?.code+' '+video.error?.message)),{once:true});
    });
    video.src=mediaUrl;video.load();await timeout(ready,45000,'video decode');
    await timeout(video.play(),15000,'video play');
    await timeout(new Promise((resolve,reject)=>{
      const id=setInterval(()=>{
        if(video.error){clearInterval(id);reject(new Error(video.error.message));}
        else if(video.currentTime>=0.2){clearInterval(id);resolve();}
      },50);
      setTimeout(()=>{clearInterval(id);reject(new Error('video clock did not advance'));},15000);
    }),17000,'video playback');
    const canvas=document.createElement('canvas');canvas.width=video.videoWidth;canvas.height=video.videoHeight;
    const ctx=canvas.getContext('2d');ctx.drawImage(video,0,0);
    const pixels=ctx.getImageData(0,0,canvas.width,canvas.height).data;
    let nonBlackPixels=0;for(let i=0;i<pixels.length;i+=4){if(pixels[i]+pixels[i+1]+pixels[i+2]>16)nonBlackPixels++;}
    result.video={width:video.videoWidth,height:video.videoHeight,time:video.currentTime,
      decodedFrames:video.getVideoPlaybackQuality().totalVideoFrames,nonBlackPixels};
    video.pause();
  }catch(error){result.video={error:String(error)};video.pause();}
  let audioContext;
  try{
    audioContext=new AudioContext();
    const response=await fetch(mediaUrl);if(!response.ok)throw new Error('fixture HTTP '+response.status);
    const bytes=await response.arrayBuffer();
    const decoded=await timeout(audioContext.decodeAudioData(bytes),45000,'AAC decode');
    let peak=0;for(let channel=0;channel<decoded.numberOfChannels;channel++){
      const samples=decoded.getChannelData(channel);for(const sample of samples)peak=Math.max(peak,Math.abs(sample));
    }
    result.audio={sampleRate:decoded.sampleRate,channels:decoded.numberOfChannels,
      frames:decoded.length,duration:decoded.duration,peak};
  }catch(error){result.audio={error:String(error)};}
  finally{if(audioContext)await audioContext.close();}
  result.webrtcVideoCodecs=globalThis.RTCRtpSender?.getCapabilities('video')?.codecs?.map(codec=>codec.mimeType)||[];
  let encoder,decoder;
  try{
    const config={codec:'avc1.42001E',width:64,height:64,bitrate:200000,framerate:30,
      hardwareAcceleration:'prefer-software',latencyMode:'realtime',avc:{format:'avc'}};
    const support=await VideoEncoder.isConfigSupported(config);
    if(!support.supported)throw new Error('Software H.264 encoder configuration is unsupported');
    const chunks=[];let decoderConfig,codecError,decodedPixel;
    encoder=new VideoEncoder({output:(chunk,metadata)=>{
      chunks.push(chunk);if(metadata.decoderConfig)decoderConfig=metadata.decoderConfig;
    },error:error=>{codecError=String(error);}});
    encoder.configure(config);
    const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
    const ctx=canvas.getContext('2d');ctx.fillStyle='#00ff00';ctx.fillRect(0,0,64,64);
    const frame=new VideoFrame(canvas,{timestamp:0,duration:33333});
    try{encoder.encode(frame,{keyFrame:true});}finally{frame.close();}
    await timeout(encoder.flush(),30000,'H.264 encode');
    if(codecError||!chunks.length||!decoderConfig)throw new Error(codecError||'Missing encoded H.264 output');
    decoder=new VideoDecoder({output:frame=>{
      try{ctx.drawImage(frame,0,0);decodedPixel=[...ctx.getImageData(32,32,1,1).data];}finally{frame.close();}
    },error:error=>{codecError=String(error);}});
    decoder.configure({...decoderConfig,hardwareAcceleration:'prefer-software'});
    for(const chunk of chunks)decoder.decode(chunk);
    await timeout(decoder.flush(),30000,'H.264 round-trip decode');
    if(codecError)throw new Error(codecError);
    result.h264Encoder={codec:config.codec,hardwarePreference:config.hardwareAcceleration,
      chunks:chunks.length,encodedBytes:chunks.reduce((total,chunk)=>total+chunk.byteLength,0),
      decodedPixel,roundTripGreen:!!decodedPixel&&decodedPixel[0]<30&&decodedPixel[1]>200&&decodedPixel[2]<30};
  }catch(error){result.h264Encoder={error:String(error)};}
  finally{if(encoder&&encoder.state!=='closed')encoder.close();if(decoder&&decoder.state!=='closed')decoder.close();}
  result.completed=new Date().toISOString();
  document.getElementById('result').textContent=JSON.stringify(result,null,2);
  await fetch(new URL('report',location.href),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(result)});
}
probe().catch(error=>fetch(new URL('report',location.href),{method:'POST',body:JSON.stringify({fatal:String(error)})}));
</script>'''


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == '/' + self.server.token + '/index.html':
            payload = PAGE.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        elif path == '/' + self.server.token + '/fixture.mp4':
            self.serve_fixture()
        else:
            self.send_error(404)

    def serve_fixture(self):
        size = self.server.media.stat().st_size
        begin, end = 0, size - 1
        requested = self.headers.get('Range')
        if requested:
            try:
                unit, value = requested.split('=', 1)
                first, last = value.split('-', 1)
                if unit != 'bytes' or not first or ',' in value:
                    raise ValueError('Unsupported range')
                begin, end = int(first), int(last) if last else end
                if not 0 <= begin <= end < size:
                    raise ValueError('Invalid range')
            except ValueError:
                self.send_error(416)
                return
        self.send_response(206 if requested else 200)
        self.send_header('Content-Type', 'video/mp4')
        self.send_header('Accept-Ranges', 'bytes')
        self.send_header('Content-Length', str(end - begin + 1))
        if requested:
            self.send_header('Content-Range', f'bytes {begin}-{end}/{size}')
        self.end_headers()
        try:
            with self.server.media.open('rb') as stream:
                stream.seek(begin)
                remaining = end - begin + 1
                while remaining:
                    block = stream.read(min(remaining, 1024 * 1024))
                    if not block:
                        break
                    self.wfile.write(block)
                    remaining -= len(block)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        if self.path != '/' + self.server.token + '/report':
            self.send_error(404)
            return
        size = int(self.headers.get('Content-Length', 0))
        if not 0 < size <= 1024 * 1024:
            self.send_error(413)
            return
        try:
            report = json.loads(self.rfile.read(size))
            if not isinstance(report, dict):
                raise ValueError('Expected an object')
        except (ValueError, UnicodeDecodeError):
            self.send_error(400)
            return
        self.server.report = report
        self.send_response(204)
        self.end_headers()
        self.server.finished.set()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', required=True, type=Path)
    parser.add_argument('--configuration', choices=['Release', 'Debug'], default='Release')
    parser.add_argument('--media', required=True, type=Path,
                        help='Chromium 156 media/test/data/bear-1280x720.mp4 (fixed SHA256, H.264 + AAC)')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--mode', choices=['auto', 'gpu-disabled'], default='auto')
    parser.add_argument('--timeout', type=int, default=180)
    parser.add_argument('--show-window', action='store_true',
                        help='Show/maximize the test window and disable background throttling on desktop hosts')
    parser.add_argument('--require-h264-encoder', action='store_true',
                        help='Also require an actual H.264 encode/decode round trip with software preference')
    args = parser.parse_args()
    binary = args.sdk.resolve() / args.configuration
    executable = binary / 'cefsimple.exe'
    resources = args.sdk.resolve() / 'Resources'
    if os.name != 'nt' or not executable.is_file() or not args.media.is_file():
        parser.error('Run on Windows with a real packaged cefsimple.exe and the MP4 fixture')
    fixture_hash = file_hash(args.media)
    if fixture_hash != FIXTURE_SHA256:
        parser.error('Fixture differs from the pinned Chromium H.264/AAC sample')
    libcef_hash = file_hash(binary / 'libcef.dll')
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.daemon_threads = True
    server.token, server.media = secrets.token_hex(24), args.media.resolve()
    server.finished, server.report = threading.Event(), None
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    args.output = args.output.resolve()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    evidence = {'configuration': args.configuration, 'mode': args.mode,
                'window_visibility': 'visible' if args.show_window else 'hidden',
                'executable': str(executable), 'host': sys.getwindowsversion().platform_version,
                'fixture_sha256': fixture_hash, 'libcef_sha256': libcef_hash,
                'fixture_source': 'Chromium 156.0.8071.0 media/test/data/bear-1280x720.mp4',
                'scope': 'Actual checks on this host. Does not prove other Windows/CPU or hardware-GPU behavior.'}
    process = None
    with tempfile.TemporaryDirectory(prefix='mycef-runtime-') as profile:
        # SDK Resources/ is separate from the binaries. ICU startup on Windows
        # looks beside the executable before CEF resource switches take effect.
        # Deploy both into a disposable app directory, as the sample CMake does.
        deployment = Path(profile) / 'app'
        shutil.copytree(binary, deployment, ignore=shutil.ignore_patterns('*.pdb', '*.lib', '*.exp'))
        shutil.copytree(resources, deployment, dirs_exist_ok=True)
        cache_path = Path(profile) / 'profile'
        cache_path.mkdir()
        command = [str(deployment / executable.name), '--url=http://127.0.0.1:' + str(server.server_port) + '/' + server.token + '/index.html',
                   '--user-data-dir=' + str(cache_path), '--root-cache-path=' + str(cache_path),
                   '--resources-dir-path=' + str(deployment), '--locales-dir-path=' + str(deployment / 'locales'),
                   '--autoplay-policy=no-user-gesture-required', '--no-first-run', '--disable-background-networking',
                   '--enable-logging', '--log-file=' + str(args.output.with_suffix('.cef.log'))]
        if args.mode == 'gpu-disabled':
            command.append('--disable-gpu')
        if args.show_window:
            # Desktop occlusion can suspend video loading before loadeddata.
            # Keep the real decoder/GPU selection, but make this validation
            # window visible and prevent background scheduling false negatives.
            command.extend(['--disable-backgrounding-occluded-windows',
                            '--disable-renderer-backgrounding',
                            '--initial-show-state=maximized'])
        evidence['command'] = command
        try:
            startup = subprocess.STARTUPINFO()
            startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startup.wShowWindow = 1 if args.show_window else 0
            with args.output.with_suffix('.process.log').open('w', encoding='utf-8') as stream:
                process = subprocess.Popen(command, cwd=deployment, stdout=stream, stderr=subprocess.STDOUT,
                                           creationflags=subprocess.CREATE_NO_WINDOW, startupinfo=startup)
                deadline = time.monotonic() + args.timeout
                while not server.finished.wait(1):
                    if process.poll() is not None:
                        raise RuntimeError(f'CEF exited with code {process.returncode} before reporting')
                    if time.monotonic() > deadline:
                        raise TimeoutError('CEF did not report runtime checks before the deadline')
                evidence['report'] = server.report
        except Exception as error:
            evidence['failure'] = repr(error)
        finally:
            if process is not None and process.poll() is None:
                subprocess.run(['taskkill.exe', '/PID', str(process.pid), '/T', '/F'],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
                process.wait(timeout=30)
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
    report = evidence.get('report', {})
    checks = {'webgl_draw': report.get('webgl', {}).get('webgl', {}).get('greenPixelDrawn') is True,
              'video_frames': report.get('video', {}).get('decodedFrames', 0) > 0 and
                              report.get('video', {}).get('nonBlackPixels', 0) > 0,
              'aac_samples': report.get('audio', {}).get('frames', 0) > 0 and report.get('audio', {}).get('peak', 0) > 0,
              'webrtc_h264': 'video/H264' in report.get('webrtcVideoCodecs', [])}
    if args.mode == 'gpu-disabled':
        renderer = report.get('webgl', {}).get('webgl', {}).get('renderer', '').lower()
        checks['software_renderer'] = any(name in renderer for name in ['swiftshader', 'warp', 'microsoft basic render'])
    if args.require_h264_encoder:
        checks['h264_encode_roundtrip'] = report.get('h264Encoder', {}).get('roundTripGreen') is True
    evidence['checks'] = checks
    evidence['passed'] = all(checks.values()) and 'failure' not in evidence
    args.output.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'passed': evidence['passed'], 'checks': checks, 'output': str(args.output)}), flush=True)
    return 0 if evidence['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
