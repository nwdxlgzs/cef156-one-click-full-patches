# 云服务器构建交接

后续新 goal 已启动：用户已提供 Ubuntu 主机，正在按 Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64 准备和构建；当前状态与继续步骤见 `LINUX-HANDOFF.zh-CN.md`。下文保留 Windows 阶段的完整交接历史，旧阶段的暂停要求已履行。

目标已按用户最新要求改为：Chromium 156.0.8071.0 / CEF，依次完成 x64、x86、ARM64 的 Release；不再构建 Debug。Release 的完整 PDB 继续保留。Win7 REWORK、CEF 适配、WebGL 软件回退及 H.264/AAC/MP4/OpenH264 配置保留；没有独立 libx264。

Windows 阶段要求：ARM64 完成 SDK 打包、校验、独立客户端链接及中间目录清理，并核对全部三套成品后暂停该阶段。此要求已履行，用户随后提供 Linux 服务器启动新阶段。独立缓存快照工具和及时回收空间的设计见 `NEXT-BUILDS.zh-CN.md`。

最终阶段状态（2026-11-08 21:00，UTC+08:00）：三套 Windows Release SDK 均完成构建与归档验证，云端任务已正常退出。ARM64 ZIP 为 `C:\cef156\packages\cef_binary_156.0.8071.0_windows_arm64_release.zip`，1,649,332,024 字节、1,424 个文件，SHA256 `906ef91513d4ee822b5b97f0288e885daf79926ccb7aa448d189dadad2981c65`。ARM64 DLL / bootstrap 的完整 PDB 匹配、独立 MSVC / CMake 沙箱客户端交叉编译链接通过；所有架构的 ZIP 哈希 / 固定版本 / 参数 / 主要 PE 架构 / 回执 / 清理状态最终复核通过，见 `validation/windows-release-final-audit.json`。三套 `Release_GN_*` 及架构 SDK 暂存目录已清理，C 盘余量约 234.5 GiB。按用户要求完成交接后暂停 goal，下一阶段须待用户提供 Linux 服务器并恢复；Windows on ARM / Win7 真机运行仍未验证。

服务器工作目录为 `C:\cef156`，脚本为 `C:\build-cef`。计划任务 `MyCEF156-Cloud` 以 SYSTEM 运行，不依赖 SSH、RDP、当前电脑或用户登录；服务器重启后可从已有状态续跑。旧任务 `MyCEF156-Build` 停用，避免并行启动两个主构建。

云端续跑流程：

1. 清理已取消的 Debug 构建目录。
2. 重编 x64 Release 的 bootstrap/bootstrapc，修复未初始化的全局命令行访问；用独立 CMake 客户端 DLL 实际验证沙箱启动，刷新原 x64 ZIP 并校验。
3. 构建、验证、压缩 x86 Release，随后处理 ARM64 Release。每套完成后删除该套构建中间文件，保留源码、工具链和 ZIP。
4. 核对 DLL/PDB 的 GUID/Age 和完整符号；x64/x86 实际检查软件 WebGL、H.264/AAC 和 H.264 编码回环；各架构编译独立 CMake 客户端以验证 SDK 接入。

2026-11-08 09:23（UTC+08:00）补充状态：x64 Release 的 bootstrap 修复、独立沙箱客户端运行、PDB 匹配和 ZIP 刷新均已完成。当前 ZIP SHA256 为 `110e1955c90508d8aff7666a498cf7ce6b2458cdebe926a84ba948d60cac0ff8`。任务已自动进入 x86 Release，接着仍会处理 ARM64 Release。后续以 `cloud-status.json` 和日志为准。

2026-11-08 15:35（UTC+08:00）恢复连接检查：服务器重启后已自动继续 ARM64 Release，实际 Ninja 进程已启动。x86 Release 已完成，ZIP 为 1,531,215,739 字节、1,419 个文件，SHA256 为 `2f70672593ae9e48b1b412b7b773b97228433434d61c4e39598f346c62d93dc5`；主要 DLL/EXE 的完整 PDB 匹配检查、默认及禁用 GPU 的软件 WebGL/媒体/编码回环、独立 CMake 沙箱客户端运行均通过。x64/x86 构建中间目录已清理，保留完整 SDK ZIP；ARM64 尚未完成。公网 IP 变化无需修改云端任务。

15:56 补充：ARM64 暴露的 BoringSSL 旧同步代码、CPU 频率查询 x86 汇编及 libwebp 旧线程模拟均已通过新增架构分支修复，三个报错对象已实际编译成功，任务正在增量构建后续模块。修复、补丁清单历史及续跑逻辑同步到一键包。x64/x86 保留原分支和原包溯源，ARM64 全量链接与 SDK 验证仍待完成。

16:22 补充：ARM64 cpuinfo 的初始化类型差异也已修复，实际 init.obj 编译成功，云端继续构建。用户下载的 x64/x86 SDK 已在本机完整解压校验，使用 VS 2022 独立编译了沙箱 cefsimple/cefclient，默认硬件 GPU 及 SwiftShader 模式的实际 WebGL/媒体/编码检查均通过；报告摘要随包放在 `validation/local-development-*`。桌面运行探测增加显式 `--show-window`，用于避免测试窗口被遮挡后的媒体节流；默认云端模式保持不变。

16:47 补充：用户要求演示沙箱开关，已在本机补编 x64/x86 的 `USE_SANDBOX=OFF` 客户端 EXE，并实际通过 WebGL/媒体/编码检查；ON/OFF 结构与相同 libcef.dll 的验证记录随包保存。云端主 SDK 继续保留沙箱及 bootstrap，ARM64 未因此改动，当前继续编译。

ARM64 的运行验证需要 Windows on ARM；Win7 运行和硬件 GPU 路径仍需要目标环境测试。镜像模式无需在服务器运行 Clash。

查看状态（服务器 PowerShell）：

```powershell
Get-ScheduledTask -TaskName MyCEF156-Cloud | Select-Object TaskName,State
Get-Content C:\cef156\state\cloud-status.json
Get-ChildItem C:\cef156\logs\cloud-*.log | Sort-Object LastWriteTime -Descending | Select-Object -First 3
Get-ChildItem C:\cef156\packages\*.zip
```

成功结束时生成 `C:\cef156\state\cloud-all-Release-complete.json`，状态为 `complete`。普通进度和实际命令日志在 `logs\`，逐架构验证结果在 `state\cloud-verified-*-Release.json`。压缩包与 SHA256 在 `packages\`。

计划任务对退出失败最多自动重试三次，间隔三分钟。编译错误或验证错误不会被跳过；失败时保存现场，在 `cloud-status.json` 记录错误。脚本不能自动修复未知源码问题；恢复工作时先读取状态和对应日志，再按首个错误修正和续跑。

手动续跑已有任务：

```powershell
Start-ScheduledTask -TaskName MyCEF156-Cloud
```

不要同时启动旧任务或另一个 Build-CEF 进程，不要对已打补丁的源码重新运行 gclient sync/runhooks 或 git reset --hard。
