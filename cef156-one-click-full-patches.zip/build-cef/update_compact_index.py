#!/usr/bin/env python3
"""Publish a compact index from actual local SDK receipts and files."""
import argparse
import json
from pathlib import Path

from minimize_sdk import VERSION, digest, write_json


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--directory',type=Path,required=True)
    args=parser.parse_args();root=args.directory.resolve();rows=[]
    for target in ['windows-x64','windows-x86','windows-arm64','linux-x64','linux-arm64','mac-arm64','mac-x64']:
        name='cef_'+VERSION+'_'+target+'_release';sdk=root/name
        archive=root/(name+('.zip' if target.startswith('windows-') else '.tar.zst'))
        if not (sdk/'STRIP_MANIFEST.json').is_file() or not archive.is_file():
            rows.append({'target':target,'status':'pending'})
            continue
        manifest=json.loads((sdk/'STRIP_MANIFEST.json').read_text('utf-8'))
        checks=json.loads((sdk/'SHA256SUMS.json').read_text('utf-8'))
        for name,info in checks.items():
            path=sdk/name
            if 'symlink' in info:
                if not path.is_symlink() or str(path.readlink())!=info['symlink']:raise RuntimeError('Local symlink differs')
            elif path.stat().st_size!=info['bytes'] or digest(path)!=info['sha256']:
                raise RuntimeError('Local SDK file differs: '+str(path))
        for path in sdk.rglob('*'):
            if path.name.endswith(('.pdb','.debug','.dwo','.dwp','.dSYM')):
                raise RuntimeError('Unexpected debug artifact')
        expected=archive.with_name(archive.name+'.sha256').read_text().split()[0]
        if digest(archive)!=expected:raise RuntimeError('Local compact archive differs')
        rows.append({'target':target,'status':'local_verified','directory':sdk.name,'archive':archive.name,
                     'archive_bytes':archive.stat().st_size,'archive_sha256':expected,
                     'sdk_bytes':sum(x.get('bytes',0) for x in checks.values()),
                     'demo_modes':manifest['demo_modes'],'demo_build_verified':manifest['demo_build_verified'],
                     'runtime_verified_after_strip':manifest['runtime_verified_after_strip']})
    write_json(root/'SDK-INDEX.json',{'chromium_version':VERSION,'configuration':'Release','sdks':rows})
    lines=['# 精简 CEF 开发 SDK', '',
           '每个架构目录均可独立使用；同名 ZIP / tar.zst 是对应目录的完整压缩包。原始含符号 SDK 位于上级 build 目录。', '',
           '| 平台/架构 | 状态 | 目录体积 | 压缩包体积 |', '|---|---|---:|---:|']
    for row in rows:
        if row['status']=='pending':lines.append('| '+row['target']+' | 完整 SDK 制作中，后续补齐 | — | — |')
        else:lines.append(f"| {row['target']} | 本地文件和压缩包摘要已核验 | {row['sdk_bytes']/1024**2:.1f} MiB | {row['archive_bytes']/1024**2:.1f} MiB |")
    lines += ['', '运行库、资源、locales 已合并到各 SDK 的 `Release/`。',
              '开发头文件为 `include/`，C++ wrapper 源码为 `libcef_dll/`，工程配置为 `cmake/`。',
              '每个 SDK 附 `demos/sandbox-on/` 和 `demos/sandbox-off/` 两个 CMake 示例入口，实际源码共用 `demos/common/`。',
              '请从对应目录的 `README.zh-CN.md` 开始；根目录还提供 CMakePresets.json。', '',
              'Windows x64/x86、Linux x64/ARM64 的两个示例入口已实际编译验证；Windows ARM64 示例源码已配齐，当前本机未安装 ARM64 C++ 工具链，未声称该示例已在此机编译或运行。',
              'Linux x64 精简运行库另已通过 sandbox ON/OFF、WebGL、H.264、AAC、WebRTC H.264 的实际运行检查。Linux ARM64 ELF 运行段保持一致，双模式 demo 已交叉编译，尚未对精简副本重新执行 ARM64 VM 运行检查。',
              'Mac 已标为本地就绪的包，其两种 demo 和 Helper 已交叉编译/链接；未声称 Mac 实机运行或 Apple 分发签名通过。其余 Mac 架构仍按表格状态制作。', '',
              'Windows 开启沙箱需要同版本 bootstrap，已保留。Mac 两种模式都需要 Helper；不要从应用结构里移除。',
              'Linux/macOS 推荐从 tar.zst 解压，以保留 Unix 文件权限和符号链接。',
              '当前文件、压缩包 SHA-256 及验证范围见 SDK-INDEX.json 和各目录的 STRIP_MANIFEST.json。', '']
    (root/'README.zh-CN.md').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(rows,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
