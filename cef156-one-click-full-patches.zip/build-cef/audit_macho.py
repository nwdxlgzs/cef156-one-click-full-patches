#!/usr/bin/env python3
"""Inspect actual 64-bit Mach-O SDK CPU, deployment, dependencies and dSYM UUIDs.

Load-command layouts follow LLVM BinaryFormat/MachO.h and the original Apple
SDK mach-o/loader.h. A successful audit does not prove macOS runtime behavior.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import struct
import uuid

CPUS = {'x64': 0x01000007, 'arm64': 0x0100000c}
MH_MAGIC_64 = 0xfeedfacf
MH_DSYM = 10
RUNTIME_TYPES = {2, 6, 8}
DYLIB_COMMANDS = {0xc, 0xd, 0x80000018, 0x8000001f, 0x20, 0x80000023}


def packed_version(value):
    return (value >> 16, (value >> 8) & 255, value & 255)


def version_string(value):
    parts = list(value)
    if len(parts) == 3 and parts[2] == 0:
        parts.pop()
    return '.'.join(map(str, parts))


def version_tuple(value):
    parts = tuple(map(int, value.split('.')))
    if not 1 <= len(parts) <= 3:
        raise ValueError('Expected a macOS version with one to three components')
    return parts + (0,) * (3 - len(parts))


def inspect(path):
    path = Path(path)
    size = path.stat().st_size
    with path.open('rb') as stream:
        header = stream.read(32)
        if len(header) < 4 or struct.unpack_from('<I', header)[0] != MH_MAGIC_64:
            raise ValueError('Expected a thin little-endian 64-bit Mach-O: ' + str(path))
        if len(header) != 32:
            raise ValueError('Truncated Mach-O header')
        magic, cpu, subtype, filetype, count, command_bytes, flags, reserved = struct.unpack('<8I', header)
        if command_bytes > 64 * 1024 * 1024 or 32 + command_bytes > size or count > command_bytes // 8:
            raise ValueError('Mach-O load-command table exceeds the actual file')
        data = stream.read(command_bytes)
    result = {'path': str(path), 'bytes': size, 'cpu_type': cpu, 'cpu_subtype': subtype,
              'architecture': next((name for name, value in CPUS.items() if value == cpu), 'unknown'),
              'file_type': filetype, 'flags': flags, 'uuid': None,
              'versions': [], 'dylibs': [], 'rpaths': [], 'sections': [], 'code_signature': None}
    offset = 0
    for _ in range(count):
        if offset + 8 > len(data):
            raise ValueError('Truncated Mach-O load command')
        kind, length = struct.unpack_from('<II', data, offset)
        if length < 8 or length % 8 != 0 or offset + length > len(data):
            raise ValueError('Invalid 64-bit Mach-O load-command length')
        command = data[offset:offset + length]

        def string_at(position):
            if not 8 <= position < len(command):
                raise ValueError('Mach-O load-command string offset is invalid')
            end = command.find(b'\0', position)
            if end == -1:
                raise ValueError('Unterminated Mach-O load-command string')
            return command[position:end].decode('utf-8')

        if kind == 0x1b:
            if length != 24 or result['uuid'] is not None:
                raise ValueError('Invalid or duplicate Mach-O UUID')
            result['uuid'] = str(uuid.UUID(bytes=command[8:24])).upper()
        elif kind in DYLIB_COMMANDS:
            if length < 24:
                raise ValueError('Truncated dylib command')
            name, stamp, current, compatibility = struct.unpack_from('<4I', command, 8)
            result['dylibs'].append({'command': kind, 'name': string_at(name),
                                    'id': kind == 0xd, 'current_version': version_string(packed_version(current)),
                                    'compatibility_version': version_string(packed_version(compatibility))})
        elif kind == 0x8000001c:
            if length < 16:
                raise ValueError('Truncated rpath command')
            result['rpaths'].append(string_at(struct.unpack_from('<I', command, 8)[0]))
        elif kind == 0x32:
            if length < 24:
                raise ValueError('Truncated build-version command')
            platform, minimum, sdk, tools = struct.unpack_from('<4I', command, 8)
            if 24 + tools * 8 > length:
                raise ValueError('Truncated build-version tool list')
            result['versions'].append({'platform': platform, 'minimum': version_string(packed_version(minimum)),
                                       'sdk': version_string(packed_version(sdk)), 'source': 'LC_BUILD_VERSION'})
        elif kind == 0x24:
            if length != 16:
                raise ValueError('Invalid minimum-macOS-version command')
            minimum, sdk = struct.unpack_from('<II', command, 8)
            result['versions'].append({'platform': 1, 'minimum': version_string(packed_version(minimum)),
                                       'sdk': version_string(packed_version(sdk)), 'source': 'LC_VERSION_MIN_MACOSX'})
        elif kind == 0x19:
            if length < 72:
                raise ValueError('Truncated 64-bit segment command')
            sections = struct.unpack_from('<I', command, 64)[0]
            if 72 + sections * 80 > length:
                raise ValueError('Truncated 64-bit section table')
            for index in range(sections):
                first = 72 + index * 80
                name, segment, address, byte_count, file_offset, alignment, reloc, reloc_count, section_flags = struct.unpack_from('<16s16sQQ5I', command, first)
                result['sections'].append({'name': name.rstrip(b'\0').decode('ascii'),
                                           'segment': segment.rstrip(b'\0').decode('ascii'),
                                           'bytes': byte_count, 'offset': file_offset, 'flags': section_flags})
        elif kind == 0x1d:
            if length != 16 or result['code_signature'] is not None:
                raise ValueError('Invalid or duplicate code-signature command')
            first, byte_count = struct.unpack_from('<II', command, 8)
            if not byte_count or first + byte_count > size:
                raise ValueError('The embedded code-signature blob exceeds the actual file')
            result['code_signature'] = {'offset': first, 'bytes': byte_count}
        offset += length
    if offset != len(data):
        raise ValueError('Mach-O load-command count and length disagree')
    # dsymutil deliberately wraps ordered 32-bit section offsets in large
    # dSYMs. Match LLVM Object's getSectionContents(), including its ordering
    # refusal, and validate the reconstructed position against the real file.
    # Reference: llvm-project e44fff5decc7,
    # llvm/lib/Object/MachOObjectFile.cpp. Runtime images never use this rule.
    adjustment = 0
    previous = 0
    for section in result['sections']:
        raw = section['offset']
        actual = raw
        if filetype == MH_DSYM and size > 0xffffffff:
            actual += adjustment
            if adjustment and actual < previous:
                raise ValueError('Large dSYM section file offsets are not ordered')
            if adjustment:
                section['offset_in_header'] = raw
                section['offset'] = actual
                result['dwarf_section_offset_encoding'] = 'llvm_ordered_32bit_wrap'
            adjustment += (raw + section['bytes']) & 0xffffffff00000000
            previous = actual
        section_type = section['flags'] & 0xff
        if (section_type not in {1, 0xc, 0x12} and section['bytes']
                and actual + section['bytes'] > size):
            raise ValueError('A Mach-O section exceeds the actual file')
    return result


def match_dsym(binary, bundle):
    image = inspect(binary)
    directory = Path(bundle) / 'Contents/Resources/DWARF'
    candidates = [path for path in directory.iterdir() if path.is_file() and not path.name.startswith('.')] if directory.is_dir() else []
    if len(candidates) != 1:
        raise ValueError('Expected exactly one real DWARF file in the dSYM bundle')
    symbols = inspect(candidates[0])
    if (not image['uuid'] or image['uuid'] != symbols['uuid'] or image['cpu_type'] != symbols['cpu_type']
            or symbols['file_type'] != MH_DSYM):
        raise ValueError('The dSYM UUID/CPU/file type does not match the linked image')
    sections = {item['name']: item['bytes'] for item in symbols['sections'] if item['segment'] == '__DWARF'}
    if not sections.get('__debug_info') or not sections.get('__debug_line'):
        raise ValueError('The matching dSYM has no full debug_info/debug_line payload')
    return {'binary': str(binary), 'bundle': str(bundle), 'dwarf': str(candidates[0]),
            'uuid': image['uuid'], 'architecture': image['architecture'], 'full_dwarf_sections': sections,
            'passed': True, 'scope': 'Actual Mach-O CPU/UUID match and full DWARF section presence; semantic DWARF verification and target runtime are separate.'}


def audit(root, cpu, max_min_macos='13.0'):
    root = Path(root).resolve()
    if not root.is_dir() or cpu not in CPUS:
        raise ValueError('Expected a real SDK directory and an explicit x64/arm64 target')
    files, errors, links = [], [], {}
    magics = {b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
              b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca', b'\xfe\xed\xfa\xcf'}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root).as_posix()
        if path.is_symlink():
            try:
                resolved = path.resolve(strict=True)
                if root not in resolved.parents and resolved != root:
                    raise ValueError('link escapes the SDK')
                links[relative] = str(path.readlink())
            except (ValueError, RuntimeError, OSError) as error:
                errors.append(relative + ': ' + str(error))
            continue
        if not path.is_file():
            continue
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic not in magics:
            continue
        try:
            item = inspect(path)
            item['path'] = relative
            if item['cpu_type'] != CPUS[cpu]:
                errors.append(relative + ': Mach-O architecture is ' + item['architecture'])
            if item['file_type'] in RUNTIME_TYPES:
                if not item['uuid'] or not item['versions']:
                    errors.append(relative + ': missing runtime UUID/deployment version')
                for entry in item['versions']:
                    if entry['platform'] != 1 or version_tuple(entry['minimum']) > version_tuple(max_min_macos):
                        errors.append(relative + ': incompatible platform/deployment ' + str(entry))
            for entry in item['dylibs']:
                name = entry['name']
                if name.startswith('/') and not name.startswith(('/System/Library/', '/usr/lib/')):
                    errors.append(relative + ': linked absolute non-system path ' + name)
            for name in item['rpaths']:
                if name.startswith('/'):
                    errors.append(relative + ': absolute build-host rpath ' + name)
            files.append(item)
        except (ValueError, OSError, UnicodeError) as error:
            errors.append(relative + ': ' + str(error))
    if not files:
        errors.append('No actual Mach-O files in the SDK')
    return {'root': str(root), 'target_cpu': cpu, 'maximum_minimum_macos': max_min_macos,
            'files': files, 'symlinks': links, 'errors': errors, 'passed': not errors,
            'scope': 'Actual thin Mach-O architectures, deployment load commands, UUIDs, library paths and internal symlinks. Not target execution or full SDK/dSYM/signature completeness.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--cpu', required=True, choices=CPUS)
    parser.add_argument('--max-min-macos', default='13.0')
    parser.add_argument('--json', type=Path)
    args = parser.parse_args()
    report = audit(args.root, args.cpu, args.max_min_macos)
    if args.json:
        args.json.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2), flush=True)
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
