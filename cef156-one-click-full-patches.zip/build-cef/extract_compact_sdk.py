#!/usr/bin/env python3
"""Expand a SHA-verified compact tar.zst without losing framework symlinks."""
import argparse
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import tarfile

from minimize_sdk import digest, zstd_reader


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--archive',type=Path,required=True)
    a=p.parse_args();archive=a.archive.resolve()
    sha=archive.with_name(archive.name+'.sha256').read_text().split()[0]
    if digest(archive)!=sha:raise RuntimeError('Local archive SHA256 differs')
    sdk=archive.with_name(archive.name.removesuffix('.tar.zst'))
    if sdk.exists():raise RuntimeError('SDK exists; preserve it and verify separately')
    links=[]
    with zstd_reader(archive) as f,tarfile.open(fileobj=f,mode='r|') as tar:
        for entry in tar:
            name=PurePosixPath(entry.name)
            if name.is_absolute() or '..' in name.parts or name.parts[0]!=sdk.name or '\\' in entry.name:
                raise RuntimeError('Unsafe compact entry')
            dest=archive.parent.joinpath(*name.parts)
            if entry.isdir():dest.mkdir(parents=True,exist_ok=True)
            elif entry.isfile():
                dest.parent.mkdir(parents=True,exist_ok=True)
                with tar.extractfile(entry) as source,dest.open('wb') as out:shutil.copyfileobj(source,out,8*1024*1024)
                os.chmod(dest,entry.mode & 0o777)
            elif entry.issym():
                if os.path.isabs(entry.linkname) or sdk.resolve() not in (dest.parent/entry.linkname).resolve().parents:
                    raise RuntimeError('Compact symlink escaped SDK')
                links.append((dest,entry.linkname))
            else:raise RuntimeError('Unsupported compact entry type')
    for path,link in links:path.symlink_to(link,target_is_directory=(path.parent/link).is_dir())
    checks=json.loads((sdk/'SHA256SUMS.json').read_text('utf-8'))
    for name,info in checks.items():
        path=sdk/name
        if 'symlink' in info:
            if not path.is_symlink() or os.readlink(path).replace('\\','/')!=info['symlink'].replace('\\','/'):
                raise RuntimeError('Local compact symlink differs')
        elif path.stat().st_size!=info['bytes'] or digest(path)!=info['sha256']:
            raise RuntimeError('Local compact file differs: '+str(path))
    print('LOCAL_COMPACT_DIRECTORY_VERIFIED',sdk,len(checks),flush=True)


if __name__=='__main__':main()
