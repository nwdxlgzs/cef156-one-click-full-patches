"""Ensure the old-kernel procfs exception never accepts an unsandboxed process."""
import unittest

from runtime_probe_posix import renderer_sandboxed


class RendererEvidenceTests(unittest.TestCase):
    def old_renderer(self):
        return {'type': 'renderer', 'seccomp': 2, 'no_new_privs': -1,
                'no_new_privs_exposed_by_procfs': False,
                'capabilities': dict.fromkeys(('CapEff', 'CapPrm', 'CapInh', 'CapAmb'), 0),
                'uid': '65534 65534 65534 65534', 'namespace_pid': '204 12',
                'tracer_pid': 0, 'command_line': 'cefsimple --type=renderer'}

    def test_old_kernel_observations_and_modern_direct_flag(self):
        item = self.old_renderer()
        self.assertTrue(renderer_sandboxed(item, '4.9.0-13-amd64'))
        self.assertFalse(renderer_sandboxed(item, '6.8.0'))
        item.update(no_new_privs=1, no_new_privs_exposed_by_procfs=True)
        self.assertTrue(renderer_sandboxed(item, '6.8.0'))

    def test_missing_or_unsafe_old_kernel_evidence_is_refused(self):
        for key, value in [('seccomp', 0), ('uid', '0 0 0 0'),
                           ('namespace_pid', '204'), ('tracer_pid', 1),
                           ('no_new_privs', 0), ('no_new_privs_exposed_by_procfs', True),
                           ('capabilities', {}), ('capabilities', {'CapEff': 1}),
                           ('command_line', 'cefsimple --type=renderer --no-sandbox')]:
            with self.subTest(key=key, value=value):
                item = self.old_renderer()
                item[key] = value
                self.assertFalse(renderer_sandboxed(item, '4.9.0-13-amd64'))


if __name__ == '__main__':
    unittest.main()
