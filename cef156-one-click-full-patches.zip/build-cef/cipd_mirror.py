#!/usr/bin/env python3
"""Read-only local CIPD metadata service backed by HTTPS mirror ZIPs.

The original CIPD/vpython clients still install and verify every package.
Only package downloads use the Flutter China mirror; this is not a general
network proxy. The service listens exclusively on an ephemeral loopback port.
Protocol fields follow luci-go cipd/api/cipd/v1/{repo,cas}.proto.
"""
from __future__ import annotations

import argparse
import base64
import contextlib
from concurrent.futures import ThreadPoolExecutor
import hashlib
import http.server
import json
import os
from pathlib import Path
import platform as host_platform
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.parse
import zipfile

MIRROR = "https://storage.flutter-io.cn/flutter_infra_release/cipd"

CLIENT_PLATFORMS = ('windows-amd64', 'linux-amd64', 'linux-arm64', 'mac-amd64', 'mac-arm64')


def client_filename(platform):
    if platform not in CLIENT_PLATFORMS:
        raise ValueError('Unsupported CIPD client platform')
    return 'cipd.exe' if platform.startswith('windows-') else 'cipd'


def native_client_platform():
    operating_system = {'win32': 'windows', 'darwin': 'mac'}.get(sys.platform, 'linux' if sys.platform.startswith('linux') else None)
    architecture = {'amd64': 'amd64', 'x86_64': 'amd64', 'arm64': 'arm64', 'aarch64': 'arm64'}.get(host_platform.machine().lower())
    result = f'{operating_system}-{architecture}'
    client_filename(result)
    return result


@contextlib.contextmanager
def cache_file_lock(path):
    """Coordinate the bootstrap CLI and the long-running metadata service."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as stream:
        if stream.seek(0, 2) == 0:
            stream.write(b'1')
            stream.flush()
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            while True:
                try:
                    msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(0.1)
            try:
                yield
            finally:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(stream, fcntl.LOCK_UN)


def digest_file(path, algorithm="sha256"):
    h = hashlib.new(algorithm)
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def instance_ref(version):
    if re.fullmatch(r"[a-f0-9]{40}", version):
        return 1, version
    if re.fullmatch(r"[A-Za-z0-9_-]{44}", version):
        raw = base64.urlsafe_b64decode(version)
        if len(raw) == 33 and raw[-1] == 2:
            return 2, raw[:-1].hex()
    return None


def varint(value):
    result = bytearray()
    while value > 127:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def field(number, value):
    if isinstance(value, int):
        return varint(number << 3) + varint(value)
    if isinstance(value, str):
        value = value.encode("utf-8")
    return varint((number << 3) | 2) + varint(len(value)) + value


def parse_fields(data):
    """Decode the protobuf wire types used by the supported read-only RPCs."""
    offset, result = 0, {}

    def integer():
        nonlocal offset
        value = shift = 0
        while offset < len(data) and shift < 70:
            byte = data[offset]
            offset += 1
            value |= (byte & 127) << shift
            if byte < 128:
                return value
            shift += 7
        raise ValueError("Truncated protobuf varint")

    while offset < len(data):
        tag = integer()
        number, wire = tag >> 3, tag & 7
        if not number:
            raise ValueError("Invalid protobuf field")
        if wire == 0:
            value = integer()
        elif wire in (1, 2, 5):
            length = integer() if wire == 2 else {1: 8, 5: 4}[wire]
            if length > len(data) - offset:
                raise ValueError("Truncated protobuf field")
            value = data[offset:offset + length]
            offset += length
        else:
            raise ValueError("Unsupported protobuf wire type")
        result[number] = value
    return result


def depot_manifest_pins(depot, platform='windows-amd64'):
    """Read checked-in package IDs for one explicit host platform."""
    client_filename(platform)
    text = (Path(depot) / 'cipd_manifest.versions').read_text('utf-8')
    pins = []
    for block in re.split(r'\r?\n\s*\r?\n', text):
        lines = [line.strip() for line in block.splitlines()
                 if line.strip() and not line.lstrip().startswith('#')]
        if len(lines) == 3 and lines[0].endswith('/' + platform):
            if not instance_ref(lines[2]):
                raise ValueError('Unrecognized pinned depot_tools package instance ID')
            pins.append((lines[0], lines[2]))
    if not pins:
        raise ValueError('No pinned host packages in depot_tools manifest for ' + platform)
    return pins


class MirrorCache:
    def __init__(self, directory, mirror=MIRROR, version_pins=None):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.mirror = mirror.rstrip("/")
        self.version_pins = dict(version_pins or {})
        if any(not instance_ref(pin) for pin in self.version_pins.values()):
            raise ValueError('Version pins must refer directly to immutable CIPD instance IDs')
        self.lock = threading.RLock()
        self.package_locks = {}
        self.index_path = self.directory / "mirror-index.json"
        self.index = json.loads(self.index_path.read_text("utf-8")) if self.index_path.exists() else {}

    def resolve(self, package, version):
        pin = self.version_pins.get(package + '@' + version)
        if pin:
            return self.resolve(package, pin)
        if not re.fullmatch(r"[a-z0-9_.+-]+(?:/[a-z0-9_.+-]+)*", package):
            raise ValueError("Invalid CIPD package name")
        if not instance_ref(version) and not re.fullmatch(r"[A-Za-z0-9_.+-]+:[A-Za-z0-9_.+@:/=-]+", version):
            raise ValueError("Only pinned CIPD instance IDs and version tags are supported")
        key = package + "@" + version
        key_digest = hashlib.sha256(key.encode()).hexdigest()
        with self.lock:
            gate = self.package_locks.setdefault(key, threading.Lock())
        with gate, cache_file_lock(self.directory / 'locks' / (key_digest + '.lock')):
            with self.lock:
                with cache_file_lock(self.directory / 'locks/index.lock'):
                    if self.index_path.exists():
                        self.index = json.loads(self.index_path.read_text('utf-8'))
                entry = self.index.get(key)
            if entry and entry.get("mirror") == self.mirror:
                path = self.directory / (entry["sha256"] + ".zip")
                if path.exists() and digest_file(path) == entry["sha256"]:
                    return entry
            url = self.mirror + "/" + package + "/+/" + urllib.parse.quote(version, safe=":@+")
            partial = self.directory / (key_digest + ".partial")
            print(f"MIRROR_FETCH {package} {version}", flush=True)
            curl = shutil.which("curl.exe") or shutil.which("curl")
            if not curl:
                raise RuntimeError("curl is required for resumable mirror downloads")
            for attempt in range(4):
                if partial.exists() and zipfile.is_zipfile(partial):
                    with zipfile.ZipFile(partial) as archive:
                        if archive.testzip() is None:
                            break
                result = subprocess.run([curl, "--fail", "--location", "--silent", "--show-error",
                                         "--connect-timeout", "15", "--max-time", "3600",
                                         "--speed-limit", "1024", "--speed-time", "90",
                                         "--continue-at", "-", "--output", str(partial), url])
                if result.returncode == 0:
                    break
                if result.returncode in (33, 36):
                    partial.unlink(missing_ok=True)
                if attempt == 3:
                    raise RuntimeError(f"Mirror download failed: {package}@{version}")
                time.sleep(2 * (attempt + 1))
            # Reject HTML/partial ZIPs and packages under a mismatching name.
            with zipfile.ZipFile(partial) as archive:
                manifest = json.loads(archive.read(".cipdpkg/manifest.json"))
                if manifest["package_name"] != package:
                    raise ValueError("Mirror package identity mismatch")
                if archive.testzip() is not None:
                    raise ValueError("Mirror package CRC mismatch")
            sha = digest_file(partial)
            expected = instance_ref(version)
            if expected and digest_file(partial, "sha1" if expected[0] == 1 else "sha256") != expected[1]:
                partial.unlink(missing_ok=True)
                raise ValueError("Mirror package does not match the pinned instance ID")
            if entry and sha != entry["sha256"]:
                partial.unlink(missing_ok=True)
                raise ValueError("Mirror version changed since it was locked")
            instance_id = base64.urlsafe_b64encode(bytes.fromhex(sha) + b"\x02").decode()
            path = self.directory / (sha + ".zip")
            partial.replace(path)
            entry = {"package": package, "version": version, "sha256": sha,
                     "instance_id": instance_id, "size": path.stat().st_size,
                     "mirror": self.mirror, "url": url}
            with self.lock:
                with cache_file_lock(self.directory / 'locks/index.lock'):
                    if self.index_path.exists():
                        self.index = json.loads(self.index_path.read_text('utf-8'))
                    self.index[key] = entry
                    pending = self.index_path.with_suffix(".tmp")
                    pending.write_text(json.dumps(self.index, indent=2) + "\n", "utf-8")
                    pending.replace(self.index_path)
            print(f"MIRROR_VERIFIED {package} {sha} {entry['size']}", flush=True)
            return entry

    def instance(self, package, ref):
        algorithm = ref.get(1, 0)
        digest = ref.get(2, b"").decode()
        if algorithm == 1 and re.fullmatch(r"[a-f0-9]{40}", digest):
            version = digest
        elif algorithm == 2 and re.fullmatch(r"[a-f0-9]{64}", digest):
            version = base64.urlsafe_b64encode(bytes.fromhex(digest) + b"\x02").decode()
        else:
            raise ValueError("Invalid instance reference")
        with self.lock:
            with cache_file_lock(self.directory / 'locks/index.lock'):
                if self.index_path.exists():
                    self.index = json.loads(self.index_path.read_text('utf-8'))
            known = next((entry["version"] for entry in self.index.values()
                          if entry["package"] == package and entry["instance_id"] == version), None)
        if known:
            return self.resolve(package, known)
        return self.resolve(package, version)

    def bootstrap_client(self, depot, platform='windows-amd64'):
        depot = Path(depot)
        filename = client_filename(platform)
        version = (depot / "cipd_client_version").read_text("utf-8").strip()
        digests = (depot / "cipd_client_version.digests").read_text("utf-8")
        match = re.search(r"^" + re.escape(platform) + r"\s+sha256\s+([a-f0-9]{64})$", digests, re.M)
        if not match:
            raise ValueError("Missing official CIPD client SHA256 in depot_tools")
        entry = self.resolve("infra/tools/cipd/" + platform, version)
        with zipfile.ZipFile(self.directory / (entry["sha256"] + ".zip")) as archive:
            executable = archive.read(filename)
        if hashlib.sha256(executable).hexdigest() != match[1]:
            raise ValueError("Mirror CIPD client does not match the official bootstrap SHA256")
        target = depot / ('.cipd_client.exe' if filename.endswith('.exe') else '.cipd_client')
        if not target.exists() or digest_file(target) != match[1]:
            pending = target.with_suffix(".tmp")
            pending.write_bytes(executable)
            pending.replace(target)
        if not filename.endswith('.exe'):
            target.chmod(0o755)
        versions = depot / ".versions"
        versions.mkdir(exist_ok=True)
        (versions / (target.name + '.cipd_version')).write_text(
            json.dumps({"package_name": entry["package"], "instance_id": entry["instance_id"]}), "utf-8")
        print("BOOTSTRAP_VERIFIED " + match[1], flush=True)


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "MyCEF-CIPD-Mirror/1"

    def log_message(self, fmt, *args):
        print(fmt % args, flush=True)

    def respond(self, status, body, content_type="application/prpc; encoding=binary", code=0):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Prpc-Grpc-Code", str(code))
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def do_POST(self):
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size < 0 or size > 1024 * 1024:
                raise ValueError("Invalid RPC request length")
            if "encoding=binary" not in self.headers.get("Content-Type", ""):
                raise ValueError("This service accepts binary pRPC only")
            fields = parse_fields(self.rfile.read(size))
            package = fields.get(1, b"").decode()
            method = self.path.removeprefix("/prpc/cipd.Repository/")
            cache = self.server.cache
            if method == "ResolveVersion":
                entry = cache.resolve(package, fields.get(2, b"").decode())
            elif method in ("GetInstanceURL", "DescribeInstance", "DescribeClient"):
                entry = cache.instance(package, parse_fields(fields.get(2, b"")))
            else:
                self.respond(501, b"Read-only mirror RPC is not implemented", "text/plain", 12)
                return
            ref = field(1, 2) + field(2, entry["sha256"])
            instance = field(1, package) + field(2, ref)
            base = f"http://127.0.0.1:{self.server.server_port}"
            if method == "ResolveVersion":
                body = instance
            elif method == "DescribeInstance":
                body = field(1, instance)
            elif method == "GetInstanceURL":
                body = field(1, base + "/objects/" + entry["sha256"] + ".zip")
            else:
                filename = client_filename(package.removeprefix('infra/tools/cipd/'))
                with zipfile.ZipFile(cache.directory / (entry["sha256"] + ".zip")) as archive:
                    executable = archive.read(filename)
                raw_sha = hashlib.sha256(executable).hexdigest()
                raw_path = cache.directory / (raw_sha + ('.exe' if filename.endswith('.exe') else '.bin'))
                if not raw_path.exists():
                    raw_path.write_bytes(executable)
                body = (field(1, instance) + field(2, field(1, 2) + field(2, raw_sha)) +
                        field(3, field(1, base + "/objects/" + raw_path.name)) +
                        field(4, len(executable)) + field(5, hashlib.sha1(executable).hexdigest()) +
                        field(6, field(1, 2) + field(2, raw_sha)) +
                        field(6, field(1, 1) + field(2, hashlib.sha1(executable).hexdigest())))
            self.respond(200, body)
        except (ValueError, KeyError, zipfile.BadZipFile) as error:
            self.respond(400, str(error).encode(), "text/plain", 3)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as error:
            print(f"MIRROR_ERROR {error}", flush=True)
            self.respond(503, str(error).encode(), "text/plain", 14)

    def do_GET(self):
        if self.path.startswith("/python/"):
            try:
                self.server.wheels.serve(self)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except Exception as error:
                print("PYTHON_MIRROR_ERROR " + str(error), flush=True)
                self.respond(503, str(error).encode(), "text/plain", 14)
            return
        if self.path == "/health":
            self.respond(200, b"mycef-cipd-mirror-v1", "text/plain")
            return
        if self.path.startswith("/client?"):
            try:
                query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
                if len(query.get('platform', [])) != 1 or len(query.get("version", [])) != 1:
                    raise ValueError("Unsupported bootstrap client request")
                platform = query['platform'][0]
                filename = client_filename(platform)
                entry = self.server.cache.resolve("infra/tools/cipd/" + platform, query["version"][0])
                with zipfile.ZipFile(self.server.cache.directory / (entry["sha256"] + ".zip")) as archive:
                    self.respond(200, archive.read(filename), "application/octet-stream")
            except Exception as error:
                self.respond(503, str(error).encode(), "text/plain", 14)
            return
        match = re.fullmatch(r"/objects/([a-f0-9]{64}\.(?:zip|exe|bin))", self.path)
        if not match:
            self.respond(404, b"Not found", "text/plain", 5)
            return
        path = self.server.cache.directory / match[1]
        if not path.is_file():
            self.respond(404, b"Not found", "text/plain", 5)
            return
        length = path.stat().st_size
        start, end = 0, length - 1
        status = 200
        if self.headers.get("Range"):
            match = re.fullmatch(r"bytes=(\d+)-(\d*)", self.headers["Range"])
            if not match or int(match[1]) >= length:
                self.respond(416, b"Invalid range", "text/plain", 3)
                return
            start = int(match[1])
            end = min(int(match[2]), end) if match[2] else end
            if end < start:
                self.respond(416, b"Invalid range", "text/plain", 3)
                return
            status = 206
        self.send_response(status)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Accept-Ranges", "bytes")
        if status == 206:
            self.send_header("Content-Range", f"bytes {start}-{end}/{length}")
        self.end_headers()
        if self.command == "HEAD":
            return
        try:
            with path.open("rb") as stream:
                stream.seek(start)
                remaining = end - start + 1
                while remaining:
                    block = stream.read(min(1024 * 1024, remaining))
                    if not block:
                        break
                    self.wfile.write(block)
                    remaining -= len(block)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_HEAD(self):
        self.do_GET()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cache", required=True)
    parser.add_argument("--log-file")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument('--platform', choices=CLIENT_PLATFORMS, default=native_client_platform())
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--ready-file")
    action.add_argument("--bootstrap-depot")
    action.add_argument("--prefetch-depot")
    args = parser.parse_args()
    if args.log_file:
        sys.stdout = open(args.log_file, "a", encoding="utf-8", buffering=1)
        sys.stderr = sys.stdout
    lock = json.loads(Path(__file__).with_name('network-lock.json').read_text('utf-8'))
    cache = MirrorCache(args.cache, version_pins=lock.get('cipd_version_pins', {}))
    if args.bootstrap_depot:
        cache.bootstrap_client(args.bootstrap_depot, args.platform)
        return
    if args.prefetch_depot:
        pins = depot_manifest_pins(args.prefetch_depot, args.platform)
        with ThreadPoolExecutor(4) as pool:
            list(pool.map(lambda pin: cache.resolve(*pin), pins))
        print('DEPOT_MIRROR_PACKAGES_VERIFIED ' + str(len(pins)), flush=True)
        return
    server = http.server.ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    server.daemon_threads = True
    server.cache = cache
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from python_wheel_mirror import WheelMirror
    server.wheels = WheelMirror(Path(args.cache).parent / "python-wheels")
    ready = {"pid": os.getpid(), "url": f"http://127.0.0.1:{server.server_port}"}
    Path(args.ready_file).write_text(json.dumps(ready), "utf-8")
    print("MIRROR_READY " + json.dumps(ready), flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
