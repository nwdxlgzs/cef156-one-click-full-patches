#!/usr/bin/env python3
"""Prepare the locked POSIX CEF checkout with scoped mirrors.

Preparation only: this command never marks a platform build complete. Run
independent tools/source stages in separate persistent services when desired.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

CHROMIUM = '156.0.8071.0'
CHROMIUM_REV = 'aa939feff52ea94f0ca07d8029086738c2683685'
CEF_REV = 'a26ddfd2792604564986b31ea298e30b09bd9b3f'
DEPOT_REV = '289a37bda3d848cfe16e6c1c599741ed3890ab55'
HERE = Path(__file__).resolve().parent
ROOT_MARKER = 'mycef-156.0.8071.0-posix-v1'


def write_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


class Preparation:
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        marker = self.root / '.mycef-build-root'
        if not marker.exists():
            # Publish complete contents atomically. Parallel continuations
            # must never observe another Preparation truncating the marker.
            with tempfile.NamedTemporaryFile(dir=self.root, prefix='.mycef-root-', delete=False) as stream:
                temporary_marker = Path(stream.name)
                stream.write((ROOT_MARKER + '\n').encode('ascii'))
            try:
                try:
                    os.link(temporary_marker, marker)
                except FileExistsError:
                    pass
            finally:
                temporary_marker.unlink()
        if marker.read_text().strip() != ROOT_MARKER:
            raise RuntimeError('Unrecognized build root marker')
        for name in ('state', 'logs', 'downloads', 'packages', 'cache', 'tools', 'chromium'):
            (self.root / name).mkdir(exist_ok=True)
        self.src = self.root / 'chromium/src'
        self.depot = self.root / 'depot_tools'
        self.env = dict(os.environ)
        self.env.update({
            'GIT_TERMINAL_PROMPT': '0', 'GIT_CONFIG_GLOBAL': str(self.root / 'gitconfig'),
            'DEPOT_TOOLS_UPDATE': '0', 'DEPOT_TOOLS_METRICS': '0',
            'PYTHONUNBUFFERED': '1', 'PYTHONUTF8': '1',
            'UV_HTTP_TIMEOUT': '1200',
            'CDS_CLANG_BUCKET_OVERRIDE': 'https://storage.googleapis.com/chromium-browser-clang',
            'PATH': str(self.depot) + os.pathsep + os.environ['PATH'],
        })
        ready = self.root / 'state/cipd-mirror.json'
        if ready.is_file():
            url = json.loads(ready.read_text())['url']
            self.env.update(CIPD_SERVICE_URL=url, VPYTHON_AR_URL=url + '/python/simple/')

    def run(self, command, cwd=None, capture=False, check=True):
        command = list(map(str, command))
        print('RUN ' + json.dumps(command), flush=True)
        return subprocess.run(command, cwd=cwd or self.root, env=self.env,
                              capture_output=capture, text=True, check=check)

    def git(self, repository, *args, **kwargs):
        return self.run(['git', '-C', repository, *args], **kwargs)

    def initial_checkout(self):
        result = self.git(self.src, 'checkout', '--detach', CHROMIUM_REV, capture=True, check=False)
        if result.returncode == 0:
            print(result.stderr, end='', flush=True)
            return
        if 'untracked working tree files would be overwritten by checkout' not in result.stderr:
            raise RuntimeError('Initial Chromium checkout failed: ' + result.stderr)
        # An interrupted first checkout can leave genuine worktree files
        # without an index/HEAD. Match existing files to their original Git
        # blobs and preserve any interrupted payloads before restoring them.
        head = self.git(self.src, 'rev-parse', '--verify', '--quiet', 'HEAD', capture=True, check=False)
        if head.returncode == 0 or (self.root / 'state/prepared-posix.json').exists():
            raise RuntimeError('Refusing initial-checkout recovery on an existing or patched worktree')
        raw = subprocess.check_output(['git', '-C', str(self.src), 'ls-tree', '-rz', CHROMIUM_REV], env=self.env)
        matched = 0
        changed = []
        recovery = self.root / 'cache/source-checkout-recovery' / dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%f')
        for entry in raw.split(b'\0'):
            if not entry:
                continue
            metadata, name = entry.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            if kind != 'blob':
                continue
            relative = name.decode('utf-8')
            path = self.src / relative
            if not path.exists() and not path.is_symlink():
                continue
            if mode == '120000' and path.is_symlink():
                payload = os.readlink(path).encode('utf-8')
                digest = hashlib.sha1(('blob ' + str(len(payload)) + '\0').encode() + payload).hexdigest()
            elif mode in ('100644', '100755') and path.is_file() and not path.is_symlink():
                digest_value = hashlib.sha1(('blob ' + str(path.stat().st_size) + '\0').encode())
                with path.open('rb') as stream:
                    for data in iter(lambda: stream.read(1024 * 1024), b''):
                        digest_value.update(data)
                digest = digest_value.hexdigest()
            else:
                raise RuntimeError('Interrupted checkout contains a different file type; preserve it: ' + relative)
            if digest != oid:
                backup = recovery / relative
                backup.parent.mkdir(parents=True, exist_ok=True)
                if path.is_symlink():
                    backup.symlink_to(os.readlink(path))
                else:
                    import shutil
                    shutil.copy2(path, backup)
                    if backup.read_bytes() != path.read_bytes():
                        raise RuntimeError('Interrupted payload backup readback failed: ' + relative)
                changed.append({'path': relative, 'expected_git_blob': oid, 'interrupted_git_blob': digest,
                                'preserved_backup': str(backup)})
            else:
                matched += 1
        self.git(self.src, 'read-tree', CHROMIUM_REV)
        self.git(self.src, 'checkout-index', '--all', '--force')
        self.git(self.src, 'checkout', '--detach', CHROMIUM_REV)
        write_json(self.root / 'state/source-initial-checkout-recovery.json', {
            'chromium_revision': CHROMIUM_REV, 'existing_files_git_blob_matched': matched,
            'interrupted_payload_backups': changed,
            'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'scope': 'Interrupted initial checkout only: existing tracked bytes audited, interrupted payloads preserved separately before restoring the original Git index/worktree. Dependency gitlinks and ignored caches retained.',
        })

    def network(self):
        lock = json.loads((HERE / 'network-lock.json').read_text('utf-8'))
        config = self.root / 'gitconfig'
        text = '[core]\n\tautocrlf = false\n[http]\n\tversion = HTTP/1.1\n'
        for origin, mirror in lock.get('posix_git_mirrors', []):
            text += '[url "' + mirror + '"]\n\tinsteadOf = ' + origin + '\n'
        for hostname in lock['google_git_hosts']:
            text += '[http]\n\tcurloptResolve = ' + hostname + ':443:' + lock['google_git_frontend'] + '\n'
        # This is a build-root configuration; no global Git, hosts or DNS edits.
        config.write_text(text, encoding='utf-8')
        write_json(self.root / 'state/network.json', {
            'git_config': str(config), 'network_lock': lock,
            'scope': 'Only processes launched for this build root; TLS verification retained.',
        })

    def checkout(self, directory, url, revision, full_history=False):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        if not (directory / '.git').exists():
            self.git(directory, 'init')
            self.git(directory, 'remote', 'add', 'origin', url)
        actual_url = self.git(directory, 'config', '--get', 'remote.origin.url', capture=True).stdout.strip()
        if actual_url != url:
            raise RuntimeError('Unexpected repository origin: ' + str(directory))
        head = self.git(directory, 'rev-parse', '--verify', '--quiet', 'HEAD', capture=True, check=False)
        if head.returncode == 0:
            if head.stdout.strip() != revision:
                raise RuntimeError('Existing checkout has a different revision: ' + str(directory))
        else:
            depth = [] if full_history else ['--depth=1']
            if full_history:
                self.git(directory, 'config', 'remote.origin.promisor', 'true')
                self.git(directory, 'config', 'remote.origin.partialclonefilter', 'blob:none')
                depth = ['--filter=blob:none']
            self.git(directory, '-c', 'http.lowSpeedLimit=1024', '-c', 'http.lowSpeedTime=180',
                     'fetch', '--no-tags', *depth, 'origin', revision)
            self.git(directory, 'checkout', '--detach', revision)
        if full_history:
            if self.git(directory, 'rev-parse', '--is-shallow-repository', capture=True).stdout.strip() == 'true':
                raise RuntimeError('Full CEF ancestry is required for version generation')
            commits = int(self.git(directory, 'rev-list', '--count', revision, capture=True).stdout)
            if commits != 3634:
                raise RuntimeError('Unexpected CEF history count: ' + str(commits))
        return revision

    def tools(self):
        with ThreadPoolExecutor(2) as pool:
            futures = [
                pool.submit(self.checkout, self.depot,
                            'https://chromium.googlesource.com/chromium/tools/depot_tools.git', DEPOT_REV),
                pool.submit(self.checkout, self.src / 'cef',
                            'https://github.com/chromiumembedded/cef.git', CEF_REV, True),
            ]
            for future in futures:
                future.result()
        write_json(self.root / 'state/posix-tools-checkout.json', {
            'depot_tools_revision': DEPOT_REV, 'cef_revision': CEF_REV, 'cef_history_commits': 3634,
        })

    def bootstrap(self, depot=None, verify_gclient=True):
        depot = Path(depot) if depot is not None else self.depot
        error = None
        for _attempt in range(30):
            try:
                ready = json.loads((self.root / 'state/cipd-mirror.json').read_text('utf-8'))
                url = ready['url']
                with urllib.request.urlopen(url + '/health', timeout=2) as response:
                    if response.read() != b'mycef-cipd-mirror-v1':
                        raise RuntimeError('Unexpected CIPD mirror health response')
                self.env.update(CIPD_SERVICE_URL=url, VPYTHON_AR_URL=url + '/python/simple/')
                break
            except (OSError, ValueError, KeyError, RuntimeError) as failure:
                error = failure
                time.sleep(1)
        else:
            raise RuntimeError('The loopback CIPD mirror did not become ready: ' + repr(error))
        lock = json.loads((HERE / 'network-lock.json').read_text('utf-8'))
        from cipd_mirror import MirrorCache
        cache = MirrorCache(self.root / 'downloads/cipd-mirror', version_pins=lock['cipd_version_pins'])
        cache.bootstrap_client(depot, 'linux-amd64')
        cipd = depot / 'cipd'
        original = 'CIPD_BACKEND="https://chrome-infra-packages.appspot.com"'
        replacement = 'CIPD_BACKEND="${CIPD_SERVICE_URL:-https://chrome-infra-packages.appspot.com}"'
        data = cipd.read_text('utf-8')
        if replacement not in data:
            if data.count(original) != 1:
                raise RuntimeError('Pinned depot_tools CIPD shell bootstrap needs review')
            data = data.replace(original, replacement)
        # CIPD_SERVICE_URL is consumed by the shell's selfupdate path, but the
        # Go client's normal ensure commands do not read that variable. Route
        # these commands explicitly too, including gclient's generated ensure.
        original_exec = 'exec "${CLIENT}" "${@}"'
        routed_exec = '''# MYCEF scoped metadata routing; package identities remain unchanged.
if [ -n "${CIPD_SERVICE_URL:-}" ]; then
  case "${1:-}" in
    ensure|ensure-file-resolve|resolve|describe)
      exec "${CLIENT}" "${@}" -service-url "${CIPD_SERVICE_URL}"
      ;;
  esac
fi
exec "${CLIENT}" "${@}"'''
        if '# MYCEF scoped metadata routing;' not in data:
            if data.count(original_exec) != 1:
                raise RuntimeError('Pinned CIPD command dispatch changed; inspect before routing')
            data = data.replace(original_exec, routed_exec)
        cipd.write_text(data, encoding='utf-8')
        archive = self.root / 'downloads' / ('gsutil_' + lock['gsutil_version'] + '.zip')
        if not archive.is_file() or hashlib.sha256(archive.read_bytes()).hexdigest() != lock['gsutil_sha256']:
            partial = archive.with_suffix('.zip.partial')
            self.run(['curl', '--fail', '--location', '--silent', '--show-error',
                      '--connect-timeout', '15', '--max-time', '3600', '--continue-at', '-',
                      '--output', partial, lock['gsutil_url']])
            if hashlib.sha256(partial.read_bytes()).hexdigest() != lock['gsutil_sha256']:
                raise RuntimeError('Pinned gsutil archive SHA256 mismatch')
            partial.replace(archive)
        gsutil_script = depot / 'gsutil.py'
        if not gsutil_script.is_file() or not re.search(r'^VERSION\s*=\s*[\'"]' + re.escape(lock['gsutil_version']) + r'[\'"]', gsutil_script.read_text('utf-8'), re.M):
            raise RuntimeError('Depot tools gsutil version differs from the verified archive lock')
        destination = depot / 'external_bin/gsutil' / ('gsutil_' + lock['gsutil_version'])
        with zipfile.ZipFile(archive) as package:
            if package.testzip() is not None:
                raise RuntimeError('Pinned gsutil ZIP integrity failure')
            for name in package.namelist():
                if not name.startswith('gsutil/') or '..' in Path(name).parts:
                    raise RuntimeError('Unexpected gsutil archive path')
            package.extractall(destination)
        if not (destination / 'gsutil/gsutil').is_file():
            raise RuntimeError('Pinned gsutil script missing')
        (destination / 'gsutil/install.flag').write_text('Verified original archive SHA256 ' + lock['gsutil_sha256'] + '\n')
        boto = self.root / 'state/public-gcs.boto'
        boto.write_text('[GSUtil]\nprefer_api = xml\n[Boto]\nhttps_validate_certificates = True\nhttp_socket_timeout = 30\nnum_retries = 4\n')
        self.env['BOTO_CONFIG'] = str(boto)
        self.run(['bash', '-c', 'source "$1/bootstrap_python3"\nbootstrap_python3',
                  'mycef-bootstrap', depot])
        self.run([depot / 'python-bin/python3', '-c',
                  'import ssl,sqlite3,sys; assert sys.version_info[:2] == (3,11); print(sys.executable,sys.version)'])
        self.run([depot / 'cipd', 'ensure', '-ensure-file', depot / 'cipd_manifest.txt',
                  '-root', depot / '.cipd_bin'], cwd=depot)
        if verify_gclient:
            self.run([depot / 'gclient', '--help'])
        revision = self.git(depot, 'rev-parse', 'HEAD', capture=True).stdout.strip()
        filename = 'depot-bootstrap.json' if depot == self.depot else 'nested-depot-bootstrap.json'
        write_json(self.root / 'state' / filename, {
            'revision': revision, 'cipd_platform': 'linux-amd64',
            'cipd_client_sha256': hashlib.sha256((depot / '.cipd_client').read_bytes()).hexdigest(),
            'gsutil_archive_sha256': lock['gsutil_sha256'], 'python': '3.11',
        })

    def sync(self):
        if (self.root / 'state/prepared-posix.json').exists():
            raise RuntimeError('Do not run gclient sync over the prepared patched checkout')
        for marker in ('chromium-checkout.json', 'posix-tools-checkout.json', 'depot-bootstrap.json'):
            if not (self.root / 'state' / marker).is_file():
                raise RuntimeError('Missing prerequisite: ' + marker)
        head = self.git(self.src, 'rev-parse', 'HEAD', capture=True).stdout.strip()
        if head != CHROMIUM_REV:
            raise RuntimeError('Unexpected Chromium revision before gclient sync')
        config = "solutions = " + repr([{
            'name': 'src', 'url': 'https://chromium.googlesource.com/chromium/src.git',
            'managed': False, 'custom_deps': {},
            'custom_vars': {'checkout_pgo_profiles': False},
        }]) + "\ntarget_os = ['linux']\ntarget_cpu = ['x64', 'arm64']\n"
        gclient = self.root / 'chromium/.gclient'
        if gclient.exists() and gclient.read_text('utf-8') != config:
            raise RuntimeError('Existing .gclient differs; preserve its target selection')
        gclient.write_text(config, encoding='utf-8')
        self.env['BOTO_CONFIG'] = str(self.root / 'state/public-gcs.boto')
        self.run([self.depot / 'gclient', 'sync', '--nohooks', '--no-history', '-j', '8',
                  '--revision', 'src@' + CHROMIUM_REV], cwd=self.root / 'chromium')
        pins = json.loads((HERE / 'dependency-pins.json').read_text('utf-8'))
        for path, expected in pins.items():
            directory = self.root / 'chromium' / path
            current = self.git(directory, 'rev-parse', 'HEAD', capture=True).stdout.strip()
            if current != expected.rsplit('@', 1)[1]:
                raise RuntimeError('Dependency revision mismatch: ' + path)
        write_json(self.root / 'state/posix-dependencies-synced.json', {
            'chromium_revision': CHROMIUM_REV, 'targets': ['linux-x64', 'linux-arm64'],
            'dependency_pins': pins, 'hooks_completed': False,
        })

    def source(self):
        if (self.root / 'state/prepared-posix.json').exists():
            raise RuntimeError('Source preparation must not overwrite a patched checkout')
        self.src.mkdir(parents=True, exist_ok=True)
        if not (self.src / '.git').exists():
            self.git(self.src, 'init')
            self.git(self.src, 'remote', 'add', 'origin', 'https://github.com/chromium/chromium.git')
        head = self.git(self.src, 'rev-parse', '--verify', '--quiet', 'HEAD', capture=True, check=False)
        if head.returncode == 0:
            if head.stdout.strip() != CHROMIUM_REV:
                raise RuntimeError('Existing Chromium revision differs from the lock')
            print('Existing locked source checkout retained; no checkout/reset performed.', flush=True)
            return
        # A parallel exact-object fetch may have finished the full Git audit
        # while a larger original request was still streaming duplicate data.
        # Re-audit actual objects/fsck, then use the genuine commit directly.
        # This checkpoint never substitutes for a complete local Git tree.
        checkpoints = [self.root / 'state/source-objects-complete.json',
                       self.root / 'state/source-small-batches-complete.json']
        for checkpoint in checkpoints:
            if not checkpoint.is_file():
                continue
            prior = json.loads(checkpoint.read_text('utf-8'))
            if (prior.get('commit') != CHROMIUM_REV or prior.get('missing_paths')
                    or prior.get('git_fsck_exit') != 0
                    or prior.get('verified_blobs') != prior.get('required_blobs')):
                raise RuntimeError('Existing source object checkpoint is incomplete or changed: ' + str(checkpoint))
            self.run([sys.executable, HERE / 'complete_source_objects.py', '--repository', self.src,
                      '--record', self.root / 'state/source-objects-complete.json', '--jobs', '4'])
            self.initial_checkout()
            self.git(self.src, 'remote', 'set-url', 'origin', 'https://chromium.googlesource.com/chromium/src.git')
            write_json(self.root / 'state/chromium-checkout.json', {
                'version': CHROMIUM, 'revision': CHROMIUM_REV,
                'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                'method': 'Full genuine local Git blob and fsck re-audit followed by original commit checkout.',
            })
            return
        archive_directory = self.root / 'downloads/source-archive'
        with ThreadPoolExecutor(2) as pool:
            archive = pool.submit(self.run, [sys.executable, HERE / 'prefetch_source_archive.py',
                                            '--directory', archive_directory, '--jobs', '8'])
            def metadata():
                self.git(self.src, 'config', 'remote.origin.promisor', 'true')
                self.git(self.src, 'config', 'remote.origin.partialclonefilter', 'blob:none')
                # Avoid the expensive full Git pack. The canonical Google Git
                # URL without .git also bypasses the large-source GitHub rule.
                self.git(self.src, '-c', 'http.lowSpeedLimit=1024', '-c', 'http.lowSpeedTime=180',
                         'fetch', '--depth=1', '--filter=blob:none', '--no-tags',
                         'https://chromium.googlesource.com/chromium/src',
                         f'refs/tags/{CHROMIUM}:refs/tags/{CHROMIUM}')
            meta = pool.submit(metadata)
            # Inspect both outcomes even if one stage fails. A successful
            # download remains resumable and is not discarded.
            errors = []
            for future in (archive, meta):
                try:
                    future.result()
                except Exception as error:
                    errors.append(error)
            if errors:
                raise RuntimeError('Source preparation stage failed: ' + '; '.join(map(str, errors)))
        actual = self.git(self.src, 'rev-parse', f'refs/tags/{CHROMIUM}^{{commit}}', capture=True).stdout.strip()
        if actual != CHROMIUM_REV:
            raise RuntimeError('Chromium tag does not match the locked commit')
        seed_record = self.root / 'state/source-archive-seed.json'
        seed = self.run([sys.executable, HERE / 'seed_source_objects.py',
                         '--repository', self.src,
                         '--archive', archive_directory / f'chromium-{CHROMIUM}.tar.xz',
                         '--record', seed_record], check=False)
        if seed.returncode:
            partial = seed_record.with_suffix('.incomplete.json')
            if not partial.is_file():
                raise RuntimeError('Source archive import failed before its completeness audit')
            audit = json.loads(partial.read_text())
            if audit.get('commit') != CHROMIUM_REV or not audit.get('missing_paths'):
                raise RuntimeError('Unrecognized source archive import failure')
        # The canonical Google Git endpoint supports exact blob wants, which
        # avoids downloading Chromium's entire historical pack.
        self.git(self.src, 'remote', 'set-url', 'origin', 'https://chromium.googlesource.com/chromium/src')
        self.run([sys.executable, HERE / 'complete_source_objects.py', '--repository', self.src,
                  '--record', self.root / 'state/source-objects-complete.json', '--jobs', '4'])
        self.initial_checkout()
        self.git(self.src, 'remote', 'set-url', 'origin', 'https://chromium.googlesource.com/chromium/src.git')
        write_json(self.root / 'state/chromium-checkout.json', {
            'version': CHROMIUM, 'revision': CHROMIUM_REV,
            'utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'method': 'Verified official archive blobs, canonical Git metadata and missing blobs; git fsck.',
        })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--stage', required=True, choices=('network', 'tools', 'source', 'bootstrap', 'sync'))
    args = parser.parse_args()
    if not sys.platform.startswith('linux'):
        parser.error('POSIX preparation currently requires the Linux build host')
    prep = Preparation(args.root)
    if not (prep.root / 'gitconfig').is_file() or args.stage == 'network':
        prep.network()
    if args.stage != 'network':
        getattr(prep, args.stage)()


if __name__ == '__main__':
    main()
