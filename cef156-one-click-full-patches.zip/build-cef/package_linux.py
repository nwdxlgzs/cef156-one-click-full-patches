#!/usr/bin/env python3
"""Create a complete Release-only Linux CEF SDK from the actual linked target.

This prepares the SDK for independent client/runtime validation. It does not
write the final verified archive receipt or delete build intermediates.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

from audit_elf import audit, inspect, MACHINES, version_key
from prepare_posix import Preparation, CHROMIUM, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            value.update(data)
    return value.hexdigest()


def full_dwarf(path):
    sections = subprocess.check_output(['readelf', '--wide', '--section-headers', str(path)], text=True)
    info = bool(re.search(r'\s\.(?:zdebug_info|debug_info)\s', sections))
    lines = bool(re.search(r'\s\.(?:zdebug_line|debug_line)\s', sections))
    if not info or not lines:
        raise RuntimeError('The SDK library has no complete DWARF payload; inspect unstripped output before packaging')
    return {'debug_info_present': info, 'debug_line_present': lines,
            'section_headers_sha256': hashlib.sha256(sections.encode()).hexdigest()}


def install_client_runtime(prep, sdk, cpu):
    """Ship a complete signed-package runtime, never a stripped sysroot stub."""
    from prepare_linux_cxx_runtime import prepare as prepare_runtime
    provenance = prepare_runtime(prep)['targets'][cpu]
    source = Path(provenance['library']).resolve()
    if (prep.root / 'cache/linux-cxx-runtime' not in source.parents
            or digest(source) != provenance['library_sha256']):
        raise RuntimeError('Client C++ runtime differs from its authenticated package')
    elf = inspect(source)
    if (not elf or elf['machine'] != MACHINES[cpu] or elf['glibc_other_requirements']
            or (elf['glibc_max_required'] and version_key(elf['glibc_max_required']) > version_key('2.28'))):
        raise RuntimeError('Pinned C++ runtime exceeds the SDK compatibility ceiling')
    licenses = HERE / 'linux-runtime-licenses'
    origins = json.loads((licenses / 'sources.json').read_text('utf-8'))
    notice = sdk / 'licenses/libstdc++'
    notice.mkdir(parents=True, exist_ok=True)
    for name, item in origins.items():
        if digest(licenses / name) != item['sha256']:
            raise RuntimeError('Bundled libstdc++ license payload changed')
        shutil.copy2(licenses / name, notice / name)
    shutil.copy2(licenses / 'sources.json', notice / 'sources.json')
    copyright = Path(provenance['copyright'])
    if digest(copyright) != provenance['copyright_sha256']:
        raise RuntimeError('Debian runtime copyright notice changed')
    shutil.copy2(copyright, notice / 'DEBIAN-COPYRIGHT')
    target = sdk / 'Release/libstdc++.so.6'
    expected = digest(source)
    if target.is_symlink():
        raise RuntimeError('Unexpected client runtime symlink in SDK staging')
    if target.exists() and digest(target) != expected:
        # The earlier SDK migration mistakenly copied the matching Chromium
        # linker-only sysroot stub. Preserve that authenticated staging file
        # before replacing it with a complete executable implementation.
        previous_path = prep.root / 'state' / ('sdk-linux-' + cpu + '-prepared.json')
        previous = json.loads(previous_path.read_text('utf-8')) if previous_path.exists() else {}
        prior_runtime = previous.get('client_cxx_runtime', {})
        if ('sysroot_provenance' not in prior_runtime
                or 'package' in prior_runtime['sysroot_provenance']
                or digest(target) != prior_runtime.get('sha256')
                or (prep.root / 'state' / ('sdk-linux-' + cpu + '-verified.json')).exists()):
            raise RuntimeError('Existing SDK C++ runtime differs from the authenticated source')
        backup = prep.root / 'state/sdk-migrations' / ('linker-only-cxx-' + cpu + '.so')
        backup.parent.mkdir(exist_ok=True)
        shutil.copy2(target, backup)
        shutil.copy2(source, target)
    if not target.exists():
        shutil.copy2(source, target)
    if digest(target) != expected:
        raise RuntimeError('SDK C++ runtime copy readback failed')
    variables = sdk / 'cmake/cef_variables.cmake'
    text = variables.read_text('utf-8')
    marker = '# MYCEF_LINUX_PINNED_CXX_RUNTIME_V1'
    if marker not in text:
        variables.write_text(text.rstrip() + '\n\n' + marker + '\nif(OS_LINUX)\n'
                             '  list(APPEND CEF_BINARY_FILES libstdc++.so.6)\n'
                             '  list(REMOVE_DUPLICATES CEF_BINARY_FILES)\nendif()\n', encoding='utf-8')
    return {'file': 'Release/libstdc++.so.6', 'sha256': expected,
            'package_provenance': provenance, 'elf': elf,
            'purpose': 'C++20 SDK clients on old distributions; engine bytes remain unchanged.'}


def prepare(root, target):
    prep = Preparation(root)
    cpu = target.removeprefix('linux-')
    compiled_path = prep.root / 'state' / ('compiled-' + target + '.json')
    compiled = json.loads(compiled_path.read_text('utf-8'))
    if (compiled['target'] != target or compiled['chromium_revision'] != CHROMIUM_REV
            or compiled['cef_revision'] != CEF_REV):
        raise RuntimeError('The compile receipt belongs to a different target or source version')
    output = Path(compiled['output']).resolve()
    if prep.src / 'out' not in output.parents or digest(output / 'libcef.so') != compiled['cef_binary_sha256']:
        raise RuntimeError('The linked CEF output changed or escaped the build root')
    configuration = json.loads((prep.root / 'state' / ('gn-' + target + '.json')).read_text('utf-8'))
    for key in ('symbol_level', 'blink_symbol_level', 'v8_symbol_level'):
        if configuration['args'].get(key) != 2:
            raise RuntimeError('Full Release symbol configuration was not retained: ' + key)
    if configuration['args'].get('is_debug') is not False or configuration['args'].get('use_debug_fission') is not False:
        raise RuntimeError('Expected a Release build with self-contained full DWARF')
    symbols = full_dwarf(output / 'libcef.so')
    staging = prep.root / 'packages/staging' / target
    subdir = 'cef_binary_' + CHROMIUM + '_linux_' + cpu + '_release'
    sdk = staging / subdir
    if staging.exists():
        prior = prep.root / 'state' / ('sdk-' + target + '-prepared.json')
        if not prior.is_file():
            raise RuntimeError('Unverified SDK staging already exists; inspect it before replacing: ' + str(staging))
        old = json.loads(prior.read_text('utf-8'))
        if (old.get('compiled_receipt_sha256') != digest(compiled_path)
                or not (sdk / 'Release/libcef.so').is_file()
                or digest(sdk / 'Release/libcef.so') != old.get('sdk_libcef_sha256')):
            raise RuntimeError('Existing SDK staging differs from the linked output')
        if (not old.get('client_cxx_runtime')
                and (prep.root / 'state' / ('sdk-' + target + '-verified.json')).exists()):
            raise RuntimeError('Do not add a client runtime to an already published SDK')
        runtime = install_client_runtime(prep, sdk, cpu)
        if old.get('client_cxx_runtime') != runtime:
            # Explicit additive staging migration before archive publication.
            if (prep.root / 'state' / ('sdk-' + target + '-verified.json')).exists():
                raise RuntimeError('Do not migrate an already published SDK')
            migration = prep.root / 'state/sdk-migrations'
            migration.mkdir(exist_ok=True)
            shutil.copy2(prior, migration / (target + '-' + digest(prior) + '.json'))
            elf = audit(sdk, cpu, max_glibc='2.28')
            if not elf['passed']:
                raise RuntimeError('C++ runtime staging migration failed the complete ELF audit')
            write_json(prep.root / 'state' / ('elf-' + target + '.json'), elf)
            metadata = json.loads((sdk / 'MYCEF_BUILD.json').read_text('utf-8'))
            metadata.update(client_cxx_runtime=runtime, runtime_validation_completed=False)
            write_json(sdk / 'MYCEF_BUILD.json', metadata)
            old['client_cxx_runtime'] = runtime
            write_json(prior, old)
        shutil.copy2(HERE / 'LINUX-SDK.zh-CN.md', sdk / 'MYCEF_LINUX.zh-CN.md')
        print('Verified existing Linux SDK staging retained:', sdk, flush=True)
        return old
    if shutil.disk_usage(prep.root).free < 20 * 1024**3:
        raise RuntimeError('Retain the linked output; recover disk space before making the SDK staging copy')
    staging.mkdir(parents=True)
    command = [prep.depot / 'python-bin/python3', 'tools/make_distrib.py', '--output-dir', staging,
               '--distrib-subdir', subdir, '--ninja-build', '--allow-partial',
               '--no-docs', '--no-archive', '--no-format', '--x64-build' if cpu == 'x64' else '--arm64-build']
    prep.run(command, cwd=prep.src / 'cef')
    binary = sdk / 'Release'
    resources = sdk / 'Resources'
    for relative in ['Release/libcef.so', 'Release/chrome-sandbox', 'Release/libvk_swiftshader.so',
                     'Release/libvulkan.so.1', 'Release/vk_swiftshader_icd.json',
                     'Release/v8_context_snapshot.bin', 'Resources/icudtl.dat', 'Resources/resources.pak',
                     'Resources/chrome_100_percent.pak', 'Resources/chrome_200_percent.pak',
                     'include/cef_app.h', 'include/cef_version.h', 'CMakeLists.txt']:
        if not (sdk / relative).is_file():
            raise RuntimeError('Incomplete standard CEF SDK: ' + relative)
    if (sdk / 'Debug').exists():
        raise RuntimeError('A Debug directory was unexpectedly included in this Release-only SDK')
    if not any((resources / 'locales').glob('*.pak')):
        raise RuntimeError('The SDK locales are missing')
    for name in ['cefsimple', 'cefclient', 'libEGL.so', 'libGLESv2.so']:
        source = output / name
        if not source.is_file():
            raise RuntimeError('A required sample or ANGLE runtime was not built: ' + str(source))
        destination = binary / name
        if source.is_symlink():
            target = source.resolve()
            if output not in target.parents:
                raise RuntimeError('Runtime library symlink points outside the built output')
            shutil.copy2(target, destination)
        else:
            shutil.copy2(source, destination)
    variables = sdk / 'cmake/cef_variables.cmake'
    text = variables.read_text('utf-8')
    tag = '# MYCEF_LINUX_SHARED_ANGLE_RUNTIME_V1'
    if tag not in text:
        variables.write_text(text.rstrip() + '\n\n' + tag + '\nif(OS_LINUX)\n'
                             '  list(APPEND CEF_BINARY_FILES libEGL.so libGLESv2.so)\n'
                             '  list(REMOVE_DUPLICATES CEF_BINARY_FILES)\nendif()\n', encoding='utf-8')
    client_runtime = install_client_runtime(prep, sdk, cpu)
    libcef_hash = digest(binary / 'libcef.so')
    if libcef_hash != compiled['cef_binary_sha256']:
        raise RuntimeError('SDK library bytes differ from the actual linked library')
    features_path = prep.root / 'state' / ('features-' + target + '.json')
    features = json.loads(features_path.read_text('utf-8'))
    if not features.get('passed') or features['args_gn_sha256'] != configuration['args_gn_sha256']:
        raise RuntimeError('Actual requested feature/header audit has not passed for this SDK')
    shutil.copy2(features_path, sdk / 'MYCEF_FEATURES.json')
    elf = audit(sdk, cpu, max_glibc='2.28')
    write_json(prep.root / 'state' / ('elf-' + target + '.json'), elf)
    if not elf['passed']:
        raise RuntimeError('The actual packaged ELF compatibility audit failed: ' + '; '.join(elf['errors']))
    symbols.update(full_dwarf(binary / 'libcef.so'))
    metadata = {
        'target': target, 'configuration': 'Release', 'chromium_version': CHROMIUM,
        'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
        'custom_cef_chromium_combination': True, 'cef_upstream_chromium': '156.0.8078.0',
        'gn_args': configuration['args'], 'measured_max_required_glibc': elf['measured_max_required_glibc'],
        'client_cxx_runtime': client_runtime,
        'full_dwarf': symbols, 'sdk_libcef_sha256': libcef_hash,
        'windows_win7_patches_applied': False, 'independent_libx264_included': False,
        'widevine_binary_included': False, 'runtime_validation_completed': False,
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'provenance': json.loads((prep.root / 'state/prepared-posix.json').read_text('utf-8')),
    }
    write_json(sdk / 'MYCEF_BUILD.json', metadata)
    shutil.copy2(HERE / 'LINUX-SDK.zh-CN.md', sdk / 'MYCEF_LINUX.zh-CN.md')
    report = {'target': target, 'sdk': str(sdk), 'staging': str(staging),
              'compiled_receipt_sha256': digest(compiled_path), 'sdk_libcef_sha256': libcef_hash,
              'elf_report': str(prep.root / 'state' / ('elf-' + target + '.json')),
              'full_dwarf': symbols, 'client_cxx_runtime': client_runtime,
              'prepared': True, 'passed_final_sdk_validation': False,
              'scope': 'Complete Release SDK staging, raw linked bytes/full DWARF, ANGLE deployment and ELF audit. Independent client, runtime, archive and cleanup gates remain required.'}
    write_json(prep.root / 'state' / ('sdk-' + target + '-prepared.json'), report)
    print('LINUX_CEF_SDK_PREPARED_FOR_VALIDATION', target, sdk, flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=['linux-x64', 'linux-arm64'])
    args = parser.parse_args()
    prepare(args.root, args.target)


if __name__ == '__main__':
    main()
