#!/usr/bin/env python3
"""Compress a POSIX SDK while preserving modes/symlinks and verifying readback."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import tarfile


def digest_file(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def list_sdk(folder):
    root = Path(folder).resolve()
    entries = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root).as_posix()
        metadata = path.lstat()
        mode = stat.S_IMODE(metadata.st_mode)
        if path.is_symlink():
            target = path.resolve()
            if (target != root and root not in target.parents) or not target.exists():
                raise RuntimeError('SDK symlink is broken or escapes the SDK: ' + relative)
            entries[relative] = {'type': 'symlink', 'target': os.readlink(path), 'mode': mode}
        elif path.is_dir():
            entries[relative] = {'type': 'directory', 'mode': mode}
        elif path.is_file():
            entries[relative] = {'type': 'file', 'sha256': digest_file(path), 'bytes': metadata.st_size, 'mode': mode}
        else:
            raise RuntimeError('Unexpected special file in SDK: ' + relative)
    return entries


def verify_archive(path, folder_name, expected):
    process = subprocess.Popen(['zstd', '--decompress', '--stdout', '--quiet', str(path)], stdout=subprocess.PIPE)
    seen = set()
    try:
        with tarfile.open(fileobj=process.stdout, mode='r|') as archive:
            for member in archive:
                if not member.name.startswith(folder_name + '/'):
                    raise RuntimeError('Archive member has a different SDK root')
                relative = member.name[len(folder_name) + 1:]
                if relative in seen or relative not in expected:
                    raise RuntimeError('Duplicate or unexpected archive member: ' + relative)
                seen.add(relative)
                info = expected[relative]
                if member.mode != info['mode']:
                    raise RuntimeError('SDK executable or directory mode changed: ' + relative)
                if info['type'] == 'directory':
                    if not member.isdir():
                        raise RuntimeError('SDK directory was not preserved: ' + relative)
                elif info['type'] == 'symlink':
                    if not member.issym() or member.linkname != info['target']:
                        raise RuntimeError('SDK symlink was not preserved: ' + relative)
                else:
                    if not member.isfile() or member.size != info['bytes']:
                        raise RuntimeError('SDK regular file metadata changed: ' + relative)
                    value = hashlib.sha256()
                    stream = archive.extractfile(member)
                    for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
                        value.update(block)
                    if value.hexdigest() != info['sha256']:
                        raise RuntimeError('SDK file readback SHA256 mismatch: ' + relative)
        # Consume/check the zstd frame trailer, not only tar's final blocks.
        while process.stdout.read(1024 * 1024):
            pass
        if process.wait() != 0:
            raise RuntimeError('Compressed SDK frame checksum failed')
        if seen != set(expected):
            raise RuntimeError('The archive omits SDK entries')
    finally:
        process.stdout.close()
        if process.poll() is None:
            process.terminate()
            process.wait()


def create_archive(folder, destination):
    root, destination = Path(folder).resolve(), Path(destination).resolve()
    if root == destination or root in destination.parents:
        raise RuntimeError('Archive must be outside its SDK directory')
    entries = list_sdk(root)
    if not entries:
        raise RuntimeError('Refusing to archive an empty SDK')
    # This manifest documents file payloads, executable bits and framework
    # symlinks. It excludes itself to avoid a circular checksum.
    manifest = root / 'SHA256SUMS.json'
    if manifest.exists():
        prior = json.loads(manifest.read_text('utf-8'))
        payload = {name: info for name, info in entries.items() if name != 'SHA256SUMS.json'}
        if prior != payload:
            raise RuntimeError('SDK contents changed since its existing archive manifest; inspect before repackaging')
    else:
        manifest.write_text(json.dumps(entries, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    metadata = manifest.stat()
    entries['SHA256SUMS.json'] = {'type': 'file', 'sha256': digest_file(manifest),
                                 'bytes': metadata.st_size, 'mode': stat.S_IMODE(metadata.st_mode)}
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        # A prior run may have published the archive before writing its final
        # receipt. Recover only after reading every entry against this SDK.
        verify_archive(destination, root.name, entries)
        value = digest_file(destination)
        destination.with_suffix(destination.suffix + '.sha256').write_text(value + '  ' + destination.name + '\n', encoding='ascii')
        return {'archive': str(destination), 'archive_sha256': value, 'bytes': destination.stat().st_size,
                'entries': len(entries), 'files': sum(item['type'] == 'file' for item in entries.values()),
                'symlinks': sum(item['type'] == 'symlink' for item in entries.values()),
                'modes_symlinks_frame_and_all_file_hashes_verified': True}
    pending = destination.with_suffix(destination.suffix + '.partial')
    with pending.open('wb') as target:
        process = subprocess.Popen(['zstd', '--threads=4', '-6', '--check', '--quiet', '--stdout'],
                                   stdin=subprocess.PIPE, stdout=target)
        try:
            with tarfile.open(fileobj=process.stdin, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for relative, info in sorted(entries.items()):
                    path = root / relative
                    member = tarfile.TarInfo(root.name + '/' + relative)
                    member.mode = info['mode']
                    member.mtime = int(path.lstat().st_mtime)
                    member.uid = member.gid = 0
                    if info['type'] == 'directory':
                        member.type = tarfile.DIRTYPE
                        archive.addfile(member)
                    elif info['type'] == 'symlink':
                        member.type = tarfile.SYMTYPE
                        member.linkname = info['target']
                        archive.addfile(member)
                    else:
                        member.type = tarfile.REGTYPE
                        member.size = info['bytes']
                        with path.open('rb') as stream:
                            archive.addfile(member, stream)
            process.stdin.close()
            if process.wait() != 0:
                raise RuntimeError('SDK compression failed')
        finally:
            if not process.stdin.closed:
                process.stdin.close()
            if process.poll() is None:
                process.terminate()
                process.wait()
    verify_archive(pending, root.name, entries)
    value = digest_file(pending)
    pending.replace(destination)
    destination.with_suffix(destination.suffix + '.sha256').write_text(value + '  ' + destination.name + '\n', encoding='ascii')
    return {'archive': str(destination), 'archive_sha256': value, 'bytes': destination.stat().st_size,
            'entries': len(entries), 'files': sum(item['type'] == 'file' for item in entries.values()),
            'symlinks': sum(item['type'] == 'symlink' for item in entries.values()),
            'modes_symlinks_frame_and_all_file_hashes_verified': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', required=True)
    parser.add_argument('--archive', required=True)
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    result = create_archive(args.sdk, args.archive)
    Path(args.report).write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
