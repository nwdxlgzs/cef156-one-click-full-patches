#!/usr/bin/env python3
"""Collect real Apple CLT/SDK metadata for a later Linux macOS GN adapter.

Never fabricates an Xcode installation or rewrites SDK version files.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import plistlib
import re
import xml.etree.ElementTree as ET

from apple_sdk_package import verify
from archive_posix import digest_file
from prepare_posix import Preparation, write_json


def collect(prep):
    extracted = json.loads((prep.root / 'state/apple-sdk-extracted-universal.json').read_text('utf-8'))
    package = extracted['package']
    archive = Path(package['path'])
    if digest_file(archive) != package['sha256']:
        raise RuntimeError('The verified Apple SDK-only package changed')
    verified = verify(archive, package['catalog_xar_toc_sha1'], package['bytes'])
    info = next(item for item in verified['members'] if item['name'] == 'PackageInfo')
    with archive.open('rb') as stream:
        stream.seek(info['offset'])
        data = stream.read(info['length'])
    metadata = ET.fromstring(data)
    identifier = metadata.get('identifier')
    version = metadata.get('version')
    if identifier != 'com.apple.pkg.CLTools_SDK_macOS_NMOS' or not re.fullmatch(r'\d+(?:\.\d+){4}', version or ''):
        raise RuntimeError('Unexpected original CLT SDK PackageInfo identity/version')
    sdk = next(item for item in extracted['sdks'] if item['version'] == '26.5' and item['product_build'] == '25F70')
    root = Path(sdk['root']).resolve()
    if prep.root / 'cache/apple-research' not in root.parents:
        raise RuntimeError('The original SDK escaped its dedicated cache')
    settings_path = root / 'SDKSettings.plist'
    if digest_file(settings_path) != sdk['settings_sha256']:
        raise RuntimeError('Original SDK settings differ from the extraction receipt')
    settings = plistlib.loads(settings_path.read_bytes())
    system = plistlib.loads((root / 'System/Library/CoreServices/SystemVersion.plist').read_bytes())
    architectures = settings['SupportedTargets']['macosx']['Archs']
    if settings['Version'] != '26.5' or system['ProductBuildVersion'] != '25F70' or not {'arm64', 'x86_64'} <= set(architectures):
        raise RuntimeError('The original SDK does not match the fixed universal version/build/CPUs')
    smoke = json.loads((prep.root / 'state/mac-cross-compiler-universal-smoke.json').read_text('utf-8'))
    if (not smoke['passed'] or smoke['sdk_version'] != settings['Version']
            or smoke['sdk_build'] != system['ProductBuildVersion']
            or len(smoke.get('debug_results', [])) != 2 or not all(item['passed'] for item in smoke['debug_results'])):
        raise RuntimeError('The actual compiler/framework/dSYM preflight did not validate this SDK')
    files = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root).as_posix()
        if path.is_symlink():
            target = path.resolve()
            if root not in target.parents or not target.exists():
                raise RuntimeError('The SDK has a broken or escaping symlink: ' + relative)
            files[relative] = {'type': 'symlink', 'target': os.readlink(path)}
        elif path.is_file():
            files[relative] = {'type': 'file', 'bytes': path.stat().st_size, 'sha256': digest_file(path)}
    manifest = prep.root / 'state/mac-sdk-tree-observed.json'
    observed_tree = {'sdk': str(root), 'files': files,
                     'scope': 'Observed original SDK cache tree after verified package extraction and compiler tests; future mutation detection, not a replacement for the signed upstream package.'}
    if manifest.exists():
        if json.loads(manifest.read_text('utf-8')) != observed_tree:
            raise RuntimeError('The previously observed original SDK cache tree changed; preserve it for inspection')
    else:
        write_json(manifest, observed_tree)
    parts = version.split('.')
    compat = f'{int(parts[0]):02}{parts[1]}{parts[2]}'
    result = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
              'sdk_path': str(root), 'sdk_version': settings['Version'], 'sdk_build': system['ProductBuildVersion'],
              'sdk_settings_sha256': digest_file(settings_path), 'architectures': architectures,
              'clt_package_identifier': identifier, 'clt_package_version': version,
              'clt_compat_version': compat, 'clt_compat_version_int': int(compat),
              'clt_build_token': 'CLT_' + version.replace('.', '_'),
              'package_sha256': package['sha256'], 'package_info_sha256': hashlib.sha256(data).hexdigest(),
              'sdk_tree_manifest': str(manifest), 'sdk_tree_manifest_sha256': digest_file(manifest),
              'compiler_smoke_receipt_sha256': digest_file(prep.root / 'state/mac-cross-compiler-universal-smoke.json'),
              'xcode_installed': False, 'xcode_product_build_known': False,
              'gn_integration_verified': False,
              'scope': 'Real verified CLT SDK PackageInfo and SDK metadata; explicit CLT compatibility fields for a future GN adapter. No fabricated Xcode product build, SDK rewrite, GN/CEF compilation or macOS runtime claim.'}
    receipt = prep.root / 'state/mac-sdk-metadata.json'
    if receipt.exists():
        prior = json.loads(receipt.read_text('utf-8'))
        stable = lambda value: {key: item for key, item in value.items() if key != 'observed_utc'}
        if stable(prior) != stable(result):
            raise RuntimeError('Existing SDK metadata differs; inspect before replacing GN inputs')
        return prior
    write_json(receipt, result)
    return result


def emit(prep):
    result = json.loads((prep.root / 'state/mac-sdk-metadata.json').read_text('utf-8'))
    if digest_file(Path(result['sdk_tree_manifest'])) != result['sdk_tree_manifest_sha256']:
        raise RuntimeError('The recorded original SDK tree manifest changed')
    if digest_file(Path(result['sdk_path']) / 'SDKSettings.plist') != result['sdk_settings_sha256']:
        raise RuntimeError('Original SDK settings changed')
    for name in ['sdk_path', 'sdk_version', 'sdk_build', 'clt_compat_version', 'clt_compat_version_int', 'clt_build_token']:
        value = result[name]
        print(name + '=' + (str(value) if isinstance(value, int) else json.dumps(value)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--emit-gn', action='store_true')
    args = parser.parse_args()
    prep = Preparation(args.root)
    if args.emit_gn:
        emit(prep)
    else:
        print(json.dumps(collect(prep), indent=2), flush=True)


if __name__ == '__main__':
    main()
