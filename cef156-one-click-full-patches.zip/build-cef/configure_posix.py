#!/usr/bin/env python3
"""Generate one Release configuration using CEF's real argument policy."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

from apply_posix_patches import install, verify_bundle
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent


def merged_arguments(cef, plan, target, extra=None):
    selected = plan['targets'][target]
    spec = importlib.util.spec_from_file_location('mycef_pinned_gn_args', cef / 'tools/gn_args.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    # CEF's defaults are target-specific. Its upstream script assumes native
    # host OS, so select the intended target policy in this isolated module;
    # leave Python's real sys.platform and the source file unchanged.
    module.platform = selected['target_os']
    module.machine = 'amd64'
    values = {**plan['common_gn'], **plan['platform_gn'][selected['target_os']],
              'target_os': selected['target_os'], 'target_cpu': selected['target_cpu'], **(extra or {})}
    original = os.environ.pop('GN_DEFINES', None)
    try:
        values = module.GetConfigArgs(module.GetMergedArgs(values), False, selected['target_cpu'])
    finally:
        if original is not None:
            os.environ['GN_DEFINES'] = original
    if values['is_debug'] is not False or values['symbol_level'] != 2 or values['is_component_build']:
        raise RuntimeError('Unexpected build type or incomplete symbol configuration')
    return values, module.GetConfigFileContents(values)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', choices=['linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64'], required=True)
    parser.add_argument('--write-args-only', action='store_true',
                        help='Write target arguments for inspection; no GN-success marker is generated')
    parser.add_argument('--allow-reconfigure', action='store_true',
                        help='Preserve the previous args/receipt and regenerate an idle output with revised arguments')
    args = parser.parse_args()
    prep = Preparation(args.root)
    plan = json.loads((HERE / 'posix-targets.json').read_text('utf-8'))
    if plan['chromium_revision'] != CHROMIUM_REV or plan['cef_revision'] != CEF_REV:
        raise RuntimeError('Build target plan differs from source lock')
    selected = plan['targets'][args.target]
    mac_inputs = None
    if selected['target_os'] == 'mac':
        from archive_posix import digest_file
        from mac_cross_sdk_info import load
        marker = prep.root / 'state/mac-gn-inputs-prepared.json'
        if not marker.is_file():
            raise RuntimeError('Run prepare_macos_gn_inputs.py with the real SDK/toolchain before macOS GN')
        mac_inputs = json.loads(marker.read_text('utf-8'))
        metadata = Path(mac_inputs['metadata_path']).resolve()
        if prep.root / 'cache/mac-gn' not in metadata.parents or digest_file(metadata) != mac_inputs['metadata_sha256']:
            raise RuntimeError('The verified macOS GN input metadata changed or escaped its cache')
        load(metadata)
    if not (prep.root / 'state/posix-hooks-complete.json').is_file():
        raise RuntimeError('Complete actual Chromium hooks before GN generation')
    install(prep)
    verify_bundle()
    cef = prep.src / 'cef'
    python = prep.depot / 'python-bin/python3'
    prep.run([python, 'tools/version_manager.py', '-u', '--fast-check'], cwd=cef)
    values, text = merged_arguments(cef, plan, args.target, mac_inputs['gn_arguments'] if mac_inputs else None)
    output = prep.src / 'out' / ('Release_GN_' + selected['target_cpu'] + ('_mac' if selected['target_os'] == 'mac' else ''))
    output.mkdir(parents=True, exist_ok=True)
    path = output / 'args.gn'
    if (path.is_file() and path.read_text('utf-8') != text
            and ((output / 'build.ninja').exists() or (output / '.ninja_log').exists())):
        if not args.allow_reconfigure:
            raise RuntimeError('Existing output has different GN arguments; inspect before changing a live build')
        for process in Path('/proc').iterdir():
            if not process.name.isdigit() or int(process.name) == os.getpid():
                continue
            try:
                name = (process / 'comm').read_text().strip()
                if name not in ('ninja', 'siso', 'clang', 'clang++', 'ld.lld', 'ld64.lld', 'rustc'):
                    continue
                cwd = (process / 'cwd').resolve()
                command = (process / 'cmdline').read_bytes().decode(errors='replace')
                if cwd == output or output in cwd.parents or str(output) in command:
                    raise RuntimeError('Refusing GN reconfiguration while a live build uses this output')
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                continue
        prior_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        backup = prep.root / 'state/gn-migrations' / args.target / prior_hash
        backup.mkdir(parents=True, exist_ok=True)
        if not (backup / 'args.gn').exists():
            (backup / 'args.gn').write_bytes(path.read_bytes())
        prior_record = prep.root / 'state' / ('gn-' + args.target + '.json')
        if prior_record.exists() and not (backup / 'gn-receipt.json').exists():
            (backup / 'gn-receipt.json').write_bytes(prior_record.read_bytes())
    if not path.is_file() or path.read_text('utf-8') != text:
        path.write_text(text, encoding='utf-8', newline='\n')
    if args.write_args_only:
        print('ARGS_WRITTEN', args.target, path, flush=True)
        return
    prep.run([prep.depot / 'gn', 'gen', output, '--fail-on-unused-args'], cwd=prep.src)
    result = prep.run([prep.depot / 'gn', 'args', output, '--list', '--json'], cwd=prep.src, capture=True)
    effective = json.loads(result.stdout)
    record = {'target': args.target, 'output': str(output), 'args': values, 'effective_gn_args': effective,
              'args_gn_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
              'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
              'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'gn_generated': True,
              'sdk_built': False}
    write_json(prep.root / 'state' / ('gn-' + args.target + '.json'), record)
    if mac_inputs:
        write_json(prep.root / 'state/mac-sdk-prepared.json', {
            'target': args.target, 'sdk_version': mac_inputs['sdk_version'], 'sdk_build': mac_inputs['sdk_build'],
            'metadata_sha256': mac_inputs['metadata_sha256'], 'gn_generated': True, 'cef_built': False,
            'gn_receipt_sha256': hashlib.sha256((prep.root / 'state' / ('gn-' + args.target + '.json')).read_bytes()).hexdigest(),
            'scope': 'Actual target GN generation with verified CLT SDK/debug tools; full CEF build, resources/signing and macOS runtime remain pending.'})
    print('GN_CONFIGURATION_GENERATED', args.target, output, flush=True)


if __name__ == '__main__':
    main()
