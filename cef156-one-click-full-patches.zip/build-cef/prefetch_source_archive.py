#!/usr/bin/env python3
"""Download the exact official source archive as an optional preparation cache.

Does not initialize a checkout, apply patches or mark gclient sync complete.
Uses bounded parallel HTTPS ranges, then checks the published object MD5.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time

URL = "https://chromium-browser-official.storage.googleapis.com/chromium-156.0.8071.0.tar.xz"
SIZE = 4416395880
MD5 = "8cfe678a480b592dc24d53e0b5d53518"
CHUNK = 16 * 1024 * 1024
REQUEST_BYTES = 1024 * 1024


def range_header(path):
    text = path.read_text('ascii', errors='replace') if path.is_file() else ''
    matches = re.findall(r'^content-range:\s*bytes (\d+)-(\d+)/(\d+)\s*$', text, re.M | re.I)
    return tuple(map(int, matches[-1])) if matches else None


def download_piece(curl, parts, index, start, end):
    """Resume a bounded byte range, accepting only matching HTTP responses."""
    size = end - start + 1
    path = parts / (str(index).zfill(4) + '.part')
    if path.is_file() and path.stat().st_size == size:
        return path
    partial = path.with_suffix('.partial')
    headers = path.with_suffix('.headers')
    tail = path.with_suffix('.tail')
    receipt = path.with_suffix('.progress.json')
    offset = 0
    if partial.is_file():
        length = partial.stat().st_size
        if receipt.is_file():
            saved = json.loads(receipt.read_text('utf-8'))
            valid = (saved.get('range') == [start, end, SIZE] and saved.get('stored') == length
                     and saved.get('sha256') == hashlib.sha256(partial.read_bytes()).hexdigest())
        else:
            # Migrate a prefix left by the older non-resuming helper only
            # when its original HTTP response names this precise range.
            valid = range_header(headers) == (start, end, SIZE)
        if valid and 0 <= length <= size:
            offset = length
        else:
            partial.unlink()
            receipt.unlink(missing_ok=True)
    attempt = 0
    while True:
        if offset == size:
            partial.replace(path)
            receipt.unlink(missing_ok=True)
            return path
        requested = start + offset
        requested_end = min(end, requested + REQUEST_BYTES - 1)
        headers.unlink(missing_ok=True)
        tail.unlink(missing_ok=True)
        command = [curl, '--fail', '--silent', '--show-error', '--connect-timeout', '15',
                   '--max-time', '120', '--speed-limit', '1024', '--speed-time', '15',
                   '--range', f'{requested}-{requested_end}', '--dump-header', str(headers),
                   '--output', str(tail), URL]
        result = subprocess.run(command, capture_output=True)
        received = tail.stat().st_size if tail.is_file() else 0
        accepted = (range_header(headers) == (requested, requested_end, SIZE) and
                    0 < received <= requested_end - requested + 1)
        if accepted:
            # Curl may return a timeout after receiving a valid range prefix.
            # Keep these bytes and request only the remainder next time.
            with partial.open('ab' if offset else 'wb') as destination, tail.open('rb') as source:
                shutil.copyfileobj(source, destination)
            offset += received
            record = {'range': [start, end, SIZE], 'stored': offset,
                      'sha256': hashlib.sha256(partial.read_bytes()).hexdigest()}
            temporary = receipt.with_suffix('.tmp')
            temporary.write_text(json.dumps(record), 'utf-8')
            temporary.replace(receipt)
        tail.unlink(missing_ok=True)
        if offset == size:
            partial.replace(path)
            receipt.unlink(missing_ok=True)
            return path
        if accepted and result.returncode == 0:
            # Short HTTP ranges finish much more reliably on this route.
            # The 16 MiB on-disk piece identity and resume receipts stay stable.
            attempt = 0
            continue
        print(f'ARCHIVE_RANGE_RETRY {index} attempt={attempt + 1} exit={result.returncode} stored={offset}/{size}', flush=True)
        if attempt == 7:
            raise RuntimeError(f'Source range download incomplete: {start}-{end}; '
                               f'{result.stderr.decode(errors="replace")}')
        time.sleep(2 * (attempt + 1))
        attempt += 1


def finish_archive(output, parts, count):
    record = {"url": URL, "size": SIZE, "md5": MD5, "path": str(output),
              "scope": "Source preparation cache only; not a completed Git checkout or dependency sync."}
    output.with_suffix(output.suffix + ".verified.json").write_text(json.dumps(record, indent=2), "utf-8")
    if parts.is_symlink() or parts.resolve().parent != output.parent.resolve():
        raise RuntimeError('Unsafe source archive parts directory; cleanup refused')
    for index in range(count):
        for suffix in ['.part', '.headers', '.partial', '.tail', '.progress.json', '.progress.tmp']:
            (parts / (str(index).zfill(4) + suffix)).unlink(missing_ok=True)
    try:
        parts.rmdir()
    except OSError:
        pass
    print("SOURCE_ARCHIVE_VERIFIED " + json.dumps(record), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True)
    parser.add_argument("--jobs", type=int, default=8, choices=range(1, 33))
    args = parser.parse_args()
    directory = Path(args.directory)
    directory.mkdir(parents=True, exist_ok=True)
    output = directory / "chromium-156.0.8071.0.tar.xz"
    parts = directory / "chromium-official-parts"
    count = (SIZE + CHUNK - 1) // CHUNK
    if output.is_file() and output.stat().st_size == SIZE:
        digest = hashlib.md5()
        with output.open('rb') as source:
            for block in iter(lambda: source.read(1024 * 1024), b''):
                digest.update(block)
        if digest.hexdigest() == MD5:
            finish_archive(output, parts, count)
            return
    parts.mkdir(exist_ok=True)
    curl = shutil.which("curl.exe") or shutil.which("curl")
    if not curl:
        raise RuntimeError("curl is required")
    def piece(index):
        start = index * CHUNK
        end = min(SIZE, start + CHUNK) - 1
        return download_piece(curl, parts, index, start, end)
    with ThreadPoolExecutor(args.jobs) as pool:
        for completed, future in enumerate(as_completed([pool.submit(piece, index) for index in range(count)]), 1):
            future.result()
            if completed % 8 == 0 or completed == count:
                print(f"ARCHIVE_PARTS {completed}/{count}", flush=True)
    pending = output.with_suffix(output.suffix + ".partial")
    digest = hashlib.md5()
    written = 0
    with pending.open("wb") as target:
        for index in range(count):
            with (parts / (str(index).zfill(4) + ".part")).open("rb") as source:
                for block in iter(lambda: source.read(1024 * 1024), b""):
                    target.write(block)
                    digest.update(block)
                    written += len(block)
    if written != SIZE or digest.hexdigest() != MD5:
        raise RuntimeError("Official archive integrity check failed; parts preserved")
    pending.replace(output)
    finish_archive(output, parts, count)


if __name__ == "__main__":
    main()
