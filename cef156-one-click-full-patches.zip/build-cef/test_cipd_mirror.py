"""Offline tests for mirror identity, immutable pins and the CIPD wire protocol."""
import base64
import hashlib
import http.server
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest import mock
import urllib.request
import zipfile

import cipd_mirror as mirror
from python_wheel_mirror import WheelMirror, ORIGIN


class MirrorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mycef-mirror-tests-")
        self.root = Path(self.temp.name)
        self.package = "infra/tools/cipd/windows-amd64"
        self.version = "git_revision:" + "1" * 40
        self.archive = self.root / "fixture.zip"
        with zipfile.ZipFile(self.archive, "w") as z:
            z.writestr(".cipdpkg/manifest.json", json.dumps({"package_name": self.package}))
            z.writestr("cipd.exe", b"test client bytes")
        self.payload = self.archive.read_bytes()
        self.digest = hashlib.sha256(self.payload).hexdigest()
        self.instance_id = base64.urlsafe_b64encode(bytes.fromhex(self.digest) + b"\x02").decode()
        self.cache = mirror.MirrorCache(self.root / "cache")

    def tearDown(self):
        self.temp.cleanup()

    def download(self, command):
        Path(command[command.index("--output") + 1]).write_bytes(self.payload)
        return mock.Mock(returncode=0)

    def test_fixed_instance_hash_and_package_identity_are_enforced(self):
        with mock.patch.object(mirror.subprocess, "run", side_effect=self.download):
            entry = self.cache.resolve(self.package, self.instance_id)
            self.assertEqual(entry["sha256"], self.digest)
            with self.assertRaisesRegex(ValueError, "pinned instance ID"):
                self.cache.resolve(self.package, "0" * 40)
            with self.assertRaisesRegex(ValueError, "identity mismatch"):
                self.cache.resolve("wrong/package", self.version)

    def test_cache_reuses_verified_bytes_and_rejects_changed_tag(self):
        with mock.patch.object(mirror.subprocess, "run", side_effect=self.download) as fetch:
            entry = self.cache.resolve(self.package, self.version)
            self.cache.resolve(self.package, self.version)
            self.assertEqual(fetch.call_count, 1)
            (self.cache.directory / (entry["sha256"] + ".zip")).unlink()
            with zipfile.ZipFile(self.archive, "a") as z:
                z.writestr("changed", b"new bytes")
            self.payload = self.archive.read_bytes()
            with self.assertRaisesRegex(ValueError, "version changed"):
                self.cache.resolve(self.package, self.version)

    def test_official_version_pin_reuses_fixed_instance_and_enforces_its_hash(self):
        pins = {self.package + '@' + self.version: self.instance_id}
        cache = mirror.MirrorCache(self.cache.directory, version_pins=pins)
        with mock.patch.object(mirror.subprocess, 'run', side_effect=self.download) as fetch:
            cache.resolve(self.package, self.instance_id)
            entry = cache.resolve(self.package, self.version)
            self.assertEqual(entry['sha256'], self.digest)
            self.assertEqual(fetch.call_count, 1)
            self.assertTrue(fetch.call_args.args[0][-1].endswith('/+/' + self.instance_id))
        bad = mirror.MirrorCache(self.root / 'bad-pin',
                                version_pins={self.package + '@' + self.version: '0' * 40})
        with mock.patch.object(mirror.subprocess, 'run', side_effect=self.download):
            with self.assertRaisesRegex(ValueError, 'pinned instance ID'):
                bad.resolve(self.package, self.version)
        with self.assertRaisesRegex(ValueError, 'immutable'):
            mirror.MirrorCache(self.root / 'recursive', version_pins={self.version: self.version})

    def test_separate_cache_clients_preserve_each_others_index_entries(self):
        second = mirror.MirrorCache(self.cache.directory)
        newer = 'git_revision:' + '2' * 40
        with mock.patch.object(mirror.subprocess, 'run', side_effect=self.download) as fetch:
            self.cache.resolve(self.package, self.version)
            second.resolve(self.package, newer)
            self.cache.resolve(self.package, newer)
            second.resolve(self.package, self.version)
        self.assertEqual(fetch.call_count, 2)
        persisted = json.loads(self.cache.index_path.read_text('utf-8'))
        self.assertEqual(set(persisted), {self.package + '@' + self.version, self.package + '@' + newer})

    def test_bootstrap_requires_official_executable_digest(self):
        depot = self.root / "depot"
        depot.mkdir()
        (depot / "cipd_client_version").write_text(self.version, "utf-8")
        digests = depot / "cipd_client_version.digests"
        digests.write_text("windows-amd64 sha256 " + "0" * 64, "utf-8")
        with mock.patch.object(mirror.subprocess, "run", side_effect=self.download):
            with self.assertRaisesRegex(ValueError, "official bootstrap SHA256"):
                self.cache.bootstrap_client(depot)
            self.assertFalse((depot / ".cipd_client.exe").exists())
            digests.write_text("windows-amd64 sha256 " + hashlib.sha256(b"test client bytes").hexdigest(), "utf-8")
            self.cache.bootstrap_client(depot)
        self.assertEqual((depot / ".cipd_client.exe").read_bytes(), b"test client bytes")

    def test_rpc_resolve_download_range_and_client_digest_aliases(self):
        with mock.patch.object(mirror.subprocess, "run", side_effect=self.download):
            self.cache.resolve(self.package, self.version)
        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), mirror.Handler)
        server.cache = self.cache
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = "http://127.0.0.1:" + str(server.server_port)
        try:
            def rpc(method, body):
                req = urllib.request.Request(base + "/prpc/cipd.Repository/" + method, data=body,
                    headers={"Content-Type": "application/prpc; encoding=binary"})
                with urllib.request.urlopen(req, timeout=5) as result:
                    self.assertEqual(result.headers["X-Prpc-Grpc-Code"], "0")
                    return result.read()
            result = mirror.parse_fields(rpc("ResolveVersion", mirror.field(1, self.package) + mirror.field(2, self.version)))
            ref = mirror.parse_fields(result[2])
            self.assertEqual(ref[2].decode(), self.digest)
            request = mirror.field(1, self.package) + mirror.field(2, result[2])
            url = mirror.parse_fields(rpc("GetInstanceURL", request))[1].decode()
            with urllib.request.urlopen(urllib.request.Request(url, headers={"Range": "bytes=3-17"})) as response:
                self.assertEqual(response.status, 206)
                self.assertEqual(response.read(), self.payload[3:18])
            client = rpc("DescribeClient", request)
            sha = hashlib.sha256(b"test client bytes").hexdigest()
            self.assertIn(mirror.field(6, mirror.field(1, 2) + mirror.field(2, sha)), client)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_linux_client_bootstrap_and_rpc_use_elf_payload_and_own_digest(self):
        platform = 'linux-amd64'
        self.package = 'infra/tools/cipd/' + platform
        executable = b'\x7fELFlinux client fixture'
        with zipfile.ZipFile(self.archive, 'w') as z:
            z.writestr('.cipdpkg/manifest.json', json.dumps({'package_name': self.package}))
            z.writestr('cipd', executable)
        self.payload = self.archive.read_bytes()
        depot = self.root / 'linux-depot'
        depot.mkdir()
        (depot / 'cipd_client_version').write_text(self.version, 'utf-8')
        digests = depot / 'cipd_client_version.digests'
        digest = hashlib.sha256(executable).hexdigest()
        digests.write_text('linux-amd64 sha256 ' + '0' * 64 + '\nwindows-amd64 sha256 ' + digest, 'utf-8')
        with mock.patch.object(mirror.subprocess, 'run', side_effect=self.download):
            with self.assertRaisesRegex(ValueError, 'official bootstrap SHA256'):
                self.cache.bootstrap_client(depot, platform)
            self.assertFalse((depot / '.cipd_client').exists())
            digests.write_text('linux-amd64 sha256 ' + digest, 'utf-8')
            self.cache.bootstrap_client(depot, platform)
        self.assertEqual((depot / '.cipd_client').read_bytes(), executable)
        self.assertFalse((depot / '.cipd_client.exe').exists())
        self.assertTrue((depot / '.versions/.cipd_client.cipd_version').is_file())
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), mirror.Handler)
        server.cache = self.cache
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(server.server_port)
        try:
            entry = self.cache.resolve(self.package, self.version)
            ref = mirror.field(1, 2) + mirror.field(2, entry['sha256'])
            req = urllib.request.Request(base + '/prpc/cipd.Repository/DescribeClient',
                data=mirror.field(1, self.package) + mirror.field(2, ref),
                headers={'Content-Type': 'application/prpc; encoding=binary'})
            with urllib.request.urlopen(req) as response:
                fields = mirror.parse_fields(response.read())
            url = mirror.parse_fields(fields[3])[1].decode()
            with urllib.request.urlopen(url) as response:
                self.assertEqual(response.read(), executable)
            with urllib.request.urlopen(base + '/client?platform=linux-amd64&version=' + self.version) as response:
                self.assertEqual(response.read(), executable)
        finally:
            server.shutdown()
            server.server_close()
            thread.join()

    def test_wheel_index_keeps_hashes_and_supports_uv_head(self):
        cache = WheelMirror(self.root / 'wheels')
        payload = b'wheel bytes already checked against the official index'
        digest = hashlib.sha256(payload).hexdigest()
        (cache.directory / (digest + '.whl')).write_bytes(payload)
        relative = 'fixture/fixture-1.0-py3-none-any.whl'
        (cache.directory / 'fixture.html').write_text(
            '<a href="' + ORIGIN + relative + '#sha256=' + digest + '">fixture</a>', 'utf-8')
        server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), mirror.Handler)
        server.wheels = cache
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        base = 'http://127.0.0.1:' + str(server.server_port)
        try:
            with urllib.request.urlopen(base + '/python/simple/fixture/') as result:
                index = result.read().decode()
            wheel_url = base + '/python/files/' + digest + '/' + relative
            self.assertIn(wheel_url + '#sha256=' + digest, index)
            with urllib.request.urlopen(urllib.request.Request(wheel_url, method='HEAD')) as result:
                self.assertEqual(int(result.headers['Content-Length']), len(payload))
                self.assertEqual(result.read(), b'')
            with urllib.request.urlopen(wheel_url) as result:
                self.assertEqual(result.read(), payload)
            with self.assertRaises(ValueError):
                cache.download('../unrelated', self.root / 'bad')
        finally:
            server.shutdown()
            server.server_close()
            thread.join()


if __name__ == "__main__":
    unittest.main()
