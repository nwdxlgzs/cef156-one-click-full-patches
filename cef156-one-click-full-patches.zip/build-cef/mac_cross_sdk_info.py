#!/usr/bin/env python3
"""Emit verified CLT SDK fields for Chromium GN on a Linux build host.

This file is also included verbatim by the macOS source adaptation patch.
There is no Xcode installation or Xcode product build in this configuration.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import plistlib
import sys


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def load(path):
    metadata = json.loads(Path(path).read_text('utf-8'))
    if (metadata.get('format') != 1 or metadata.get('host_os') != 'linux'
            or metadata.get('xcode_installed') is not False):
        raise RuntimeError('Not a verified Linux/CLT cross-build configuration')
    for filename, expected in metadata['verified_files'].items():
        if digest(filename) != expected:
            raise RuntimeError('macOS cross-build input changed: ' + filename)
    sdk = Path(metadata['sdk_path']).resolve()
    settings = plistlib.loads((sdk / 'SDKSettings.plist').read_bytes())
    system = plistlib.loads((sdk / 'System/Library/CoreServices/SystemVersion.plist').read_bytes())
    if (settings['Version'] != metadata['sdk_version']
            or system['ProductBuildVersion'] != metadata['sdk_build']
            or not {'arm64', 'x86_64'} <= set(settings['SupportedTargets']['macosx']['Archs'])):
        raise RuntimeError('Real SDK identity/architectures differ from the verified configuration')
    for name in ['dsymutil_path', 'otool_path']:
        if not Path(metadata[name]).is_file():
            raise RuntimeError('Missing Linux macOS auxiliary tool: ' + name)
    return metadata


def emit(path):
    metadata = load(path)
    for name in ['sdk_path', 'sdk_version', 'sdk_build', 'clt_package_version',
                 'clt_compat_version_int', 'clt_build_token', 'dsymutil_path', 'otool_path']:
        value = metadata[name]
        print(name + '=' + (str(value) if isinstance(value, int) else json.dumps(value)))


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: mac_cross_sdk_info.py <verified-cross-metadata.json>')
    emit(sys.argv[1])
