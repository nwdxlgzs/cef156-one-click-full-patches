#!/usr/bin/env python3
"""Complete a genuine Chromium Git snapshot without omitting missing files.

An optional interrupted pack can supply objects Git can still validate. The
pack recovery exit code is recorded, never treated as proof of completion.
Remaining exact blob IDs are fetched in bounded batches from the configured
origin. Success requires the real commit's entire blob set to be present.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import re
import subprocess
import time

COMMIT = "aa939feff52ea94f0ca07d8029086738c2683685"


def required_blobs(repository, environment, revision=COMMIT):
    result = subprocess.run(["git", "-C", str(repository), "ls-tree", "-r", "-z", revision],
                            check=True, capture_output=True, env=environment)
    required = {}
    for entry in result.stdout.split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        _, kind, oid = metadata.split()
        if kind == b"blob":
            required.setdefault(oid.decode("ascii"), []).append(path.decode("utf-8"))
    return required


def present_blobs(repository, required, environment):
    # Git 2.43 aborts a direct batch-check of an absent promised blob even
    # with GIT_NO_LAZY_FETCH=1. Enumerating locally stored objects avoids both
    # that fatal lookup and any implicit network fetch on older Git versions.
    result = subprocess.run(["git", "-C", str(repository), "cat-file", "--batch-all-objects", "--unordered",
                             "--batch-check=%(objectname) %(objecttype)"],
                            check=True, capture_output=True, env=environment)
    present = {line.split()[0].decode("ascii") for line in result.stdout.splitlines() if line.endswith(b" blob")}
    return set(required) & present


def missing_blobs(repository, required, environment):
    return sorted(set(required) - present_blobs(repository, required, environment))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--record", required=True)
    parser.add_argument('--revision', default=COMMIT)
    parser.add_argument("--recover-pack")
    parser.add_argument("--batch-size", type=int, default=3000)
    parser.add_argument("--jobs", type=int, default=4, choices=range(1, 9))
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{40}', args.revision):
        parser.error('Revision must be an immutable full Git commit ID')
    if not 1 <= args.batch_size <= 10000:
        parser.error("Batch size must be 1..10000")
    repository, record = Path(args.repository), Path(args.record)
    env = {**os.environ, "GIT_NO_LAZY_FETCH": "1", "GIT_TERMINAL_PROMPT": "0"}
    required = required_blobs(repository, env, args.revision)
    missing = missing_blobs(repository, required, env)
    print(f"SOURCE_OBJECTS_MISSING {len(missing)}/{len(required)}", flush=True)
    recovery_exit = None
    if missing and args.recover_pack:
        pack = Path(args.recover_pack)
        with pack.open("rb") as source, record.with_suffix(".recovery.log").open("wb") as log:
            result = subprocess.run(["git", "-C", str(repository), "unpack-objects", "-r"],
                                    stdin=source, stdout=log, stderr=subprocess.STDOUT, env=env)
        recovery_exit = result.returncode
        missing = missing_blobs(repository, required, env)
        print(f"SOURCE_PACK_RECOVERY exit={recovery_exit} remaining={len(missing)}", flush=True)
    def fetch_batch(start):
        batch = missing[start:start + args.batch_size]
        # Another bounded fetch may already have supplied some objects.
        batch = missing_blobs(repository, {oid: required[oid] for oid in batch}, env)
        if not batch:
            return
        log_path = record.with_name(record.stem + f".fetch-{start // args.batch_size:04}.log")
        for attempt in range(3):
            print(f"SOURCE_BLOB_FETCH {start + 1}-{start + len(batch)}/{len(missing)} attempt={attempt + 1}", flush=True)
            with log_path.open("ab") as log:
                result = subprocess.run(["git", "-C", str(repository), "-c", "http.lowSpeedLimit=1024",
                    "-c", "http.lowSpeedTime=90", "-c", "fetch.negotiationAlgorithm=noop",
                    "fetch", "--no-auto-maintenance", "--no-write-fetch-head",
                    "--no-tags", "--no-recurse-submodules", "--filter=blob:none", "--stdin", "origin"],
                    input=("\n".join(batch) + "\n").encode("ascii"), stdout=log, stderr=subprocess.STDOUT, env=env)
            if result.returncode == 0:
                break
            if attempt == 2:
                raise RuntimeError("Exact blob fetch failed; inspect " + str(log_path))
            time.sleep(3 * (attempt + 1))
    with ThreadPoolExecutor(args.jobs) as pool:
        pending = [pool.submit(fetch_batch, start) for start in range(0, len(missing), args.batch_size)]
        for future in as_completed(pending):
            future.result()
    unresolved = missing_blobs(repository, required, env)
    details = {"commit": args.revision, "tracked_paths": sum(map(len, required.values())),
               "required_blobs": len(required), "verified_blobs": len(required) - len(unresolved),
               "missing_paths": [path for oid in unresolved for path in required[oid]],
               "recovery_exit": recovery_exit,
               "method": "Archive-imported matching Git blobs, optional Git-validated interrupted pack recovery, exact missing blob fetches; final full tree blob presence check."}
    if unresolved:
        record.with_suffix(".unresolved.json").write_text(json.dumps(details, indent=2), "utf-8")
        raise RuntimeError(f"{len(unresolved)} required blobs are still absent; source snapshot remains incomplete")
    integrity_log = record.with_suffix('.fsck.log')
    with integrity_log.open('wb') as output:
        integrity = subprocess.run(['git', '-C', str(repository), 'fsck', '--full', '--no-dangling'],
                                   stdout=output, stderr=subprocess.STDOUT, env=env)
    if integrity.returncode:
        raise RuntimeError('Git object integrity validation failed; inspect ' + str(integrity_log))
    details['git_fsck_exit'] = integrity.returncode
    record.write_text(json.dumps(details, indent=2), "utf-8")
    print("CHROMIUM_GIT_OBJECTS_COMPLETE " + str(record), flush=True)


if __name__ == "__main__":
    main()
