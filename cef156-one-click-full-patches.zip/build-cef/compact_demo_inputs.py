"""Bind cross-host demo validation to the exact local SDK development inputs."""
from pathlib import Path
import os

from minimize_sdk import digest


def sdk_inputs(sdk):
    sdk = Path(sdk)
    paths = [sdk / 'CMakeLists.txt', sdk / 'CMakePresets.json']
    for name in ('Release', 'include', 'libcef_dll', 'cmake', 'demos'):
        paths.extend((sdk / name).rglob('*'))
    return {p.relative_to(sdk).as_posix():
            {'symlink': os.readlink(p).replace('\\', '/')} if p.is_symlink()
            else {'sha256': digest(p)}
            for p in sorted(paths) if p.is_file() or p.is_symlink()}


def verify_portable(sdk, manifest, evidence):
    if (evidence['target'] != manifest['target']
            or evidence['source_archive_sha256'] != manifest['source_archive_sha256']
            or evidence['sdk_inputs'] != sdk_inputs(sdk)
            or evidence.get('binary_hashes_verified_on_build_host') is not True
            or {x['sandbox'] for x in evidence['clients']} != {'ON', 'OFF'}):
        raise RuntimeError('Portable demo evidence does not match this SDK')
    for client in evidence['clients']:
        if not client.get('binary_sha256') or len(client.get('images', [])) < 5:
            raise RuntimeError('Incomplete cross-host Mac demo image evidence')
