#!/usr/bin/env python3
"""Remove only CEF's MainMenu nib autoload key for programmatic-menu builds."""
from __future__ import annotations

import argparse
from pathlib import Path
import plistlib


def convert(source, output):
    data = plistlib.loads(Path(source).read_bytes())
    if data.get('NSMainNibFile') != 'MainMenu':
        raise RuntimeError('Expected the original CEF MainMenu nib autoload key')
    del data['NSMainNibFile']
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    Path(output).write_bytes(plistlib.dumps(data, fmt=plistlib.FMT_XML, sort_keys=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    convert(args.input, args.output)
