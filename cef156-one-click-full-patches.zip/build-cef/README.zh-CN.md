# Chromium 156.0.8071.0 / Windows CEF 构建脚本

Linux / macOS 新 goal 已在 Ubuntu 主机开始，当前准备及继续步骤见 `LINUX-HANDOFF.zh-CN.md`；源码补丁与分阶段准备工具已加入此 ZIP，完整 POSIX SDK 尚未构建。Linux 4.9+、旧 glibc / UOS 桌面教育版 V20 E 的要求见 `LINUX-PLAN.zh-CN.md`，继续尽量降低最终产物的 libc 需求；musl 暂缓。下面的 Windows 自动构建入口继续用于 Windows。

macOS x64/ARM64 交叉架构构建的可行性笔记见 `MACOS-NOTES.zh-CN.md`，不表示已经实现 macOS 构建入口。

本次 Windows CEF 的模块、编译开关和实际运行验证范围见 `BUILD-FEATURES.zh-CN.md`。

2026-11-08 最终状态：x64、x86、ARM64 三套 Windows Release SDK 已完成编译、压缩、逐文件校验、完整 PDB 身份核验及独立客户端编译；总复核见 `validation/windows-release-final-audit.json`。x64 / x86 有运行验证，ARM64 真机与 Win7 运行仍待验证。三套构建中间目录和 SDK 暂存目录均已清理；下文的使用流程和历史记录不表示 Linux / macOS 已完成。

Windows ARM64 完成后已到达要求的暂停阶段。用户随后开好 Linux 服务器并恢复了新 goal，顺序仍为 Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64；耗时估算、磁盘回收及快照工具缓存设计见 `NEXT-BUILDS.zh-CN.md`。

面向 Windows Server 2025 x64 构建机。支持只有 C 盘的服务器，默认使用 `C:\cef156`，依次构建、压缩、校验、清理：

1. x64 Release
2. x86 Release
3. ARM64 Release

**按用户最新要求，只制作三套 Release，保留完整 PDB，不再制作 Debug。本台 CVM 的三套 SDK 已完成，其他机器上的新构建仍须各自通过完整流程。** Chromium `156.0.8071.0` 没有官方精确对应的 CEF 兼容记录。本脚本固定 CEF `a26ddfd2792604564986b31ea298e30b09bd9b3f`，该 CEF 原本对应 Chromium `156.0.8078.0`。随附 `patches/cef-8071` 中的 10 个适配补丁，解决对 `8071.0 + Win7 补丁` 做源文件检查时发现的补丁冲突；具体适配记录见该目录 README。其余补丁冲突、GN 错误、编译错误都会停止并保留日志，不会自动换 Chromium 版本或跳过失败补丁。

## 补丁已全部随包携带

使用 `cef156-one-click-full-patches.zip`。本包内置该版本 **345 个 Win7 兼容补丁、CEF 官方完整补丁目录、10 个 CEF 适配补丁以及独立的 WebGL 回退补丁**，脚本直接读取本地补丁，不再拉取 Win7 补丁仓库。补丁目录为 `patches/`，版本及逐文件 SHA256 见 `patches/manifest.json`；执行安装前就会检查文件是否缺失或损坏。

WebGL 补丁位于 **`patches/webgl/webgl-fallback.patch`**，会自动应用。Chromium/CEF 源码、VS/SDK、depot_tools 和其他构建依赖仍需联网下载。

复核新增 **`patches/windows-build/portable-processor-number.patch`**：原补丁在通用 Windows 沙箱代码中加入了 x86 内联汇编，无法用于 ARM64。该补丁保留动态查询 Windows API，移除该汇编，并修正初始化中的数据竞争。CEF 使用完整提交历史生成版本号，避免浅克隆产生错误的构建编号；Chromium 仍使用浅克隆。打包阶段直接移动已经提取的 PDB，避免再次复制完整符号文件。

详细验证结果和目标系统运行边界见 `VALIDATION.md`。

ARM64 实际编译发现 REWORK 的 BoringSSL 一次性初始化和替代读写锁依赖 x86 内存顺序；随附 `windows-build/boringssl-arm64-synchronization.patch` 仅为 ARM64 恢复上游 INIT_ONCE/SRWLOCK，实现原生同步。x86/x64 保留原有兼容分支，已验证 SDK 保持其原始补丁清单和 ZIP 哈希。

`windows-build/arm64-processor-number.patch` 另外为 CPU 频率采样中的处理器编号查询恢复 ARM64 的原生 API，避免编译该处仅适用 x86 的汇编回退；x86/x64 分支保持原样。

`windows-build/libwebp-arm64-synchronization.patch` 为 ARM64 保留 libwebp 上游的 Windows 条件变量和读写锁，避免旧版线程模拟代码的编译问题及内存顺序假设；x86/x64 仍使用原兼容分支，图像解码的多线程功能保留。

`windows-build/cpuinfo-arm64-once.patch` 使 ARM64 的 CPU 信息初始化使用与其 InitOnceExecuteOnce 调用匹配的 INIT_ONCE 类型，x86/x64 的旧兼容初始化保留。

## 使用

将 ZIP 完整解压到 `C:\`，得到 `C:\build-cef\Build-CEF.cmd`、`Build-CEF.ps1`、`build_cef.py` 和 `patches\`。直接双击 `Build-CEF.cmd`，接受管理员提权后开始。脚本默认在 `C:\cef156` 下载和构建；该工作目录首次运行必须为空或不存在，因此不要把脚本包解压到 `C:\cef156` 里面。

不需要新建分区或格式化 C 盘。构建卷必须为 NTFS，首次至少有 200 GiB 空闲。若另有空间充足的 NTFS 卷，也可用 `-Root E:\cef156` 指定其他构建目录。

也可从 **64 位 Windows PowerShell** 运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Build-CEF.ps1 -Root C:\cef156
```

脚本自动安装 Git、VS 2026 Build Tools 的 x86/x64/ARM64 C++、ATL/MFC，以及 Windows SDK 28000 和调试工具。另安装 SDK 26100 并先保存其 x86/x64 `d3dcompiler_47.dll`，打包时替换新 SDK 的该 DLL，以符合 Win7 补丁仓库的运行依赖说明。ARM64 使用当前 SDK 运行库。脚本使用 Chromium 自带 Clang/Rust，不需要预装 Python。`toolchain-lock.json` 记录当前微软 VS 清单的实际文件哈希：该固定官方地址返回的文件与 channel 声明的哈希/大小不一致，已在本机和 CVM 独立取得相同文件并固定哈希；安装包仍逐项核对 SHA256 与 Authenticode 签名。这里采用的是 **156 标签的构建工具链要求**，不沿用旧版本的 VS 2022 安装教程。

默认在构建卷配置 32 GiB 固定页面文件；默认目录下为 `C:\pagefile.sys`，会调整这个现有页面文件的大小，不会再分配第二份。首次配置后通常需要手动重启，再次双击同一脚本续跑。安装器如果要求重启也会暂停，脚本不会主动重启服务器。已有合适页面文件时，可用 `-PageFileGB 0` 跳过配置。

默认启用镜像模式，无需在服务器安装 Clash：

```powershell
.\Build-CEF.ps1 -Root C:\cef156 -DependencySource Mirror
```

镜像模式从华为镜像取得便携 Python 3.11.9，核对固定 SHA256 和 Python 官方签名；CIPD 文件从 Flutter 中国镜像的 `flutter_infra_release/cipd` 路径下载。镜像仅提供包文件，因此随包的 `cipd_mirror.py` 在服务器本机回环地址启动只读元数据接口，供原版 CIPD/vpython 使用；不开放公网端口，不提供通用网络转发。CIPD 客户端本身仍须匹配 depot_tools 中的官方可执行文件哈希；已有 instance ID 的包仍按该 ID 校验，版本标签首次下载后将 ZIP SHA256 固定到 `downloads\cipd-mirror\mirror-index.json`，续跑拒绝同一标签的内容变化。首次按版本标签取得的文件依赖镜像 HTTPS 来源，不能把这个本机锁文件说成 Google 签名。日志为 `logs\cipd-mirror.log`。不会通过跳过 CIPD 依赖来宣称同步完成。

Python wheel 缓存通过 `VPYTHON_AR_URL` 提供 Chromium 官方 Artifact Registry 的所需包，保留索引中的 SHA256。针对当前 CVM 的 DNS/连通性，下载器对这个固定官方域名使用已实测可达的 Google 前端路由，仍核对 HTTPS 证书；没有更改系统 DNS、hosts 或证书信任。这个缓存只支持固定官方仓库的 Python 文件。gsutil 5.35 从官方公开 bucket 的可达域名取得，核对 `network-lock.json` 中的 SHA256 后安装，绕开其不可达的元数据启动地址；Google Storage 文件仍由原版工具按 DEPS 中的哈希验证。

`network-lock.json` 记录镜像地址和 Python 哈希。Chromium、ANGLE、Dawn、Skia、SwiftShader、V8 使用已核对存在相应提交的官方 GitHub 镜像；Git 的 URL 替换仅写入本构建目录的 `gitconfig`。Chromium 标签还必须对应固定提交 `aa939feff52ea94f0ca07d8029086738c2683685`。其余 Git 仓库、Google Storage 以及微软下载仍按上游地址访问，当前方案并不是全量离线镜像。仍在进行的源码拉取会保留。需要原始下载方式时指定 `-DependencySource Upstream`。

脚本保留 HTTPS 证书验证。安装包优先用系统 curl 流式下载并断点续传，下载后校验 SHA256 和安装器签名；服务器不支持断点续传时重新下载。网络失败会重试并写日志。可选的 `-ProxyUrl` 参数仅供已经有代理的环境显式指定，镜像模式不需要此参数。

镜像模式首次建立源码目录时，会调用包内 `prefetch_source_archive.py`、`seed_source_objects.py` 和 `complete_source_objects.py`：分段下载指定版本官方源码归档，核对完整文件大小/MD5，再将文件内容核对到真实 Git 提交的逐项 blob ID，导入已取得提交和树对象的本地 Git 镜像。官方发行归档省略了大量测试文件，因此仍需从上游按精确 blob ID 补取缺项；辅助工具也可从中断 Git 数据包恢复可验证对象。只有全部所需 blob 存在、Git 完整性检查通过，才从本地镜像建立真实源码检出。已有源码目录继续原来的续跑路径。这个流程不生成替代提交，不跳过缺失对象，也不会标记构建依赖同步完成；后续仍要求正常 gclient sync/runhooks。仅有归档下载完成不能作为源码准备成功的依据。

`prefetch_git_dependencies.py` 可提前拉取 `dependency-pins.json` 中的 9 个较大 Git 依赖；初始化前会核对它们确实是固定 Chromium 提交中的 gitlink。预取直接放入将来的对应源码目录，完整 gclient 同步会继续核对和补齐，不会把预取成功当成所有依赖已完成。

## 产物和磁盘

压缩包在 `C:\cef156\packages`，名称示例：

```text
cef_binary_156.0.8071.0_windows_x64_release.zip
cef_binary_156.0.8071.0_windows_x64_release.zip.sha256
... x86 / arm64 ...
```

每个 ZIP 是一个可单独使用的 CEF Release SDK，包含 DLL、导入库、完整 PDB、资源、头文件、CMake/包装层源码、bootstrap 程序、示例程序和 `swiftshader` 软件渲染 DLL。运行库位于 `Release/`；完整文件按各自 ZIP 清单为准。

`cefsimple`、`cefclient` 是演示/测试程序，自己的产品无需一起发布。Windows 从 M138 起，SDK 的沙箱接入通常是将 bootstrap 改名为自己的 `MyApp.exe`，再用本机编译器生成承载业务代码的 `MyApp.dll`；用户直接启动 MyApp.exe，目录中无需另留 bootstrap.exe 副本。若使用 `USE_SANDBOX=OFF` 则可以直接编译主 EXE，但会关闭 Chromium 沙箱；保留沙箱且不用 bootstrap，需要把应用纳入 Chromium/CEF 的源码构建工具链。CEF 运行 DLL 和必需资源仍须部署，完整 SDK、PDB、头文件、导入库和示例源码无需全部随最终程序发布。

SDK 中的 CMake 复制清单额外包含 `libEGL.dll`、`libGLESv2.dll`、`swiftshader/`，存在 `dxil.dll` 时也一起部署，避免外部 CMake 示例构建后缺少补丁恢复的软件 WebGL 文件。手动部署时同样保留这些文件及相对目录。

**Release 保留优化和完整符号，不另做 Debug 配置。** 设置 `symbol_level=2`、`blink_symbol_level=2`、`v8_symbol_level=2`，仍可借助匹配的 PDB 分析崩溃和进行符号调试；优化会影响单步执行与局部变量观察。PDB 可单独保存，运行时不必随应用部署。

每个配置构建结束后：先生成 SDK → ZIP64 压缩 → 逐文件解压读取并核对 SHA256/CRC → 写 ZIP 的 SHA256 → 写完成标记 → 删除 SDK 暂存目录和该配置的 `src\out\*_GN_*`。下一配置随后开始。保留源码、工具链、日志、状态和已验证 ZIP；失败时保留当前构建目录。

磁盘能否完成构建，取决于 Windows、源码依赖、单次含全符号构建、打包副本、页面文件和已完成 ZIP 的峰值之和。逐个清理限制了累积中间文件，**不能保证约 350 GiB 的 C 盘必定足够**。默认首次启动要求 200 GiB 空闲，每个全新配置要求 80 GiB 空闲；这是启动下限，不是峰值估计。使用只有 C 盘的机器时，源码、VS、SDK、TEMP、页面文件和成品都在同一卷，应避免同时放置其他大文件。空间不足时停止，保留当前文件，扩容构建卷后再续跑。

32G 内存默认 `-Jobs 10`，关闭 ThinLTO 和 PGO 来降低构建及链接的内存压力。速度和资源使用需要在这台 CVM 上实测，可用 `-Jobs 8` 减少并发。关闭 PGO/ThinLTO 会牺牲一部分优化效果；Release 的其余优化保留。

本台 16 vCPU/32 GiB CVM 在 x64 Release 编译约 20,000 个任务后，实测 CPU 使用率约 76%、空闲物理内存约 25 GiB，后台任务已改用 `-Jobs 14` 续跑，利用剩余 CPU。此参数不会使已完成的对象文件失效；仍需继续观察后续大型编译单元的内存峰值。每份 SDK 的 `MYCEF_BUILD.json` 记录实际并发数。新机器默认仍为 10，可按资源情况手动传 `-Jobs 14`。

## WebGL 与媒体

保留补丁仓库对软件 WebGL 的支持，并额外修改：

- 硬件 WebGL1 正常时保持硬件路径；仅 WebGL2/GLES3 不支持、或独立的合成器限制，不触发自动切换。
- GPU 能力尚未确定时不提前切换；WebGL1 被确定为 blocklisted/disabled 时才进入现有软件回退逻辑。
- 尊重用户显式指定的 GL/ANGLE 后端、`--disable-webgl`、`--disable-software-rasterizer` 和软件渲染功能开关。
- 保留补丁启用的 GPU 进程失败/崩溃回退。此改动不是为每个网页创建上下文都增加 JS 重试；无法承诺修复内存不足等任意 `getContext()` 失败。
- 打包旧 SwiftShader 的 `swiftshader/libEGL.dll`、`swiftshader/libGLESv2.dll`，以及原有 Vulkan SwiftShader 文件。

启用 `proprietary_codecs=true`、`ffmpeg_branding="Chrome"`、`media_use_openh264=true`、`rtc_use_h264=true`，用于 H.264/AAC/MP4 和 WebRTC H.264。启用 HEVC 平台解析/硬件解码入口，但实际可用性依赖目标 Windows、驱动和硬件；不承诺 Win7 上有 H.265 软解。

**没有集成独立的 libx264 编码器，也没有内置 Widevine CDM。** 若需求是特定 libx264 编码参数或独立转码，需要另外集成编码器。

每个 SDK 内的 `verify-runtime.html` 可以由 cefclient/cefsimple 加载，检查真实 WebGL1/2 上下文、绘制结果、渲染器名称、媒体能力和 WebRTC 编解码声明。仍需在目标 Windows 上使用实际 H.264/AAC 文件验证播放，并在无可用硬件 WebGL 的环境验证软件回退。ARM64 产物需要 Windows on ARM 验证；Win7 兼容验证针对 x86/x64。

一键包另带 `runtime_probe.py`，在目标 Windows 上使用 Python 3.10 及以上版本运行，启动 SDK 自带的 cefsimple，经回环 HTTP 地址实际检查 WebGL 绿色像素、MP4 视频解码/播放、AAC 样本解码及 WebRTC H.264 声明。媒体样本直接取已下载的 Chromium 源码，SHA256 固定校验，不随包重新分发。

```powershell
python .\runtime_probe.py --sdk C:\path\cef_binary_156.0.8071.0_windows_x64_release --configuration Release --media C:\cef156\chromium\src\media\test\data\bear-1280x720.mp4 --output C:\cef156\state\runtime-x64-Release-auto.json
python .\runtime_probe.py --sdk C:\path\cef_binary_156.0.8071.0_windows_x64_release --configuration Release --media C:\cef156\chromium\src\media\test\data\bear-1280x720.mp4 --mode gpu-disabled --output C:\cef156\state\runtime-x64-Release-software.json

# 还要求实际 H.264 编码并解码还原像素
python .\runtime_probe.py --sdk C:\path\cef_binary_156.0.8071.0_windows_x64_release --configuration Release --media C:\cef156\chromium\src\media\test\data\bear-1280x720.mp4 --mode gpu-disabled --require-h264-encoder --output C:\cef156\state\runtime-x64-Release-h264-encoder.json
```

检查结果与 CEF 日志保存到指定输出旁；工具将 DLL/EXE 和 Resources 合并到临时应用目录（包括 EXE 旁的 ICU 数据），不复制 PDB，不修改 SDK。进程在结束后关闭，临时目录随后清理。`gpu-disabled` 额外要求报告软件渲染器。本次 x64 Release 已在 CVM 通过默认和禁用 GPU 两种模式，WebGL1/2 均用 SwiftShader 正确绘制，H.264 视频播放和 AAC 解码通过；证据见 validation/ 下的 JSON。它记录当前主机的证据，不能证明其他 Windows 版本或架构可运行。

探测页面还执行 WebCodecs H.264 编码/解码闭环：将绿色画面以 `avc1.42001E`、`prefer-software` 编码，再解码并核对像素；`--require-h264-encoder` 将此结果加入必须通过的检查。x64 Release 已在禁用 GPU 时实际通过，结果见 `validation/runtime-x64-Release-h264-encoder.json`。这是一帧的功能检查，未验证长时间编码性能。

在有交互桌面的开发机上验证时，可加 `--show-window`：测试窗口显示并最大化，同时关闭该测试进程的后台/遮挡节流，避免视频加载被暂停而超时。此选项保留原有 GPU/解码器选择，`auto` 仍使用正常硬件路径；`gpu-disabled` 才禁用 GPU。结果记录窗口模式及完整命令行，不改变 SDK 或宿主应用的默认设置。

## 续跑与故障

本台已准备好的 CVM 另有无人值守接续入口 `Cloud-Continue.ps1`，由计划任务 `MyCEF156-Cloud` 以 SYSTEM 运行；该入口面向现有完整源码环境，不代替新机器的 `Build-CEF.cmd` 安装流程。它独立于当前电脑和 SSH 会话，重启后可继续；任务失败最多重试三次、每次间隔三分钟。交接说明见 `HANDOFF.zh-CN.md`。状态写入 `C:\cef156\state\cloud-status.json`，成功完成全部三套 Release 后生成 `cloud-all-Release-complete.json`；实际未知编译/验证错误会停止并保留日志。

直接再次运行同一命令。已完成的 ZIP 会核对哈希后跳过；已下载的源码、已经应用的补丁以及 Ninja 中间产物会复用。完整依赖同步成功后先写 `state\dependencies-synced.json`，钩子失败时从后续钩子继续；源码中固定的嵌套 depot_tools 同样会先经镜像完成初始化。完成全部源码准备后不会再次执行 gclient sync/runhooks，避免覆盖 Rust/第三方补丁。

原先六配置的构建计划可迁移为仅三套 Release：要求版本和所有 GN 参数完全相同，仅移除 Debug；原计划按 SHA256 保存到 `state/build-plan-history/`，已完成 Release 压缩包继续校验和复用。其他构建参数变化仍会拒绝续跑。

外层和源码内的 depot_tools 都显式运行其官方 `bootstrap\win_tools.bat`，按各自清单安装 Python 并生成 `gn`/`autoninja` 所需的启动路径。固定 depot_tools 版本时不能仅依赖 `gclient --help` 或 vpython 隐式完成这一步；脚本还实际运行 Python shim，检查版本和标准库。

源码内旧版清单的 CPython 标签按外层官方 `bootstrap/manifest.versions` 固定为对应 instance ID，记录在 `network-lock.json`。两份工具可复用同一份镜像下载缓存，并继续按该 ID 校验包内容。

中文 Windows 的 `icacls` 输出按 Windows ANSI 代码页解码，避免 Python UTF-8 模式导致构建权限步骤失败。这个修正随 `windows-build/localized-acls.patch` 提供。已准备的源码可在核对历史补丁清单后增补 Windows 构建修正；任何既有补丁的哈希变化都会拒绝续跑。

Chromium 156 的权限请求枚举已经移除 `kAmbientLogin`，而固定 CEF 补丁仍包含该旧枚举映射。`windows-build/cef-permission-request-type.patch` 删除这条无对应 Chromium 请求类型的映射；其他权限类型保持不变。它作为增量兼容修正随包提供。

`windows-build/cef-setting-helper-content-type.patch` 适配内容设置类型差异：Chromium 8071 仍保留 Storage Access Header Origin Trial 和 Direct Sockets Private Network Access，固定 CEF 已将对应 API 槽位命名为 deprecated。补丁保留两者的双向映射及现有 CEF ABI 槽位，使读取和修改设置仍能对应正确的 Chromium 类型。

`windows-build/bootstrap-sandbox-command-line.patch` 修复实际运行 bootstrap 时发现的空指针：bootstrap 使用局部命令行对象，而 Chromium 沙箱辅助函数原先读取尚未初始化的全局命令行。新增显式命令行重载，由 bootstrap 传入已经解析的对象；原入口、进程分类和沙箱缓解措施保留，不通过关闭沙箱来回避故障。运行验证状态见 `VALIDATION.md`。

```powershell
# 只查看计划，不安装、不提权、不修改系统
.\Build-CEF.ps1 -PlanOnly

# 已手动安装依赖时，跳过自动安装
.\Build-CEF.ps1 -Root C:\cef156 -SkipInstall

# 保留中间文件，需要更大的磁盘
.\Build-CEF.ps1 -Root C:\cef156 -KeepIntermediates
```

日志：`C:\cef156\logs`。源码状态和逐项完成标记：`C:\cef156\state`。包内 `patches/webgl/webgl-fallback.patch` 应用后会同时保存到 `state\mycef-webgl-fallback.patch`，并放入每个 SDK。版本、Git 提交、GN 参数、媒体选项和补丁清单都写入 ZIP。

失败后不要手动执行 `git reset --hard`、`gclient revert` 或清空整个源码目录。遇到精确版本不兼容时，应根据首个错误移植 CEF/Win7 补丁后再构建；本脚本不会凭空认定这个组合已受上游支持。

## 上游依据

- Chromium 156 构建要求：https://github.com/chromium/chromium/blob/156.0.8071.0/docs/windows_build_instructions.md
- 固定 CEF 的兼容记录：https://github.com/chromiumembedded/cef/blob/a26ddfd2792604564986b31ea298e30b09bd9b3f/CHROMIUM_BUILD_COMPATIBILITY.txt
- CEF 官方构建配置：https://github.com/chromiumembedded/cef/blob/a26ddfd2792604564986b31ea298e30b09bd9b3f/tools/gn_args.py
- 固定 Win7 补丁版本：https://github.com/e3kskoy7wqk/Chromium-for-windows-7-REWORK/tree/b4d1c429f461bd756443ea0b68270d0bdb1c5536/chromium-156.0.8071.0
- Chromium 媒体选项：https://github.com/chromium/chromium/blob/156.0.8071.0/media/media_options.gni
