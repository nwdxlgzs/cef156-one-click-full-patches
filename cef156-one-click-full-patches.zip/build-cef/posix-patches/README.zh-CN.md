# Linux / macOS 的独立补丁选择

固定 Chromium `156.0.8071.0` / `aa939feff52ea94f0ca07d8029086738c2683685`、CEF `a26ddfd2792604564986b31ea298e30b09bd9b3f`。Windows 已验证的 `patches/manifest.json` 保持原样；此目录独立记录 POSIX 的补丁和校验。

采用完整的 117 个 CEF 官方配置补丁，其中 8 个针对干净的 Chromium 8071 重新整理上下文或 API 差异。已使用未修改的官方 CEF patcher 在新建的、真实 Git 内容匹配的源文件集合上验证：117 applied、0 skipped、0 failed。再验证两个共用 CEF C++ 适配、WebGL 补丁及完整 DWARF 压缩补丁。记录见 `../validation/posix-source-patch-audit.json`。这一步证明补丁可应用，C++ / GN / GTest / 运行验证仍待正式构建。

- `cef-8071/`：PiP 激活接口、8071 的菜单参数 / Toolbar API、CEF profile 映射、autofill 空处理器，以及 Views / 文件选择 / 颜色观察者等上下文差异。补丁按 CEF 原配置顺序替换，不把 Win7 的版本判断、平台替代 API 或 x86 兼容代码引入 POSIX。
- `common/`：已在 Windows 构建中遇到、同样涉及共用 CEF C++ 的 permission request type 和 content setting 映射适配，单独复制并校验。
- `webgl/`：保留可用的硬件 WebGL1；状态未知时继续硬件初始化，确认禁用 / blocklist 后才选择正常 SwiftShader 后端。仅 GLES3 不可用不触发回退。Linux/macOS 恢复软件回退及 GPU 崩溃回退许可，继续尊重显式 GL 实现、关闭软件渲染、关闭 WebGL 和相应 feature 的选择。包含真实 GPU 函数的 GTest，尚待编译执行。
- `build/`：Linux 在 `symbol_level=2 use_debug_fission=false` 时压缩对象及链接结果的 DWARF，保留完整符号并限制磁盘占用；采用上游已有的 zlib 格式，macOS 使用 dSYM。另有 `mac-linux-cross-sdk.patch`，为 Linux → macOS 增加显式、已验证的 CLT SDK 元数据和 Linux dSYM 工具入口；保留原生 Mac 的 Xcode 路线，跨系统产物只记录真实 SDK / CLT 信息，不伪造 DTXcode。该新增补丁已对真实固定源码通过应用检查，并经固定 GN 2574 实际解析 / 格式化；见 `../validation/mac-cross-sdk-source-patch.json`。完整 GN / CEF 编译及符号读取仍待验证。

GNU/Linux 的目标用户态仍是 glibc，必须覆盖桌面教育版 UOS V20 E，并尽量降低成品实际需要的版本。`audit_elf.py` 读取实际 ELF 的版本依赖，兼容门槛不是预先声称的最低版本；glibc 符号、其他共享库、Linux 4.9 内核与图形 / 媒体 / 沙箱分别验证。

本目录不应用 345 个 Win7 REWORK 补丁。Windows 完整补丁仍随总 ZIP 携带，继续由 Windows 构建入口使用。

`build/mac-linux-menu-resources.patch` 为 Linux 宿主的 macOS 示例提供基于原始 XIB 的程序化 AppKit 菜单，并只在该构建分支移除 MainMenu nib 自动加载键；原生 Mac / CMake 路线保留原 XIB。四份原菜单在 ARM64/x64、ARC/手动计数下共 16 份真实对象编译通过，隔离的真实 CEF GN 模板与 Ninja 依赖也已编译通过；见 `../validation/mac-menu-source-patch.json`。完整 CEF 和 macOS 运行仍待验证，没有创建假的 ibtool 或空 nib。
