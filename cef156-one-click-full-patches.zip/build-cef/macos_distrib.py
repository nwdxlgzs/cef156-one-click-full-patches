#!/usr/bin/env python3
"""Run the pinned CEF distributor with an explicit macOS target on Linux.

Only the distributor's target policy and existing output-directory suffix are
selected. Python's real host platform and the upstream source remain intact.
SDK symbols, independent clients, archives and runtime are separate gates.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

from archive_posix import digest_file
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json


def exporter(prep, target):
    if not sys.platform.startswith('linux') or target not in {'mac-arm64', 'mac-x64'}:
        raise RuntimeError('This explicit cross-distributor adapter requires a Linux host and macOS target')
    cpu = target.removeprefix('mac-')
    tool = prep.src / 'cef/tools/make_distrib.py'
    data = tool.read_bytes()
    blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
    expected = prep.git(prep.src / 'cef', 'ls-tree', CEF_REV, '--', 'tools/make_distrib.py', capture=True).stdout.split()[2]
    if blob != expected:
        raise RuntimeError('The pinned original CEF distributor changed')
    prior_path = list(sys.path)
    sys.path.insert(0, str(tool.parent))
    try:
        spec = importlib.util.spec_from_file_location('mycef_original_mac_distributor_' + cpu, tool)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
    finally:
        sys.path[:] = prior_path
    native_platform = module.get_platform
    native_architecture = module.get_architecture
    if native_platform(sys.platform) != 'linux':
        raise RuntimeError('The original distributor does not recognize the real Linux host')

    def selected_platform(actual):
        if actual != sys.platform:
            raise RuntimeError('Unexpected caller platform during explicit macOS target selection')
        return 'mac'

    def selected_architecture(options):
        architecture, binary_cpu, suffix = native_architecture(options)
        if binary_cpu != cpu:
            raise RuntimeError('The requested distributor CPU differs from its compiled macOS target')
        return architecture, binary_cpu, suffix + '_mac'

    module.get_platform = selected_platform
    module.get_architecture = selected_architecture
    return module, {'original_distributor_git_blob': blob, 'original_distributor_sha256': digest_file(tool),
                    'host_sys_platform': sys.platform, 'target_platform': 'mac', 'target_cpu': cpu}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=['mac-arm64', 'mac-x64'])
    parser.add_argument('--policy-only', action='store_true', help='Check real distributor target policy without creating an SDK')
    parser.add_argument('--output-dir', type=Path)
    parser.add_argument('--distrib-subdir')
    args = parser.parse_args()
    prep = Preparation(args.root)
    actual_host = sys.platform
    module, identity = exporter(prep, args.target)
    cpu = identity['target_cpu']
    selected = ['--output-dir', str(args.output_dir or prep.root / 'packages/staging' / args.target),
                '--ninja-build', '--allow-partial', '--no-docs', '--no-archive', '--no-format',
                '--arm64-build' if cpu == 'arm64' else '--x64-build']
    if args.distrib_subdir:
        selected += ['--distrib-subdir', args.distrib_subdir]
    options, extra = module.create_option_parser().parse_args(selected)
    if extra or module.validate_options(options, module.get_platform(actual_host)):
        raise RuntimeError('Original distributor rejected the explicit target options')
    architecture = module.get_architecture(options)
    if architecture[1] != cpu or architecture[2] != '_GN_' + cpu + '_mac' or sys.platform != actual_host:
        raise RuntimeError('Unexpected macOS distributor CPU/directory or changed Python host')
    if args.policy_only:
        receipt = {**identity, 'architecture': architecture, 'upstream_options': selected,
                   'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                   'passed': True, 'sdk_created': False,
                   'scope': 'Actual unchanged pinned CEF distributor imported and its real parser/validation exercised with explicit target policy; no SDK packaging, CEF build or runtime claim.'}
        write_json(prep.root / 'state' / ('mac-distributor-policy-' + cpu + '.json'), receipt)
        print(json.dumps(receipt, indent=2), flush=True)
        return
    if (args.output_dir is None or not args.distrib_subdir or args.distrib_subdir in {'.', '..'}
            or not re.fullmatch(r'[A-Za-z0-9_.+-]+', args.distrib_subdir)):
        parser.error('Actual packaging needs --output-dir and a single --distrib-subdir directory name')
    destination = args.output_dir.resolve()
    if prep.root / 'packages/staging' not in destination.parents:
        raise RuntimeError('Expected a dedicated descendant of the SDK staging directory')
    compiled_path = prep.root / 'state' / ('compiled-' + args.target + '.json')
    compiled = json.loads(compiled_path.read_text('utf-8'))
    output = Path(compiled['output']).resolve()
    image = Path(compiled['cef_binary']).resolve()
    if (compiled['target'] != args.target or compiled.get('chromium_revision') != CHROMIUM_REV
            or compiled.get('cef_revision') != CEF_REV or output != prep.src / 'out' / ('Release_GN_' + cpu + '_mac')
            or output not in image.parents or digest_file(image) != compiled['cef_binary_sha256']):
        raise RuntimeError('The real compiled macOS output differs from its receipt')
    if (destination / args.distrib_subdir).exists():
        raise RuntimeError('Existing SDK staging must be audited before the original exporter can replace it')
    original_main_path = list(sys.path)
    sys.path.insert(0, str(prep.src / 'cef/tools'))
    try:
        if module.main(selected) not in (None, 0):
            raise RuntimeError('The original CEF distributor failed')
    finally:
        sys.path[:] = original_main_path
    if sys.platform != actual_host:
        raise RuntimeError('Python host platform changed while distributing')
    sdk = destination / args.distrib_subdir
    copied_image = sdk / 'Release/Chromium Embedded Framework.framework/Chromium Embedded Framework'
    if digest_file(copied_image) != compiled['cef_binary_sha256']:
        raise RuntimeError('The actual macOS SDK engine differs from the linked engine')
    receipt = {**identity, 'sdk': str(sdk), 'compiled_receipt_sha256': digest_file(compiled_path),
               'sdk_engine_sha256': digest_file(copied_image), 'sdk_created': True,
               'symbols_verified': False, 'final_sdk_verified': False,
               'scope': 'Original standard CEF distributor actually executed for an explicit macOS target and matching engine copied. Complete symbols/clients/archive/runtime remain separate gates.'}
    write_json(prep.root / 'state' / ('mac-distributor-' + cpu + '.json'), receipt)
    print('ORIGINAL_MACOS_CEF_DISTRIBUTOR_EXECUTED', args.target, sdk, flush=True)


if __name__ == '__main__':
    main()
