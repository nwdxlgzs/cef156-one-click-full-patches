#!/usr/bin/env python3
"""Prepare the requested compact Mac SDKs only after full archives verify."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

from audit_macho import inspect, CPUS
from minimize_sdk import digest, write_json


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--root',type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();here=Path(__file__).resolve().parent
    work=root/'cache/strip-validation';work.mkdir(parents=True,exist_ok=True)
    for cpu in ['arm64','x64']:
        target='mac-'+cpu
        receipt=root/'state'/('sdk-'+target+'-verified.json')
        cleanup=root/'state'/('sdk-'+target+'-cleanup.json')
        while not (receipt.is_file() and cleanup.is_file()):
            # This follower never starts/restarts the actual engine build.
            service=subprocess.check_output(['systemctl','show','mycef-macos-release-continuation',
                                               '-p','ActiveState','--value'],text=True).strip()
            if service not in ('active','activating','reloading'):
                raise RuntimeError('Full Mac SDK pipeline stopped before '+target+' was verified/cleaned')
            time.sleep(30)
        full=json.loads(receipt.read_text())
        if not full.get('passed') or digest(Path(full['archive']))!=full['archive_sha256']:
            raise RuntimeError('Full Mac archive identity differs')
        dest=root/'packages/strip-lib'
        sdk=dest/('cef_156.0.8071.0_'+target+'_release')
        def run(command, log=None):
            if log:
                with log.open('w') as f:
                    v=subprocess.run(list(map(str,command)),stdout=f,stderr=subprocess.STDOUT)
                if v.returncode:raise RuntimeError('Compact Mac command failed: '+str(log))
            else:subprocess.run(list(map(str,command)),check=True)
        if sdk.exists():
            manifest=json.loads((sdk/'STRIP_MANIFEST.json').read_text())
            if manifest['source_archive_sha256']!=full['archive_sha256']:
                raise RuntimeError('Existing compact Mac SDK has a different source')
        else:
            run([sys.executable,here/'minimize_sdk.py','--source',full['archive'],'--target',target,
                 '--destination',dest,'--source-sha256',full['archive_sha256'],'--archive'])
        tool=json.loads((root/'state'/('mac-client-toolchain-'+cpu+'.json')).read_text())
        target_work=work/target;target_work.mkdir(exist_ok=True)
        clients=[]
        for mode in ['on','off']:
            out=target_work/mode
            run(['cmake','-S',sdk/'demos'/('sandbox-'+mode),'-B',out,'-G','Ninja',
                 '-DCMAKE_BUILD_TYPE=Release','-DPROJECT_ARCH='+('arm64' if cpu=='arm64' else 'x86_64'),
                 '-DCMAKE_INSTALL_NAME_TOOL='+str(root/'chromium/src/third_party/llvm-build/Release+Asserts/bin/llvm-install-name-tool'),
                 '-DCMAKE_TOOLCHAIN_FILE='+tool['toolchain']],target_work/(mode+'-configure.log'))
            run(['cmake','--build',out,'--target','cefsimple','-j','2'],target_work/(mode+'-build.log'))
            app=out/'sdk/demos/common/Release/cefsimple.app'
            images=[x for x in app.rglob('*') if x.is_file() and not x.is_symlink()]
            actual=[]
            for path in images:
                with path.open('rb') as f:magic=f.read(4)
                if magic!=b'\xcf\xfa\xed\xfe':continue
                info=inspect(path)
                if info['cpu_type']!=CPUS[cpu]:raise RuntimeError('Compact Mac image architecture differs')
                actual.append({'path':str(path),'sha256':digest(path)})
            binary=app/'Contents/MacOS/cefsimple'
            if len(actual)<5 or not binary.is_file():raise RuntimeError('Missing compact Mac app/helper images')
            clients.append({'sandbox':mode.upper(),'binary':str(binary),'binary_sha256':digest(binary),'images':actual})
        evidence={'target':target,'demo_build_verified':True,'runtime_verified_after_strip':False,
                  'clients':clients,'scope':'Two actual compact SDK CMake demos and Helpers cross-compiled and linked; no Mac execution/signing claim.'}
        result=target_work/'result.json';write_json(result,evidence)
        run([sys.executable,here/'finalize_minimal_sdk.py','--sdk',sdk,'--evidence',result])
        print('COMPACT_MAC_READY_FOR_DOWNLOAD',target,flush=True)


if __name__=='__main__':main()
