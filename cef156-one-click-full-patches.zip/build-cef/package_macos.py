#!/usr/bin/env python3
"""Prepare an actual Release macOS SDK and all matching runtime dSYMs.

This stage does not claim independent-client, signing or macOS runtime success,
does not publish a verified archive, and does not remove build intermediates.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import plistlib
import re
import shutil
import subprocess
import sys

from archive_posix import digest_file
from audit_macho import audit, inspect, match_dsym, RUNTIME_TYPES
from prepare_posix import Preparation, CHROMIUM, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent
FRAMEWORK = 'Chromium Embedded Framework'


def tree_bytes(path):
    return sum(item.stat().st_size for item in Path(path).rglob('*')
               if item.is_file() and not item.is_symlink())


def configure_deployment(sdk, deployment):
    variables = Path(sdk) / 'cmake/cef_variables.cmake'
    text = variables.read_text('utf-8')
    text, count = re.subn(r'(set\(CEF_TARGET_SDK\s+)"[0-9.]+"(\))',
                         lambda match: match[1] + '"' + deployment + '"' + match[2], text)
    if count != 1:
        raise RuntimeError('Unexpected original CMake macOS deployment setting')
    variables.write_text(text, encoding='utf-8')
    for path in sorted((Path(sdk) / 'tests').glob('*/mac/*Info.plist.in')):
        values = plistlib.loads(path.read_bytes())
        if 'LSMinimumSystemVersion' in values:
            values['LSMinimumSystemVersion'] = deployment
            path.write_bytes(plistlib.dumps(values, sort_keys=False))


def symbol_index(output):
    """Index genuine top-level GN dSYMs by CPU and UUID, not guessed filenames."""
    result = {}
    for bundle in sorted(output.glob('*.dSYM')):
        directory = bundle / 'Contents/Resources/DWARF'
        if not directory.is_dir():
            continue
        files = [p for p in directory.iterdir() if p.is_file() and not p.name.startswith('.')]
        if len(files) != 1:
            raise RuntimeError('Malformed original dSYM bundle: ' + str(bundle))
        info = inspect(files[0])
        if not info['uuid']:
            raise RuntimeError('Original dSYM has no UUID: ' + str(bundle))
        result.setdefault((info['cpu_type'], info['uuid']), []).append(bundle)
    return result


def prepare(root, target):
    prep = Preparation(root)
    cpu = target.removeprefix('mac-')
    compiled_path = prep.root / 'state' / ('compiled-' + target + '.json')
    compiled = json.loads(compiled_path.read_text('utf-8'))
    output = Path(compiled['output']).resolve()
    image = output / (FRAMEWORK + '.framework') / FRAMEWORK
    if (compiled['target'] != target or compiled['chromium_revision'] != CHROMIUM_REV
            or compiled['cef_revision'] != CEF_REV
            or output != prep.src / 'out' / ('Release_GN_' + cpu + '_mac')
            or digest_file(image) != compiled['cef_binary_sha256']):
        raise RuntimeError('Compiled macOS engine/source identity differs from its receipt')
    configuration = json.loads((prep.root / 'state' / ('gn-' + target + '.json')).read_text('utf-8'))
    if (digest_file(output / 'args.gn') != configuration['args_gn_sha256']
            or compiled['gn_configuration_sha256'] != configuration['args_gn_sha256']
            or configuration['args']['is_debug'] is not False
            or configuration['args']['enable_dsyms'] is not True
            or any(configuration['args'].get(k) != 2
                   for k in ('symbol_level', 'blink_symbol_level', 'v8_symbol_level'))):
        raise RuntimeError('Expected the real Release configuration with complete symbols')
    features_path = prep.root / 'state' / ('features-' + target + '.json')
    features = json.loads(features_path.read_text('utf-8'))
    if not features.get('passed') or features['args_gn_sha256'] != configuration['args_gn_sha256']:
        raise RuntimeError('The actual target feature audit has not passed')
    staging = prep.root / 'packages/staging' / target
    subdir = 'cef_binary_' + CHROMIUM + '_mac_' + cpu + '_release'
    sdk = staging / subdir
    prepared_path = prep.root / 'state' / ('sdk-' + target + '-prepared.json')
    framework = sdk / 'Release' / (FRAMEWORK + '.framework')
    if prepared_path.is_file():
        prior = json.loads(prepared_path.read_text('utf-8'))
        if (prior['compiled_receipt_sha256'] != digest_file(compiled_path)
                or prior['sdk'] != str(sdk)
                or digest_file(framework / FRAMEWORK) != compiled['cef_binary_sha256']):
            raise RuntimeError('Existing prepared macOS SDK differs from its compile identity')
        print('Existing prepared macOS SDK retained:', sdk, flush=True)
        return prior
    dsyms = symbol_index(output)
    if not dsyms:
        raise RuntimeError('The actual macOS build has no dSYM bundles')
    if not sdk.exists():
        estimate = sum(tree_bytes(output / name) for name in
                       (FRAMEWORK + '.framework', 'cefsimple.app', 'cefclient.app'))
        estimate += sum(tree_bytes(paths[0]) for paths in dsyms.values())
        if shutil.disk_usage(prep.root).free < int(estimate * 1.2) + 5 * 1024**3:
            raise RuntimeError('Retain outputs: insufficient room for the actual SDK and full symbols')
        staging.mkdir(parents=True, exist_ok=True)
        prep.run([sys.executable, HERE / 'macos_distrib.py', '--root', prep.root,
                  '--target', target, '--output-dir', staging, '--distrib-subdir', subdir])
    distributed_path = prep.root / 'state' / ('mac-distributor-' + cpu + '.json')
    distributed = json.loads(distributed_path.read_text('utf-8'))
    if (distributed.get('sdk') != str(sdk)
            or distributed.get('compiled_receipt_sha256') != digest_file(compiled_path)
            or not distributed.get('sdk_created')):
        raise RuntimeError('Original distributor receipt does not validate this SDK staging')
    required = ['include/cef_app.h', 'include/cef_version.h', 'CMakeLists.txt']
    required += ['Release/' + FRAMEWORK + '.framework/' + name for name in (
        FRAMEWORK, 'Resources/Info.plist', 'Resources/icudtl.dat', 'Resources/resources.pak',
        'Resources/chrome_100_percent.pak', 'Resources/chrome_200_percent.pak',
        'Resources/snapshot_blob.bin', 'Resources/gpu_shader_cache.bin',
        'Libraries/libcef_sandbox.dylib', 'Libraries/libvk_swiftshader.dylib',
        'Libraries/libvulkan.dylib', 'Libraries/libEGL.dylib', 'Libraries/libGLESv2.dylib',
        'Libraries/vk_swiftshader_icd.json')]
    for relative in required:
        if not (sdk / relative).is_file():
            raise RuntimeError('Incomplete actual macOS SDK: ' + relative)
    if (sdk / 'Debug').exists() or not any((framework / 'Resources').glob('*.lproj/locale.pak')):
        raise RuntimeError('Unexpected Debug SDK or missing actual macOS locale resources')
    if digest_file(framework / FRAMEWORK) != compiled['cef_binary_sha256']:
        raise RuntimeError('Copied SDK engine bytes differ from the compiled engine')
    # The original CEF template still advertises 12.0, while this Chromium
    # engine targets 13.0. Let downstream clients inherit the measured floor.
    from audit_macho import version_tuple, version_string
    engine_versions = inspect(framework / FRAMEWORK)['versions']
    if not engine_versions or any(item['platform'] != 1 for item in engine_versions):
        raise RuntimeError('The actual framework lacks its macOS deployment version')
    deployment = version_string(max(version_tuple(item['minimum']) for item in engine_versions))
    configure_deployment(sdk, deployment)
    examples = sdk / 'Examples'
    examples.mkdir(exist_ok=True)
    for name in ('cefsimple', 'cefclient'):
        original = output / (name + '.app')
        destination = examples / original.name
        if not destination.exists():
            shutil.copytree(original, destination, symlinks=True)
        if digest_file(destination / 'Contents/MacOS' / name) != digest_file(original / 'Contents/MacOS' / name):
            raise RuntimeError('Packaged sample executable differs from its linked output')
    symbols = sdk / 'Symbols'
    original_symbols = staging / (subdir + '_release_symbols')
    if not symbols.exists():
        if original_symbols.exists():
            original_symbols.rename(symbols)
        else:
            symbols.mkdir()
    # Include dSYMs for every runtime image, including shared ANGLE libraries,
    # examples and Helpers, rather than only the distributor's three defaults.
    report = audit(sdk, cpu)
    if not report['passed']:
        raise RuntimeError('Actual macOS SDK Mach-O audit failed: ' + repr(report['errors']))
    runtime = {}
    for item in report['files']:
        if item['file_type'] in RUNTIME_TYPES:
            runtime.setdefault((item['cpu_type'], item['uuid']), []).append(item['path'])
    auxiliary = json.loads((prep.root / 'state/mac-aux-tools-verified.json').read_text('utf-8'))
    tool = auxiliary['tools']['llvm-dwarfdump']
    if (digest_file(Path(tool['path'])) != tool['wrapper_sha256']
            or digest_file(Path(tool['executable'])) != tool['executable_sha256']):
        raise RuntimeError('The verified DWARF inspection tool changed')
    validations = []
    log_root = prep.root / 'logs' / ('symbols-' + target)
    log_root.mkdir(exist_ok=True)
    for identity, paths in sorted(runtime.items()):
        candidates = dsyms.get(identity, [])
        if not candidates:
            raise RuntimeError('Missing full matching dSYM for runtime image: ' + paths[0])
        original = candidates[0]
        destination = symbols / original.name
        if not destination.exists():
            shutil.copytree(original, destination, symlinks=True)
        matched = match_dsym(sdk / paths[0], destination)
        original_match = match_dsym(sdk / paths[0], original)
        dwarf = Path(matched['dwarf'])
        if digest_file(dwarf) != digest_file(Path(original_match['dwarf'])):
            raise RuntimeError('Copied full DWARF differs from the actual GN output')
        log = log_root / (identity[1] + '.log')
        with log.open('w') as stream:
            result = subprocess.run([tool['path'], '--verify', str(dwarf)],
                                    env=prep.env, stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError('Actual complete DWARF verification failed; see ' + str(log))
        validations.append({**matched, 'images': paths, 'dwarf_sha256': digest_file(dwarf),
                            'dwarf_bytes': dwarf.stat().st_size, 'verify_log_sha256': digest_file(log),
                            'semantic_dwarf_verified': True})
    report = audit(sdk, cpu)
    if not report['passed']:
        raise RuntimeError('Packaged dSYMs or SDK paths failed the final Mach-O audit')
    write_json(prep.root / 'state' / ('macho-' + target + '.json'), report)
    symbols_path = prep.root / 'state' / ('symbols-' + target + '.json')
    write_json(symbols_path, {'target': target, 'images': validations, 'passed': True,
                             'scope': 'Every SDK runtime CPU/UUID matched to complete original DWARF; each copied dSYM semantically verified with llvm-dwarfdump.'})
    shutil.copy2(features_path, sdk / 'MYCEF_FEATURES.json')
    shutil.copy2(HERE / 'MACOS-SDK.zh-CN.md', sdk / 'MYCEF_MACOS.zh-CN.md')
    metadata = {'target': target, 'configuration': 'Release', 'chromium_version': CHROMIUM,
                'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
                'custom_cef_chromium_combination': True, 'cef_upstream_chromium': '156.0.8078.0',
                'sdk_engine_sha256': compiled['cef_binary_sha256'], 'gn_args': configuration['args'],
                'all_runtime_dsyms_verified': True, 'windows_win7_patches_applied': False,
                'independent_libx264_included': False, 'widevine_binary_included': False,
                'macos_runtime_verified': False, 'independent_client_verified': False,
                'apple_distribution_signing_verified': False,
                'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                'provenance': json.loads((prep.root / 'state/prepared-posix.json').read_text('utf-8'))}
    write_json(sdk / 'MYCEF_BUILD.json', metadata)
    prepared = {'target': target, 'sdk': str(sdk), 'staging': str(staging),
                'compiled_receipt_sha256': digest_file(compiled_path),
                'sdk_engine_sha256': compiled['cef_binary_sha256'],
                'symbols_receipt_sha256': digest_file(symbols_path), 'prepared': True,
                'passed_final_sdk_validation': False,
                'scope': 'Actual original SDK distribution, examples/Helpers, all runtime dSYMs and Mach-O audit. Independent clients, signing/runtime boundaries, archive and cleanup remain separate.'}
    write_json(prepared_path, prepared)
    print('MACOS_CEF_SDK_PREPARED_FOR_VALIDATION', target, sdk, flush=True)
    return prepared


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=('mac-arm64', 'mac-x64'))
    args = parser.parse_args()
    prepare(args.root, args.target)


if __name__ == '__main__':
    main()
