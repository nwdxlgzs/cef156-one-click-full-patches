# 后续 Linux CEF 计划

记录日期：2026-11-08。Windows 三套 Release 已完成，最终记录见 `validation/windows-release-final-audit.json`。用户随后提供 Linux 服务器并启动新 goal：Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64。当前已开始 Linux 主机准备及固定源码下载，尚未完成 POSIX SDK；Windows 一键入口不作为 POSIX 构建入口使用。

## 用户要求

最新接续安排见 `NEXT-BUILDS.zh-CN.md`：Windows ARM64 完成后已到达暂停阶段；用户随后开好 Linux 服务器并恢复任务，当前按 Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64 顺序串行制作；快照工具按目标提前规划与保留。

## 已启动的 Linux 主机

- 腾讯云 CVM：16 vCPU、约 30 GiB 可用物理内存，Ubuntu Server 24.04.5 x64 / UEFI，实际内核 6.8.0-139。
- 工作根目录 `/home/ubuntu/cef156`，单根分区约 295 GiB；32 GiB swap 已启用。swap 属于内存保障，不能作为构建中间文件回收。
- SSH 密钥已部署，服务端持续执行准备任务。Git 配置仅作用于此构建根目录，保留 HTTPS 验证；不安装 Clash，不改全机 hosts / DNS。
- Chromium 大体积完整 Git pack 下载超时，切换为官方固定版本归档、真实 Git commit/tree、逐对象匹配导入和缺失 blob 补全；必须通过完整对象审计与 `git fsck` 后才建立工作树。
- `prepare_posix.py` 是源码 / 工具链仓库准备入口，尚不是完整构建与交付实现。CIPD 镜像助手已增加 Linux/macOS 宿主客户端选择和官方 SHA256 检查，并保留 Windows 默认行为。

- 后续制作 Linux x64、ARM64 的 CEF Release，沿用 Chromium 156.0.8071.0 和必要的 CEF 适配、媒体及 WebGL 能力。
- 用户已确认具体产品为 **桌面教育版 `UOS V20 E`**；服务器欧拉 E 版不是本次指定的兼容目标。
- 用户补充硬件预算：接近当前 Windows CVM 的 16 vCPU / 32 GB，最多约 24 核；后续按 16–24 vCPU / 32 GB 设计，不把 32 vCPU / 64 GB 当作开工条件。
- 用户最新确认：先走 glibc，并尽可能降低最终产物的 glibc 要求，扩大低版本可用性。UOS 桌面教育版 V20 E 的 glibc 2.28 是必须覆盖的验收环境，不把 2.28 人为设成产物最低门槛；上游已有的较低兼容能力应保留，并继续评估更低基线。最终最低版本须有 ELF 审计与实际运行证据，不预先承诺 glibc 2.17。musl 暂不安排正式产物。
- 无论最终 libc 路线为何，Linux 4.9+ 都是目标要求，需要分别验证 x64/ARM64。不能把编译通过或新内核容器运行通过当成 4.9 兼容已实现。
- 本次 Windows Win7 补丁不是 Linux 支持实现。后续必须按平台选择补丁，逐项评估共用代码，不能把全套 Windows 兼容改动直接套到 Linux；保留 Windows 已验证产物的溯源。

## 已核实的预研信息

### 桌面教育版 UOS V20 E 的兼容基线（用户已确认）

- 统信官方产品页明确把桌面教育版称为 `V20 E`。后续目标环境需记录教育版实际更新号、CPU 架构和 libc 包版本，不与服务器欧拉版混称。
- 从官网文档中心的桌面 V20 白皮书下载入口，取得《统信桌面操作系统 V20 白皮书（2023 年版）》：正文第 3 页（PDF 第 7 页）明确把教育版列入产品系列，并列出教育版支持 AMD64、ARM64 等架构，内核为 4.19 / 5.10；正文第 21 页（PDF 第 25 页）的统一技术参数列出 Glibc 2.28、GCC 8.3、Xorg 1.20。这份桌面产品线资料为 glibc 2.28 工程目标提供直接依据，而非套用服务器版结论。
- 实际下载到的该白皮书为 1,819,579 字节，SHA256 为 `3308548172866e27fff8b7b993094348427b9c1875056efb118ca08f77e79bdb`；目标、页码和证据范围另记录在 `validation/uos-v20-education-baseline.json`。
- 旧 UOS 通用 Debian 系仓库的 `libc6_2.28.7-1+deepin` 只能作为历史旁证。尚未安装教育版最早出厂 ISO，不能把 2020 年通用 V20 的发布日期、服务器版日期或旧仓库文件日期当作教育版首发与运行实测证据；本轮不承诺已经精确定位并测试教育版第一份 ISO。
- 后续 Linux 主线采用 x64 / ARM64 的 glibc SDK，必须在桌面教育版 V20 E 的 glibc 2.28 环境中使用，并争取更低 glibc 的可用性。构建使用受控 sysroot，避免宿主新 libc / 新依赖泄入产物；结合源码中的较低基线处理，审计 SDK、独立业务宿主与随包 `.so` 的版本依赖，再逐级验证较旧用户态。x64 / ARM64 分别报告真实最低版本；目标机保持其系统 libc。
- Linux 4.9+ 继续作为独立目标。教育版文档中的 4.19 / 5.10 不能代替 4.9 内核测试；glibc 符号版本满足也不代表窗口系统、字体、沙箱、图形与媒体全部已验证。

### 其他预研依据

1. Alpine 的 Chromium 构建配方当前为 156.0.8078.79，列出 x86_64、aarch64 和 musl 依赖，并带有 sandbox、TLS、allocator、libc++ 等适配补丁。这证明同代 Chromium 有 musl 路线可参考；不证明固定 Chromium 156.0.8071.0 + 本次 CEF 提交已经构建或运行成功。
2. musl 版 libcef.so 不能当作所有 glibc 宿主的通用替代品。共享库、宿主及其依赖的 libc/ABI 需要一致规划；不能靠把 musl 静态塞进 libcef.so 就宣称通用。若目标是被既有 glibc 应用直接链接，通常仍需 glibc SDK。全应用走 musl 的方案需整体验证，包括窗口系统、字体、音频和图形驱动依赖。
3. 固定 Chromium 156.0.8071.0 的 sysroot_creator.py 为 amd64/arm64 选择 Debian bullseye，并把 glibc 特性宏与符号兼容处理基线设为 2.26；reversion_glibc.py 明确记录 MAX_ALLOWED_GLIBC_VERSION=[2,26] 且有例外符号。实际 CEF、客户端、依赖库的最低 glibc 必须用最终 ELF 的版本依赖和旧用户态运行核实，不能凭 sysroot 名称推断，也不能当前承诺 glibc 2.17 可用。
4. 使用现代 Ubuntu 作为构建主机并不强迫产物依赖主机 glibc：目标依赖应由受控 sysroot 决定。固定 Chromium 的 Linux 构建文档使用 x86-64 主机，基础设施为 Ubuntu 22.04。
5. Docker 容器共享宿主内核；旧用户态容器不等于 Linux 4.9 测试。应启动真正的 4.9 内核 VM 或目标设备，核实进程/线程、沙箱、图形与媒体功能，再补测较新内核。QEMU 的完整系统模式可作为旧内核验证候选；是否有硬件加速需实际确认，不假定 CVM 开放嵌套虚拟化。

## musl 对业务程序接入的影响（保留的早期预研）

- 普通 CEF 接入会在业务宿主进程中加载 `libcef.so`。若发布 musl 版 CEF，应让该宿主和依赖的运行库按 musl 环境构建 / 部署；不把 glibc 宿主直接加载 musl 版 `libcef.so` 作为受支持配置。少量简单库的实验加载成功不能证明完整 CEF 的线程、动态加载与依赖链兼容。
- 绑定 musl 用户态运行环境不等于绑定 Alpine 或要求整台目标系统改用 musl。在 glibc 发行版上，可以研究随应用提供 musl 加载器和配套用户态库；CEF 的窗口 / 字体 / 音频 / 图形驱动依赖仍需按实际目标验证，不能直接复用 glibc 版 `.so` 后声称兼容。
- 如果原业务必须使用 glibc，可以另建独立的 musl CEF 程序，再通过进程通信交换数据。此时是两个进程各用自己的 libc，需要额外设计业务调用、显示 / 输入与生命周期；不是直接链接 SDK 的同等接入方式。
- CEF 自带的 Browser / Renderer 多进程结构并不会自动解决 libc 混用：Browser 进程通常就是业务宿主，宿主仍加载 CEF。设置单独的 `browser_subprocess_path` 不等于把 CEF 从宿主中移出。
- 不采用“把 musl 静态塞进 `libcef.so`，然后给任意 glibc 程序加载”的通用化方案。musl 维护者指出，多套 libc 会竞争线程、信号等进程状态；该做法不受支持。
- 选择门槛应包含业务宿主及第三方依赖。用户最新选择已转为满足旧 UOS 的 glibc 兼容，当前先走 glibc 主线；此节说明为何不用 musl 替代既有 glibc SDK 的兼容工作。

## 腾讯云配置建议（容量规划，非报价）

优先准备一台 x86-64 主编译机，串行生成 glibc 版 x64 与交叉编译 ARM64：

| 项目 | 建议 |
| --- | --- |
| CPU / 内存 | 按用户预算使用 16–24 vCPU / 32 GB；增加 CPU 不代表应同时增加到同等数量的编译进程 |
| 实例候选 | 腾讯云 SA5 或 S8 的相应规格；以购买日地域、库存和实际价格为准 |
| 构建系统 | Ubuntu 22.04 x86_64；目标 libc 用 sysroot / 独立构建环境控制 |
| 系统盘 | 60–80 GB；也可以像当前机器一样只用一个容量足够的工作卷 |
| 工作盘 | 若沿用接近当前约 350 GB 的 SSD，先做单架构并记录实际峰值；可调整容量时优先考虑总计约 500 GB，600–800 GB 可留出更多实验余量。尚无本版本 Linux 峰值实测，不能保证最小容量 |
| 内存与并发 | 预留 32 GB swap；初始约 10–14 个编译任务，按实测调整；大型链接单独限流。初始关闭 PGO / ThinLTO，但保留 Release 优化和计划需要的符号，不并行构建两种架构或两种 libc |
| GPU | 主编译机无需 GPU；真实硬件图形行为另找对应设备验证 |
| ARM64 验证 | 按需短租原生 ARM64 4 vCPU / 8–16 GB；腾讯云 SR1 可作为候选，先确认地域库存及目标内核验证方式 |

上述磁盘与并发是容量规划，不是已测得的最低用量或性能承诺。32 GB 内存高于 Chromium / CEF 文档的内存下限；实际链接峰值仍需实测。逐个架构构建，打包校验后清理中间目录。Linux 原生 ARM64 运行验证另行解决。

## 后续开始时的验证门槛

- 单独的 Linux 补丁选择、构建入口、依赖锁、架构和 libc 标签；Windows 的脚本与完成标记不冒充 Linux 支持。
- glibc 路线审计 libcef.so、客户端、所有随包共享库的 GLIBC/GLIBCXX/CXXABI 版本和动态依赖，确认在目标 UOS V20 E 环境可解析 / 运行；不引入高于其 glibc 2.28 能提供的 GLIBC 版本依赖，并以尽量降低该需求为优化目标。保留对较旧 libc 的适配，不靠改版本标记或忽略缺失符号宣称兼容；逐架构记录低版本用户态实际运行证据。
- 如以后另行恢复 musl 研究，须验证完整 CEF SDK、宿主、依赖、多进程与沙箱；不以 Alpine 的 Chromium 浏览器配方代替 CEF 验证。
- x64/ARM64 分别在真实 Linux 4.9 内核上检查启动/退出、线程、沙箱、WebGL 硬件优先与软件回退、H.264/AAC、WebRTC 和编码功能，并补测较新内核。
- 清楚区分最低内核、最低 libc、其他动态库版本、CPU 指令集和 GPU 驱动要求，不用单个“Linux 4.9+”标识代替完整兼容边界。

## 主要来源

- 统信官方文档中心（桌面 V20 白皮书入口）： https://www.uniontech.com/Documentation.html
- 统信桌面 V20 白皮书（2023 年版，正文第 3 / 21 页）： https://www.uniontech.com/uploads/files/2024/0419/7903Xa7PccyBbCr1vKRtZWliuBFTpDSPxTRk90Sl.pdf
- 统信旧 glibc 包仓库（历史旁证，不代表教育版专用仓库）： https://packages.chinauos.com/uos/pool/main/g/glibc/
- 统信桌面教育版 V20 E 官方产品页： https://www.uniontech.com/OS-Educational-edition.html
- 统信服务器 E / D / A 名称说明： https://faq.uniontech.com/sever/sysmain/9c88

- 固定 Chromium sysroot 构造： https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/build/linux/sysroot_scripts/sysroot_creator.py
- 固定 Chromium glibc 符号处理： https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/build/linux/sysroot_scripts/reversion_glibc.py
- 固定 Chromium 构建说明： https://raw.githubusercontent.com/chromium/chromium/156.0.8071.0/docs/linux/build_instructions.md
- Alpine 官方 Chromium 配方： https://raw.githubusercontent.com/alpinelinux/aports/master/community/chromium/APKBUILD
- musl 作者对 libc 共享库混用的说明： https://www.openwall.com/lists/musl/2025/11/12/6
- musl 加载器与运行库路径： https://wiki.musl-libc.org/guidelines-for-distributions.html
- CEF 库和 Browser / Renderer 进程结构： https://raw.githubusercontent.com/chromiumembedded/cef/a26ddfd2792604564986b31ea298e30b09bd9b3f/docs/general_usage.md
- Linux Unix socket 进程通信： https://man7.org/linux/man-pages/man7/unix.7.html
- Docker 容器与内核： https://docs.docker.com/get-started/docker-concepts/the-basics/what-is-a-container/
- 腾讯云实例规格： https://intl.cloud.tencent.com/zh/document/product/213/11518

网页、实例供应和软件配方会变化，正式开工及购买前重新核实。
