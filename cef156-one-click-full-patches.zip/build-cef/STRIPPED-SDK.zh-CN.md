# 精简开发 SDK 制作

原始带符号 SDK 保留。精简包放在本地 `build/strip-lib`，每个平台和架构各有独立目录及压缩包。

`minimize_sdk.py` 读取不可变原包，校验完整 SHA-256，只保留引擎、开发链接库、全部公共头文件、C++ wrapper 源码、CMake、许可证和最小 demo。将原 Resources 合并到 Release，更新复制路径，移除 PDB / dSYM / ELF DWARF、预编译 demo、单元测试及构建补丁。Windows DLL 和 libcef.lib 字节保持原样；bootstrap / bootstrapc 作为沙箱或控制台入口保留。Linux 通过同版 llvm-objcopy strip，并对全部 ELF 的加载程序头、所有 SHF_ALLOC 段内容和动态导出/版本数据逐项比较。

示例源码共用 demos/common；demos/sandbox-on 与 demos/sandbox-off 分别固定开关，可独立作为 CMake 源目录。根目录还附 Ninja 的 CMakePresets.json。Mac demo 使用从原 XIB 转换并保留菜单语义的 AppKit 源码，避免 Linux 交叉编译时依赖不可用的 ibtool；SDK 发布包不需要该转换器。

制作单个平台，source-sha256 必须填写该原包已核实的完整摘要：

```sh
python3 minimize_sdk.py --source /path/to/original.tar.zst --target linux-x64 --destination /path/to/strip-lib --source-sha256 ORIGINAL_SHA256 --objcopy /path/to/pinned/llvm-objcopy --archive
```

Windows 使用同一脚本，target 改为 windows-x64 / windows-x86 / windows-arm64，原包为 ZIP，不传 objcopy。macOS 使用 mac-arm64 / mac-x64；原包中调试信息已分离为 dSYM，精简时排除 dSYM 并拒绝运行镜像中残留的 DWARF，不用 ELF 工具改写已签名 Mach-O。

`validate_minimal_linux.py` 实际构建两种入口；x64 还使用精简 SDK 执行三种图形/媒体/沙箱运行检查。ARM64 交叉编译与实际 ARM64 执行分别记录。`finalize_minimal_sdk.py` 绑定实际 demo 证据，重新核对运行文件身份，生成最终文件摘要，再压缩并逐文件读回核验。

精简和压缩均在本地进行：服务器只下载一份完整 SDK 到本地 `build`，再用本地原包生成 `build/strip-lib`，不额外下载服务器上的精简副本。Mac 不需要本地安装 Xcode 即可整理包；独立示例的编译/链接验证与精简打包分别记录，Mac 实机执行和 Apple 分发签名仍需目标设备验证。

例如在当前 Windows 工作站生成 macOS x64 包：

```powershell
python build-cef/minimize_sdk.py --source build/cef_binary_156.0.8071.0_mac_x64_release.tar.zst --target mac-x64 --destination build/strip-lib --source-sha256 5479258a296379c148212954a2a4e9d4ca303cb240df0fb6a5b6a6c0510a3f83 --archive
```

`compact_mac_runner.py` 保留为历史服务器验证工具，当前服务器的该服务已停用，不作为默认制作或下载步骤。

本地生成后执行：

```sh
python update_compact_index.py --directory /path/to/build/strip-lib
```

该命令逐文件复核本地目录和压缩包，更新 README.zh-CN.md 与 SDK-INDEX.json。Linux / macOS 的 tar.zst 保留 Unix 权限与相对符号链接；在目标系统使用 tar --zstd 解压。Windows 上展开目录是浏览/开发便利副本，Unix 原始权限仍以压缩包为准。
