import copy
from pathlib import Path
import tempfile
import unittest

from compact_demo_inputs import sdk_inputs, verify_portable


class PortableEvidenceTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.sdk = Path(self.tmp.name)
        for name in ('CMakeLists.txt', 'CMakePresets.json', 'demos/common/main.cc', 'Release/engine'):
            p = self.sdk / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(name)
        self.manifest = {'target': 'mac-x64', 'source_archive_sha256': 'a' * 64}
        self.evidence = {**self.manifest, 'sdk_inputs': sdk_inputs(self.sdk),
                         'binary_hashes_verified_on_build_host': True,
                         'clients': [{'sandbox': mode, 'binary_sha256': 'b' * 64,
                                      'images': [{'sha256': 'b' * 64}] * 5}
                                     for mode in ('ON', 'OFF')]}

    def test_matches_and_rejects_changed_source(self):
        verify_portable(self.sdk, self.manifest, self.evidence)
        (self.sdk / 'demos/common/main.cc').write_text('different')
        with self.assertRaises(RuntimeError):
            verify_portable(self.sdk, self.manifest, self.evidence)

    def test_rejects_added_build_input(self):
        (self.sdk / 'demos/common/new.cc').write_text('new')
        with self.assertRaises(RuntimeError):
            verify_portable(self.sdk, self.manifest, self.evidence)

    def test_rejects_missing_mode_and_wrong_original(self):
        for key, value in [('clients', self.evidence['clients'][:1]),
                           ('source_archive_sha256', 'c' * 64)]:
            e = copy.deepcopy(self.evidence)
            e[key] = value
            with self.assertRaises(RuntimeError):
                verify_portable(self.sdk, self.manifest, e)


if __name__ == '__main__':
    unittest.main()
