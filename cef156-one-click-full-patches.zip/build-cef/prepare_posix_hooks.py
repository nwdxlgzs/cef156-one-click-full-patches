#!/usr/bin/env python3
"""Run actual Chromium hooks with the pinned tools and Linux sysroots."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import sys

from prepare_posix import Preparation, CHROMIUM_REV, write_json

HERE = Path(__file__).resolve().parent
NESTED_REV = '910f54316dac310fadee0c453c4d460c0c446189'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    complete = prep.root / 'state/posix-hooks-complete.json'
    if complete.is_file():
        record = json.loads(complete.read_text('utf-8'))
        if record['chromium_revision'] != CHROMIUM_REV:
            raise RuntimeError('Existing hooks checkpoint belongs to a different Chromium revision')
        print('Existing completed hooks retained.', flush=True)
        return
    if (prep.root / 'state/prepared-posix.json').exists():
        raise RuntimeError('Do not rerun upstream hooks over a prepared patched source tree')
    if not (prep.root / 'state/posix-dependencies-synced.json').is_file():
        raise RuntimeError('Complete actual gclient dependency sync before hooks')
    nested = prep.src / 'third_party/depot_tools'
    if prep.git(nested, 'rev-parse', 'HEAD', capture=True).stdout.strip() != NESTED_REV:
        raise RuntimeError('The Chromium-pinned nested depot_tools revision differs')
    prep.bootstrap(nested, verify_gclient=False)
    prep.env['BOTO_CONFIG'] = str(prep.root / 'state/public-gcs.boto')
    prep.env['GN_DEFINES'] = 'use_sysroot=true is_debug=false use_remoteexec=false use_siso=false'
    # runhooks reparses DEPS and deletes GCS output directories whose migration
    # metadata was replaced by an upstream legacy installer. Run it before the
    # cache-backed installers, so the final toolchain remains available to GN.
    prep.run([prep.depot / 'gclient', 'runhooks'], cwd=prep.root / 'chromium')
    prep.run([sys.executable, HERE / 'prefetch_linux_sysroots.py', '--root', prep.root, '--stage', 'install'])
    # Initial sync may replace toolchain directories populated during early
    # research. Reuse verified archives via the original installers, rather
    # than trusting stale prefetch receipts or downloading the same tools again.
    prep.run([sys.executable, HERE / 'prefetch_clang.py', '--root', prep.root,
              '--installer', prep.src / 'tools/clang/scripts/update.py'])
    prep.run([sys.executable, HERE / 'prefetch_rust.py', '--root', prep.root])
    stamp = prep.src / 'third_party/llvm-build/Release+Asserts/cr_build_revision'
    if not stamp.is_file() or 'llvmorg-24-init-7747-g62397f8b-29' not in stamp.read_text():
        raise RuntimeError('The hooks did not install the locked Clang toolchain')
    clang = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
    version = prep.run([clang, '--version'], capture=True).stdout
    if 'clang version 24' not in version:
        raise RuntimeError('Clang compiler version check failed')
    write_json(complete, {
        'chromium_revision': CHROMIUM_REV, 'nested_depot_tools_revision': NESTED_REV,
        'clang_stamp': stamp.read_text(), 'clang_version': version,
        'clang_sha256': hashlib.sha256(clang.read_bytes()).hexdigest(),
        'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'scope': 'gclient runhooks actually succeeded with pinned tools; GN configuration and CEF build remain separate stages.',
    })


if __name__ == '__main__':
    main()
