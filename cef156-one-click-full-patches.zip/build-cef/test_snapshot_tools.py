"""Select real CEF snapshot dependencies without exporting unused host actions."""
import unittest

from snapshot_tools import required_snapshot_labels


class SnapshotDependencyTests(unittest.TestCase):
    def test_mac_arm64_excludes_unused_host_snapshot(self):
        actual = '//v8:run_mksnapshot_default'
        host = actual + '(//build/toolchain/linux:clang_x64_v8_arm64)'
        self.assertEqual(required_snapshot_labels([actual, host], [], {actual}), {actual})

    def test_keeps_required_qualified_context_and_v8_actions(self):
        startup = '//v8:run_mksnapshot_default(//build/toolchain/linux:clang_arm64)'
        context = '//tools/v8_context_snapshot:generate_v8_context_snapshot'
        unused = context + '(//build/toolchain/linux:clang_x64)'
        self.assertEqual(required_snapshot_labels([startup], [context, unused],
                                                 {startup, context}), {startup, context})

    def test_no_reachable_action_does_not_fall_back_to_all_toolchains(self):
        self.assertEqual(required_snapshot_labels(['//v8:run_mksnapshot_default'], [], set()), set())


if __name__ == '__main__':
    unittest.main()
