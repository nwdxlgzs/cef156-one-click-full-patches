@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Build-CEF.ps1" %*
set "BUILD_EXIT=%ERRORLEVEL%"
echo.
if "%BUILD_EXIT%"=="0" (echo Build finished.) else (echo Build stopped. Exit code: %BUILD_EXIT%. Read the log, then run this file again to resume.)
pause
exit /b %BUILD_EXIT%
