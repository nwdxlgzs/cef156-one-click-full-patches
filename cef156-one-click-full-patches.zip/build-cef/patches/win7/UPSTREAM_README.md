# <img width="64" src="product_logo_256.png" alt="Logo" /> Chromium for windows 7 <img width="64" src="xp_flag.png" alt="Logo" />

Chromium is an open-source browser project that aims to build a safer, faster,
and more stable way for all users to experience the web.

Chromium 109 is the last version to support Windows 7/8/8.1. This repository includes patches that enable newer versions of Chromium to run on Windows 7/8/8.1.

## Platform Support

Windows 7/8/8.1.

![](app.bmp)

might also work on Windows XP SP3 and Windows Vista.

## Building

see https://github.com/e3kskoy7wqk/Chromium-for-windows-7-REWORK/issues/37.

## Other Projects Using This Repository

* [Chromium for Windows 2000](https://github.com/mjd7989/Chromium-for-windows-2000) by mjd7989
* [Electron for Windows 7](https://github.com/e3kskoy7wqk/Electron-for-windows-7)
