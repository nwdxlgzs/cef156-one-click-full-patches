# 随包携带的补丁

此目录包含实际补丁文件，构建脚本直接使用本地文件，无需单独下载 Win7 补丁仓库。Chromium、CEF 源码和构建依赖仍需联网获取。

| 目录 | 内容 |
|---|---|
| `win7/chromium-156.0.8071.0/` | Win7 REWORK 该版本的 345 个 `.diff`、`commit_hashes.txt`、原始提交说明与作者 BAT |
| `cef-official/` | 固定 CEF 提交自带的完整 `patch` 目录，包括 `patch.cfg` 和 118 个补丁文件；其中 117 个列入应用配置 |
| `cef-8071/` | 本脚本对其中 10 个 CEF 补丁的完整替换版本，用于适配 Chromium 8071 + Win7 补丁；不是额外重复应用 10 遍 |
| `webgl/webgl-fallback.patch` | 独立的 WebGL 软件兜底回退规则补丁 |
| `windows-build/portable-processor-number.patch` | 修正原 Win7 补丁加入的 x86 汇编，使该沙箱辅助函数可用于 ARM64，并使用安全的静态初始化 |
| `manifest.json` | 版本、原始 Git 提交、应用顺序及所有补丁文件的 SHA256 清单 |

脚本先校验整个补丁目录，再开始安装和下载源码。原始 Win7 文件按字节保留；脚本仅在应用前修正个别补丁的路径头并写入构建目录 `state/normalized-patches`。

## 版本与应用次序

- Chromium：`156.0.8071.0`。
- Win7 REWORK：`b4d1c429f461bd756443ea0b68270d0bdb1c5536`。
- CEF：`a26ddfd2792604564986b31ea298e30b09bd9b3f`，其上游兼容记录原本指向 Chromium `156.0.8078.0`。本包包含 8071 的自定义适配，完整构建仍需验证。

构建顺序：同步源代码依赖 → 应用 CEF `runhooks.patch` 并运行下载钩子 → 按作者 `commit_hashes.txt` 的逆序应用 345 个 Win7 补丁 → 用 `cef-8071` 替换对应官方补丁文件 → 由 CEF patcher 按 `patch.cfg` 应用官方集成补丁 → 应用 `windows-build` 修正 → 应用 `webgl/webgl-fallback.patch` → 生成构建配置。

请使用顶层 `Build-CEF.cmd`。`win7` 目录内的原作者 BAT 保留了上游固定的源码路径，仅用于保留原始资料；顶层脚本已有实际应用逻辑。

## WebGL 回退行为

`webgl/webgl-fallback.patch` 是可直接检查和应用的补丁文件，会自动应用到 Win7/CEF 补丁处理后的源码，不再在构建时临时生成。

- 硬件 WebGL1 正常时保留硬件路径。
- 等待 GPU 能力判断完成；WebGL1 被确定为 blocklisted/disabled 时，才走已有的软件渲染回退。
- 仅缺少 WebGL2/GLES3 不触发软件切换。
- 尊重显式后端选择、`--disable-webgl`、`--disable-software-rasterizer` 和软件渲染开关。
- Win7 原补丁启用的初始化失败/崩溃回退保留；打包阶段携带 SwiftShader DLL。

这不是网页端针对任意 `getContext()` 失败的重试脚本。最终运行行为需要在有/无可用硬件 WebGL 的目标 Windows 上验证。
