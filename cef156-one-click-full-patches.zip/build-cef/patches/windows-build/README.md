# Windows architecture build fix

Applied after the upstream Win7 and CEF patches. The original Win7 diff
`535df75ba973adadcf74c761dc07c1103f92a106.diff` inserts an unguarded x86
assembly block in `sandbox/win/src/handle_closer_agent.cc`, which is also
compiled for ARM64.

`portable-processor-number.patch` retains the dynamic
`GetCurrentProcessorNumber` lookup. That API is available on Windows 7 and
modern Windows on ARM. A zero fallback remains for older systems where the
API does not exist. Function-local static initialization replaces the
unsynchronized flag/pointer initialization. No CPU-specific assembly remains
in this helper.

Validated by applying to the actual post-Win7 Chromium 156.0.8071.0 source
and checking the reverse patch. Full C++ compilation remains unverified.
