# BoringSSL ARM64 synchronization

The REWORK once implementation rejects non-x86 Windows targets and assumes
x86 acquire ordering. Its replacement push locks also depend on x86 ordering.
For OPENSSL_AARCH64 only, restore the pinned upstream INIT_ONCE type,
InitOnceExecuteOnce callback, and SRWLOCK operations. Retain the original
REWORK branch for x86/x64. The common TLS destructor critical section remains.

This patch is applied after the REWORK and CEF patches. Windows on ARM has
the native primitives; Windows 7 compatibility continues to target x86/x64.
Compile/link and target-device runtime evidence are recorded in VALIDATION.md.
