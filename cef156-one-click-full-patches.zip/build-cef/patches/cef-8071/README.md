# CEF patches adapted for Chromium 156.0.8071.0 + Win7 REWORK

CEF revision: `a26ddfd2792604564986b31ea298e30b09bd9b3f`.
Chromium: `156.0.8071.0`.
Win7 patch revision: `b4d1c429f461bd756443ea0b68270d0bdb1c5536`.

These files replace ten original CEF patches. They are applied by CEF's normal
patcher in its original order. `manifest.json` records both the original and the
adapted patch SHA256. The build script rejects any other original patch contents.

Four adaptations retain the original edits with updated surrounding context:
`views_widget`, `chrome_browser_dialogs_native`, `chrome_browser_dialogs_widget`,
and `color_provider_manager_3610`. They preserve the Win7 changes already present
in those surrounding lines, including Windows version guards.

The other six also account for code absent or different in 8071:

- `webkit_move_pip`: insert the CEF activation bypass into 8071's existing
  transient-activation check. 8071 does not have the newer PiP request token.
- `views_1749_2102_3330`: preserve all applicable menu API changes. The 8071
  `ActionAppMenu::RunMenuAt` call passes five arguments; its new `parent_widget`
  argument uses the declared null default, so that call needs no new argument.
- `chrome_runtime_views`: retain applicable toolbar/window changes. Omit the
  override of `CanHostWebUIOmnibox`, which does not exist in Chromium 8071.
- `chrome_browser_profile_menu`: include CEF's unique off-the-record profile in
  8071's simpler profile DCHECK. Its existing regular/incognito return mapping
  already maps CEF off-the-record profiles to the incognito metric.
- `win_taskbar_decorator_3645`: retain CEF includes around the Win7 version include.
- `chrome_autofill_bubble_3796`: add the null-handler return directly; 8071 does
  not have the newer CHECK that the original patch replaces.

Verification covers application to actual upstream source files and the Win7
overlap hunks. Patch application does not establish C++ API or runtime
compatibility; the full build and target-OS runtime tests remain necessary.

Upstream CEF sources and patches use the BSD-style license in CEF's LICENSE file:
https://github.com/chromiumembedded/cef/blob/a26ddfd2792604564986b31ea298e30b09bd9b3f/LICENSE.txt
