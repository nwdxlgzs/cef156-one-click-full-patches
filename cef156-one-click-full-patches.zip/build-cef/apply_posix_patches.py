#!/usr/bin/env python3
"""Install the separately verified CEF/POSIX patches on a synced checkout."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

from prepare_posix import Preparation, CHROMIUM, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent
PATCHES = HERE / 'posix-patches'


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_bundle():
    manifest = json.loads((PATCHES / 'manifest.json').read_text('utf-8'))
    if (manifest.get('format') != 1 or manifest.get('chromium_revision') != CHROMIUM_REV
            or manifest.get('cef_revision') != CEF_REV or not manifest.get('source_application_verified')):
        raise RuntimeError('POSIX patch manifest is not ready or has a different version lock')
    files = manifest['files']
    actual = {p.relative_to(PATCHES).as_posix() for p in PATCHES.rglob('*')
              if p.is_file() and p != PATCHES / 'manifest.json'}
    if actual != set(files):
        raise RuntimeError('Unlisted or missing POSIX patch payload')
    for name, digest in files.items():
        path = PATCHES / name
        if PATCHES.resolve() not in path.resolve().parents or sha256(path) != digest:
            raise RuntimeError('Invalid or changed POSIX patch payload: ' + name)
    if sha256(HERE / 'patches/manifest.json') != manifest['official_patch_bundle_sha256']:
        raise RuntimeError('The bundled upstream CEF patch set has changed')
    upstream = json.loads((HERE / 'patches/manifest.json').read_text('utf-8'))['files']
    for name, digest in upstream.items():
        if name.startswith('cef-official/') and sha256(HERE / 'patches' / name) != digest:
            raise RuntimeError('The bundled upstream CEF patch file has changed: ' + name)
    return manifest


def apply(preparation, patch, strip):
    command = ['git', '-C', preparation.src, 'apply', f'-p{strip}', '--ignore-whitespace']
    forward = preparation.run([*command, '--check', patch], capture=True, check=False)
    if forward.returncode:
        reverse = preparation.run([*command, '--reverse', '--check', patch], capture=True, check=False)
        if reverse.returncode == 0:
            return
        raise RuntimeError('Patch does not apply: ' + str(patch) + '\n' + forward.stderr)
    preparation.run([*command, patch])


def extend_prepared(preparation, prior, manifest, identity, prepared):
    """Append verified fixes while preserving all prior payloads and sources."""
    old = prior.get('posix_patch_manifest')
    if not old:
        raise RuntimeError('Existing preparation lacks its full manifest; inspect before migration')
    appendable = {'files', 'common_fixes', 'build_fixes'}
    if {k: v for k, v in old.items() if k not in appendable} != {
            k: v for k, v in manifest.items() if k not in appendable}:
        raise RuntimeError('A prepared patch migration changed immutable version/policy fields')
    if any(manifest['files'].get(k) != v for k, v in old['files'].items()):
        raise RuntimeError('A prepared patch migration changed or removed an existing payload')
    additions = []
    for key in ('common_fixes', 'build_fixes'):
        before, after = old[key], manifest[key]
        if after[:len(before)] != before:
            raise RuntimeError('A prepared patch migration reordered existing patches')
        additions.extend(after[len(before):])
    if not additions or set(manifest['files']) - set(old['files']) != set(additions):
        raise RuntimeError('A prepared patch migration must contain only explicitly appended patches')
    affected = set()
    for relative in additions:
        apply(preparation, PATCHES / relative, 1)
        affected.update(re.findall(r'^\+\+\+ b/([^\r\n\t]+)',
                                   (PATCHES / relative).read_text('utf-8'), re.M))
    backup = prepared.parent / 'patch-migrations' / (prior['posix_patch_bundle_sha256'] + '.json')
    backup.parent.mkdir(parents=True, exist_ok=True)
    if not backup.exists():
        write_json(backup, prior)
    updated = {**prior, 'posix_patch_bundle_sha256': identity, 'posix_patch_manifest': manifest,
               'patched_source_sha256': dict(prior['patched_source_sha256'])}
    for name in sorted(affected):
        path = preparation.src / name
        updated['patched_source_sha256'][name] = sha256(path) if path.is_file() else None
    updated['additive_migrations'] = [*prior.get('additive_migrations', []), {
        'previous_manifest_sha256': prior['posix_patch_bundle_sha256'],
        'manifest_sha256': identity, 'appended_patches': additions,
        'applied_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'previous_receipt': str(backup)}]
    write_json(prepared, updated)
    return updated


def install(preparation):
    manifest = verify_bundle()
    prepared = preparation.root / 'state/prepared-posix.json'
    identity = sha256(PATCHES / 'manifest.json')
    if prepared.exists():
        prior = json.loads(prepared.read_text('utf-8'))
        for name, digest in prior['patched_source_sha256'].items():
            path = preparation.src / name
            actual = sha256(path) if path.is_file() else None
            if actual != digest:
                raise RuntimeError('Prepared source changed: ' + name)
        if prior.get('posix_patch_bundle_sha256') != identity:
            return extend_prepared(preparation, prior, manifest, identity, prepared)
        return prior
    if not (preparation.root / 'state/posix-dependencies-synced.json').is_file():
        raise RuntimeError('Complete actual gclient dependency sync before patching')
    for directory, expected in [(preparation.src, CHROMIUM_REV), (preparation.src / 'cef', CEF_REV)]:
        actual = preparation.git(directory, 'rev-parse', 'HEAD', capture=True).stdout.strip()
        if actual != expected:
            raise RuntimeError('Source revision changed: ' + str(directory))
    overrides = json.loads((PATCHES / 'cef-8071/manifest.json').read_text('utf-8'))
    cef = preparation.src / 'cef'
    for name, record in overrides.items():
        original = HERE / 'patches/cef-official/patches' / (name + '.patch')
        replacement = PATCHES / 'cef-8071' / original.name
        destination = cef / 'patch/patches' / original.name
        if sha256(original) != record['upstream_sha256'] or sha256(replacement) != record['adapted_sha256']:
            raise RuntimeError('CEF adaptation identity mismatch: ' + name)
        if sha256(destination) not in (record['upstream_sha256'], record['adapted_sha256']):
            raise RuntimeError('Existing CEF patch has unexpected modifications: ' + name)
        shutil.copy2(replacement, destination)
    preparation.run([sys.executable, 'tools/patcher.py'], cwd=cef)
    extras = [*manifest['common_fixes'], manifest['webgl_patch'], *manifest['build_fixes']]
    for relative in extras:
        apply(preparation, PATCHES / relative, 1)
    # Include dependency-relative CEF patch paths as well as the common CEF
    # source fixes. A resume must validate the actual post-patch contents.
    import ast
    configured = ast.literal_eval(ast.parse((cef / 'patch/patch.cfg').read_text('utf-8')).body[0].value)
    modified = set()
    for item in configured:
        text = (cef / 'patch/patches' / (item['name'] + '.patch')).read_text('utf-8')
        for name in re.findall(r'^\+\+\+ (?!/dev/null)([^\r\n\t]+)', text, re.M):
            modified.add((Path(item.get('path', '')) / name).as_posix())
    for relative in extras:
        text = (PATCHES / relative).read_text('utf-8')
        modified.update(re.findall(r'^\+\+\+ b/([^\r\n\t]+)', text, re.M))
    report = {
        'chromium_version': CHROMIUM, 'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
        'posix_patch_bundle_sha256': identity, 'cef_configured_patches': len(configured),
        'posix_patch_manifest': manifest,
        'cef_adaptations': list(overrides), 'windows_compatibility_patches_applied': False,
        'patched_source_sha256': {name: sha256(preparation.src / name) if (preparation.src / name).is_file() else None
                                  for name in sorted(modified)},
        'prepared_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
        'scope': 'Patched source checkpoint, not a completed hook run, GN configuration or SDK build.',
    }
    write_json(prepared, report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    if not sys.platform.startswith('linux'):
        parser.error('Use the Linux build host for this POSIX preparation stage')
    install(Preparation(args.root))


if __name__ == '__main__':
    main()
