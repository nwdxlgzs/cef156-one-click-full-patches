import unittest
from audit_elf import needed_versions, version_key


class ElfVersionTests(unittest.TestCase):
    def test_exports_are_not_counted_as_runtime_requirements(self):
        text = '''Version symbols section '.gnu.version' contains 3 entries:
  004: GLIBC_99.0
Version definition section '.gnu.version_d' contains 2 entries:
  0x001c: Rev: 1 Flags: none Index: 3 Cnt: 1 Name: GLIBC_99.0
Version needs section '.gnu.version_r' contains 2 entries:
  0x0000: Version: 1 File: libc.so.6 Cnt: 2
  0x0010: Name: GLIBC_2.17 Flags: none Version: 3
  0x0020: Name: GLIBC_2.28 Flags: none Version: 2
  0x0030: Name: NSS_3.35 Flags: none Version: 5
'''
        self.assertEqual(needed_versions(text), ['GLIBC_2.17', 'GLIBC_2.28', 'NSS_3.35'])

    def test_non_numeric_abi_requirements_remain_visible(self):
        self.assertEqual(needed_versions("Version needs section '.gnu.version_r' contains 1 entry:\n  Name: GLIBC_ABI_DT_RELR Flags: none Version: 3"), ['GLIBC_ABI_DT_RELR'])
        self.assertGreater(version_key('2.28'), version_key('2.9'))


if __name__ == '__main__':
    unittest.main()
