#!/usr/bin/env python3
"""Compile one configured Release target and preserve its snapshot tools."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import sys
import xml.etree.ElementTree as ET

from apply_posix_patches import install
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json

HERE = Path(__file__).resolve().parent


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def verify_webgl_gtest(path):
    # Chromium's multiprocess launcher writes an XML aggregate, including
    # when gtest_output was given a json prefix. Request and parse XML.
    root = ET.parse(path).getroot()
    expected = {'MyCefWebGLRetainsHardwareWithCompositorRestriction', 'MyCefWebGLDefersUnknownHardwareState',
                'MyCefWebGLFallsBackAfterConfirmedFailure', 'MyCefWebGLHonorsOptOutAndExplicitImplementation'}
    cases = root.findall('.//testcase')
    if (root.tag != 'testsuites' or root.get('tests') != '4'
            or any(root.get(key, '0') != '0' for key in ('failures', 'disabled', 'errors'))
            or len(cases) != 4 or {case.get('name') for case in cases} != expected
            or any(case.get('classname') != 'GpuUtilTest' or case.get('status') != 'run'
                   or case.find('failure') is not None or case.find('error') is not None
                   or case.find('skipped') is not None for case in cases)):
        raise RuntimeError('The real WebGL GTest report did not execute all four required policy checks')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=['linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64'])
    parser.add_argument('--jobs', type=int, choices=range(1, 25), default=14)
    args = parser.parse_args()
    prep = Preparation(args.root)
    plan = json.loads((HERE / 'posix-targets.json').read_text('utf-8'))
    order = plan['order']
    for previous in order[:order.index(args.target)]:
        receipt = prep.root / 'state' / ('sdk-' + previous + '-verified.json')
        if not receipt.is_file():
            raise RuntimeError('Finish the earlier target and its archive validation first: ' + previous)
        prior = json.loads(receipt.read_text('utf-8'))
        if not prior.get('passed') or not Path(prior.get('archive', '')).is_file():
            raise RuntimeError('Earlier target has no verified archive: ' + previous)
        if digest(Path(prior['archive'])) != prior['archive_sha256']:
            raise RuntimeError('Earlier target archive changed: ' + previous)
    gn_record = prep.root / 'state' / ('gn-' + args.target + '.json')
    if not gn_record.is_file():
        raise RuntimeError('Generate and verify the real target GN configuration before compiling')
    config = json.loads(gn_record.read_text('utf-8'))
    output = Path(config['output']).resolve()
    if prep.src / 'out' not in output.parents or digest(output / 'args.gn') != config['args_gn_sha256']:
        raise RuntimeError('Generated target output or GN arguments changed')
    install(prep)
    minimum_gib = 12 if (output / '.ninja_log').is_file() else 100
    available = shutil.disk_usage(prep.root).free / 1024**3
    if available < minimum_gib:
        raise RuntimeError(f'Only {available:.1f} GiB free; retain current outputs and recover verified intermediates before continuing')
    prep.run([sys.executable, HERE / 'linux_link_swap.py', '--root', prep.root, '--stage', 'ensure'])
    prep.env['NINJA_STATUS'] = '[%r running, %f/%t @ %o/s : %es] '
    prep.run([sys.executable, HERE / 'snapshot_tools.py', '--root', prep.root, '--target', args.target,
              '--stage', 'plan', '--output', output, '--gn', prep.depot / 'gn'], cwd=prep.src)
    snapshot = json.loads((prep.root / 'state' / ('snapshot-plan-' + args.target + '.json')).read_text('utf-8'))
    tools = []
    for info in snapshot['identity']['snapshot_tools'].values():
        for value in info.get('outputs', []):
            path = prep.src / value[2:] if value.startswith('//') else output / value
            tools.append(path.relative_to(output).as_posix())
    if not tools:
        raise RuntimeError('No actual snapshot generator executable outputs found')
    prep.run([prep.depot / 'autoninja', '-C', output, '-j', str(args.jobs), *tools], cwd=prep.src)
    selected = plan['targets'][args.target]
    targets = ['cefsimple', 'cefclient']
    if selected['target_os'] == 'linux':
        targets.extend(['chrome_sandbox', 'gpu_unittests'])
    else:
        targets.append('cef_sandbox')
    prep.run([prep.depot / 'autoninja', '-C', output, '-j', str(args.jobs), *targets], cwd=prep.src)
    prep.run([sys.executable, HERE / 'linux_link_swap.py', '--root', prep.root, '--stage', 'release'])
    binary = output / 'libcef.so' if selected['target_os'] == 'linux' else output / 'Chromium Embedded Framework.framework/Chromium Embedded Framework'
    if not binary.is_file():
        raise RuntimeError('Compile finished without the expected CEF binary: ' + str(binary))
    prep.run([sys.executable, HERE / 'audit_posix_features.py', '--root', prep.root, '--target', args.target])
    if args.target == 'linux-x64':
        gtest_report = prep.root / 'state/webgl-policy-gtest-linux-x64.xml'
        prep.run([output / 'gpu_unittests', '--gtest_filter=GpuUtilTest.MyCef*',
                  '--gtest_output=xml:' + str(gtest_report)], cwd=output)
        verify_webgl_gtest(gtest_report)
    prep.run([sys.executable, HERE / 'snapshot_tools.py', '--root', prep.root, '--target', args.target,
              '--stage', 'export'], cwd=prep.src)
    compiled_path = prep.root / 'state' / ('compiled-' + args.target + '.json')
    completed = {
        'target': args.target, 'output': str(output), 'cef_binary': str(binary), 'cef_binary_sha256': digest(binary),
        'gn_configuration_sha256': digest(output / 'args.gn'), 'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
        'targets': targets, 'snapshot_identity_sha256': snapshot['identity_sha256'],
        'compiled_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'sdk_packaged': False,
        'scope': 'Actual compilation/linking and snapshot export. SDK packaging, symbols, independent client and target runtime remain separate gates.',
    }
    # A no-change rerun must retain the receipt identity already bound into
    # staged SDKs and independent clients. All artifacts and gates above
    # were checked again; a timestamp alone must not invalidate packaging.
    if compiled_path.is_file():
        previous = json.loads(compiled_path.read_text('utf-8'))
        if {k: v for k, v in previous.items() if k != 'compiled_utc'} == {
                k: v for k, v in completed.items() if k != 'compiled_utc'}:
            completed['compiled_utc'] = previous['compiled_utc']
    write_json(compiled_path, completed)
    print('CEF_RELEASE_TARGET_COMPILED', args.target, output, flush=True)


if __name__ == '__main__':
    main()
