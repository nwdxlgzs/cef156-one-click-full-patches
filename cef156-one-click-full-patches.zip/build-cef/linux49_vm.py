#!/usr/bin/env python3
"""Build a small Linux 4.9 VM initramfs and run a bounded QEMU boot probe.

The kernel comes from the verified Debian package cache. The x64 probe can
mount an existing old userland over 9p, allowing real kernel/userland checks
without making a second full filesystem copy. This is not yet a CEF test.
"""
from __future__ import annotations

import argparse
import datetime as dt
import gzip
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess

from prepare_posix import Preparation, write_json


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            result.update(data)
    return result.hexdigest()


def arm_busybox(prep):
    state = json.loads((prep.root / 'state/linux49-kernel-cache.json').read_text('utf-8'))
    pin = next(item for item in state['packages'] if item['architecture'] == 'arm64')
    index = prep.root / 'downloads/linux49/Packages-arm64.xz'
    if digest(index) != pin['index_sha256']:
        raise RuntimeError('Signed ARM64 package index has changed')
    selected = None
    for block in lzma.decompress(index.read_bytes()).decode().split('\n\n'):
        if block.startswith('Package: busybox-static\n'):
            selected = dict(line.split(': ', 1) for line in block.splitlines()
                            if line and not line.startswith(' ') and ': ' in line)
            break
    if selected is None:
        raise RuntimeError('No ARM64 static busybox in the signed old Debian index')
    from prefetch_49_kernels import download
    package = prep.root / 'downloads/linux49' / Path(selected['Filename']).name
    download(selected['Filename'], package, selected['SHA256'], int(selected['Size']))
    directory = prep.root / 'cache/oldlinux/busybox-arm64'
    directory.mkdir(exist_ok=True)
    subprocess.run(['dpkg-deb', '-x', str(package), str(directory)], check=True)
    return directory / 'bin/busybox'


def make_initramfs(prep, arch, busybox, setup=False, runtime=False):
    with Path(busybox).open('rb') as stream:
        header = stream.read(20)
    expected_machine = 62 if arch == 'amd64' else 183
    if header[:6] != b'\x7fELF\x02\x01' or struct.unpack('<H', header[18:20])[0] != expected_machine:
        raise RuntimeError('The initramfs busybox has the wrong CPU architecture')
    state = json.loads((prep.root / 'state/linux49-kernel-cache.json').read_text('utf-8'))
    package = next(item for item in state['packages'] if item['architecture'] == arch)
    if digest(Path(package['path'])) != package['sha256']:
        raise RuntimeError('Old-kernel package cache has changed')
    kernel_root = prep.root / 'cache/oldlinux' / arch
    kernel_root.mkdir(exist_ok=True)
    if not (kernel_root / 'boot').exists():
        subprocess.run(['dpkg-deb', '-x', package['path'], str(kernel_root)], check=True)
    version = next((kernel_root / 'lib/modules').iterdir()).name
    subprocess.run(['depmod', '-b', str(kernel_root), version], check=True)
    suffix = arch + ('-runtime' if runtime else '-setup' if setup else '')
    staging = prep.root / 'cache/oldlinux' / ('initramfs-' + suffix)
    if staging.exists():
        raise RuntimeError('Initramfs staging already exists; inspect before replacing: ' + str(staging))
    staging.mkdir()
    for relative in ['bin', 'sbin', 'lib/modules/' + version, 'proc', 'sys', 'dev', 'newroot', 'tmp']:
        (staging / relative).mkdir(parents=True, exist_ok=True)
    shutil.copy2(busybox, staging / 'bin/busybox')
    for name in ['sh', 'mount', 'mkdir', 'uname', 'cat', 'sleep', 'poweroff', 'chroot', 'dmesg', 'sync', 'ip']:
        (staging / 'bin' / name).symlink_to('busybox')
    for name in ['modprobe', 'insmod']:
        (staging / 'sbin' / name).symlink_to('../bin/busybox')
    modules = set()
    for name in ['virtio_pci', 'virtio_mmio', '9pnet_virtio', '9p', *(['virtio_blk', 'ext4'] if setup or runtime else [])]:
        result = subprocess.run(['modprobe', '--dirname', str(kernel_root), '--set-version', version,
                                 '--show-depends', name], capture_output=True, text=True)
        if result.returncode and name == 'virtio_mmio' and arch == 'amd64':
            continue
        if result.returncode:
            raise RuntimeError('Missing required VM module: ' + name + result.stderr)
        for line in result.stdout.splitlines():
            fields = line.split()
            if len(fields) >= 2 and fields[0] == 'insmod':
                modules.add(Path(fields[1]))
    for source in modules:
        destination = staging / source.relative_to(kernel_root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
    for name in ['modules.dep', 'modules.alias', 'modules.softdep', 'modules.builtin', 'modules.order']:
        source = kernel_root / 'lib/modules' / version / name
        if source.is_file():
            shutil.copy2(source, staging / 'lib/modules' / version / name)
    init = '''#!/bin/sh
export PATH=/bin:/sbin
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
echo MYCEF_KERNEL_PROBE_BEGIN
uname -a
cat /proc/cmdline
modprobe virtio_pci
modprobe virtio_mmio 2>/dev/null || true
modprobe 9pnet_virtio
modprobe 9p
if mount -t 9p -o trans=virtio,version=9p2000.L,msize=262144,ro oldroot /newroot; then
  echo MYCEF_OLD_USERLAND_MOUNTED
  chroot /newroot /usr/bin/ldd --version
  chroot /newroot /bin/uname -r
  echo MYCEF_OLD_USERLAND_PROBE_DONE
fi
echo MYCEF_KERNEL_PROBE_DONE
poweroff -f
'''
    if setup:
        init = '''#!/bin/sh
export PATH=/bin:/sbin
export LC_ALL=C
export DEBIAN_FRONTEND=noninteractive
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
echo MYCEF_KERNEL_PROBE_BEGIN
uname -a
modprobe virtio_pci
modprobe virtio_mmio 2>/dev/null || true
modprobe virtio_blk
modprobe ext4
if mount -t ext4 /dev/vda /newroot; then
  mount --bind /dev /newroot/dev
  mount -t proc proc /newroot/proc
  mount -t sysfs sysfs /newroot/sys
  mkdir -p /newroot/run
  mount -t tmpfs tmpfs /newroot/run
  if chroot /newroot /bin/sh /debootstrap/debootstrap --second-stage; then
    chroot /newroot /usr/bin/ldd --version
    echo MYCEF_USERLAND_SECOND_STAGE_DONE
  fi
fi
sync
echo MYCEF_KERNEL_PROBE_DONE
poweroff -f
'''
    if runtime:
        init = '''#!/bin/sh
export PATH=/bin:/sbin
export LC_ALL=C
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
echo MYCEF_KERNEL_PROBE_BEGIN
uname -a
modprobe virtio_pci
modprobe virtio_mmio 2>/dev/null || true
modprobe virtio_blk
modprobe ext4
modprobe 9pnet_virtio
modprobe 9p
ip link set lo up
if mount -t ext4 /dev/vda /newroot 2>/dev/null || mount -t 9p -o trans=virtio,version=9p2000.L,msize=262144 oldroot /newroot; then
  mount --bind /dev /newroot/dev
  mount -t proc proc /newroot/proc
  mount -t sysfs sysfs /newroot/sys
  mount -t tmpfs tmpfs /newroot/tmp
  mkdir -p /newroot/run /newroot/dev/shm /newroot/opt/mycef-validation /newroot/opt/mycef-sdk
  mount -t tmpfs tmpfs /newroot/run
  mount -t tmpfs -o mode=1777 tmpfs /newroot/dev/shm
  if mount -t 9p -o trans=virtio,version=9p2000.L,msize=262144 exchange /newroot/opt/mycef-validation; then
    mount -t 9p -o trans=virtio,version=9p2000.L,msize=262144,ro sdk /newroot/opt/mycef-sdk 2>/dev/null || true
    if chroot /newroot /bin/sh /opt/mycef-validation/guest-run.sh; then
      echo MYCEF_GUEST_VALIDATION_DONE
    else
      echo MYCEF_GUEST_VALIDATION_FAILED
    fi
  fi
fi
sync
echo MYCEF_KERNEL_PROBE_DONE
poweroff -f
'''
    (staging / 'init').write_text(init, encoding='utf-8')
    (staging / 'init').chmod(0o755)
    archive = prep.root / 'cache/oldlinux' / ('initramfs-' + suffix + '.cpio.gz')
    listing = subprocess.check_output(['find', '.', '-print0'], cwd=staging)
    with archive.open('wb') as target:
        packed = subprocess.Popen(['cpio', '--null', '-o', '--format=newc', '--quiet'], cwd=staging,
                                  stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        packed.stdin.write(listing)
        packed.stdin.close()
        with gzip.GzipFile(fileobj=target, mode='wb', mtime=0) as compressed:
            shutil.copyfileobj(packed.stdout, compressed)
        if packed.wait():
            raise RuntimeError('Failed to create VM initramfs')
    kernel = next((kernel_root / 'boot').glob('vmlinuz-*'))
    info = {'architecture': arch, 'kernel': str(kernel), 'kernel_sha256': digest(kernel),
            'initramfs': str(archive), 'initramfs_sha256': digest(archive), 'kernel_package': package,
            'busybox': str(busybox), 'busybox_sha256': digest(busybox),
            'module_count': len(modules), 'created_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    write_json(prep.root / 'state' / ('linux49-vm-' + suffix + '.json'), info)
    return info


def boot(prep, arch, userland=None, seconds=180, image=None):
    suffix = arch + ('-setup' if image else '')
    info = json.loads((prep.root / 'state' / ('linux49-vm-' + suffix + '.json')).read_text('utf-8'))
    for key in ['kernel', 'initramfs']:
        if digest(Path(info[key])) != info[key + '_sha256']:
            raise RuntimeError('Old VM boot input changed: ' + key)
    if arch == 'amd64':
        command = ['qemu-system-x86_64', '-machine', 'q35,accel=tcg', '-cpu', 'max',
                   '-append', 'console=ttyS0 panic=-1 rdinit=/init']
    else:
        command = ['qemu-system-aarch64', '-machine', 'virt,accel=tcg,gic-version=2', '-cpu', 'cortex-a72',
                   '-append', 'console=ttyAMA0 panic=-1 rdinit=/init']
    command.extend(['-m', '1024', '-smp', '2', '-kernel', info['kernel'], '-initrd', info['initramfs'],
                    '-display', 'none', '-monitor', 'none', '-serial', 'stdio', '-no-reboot', '-nic', 'none'])
    if userland:
        userland = Path(userland).resolve()
        if prep.root / 'validation/oldlinux' not in userland.parents:
            raise RuntimeError('Old userland must be inside the dedicated validation directory')
        command.extend(['-virtfs', 'local,path=' + str(userland) + ',mount_tag=oldroot,security_model=none,readonly=on'])
    if image:
        image = Path(image).resolve()
        if prep.root / 'cache/oldlinux' not in image.parents:
            raise RuntimeError('The userland image escaped its validation cache')
        command.extend(['-drive', 'file=' + str(image) + ',format=raw,if=virtio'])
    log = prep.root / 'logs' / ('linux49-vm-' + suffix + '.log')
    timeout = False
    with log.open('w') as output:
        try:
            result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, timeout=seconds)
            returncode = result.returncode
        except subprocess.TimeoutExpired:
            timeout = True
            returncode = None
    text = log.read_text('utf-8', errors='replace')
    passed = (not timeout and returncode == 0 and 'MYCEF_KERNEL_PROBE_DONE' in text
              and bool(re.search(r'Linux version 4\.9\.', text)))
    if userland:
        passed = passed and 'MYCEF_OLD_USERLAND_PROBE_DONE' in text and 'GLIBC 2.28' in text
    if image:
        passed = passed and 'MYCEF_USERLAND_SECOND_STAGE_DONE' in text and 'GLIBC 2.28' in text
    report = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'architecture': arch,
              'command': command, 'returncode': returncode, 'timeout': timeout, 'passed': passed,
              'userland': str(userland) if userland else None, 'log': str(log), 'log_sha256': digest(log),
              'cef_runtime_verified': False,
              'scope': 'Real full-system Linux 4.9 boot; optional old userland execution. This is not CEF, sandbox, media or GPU validation.'}
    write_json(prep.root / 'state' / ('linux49-vm-' + suffix + '-boot.json'), report)
    print(json.dumps(report, indent=2), flush=True)
    if not passed:
        raise RuntimeError('Linux 4.9 VM probe failed; inspect ' + str(log))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--arch', choices=['amd64', 'arm64'], required=True)
    parser.add_argument('--stage', choices=['initramfs', 'boot'], required=True)
    parser.add_argument('--busybox')
    parser.add_argument('--userland')
    parser.add_argument('--setup-userland', action='store_true')
    parser.add_argument('--root-image')
    parser.add_argument('--timeout', type=int, default=180)
    args = parser.parse_args()
    prep = Preparation(args.root)
    if args.stage == 'initramfs':
        binary = Path(args.busybox).resolve() if args.busybox else (arm_busybox(prep) if args.arch == 'arm64' else Path('/usr/bin/busybox'))
        make_initramfs(prep, args.arch, binary, args.setup_userland)
    else:
        boot(prep, args.arch, args.userland, args.timeout, args.root_image)


if __name__ == '__main__':
    main()
