# Windows CEF 功能配置

核对日期：2026-11-08。Chromium 156.0.8071.0，固定 CEF 提交 a26ddfd2792604564986b31ea298e30b09bd9b3f。x64、x86、ARM64 Release SDK 均已完成构建和归档验证；x64 / x86 有实际运行证据，ARM64 有完整符号和独立客户端交叉编译 / 链接证据。功能编译启用与目标设备实际可用分别说明。

## 本次显式配置

- Release：`is_debug=false`、`is_official_build=true`、`is_component_build=false`。保留完整 PDB，`symbol_level=2`、`blink_symbol_level=2`、`v8_symbol_level=2`。按本机内存规划关闭 PGO / ThinLTO，其余 Release 优化保留。
- H.264 / AAC / MP4：`proprietary_codecs=true`、`ffmpeg_branding="Chrome"`。
- H.264 软件编码与 WebRTC：`media_use_openh264=true`、`rtc_use_h264=true`。本次采用 OpenH264，没有集成独立 libx264。
- HEVC / H.265：`enable_platform_hevc=true`、`enable_hevc_parser_and_hw_decoder=true`。这是平台解析与硬件解码路径，实际能力受系统、驱动、硬件影响，不承诺所有设备或 Win7 能软解。
- 软件图形后备：`enable_swiftshader=true`、`use_static_angle=false`；同时打包 ANGLE 和补丁恢复的旧 SwiftShader GL 库，保留硬件优先的 WebGL 规则。
- WebGL 自定义补丁：硬件 WebGL1 正常时保持硬件路径；WebGL1 明确被 blocklisted / disabled 时进入软件回退。仅 WebGL2 / GLES3 不支持，不因此切换整个 WebGL 后端；尊重显式后端和禁用开关。任意网页 `getContext()` 失败不等于都会自动重试。
- Win7 REWORK 345 个补丁、CEF 官方补丁及 8071 适配随包。x86 / x64 的 Win7 运行仍需目标机实测；ARM64 补丁修复保留 Windows on ARM 原生同步和处理器查询路径。

## 实际生成的构建标志

以下在 ARM64 构建过程中由输出目录的 `gen/` 生成头文件核对，不是把每个 GN 默认值一律当作已实测功能；x64 / x86 的显式媒体配置同上，完整运行验证范围见下节。

实际 `args.gn` 及 10 个生成头文件的 SHA256、逐项标志值已保存为 `validation/build-features-arm64-Release.json`。该记录带有观测时间和补丁清单哈希，范围仅为当时的 ARM64 配置；最终 SDK / 符号结果另见 `validation/cloud-verified-arm64-Release.json`，运行情况仍须目标设备验证。

| 生成头文件 | 已启用 |
| --- | --- |
| `pdf/buildflags.h` | `ENABLE_PDF=1` |
| `printing/buildflags/buildflags.h` | `ENABLE_PRINTING=1`、`ENABLE_PRINT_PREVIEW=1`、基础打印对话框、进程外打印 |
| `extensions/buildflags/buildflags.h` | `ENABLE_EXTENSIONS=1`、`ENABLE_EXTENSIONS_CORE=1`；具体扩展仍需接入和兼容测试 |
| `media/media_buildflags.h` | FFmpeg 及软件视频解码器、OpenH264、libvpx、libaom、dav1d / AV1 解码、HLS、MSE MPEG2-TS 解析；平台 HEVC 和 Dolby Vision 入口 |
| `third_party/widevine/cdm/buildflags.h` | `ENABLE_WIDEVINE=1`、`ENABLE_WIDEVINE_CDM_COMPONENT=1`；`BUNDLE_WIDEVINE_CDM=0` |

Widevine 接入代码不等于已提供可用 CDM：当前 SDK 没有附带 Widevine CDM，未验证 DRM 播放。Dolby Vision 的实际解码也依赖平台及运行时功能开关，不将编译标志当成普遍可用性承诺。当前生成标志中 AC3 / EAC3、AC4、DTS 和音频直通均为关闭。

## CEF 接入能力与验证范围

- 保留正常 CEF 页面 / JavaScript 引擎、网络、缓存与存储、DevTools、WebRTC、音视频采集、离屏渲染及 C++ / JavaScript 接入能力；宿主仍需通过 CEF API、权限处理与运行配置接入相应功能。WebGPU 代码参与构建，但目标系统的运行可用性未单独验证。
- 沙箱支持保留。x64 / x86 SDK 已实际编译并运行 `USE_SANDBOX=ON` 的 bootstrap EXE + 业务 DLL，以及 `USE_SANDBOX=OFF` 的业务 EXE。二者使用相同的对应架构 libcef.dll；宿主可选择模式。ARM64 引擎构建后，独立 `USE_SANDBOX=ON` CMake 客户端交叉编译 / 链接及 PE 架构检查通过，真实 ARM64 运行仍待目标设备验证。
- x64 / x86 在 Server 2025 及本机 Windows 11 上，已通过 WebGL1 / 2 像素绘制、H.264 视频播放、AAC 解码、WebRTC H.264 能力声明、H.264 软件编码后解码回环。硬件 WebGL 和禁用 GPU 后的 SwiftShader 分别有运行报告。
- WebRTC 的完整通话、PDF、打印、任意第三方扩展、AV1 / HEVC / Dolby Vision / HLS、DRM 和 WebGPU 尚未逐项做端到端验收；不把编译启用或单帧 H.264 回环描述成这些功能的完整质量保证。
- 没有 Debug 配置；Release PDB 可用于符号调试，优化会影响单步及局部变量观察。

本文件是配置和证据范围说明，未改变构建选项。已有 SDK 的实际参数可查看各包的 `MYCEF_args.gn` 和 `MYCEF_BUILD.json`；验证记录位于随包脚本目录的 `validation/`。
