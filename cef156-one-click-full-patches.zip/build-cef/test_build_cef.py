"""Local orchestration tests. No downloads, installs or Chromium compilation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

import build_cef as build


class BuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="mycef-tests-")
        self.root = Path(self.temp.name)
        for folder in ("logs", "state", "packages"):
            (self.root / folder).mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def builder(self):
        return build.Builder(argparse.Namespace(root=str(self.root), jobs=2,
                                                build_free_gb=0, keep_intermediates=False))

    def test_hook_failure_resumes_after_successful_sync_without_resyncing_patches(self):
        builder = self.builder()
        (builder.cef / 'patch/patches').mkdir(parents=True)
        (builder.src / 'chrome').mkdir()
        (builder.src / 'chrome/VERSION').write_text('MAJOR=156\nMINOR=0\nBUILD=8071\nPATCH=0\n')
        (builder.cef / 'CHROMIUM_BUILD_COMPATIBILITY.txt').write_text('refs/tags/' + build.CEF_UPSTREAM_CHROMIUM)
        builder.checkout = mock.Mock(side_effect=lambda path, *args, **kwargs: build.CHROMIUM_REV if path == builder.src else build.CEF_REV)
        builder.install_cef_official_patches = mock.Mock()
        builder.prepare_source_mirror = mock.Mock(return_value=None)
        builder.prepare_nested_depot_tools = mock.Mock()
        builder.apply_patch = mock.Mock()
        def command(arguments, **kwargs):
            if arguments[:2] == ['gclient', 'runhooks']:
                raise RuntimeError('simulated hook failure')
            return 0, ''
        builder.run = mock.Mock(side_effect=command)
        for attempt in range(2):
            with self.assertRaisesRegex(RuntimeError, 'simulated hook failure'):
                builder.prepare_sources()
        syncs = [call.args[0] for call in builder.run.call_args_list if call.args[0][:2] == ['gclient', 'sync']]
        self.assertEqual(len(syncs), 1)
        self.assertIn('src@' + build.CHROMIUM_REV, syncs[0])
        self.assertTrue((builder.state / 'dependencies-synced.json').exists())
        self.assertFalse((builder.state / 'sync-and-hooks.json').exists())
        self.assertFalse((builder.state / 'prepared.json').exists())

    @unittest.skipUnless(os.name == "nt", "Windows PowerShell bootstrap")
    def test_powershell_plan_defaults_to_c_and_creates_no_build_root(self):
        command = ["powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                   "-File", str(Path(build.__file__).with_name("Build-CEF.ps1")), "-PlanOnly"]
        result = subprocess.run(command, capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("Root: C:\\cef156;", result.stdout)
        dedicated = Path("C:/mycef_plan_" + self.root.name)
        self.assertFalse(dedicated.exists())
        result = subprocess.run(command + ["-Root", str(dedicated)],
                                capture_output=True, text=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertFalse(dedicated.exists())

    @unittest.skipUnless(os.name == "nt", "Windows PowerShell bootstrap")
    def test_powershell_rejects_volume_root_and_ambiguous_paths(self):
        command = ["powershell.exe", "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass",
                   "-File", str(Path(build.__file__).with_name("Build-CEF.ps1")), "-PlanOnly", "-Root"]
        for invalid in ("C:\\", "C:\\\\", "C:\\build\\..\\Windows", "C:\\folder name", "\\\\server\\share\\cef"):
            result = subprocess.run(command + [invalid], capture_output=True, text=True, timeout=60)
            self.assertNotEqual(result.returncode, 0, invalid)
            self.assertIn("Use a dedicated short ASCII folder", result.stdout + result.stderr)

    def test_archive_round_trip_and_per_file_hashes(self):
        folder = self.root / "sdk"
        (folder / "Release").mkdir(parents=True)
        (folder / "Release/libcef.dll").write_bytes(b"dummy PE payload\0" * 10000)
        (folder / "Release/libcef.dll.pdb").write_bytes(b"dummy symbols" * 20000)
        output = self.root / "sdk.zip"
        result = build.make_archive(folder, output, {"version": build.CHROMIUM})
        self.assertEqual(result["sha256"], hashlib.sha256(output.read_bytes()).hexdigest())
        with zipfile.ZipFile(output) as archive:
            manifest = json.loads(archive.read("SHA256SUMS.json"))
            for name, digest in manifest.items():
                self.assertEqual(hashlib.sha256(archive.read(name)).hexdigest(), digest)
        self.assertTrue(output.with_suffix(".zip.sha256").exists())
        self.assertFalse(output.with_suffix(".zip.partial").exists())

    def test_cleanup_rejects_parent_and_outside(self):
        parent = self.root / "out"
        parent.mkdir()
        with self.assertRaises(RuntimeError):
            build.safe_remove(parent, parent)
        with self.assertRaises(RuntimeError):
            build.safe_remove(self.root / "packages", parent)
        target = parent / "Release_GN_x64"
        target.mkdir()
        (target / "object.obj").write_text("dummy", encoding="utf8")
        build.safe_remove(target, parent)
        self.assertFalse(target.exists())
        self.assertTrue(parent.exists())

    def test_normalize_malformed_upstream_header_and_apply(self):
        repo = self.root / "repo"
        (repo / "media/cdm").mkdir(parents=True)
        subprocess.run(["git", "-C", str(repo), "init", "-q"], check=True)
        (repo / "media/cdm/cdm_module.cc").write_text("one\ntwo\nthree\n", encoding="utf8")
        malformed = ('diff --git "a/C:\\\\old.cc" "b/C:\\\\new.cc"\n'
                     '--- a/media/cdm/cdm_module.cc\n+++ b/media/cdm/cdm_module.cc\n'
                     '@@ -1,3 +1,3 @@\n one\n-two\n+TWO\n three\n')
        patch = self.root / "sample.diff"
        patch.write_text(build.normalize_patch(malformed), encoding="utf8")
        builder = self.builder()
        builder.apply_patch(patch, root=repo)
        builder.apply_patch(patch, root=repo)  # A crash after apply is resumable.
        self.assertEqual((repo / "media/cdm/cdm_module.cc").read_text(), "one\nTWO\nthree\n")

    def test_upstream_cef_prefixless_patch(self):
        repo = self.root / "repo"
        repo.mkdir()
        subprocess.run(["git", "-C", str(repo), "init", "-q"], check=True)
        (repo / "test.py").write_text("one\ntwo\nthree\n", encoding="utf8")
        patch = self.root / "runhooks.patch"
        patch.write_text('diff --git test.py test.py\n--- test.py\n+++ test.py\n'
                         '@@ -1,3 +1,3 @@\n one\n-two\n+TWO\n three\n', encoding="utf8")
        self.builder().apply_patch(patch, root=repo, strip=0)
        self.assertIn("TWO", (repo / "test.py").read_text())

    def test_adapted_patch_checksums_and_syntax(self):
        folder = build.PATCHES_DIR / "cef-8071"
        manifest = build.read_json(folder / "manifest.json")
        self.assertEqual(len(manifest), 10)
        for name, info in manifest.items():
            patch = folder / (name + ".patch")
            self.assertEqual(build.sha256(patch), info["rebased_sha256"])
            result = subprocess.run(["git", "apply", "-p0", "--numstat", str(patch)],
                                    capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))

    def test_full_patch_bundle_is_local_and_complete(self):
        manifest = build.verify_patch_bundle()
        self.assertEqual(manifest["win7_revision"], build.PATCH_REV)
        win7 = build.PATCHES_DIR / "win7" / f"chromium-{build.CHROMIUM}"
        names = [name.strip() for name in (win7 / "commit_hashes.txt").read_text().splitlines() if name.strip()]
        self.assertEqual(len(names), 345)
        self.assertEqual({name + ".diff" for name in names}, {path.name for path in win7.glob("*.diff")})
        webgl = build.PATCHES_DIR / "webgl/webgl-fallback.patch"
        self.assertIn("MYCEF_WEBGL_FALLBACK_V1", webgl.read_text())
        self.assertIn("MYCEF_WEBGL_GLES2_V1", webgl.read_text())
        result = subprocess.run(["git", "apply", "--numstat", str(webgl)], capture_output=True)
        self.assertEqual(result.returncode, 0, result.stderr.decode(errors="replace"))

    def test_all_win7_patch_files_parse_after_normalization(self):
        folder = build.PATCHES_DIR / "win7" / f"chromium-{build.CHROMIUM}"
        for patch in folder.glob("*.diff"):
            data = build.normalize_patch(patch.read_text(encoding="utf-8-sig"))
            # Use bytes: Windows text pipes change LF to CRLF, which corrupts
            # Git's binary-patch parsing. The builder writes LF-only files.
            result = subprocess.run(["git", "apply", "--numstat", "-"],
                                    input=data.encode("utf8"), capture_output=True)
            self.assertEqual(result.returncode, 0, patch.name + ": " + result.stderr.decode(errors="replace"))

    def test_patch_bundle_rejects_missing_changed_and_unlisted_files(self):
        folder = self.root / "patches"
        shutil.copytree(build.PATCHES_DIR, folder)
        patch = folder / "webgl/webgl-fallback.patch"
        original = patch.read_bytes()
        patch.unlink()
        with self.assertRaisesRegex(RuntimeError, "missing or changed"):
            build.verify_patch_bundle(folder)
        patch.write_bytes(original + b"\nmodified\n")
        with self.assertRaisesRegex(RuntimeError, "missing or changed"):
            build.verify_patch_bundle(folder)
        patch.write_bytes(original)
        (folder / "unknown.diff").write_text("unlisted", encoding="utf8")
        with self.assertRaisesRegex(RuntimeError, "unlisted or missing"):
            build.verify_patch_bundle(folder)

    def test_prepared_bundle_accepts_only_additive_windows_fixes(self):
        folder = self.root / 'bundle-history'
        previous = {'files': {'win7/original.diff': '1' * 64}}
        snapshot = folder / 'original.json'
        build.write_json(snapshot, previous)
        digest = build.sha256(snapshot)
        history = folder / 'history' / (digest + '.json')
        history.parent.mkdir()
        shutil.copy2(snapshot, history)
        current = {'files': dict(previous['files'], **{'windows-build/new.patch': '2' * 64})}
        build.verify_additive_build_fixes(folder, digest, current)
        current['files']['win7/original.diff'] = '3' * 64
        with self.assertRaisesRegex(RuntimeError, 'changed or removed'):
            build.verify_additive_build_fixes(folder, digest, current)
        current['files'] = dict(previous['files'], **{'webgl/new.patch': '4' * 64})
        with self.assertRaisesRegex(RuntimeError, 'Only additive Windows'):
            build.verify_additive_build_fixes(folder, digest, current)

    def test_official_patch_restore_preserves_recognized_adaptations(self):
        builder = self.builder()
        official = build.PATCHES_DIR / "cef-official"
        shutil.copytree(official, builder.cef / "patch")
        adapted = build.PATCHES_DIR / "cef-8071/views_widget.patch"
        shutil.copy2(adapted, builder.cef / "patch/patches/views_widget.patch")
        builder.install_cef_official_patches()
        self.assertEqual(build.sha256(adapted), build.sha256(builder.cef / "patch/patches/views_widget.patch"))
        builder.install_cef_rebased_patches()
        for name, info in build.read_json(build.PATCHES_DIR / "cef-8071/manifest.json").items():
            self.assertEqual(build.sha256(builder.cef / "patch/patches" / (name + ".patch")), info["rebased_sha256"])

    @unittest.skipUnless(os.name == "nt", "Windows command shim quoting")
    def test_windows_batch_shim_with_spaces(self):
        path = self.root / "shim with spaces.cmd"
        path.write_text('@echo off\n"' + sys.executable +
                        '" -c "import sys,json; print(json.dumps(sys.argv[1:]))" %*\n', encoding="utf8")
        code, output = self.builder().run([path, "argument with spaces", "--option=value"], capture=True)
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(output), ["argument with spaces", "--option=value"])

    def fake_build(self, builder):
        builder.prepare_build_python = mock.Mock()
        events = []
        builder.prepare_sources = lambda: {"chromium_version": build.CHROMIUM}
        builder.assert_space = lambda *args: None

        def generate(cpu, config):
            # Every previous output should have been cleaned before this build.
            out = builder.src / "out"
            self.assertFalse(any(out.glob("*_GN_*")))
            output = out / f"{config}_GN_{cpu}"
            output.mkdir(parents=True)
            (output / "args.gn").write_text("dummy", encoding="utf8")
            events.append((cpu, config))
            return output, builder.env

        def run(command, **kwargs):
            output = Path(command[command.index("-C") + 1])
            (output / "libcef.dll").write_bytes(b"dummy DLL")
            (output / "libcef.dll.pdb").write_bytes(b"dummy PDB")
            return 0, ""

        def package(cpu, config, output, metadata):
            staging = builder.root / "packages/staging" / f"{cpu}-{config}"
            staging.mkdir(parents=True)
            shutil.copy2(output / "libcef.dll", staging)
            result = build.make_archive(staging, builder.root / "packages" / f"{cpu}-{config}.zip", metadata)
            return staging, result

        builder.generate, builder.run, builder.package = generate, run, package
        return events

    def test_all_three_release_builds_cleanup_and_resume(self):
        builder = self.builder()
        events = self.fake_build(builder)
        builder.build()
        self.assertEqual(events, build.ORDER)
        self.assertEqual(events, [("x64", "Release"), ("x86", "Release"), ("arm64", "Release")])
        self.assertEqual(len(list((self.root / "packages").glob("*.zip"))), 3)
        self.assertFalse(any((builder.src / "out").glob("*_GN_*")))
        events.clear()
        builder.build()
        self.assertEqual(events, [])
        archive = self.root / "packages/x64-Release.zip"
        archive.write_bytes(b"corrupted archive")
        with self.assertRaisesRegex(RuntimeError, "missing or changed"):
            builder.build()

    def test_release_only_plan_migration_preserves_completed_packages(self):
        builder = self.builder()
        events = self.fake_build(builder)
        builder.build()
        events.clear()
        plan_path = builder.state / "build-plan.json"
        legacy = build.read_json(plan_path)
        legacy["order"] = [[cpu, config] for cpu in ("x64", "x86", "arm64")
                           for config in ("Release", "Debug")]
        build.write_json(plan_path, legacy)
        previous = plan_path.read_bytes()
        builder.build()
        self.assertEqual(events, [])
        self.assertEqual(build.read_json(plan_path)["order"], [list(item) for item in build.ORDER])
        history = builder.state / "build-plan-history" / (hashlib.sha256(previous).hexdigest() + ".json")
        self.assertEqual(history.read_bytes(), previous)
        legacy["gn_defines"] += " unexpected_change=true"
        build.write_json(plan_path, legacy)
        with self.assertRaisesRegex(RuntimeError, "Build parameters changed"):
            builder.build()

    def test_package_failure_preserves_output(self):
        builder = self.builder()
        self.fake_build(builder)
        builder.package = mock.Mock(side_effect=RuntimeError("simulated ZIP validation failure"))
        with self.assertRaisesRegex(RuntimeError, "ZIP validation"):
            builder.build()
        self.assertTrue((builder.src / "out/Release_GN_x64/libcef.dll").exists())
        self.assertFalse((builder.state / "complete-x64-Release.json").exists())

    def test_checkout_into_empty_root(self):
        origin = self.root / "origin"
        origin.mkdir()
        subprocess.run(["git", "-C", str(origin), "init", "-q"], check=True)
        (origin / "file.txt").write_text("test", encoding="utf8")
        subprocess.run(["git", "-C", str(origin), "add", "."], check=True)
        subprocess.run(["git", "-C", str(origin), "-c", "user.name=Test", "-c", "user.email=test@example.invalid", "commit", "-qm", "fixture"], check=True)
        revision = subprocess.check_output(["git", "-C", str(origin), "rev-parse", "HEAD"], text=True).strip()
        builder = self.builder()
        destination = self.root / "checkout"
        canonical = "https://example.invalid/chromium.git"
        gitconfig = self.root / "mirror.gitconfig"
        subprocess.run(["git", "config", "--file", str(gitconfig),
                        "url." + str(origin) + ".insteadOf", canonical], check=True)
        builder.env["GIT_CONFIG_GLOBAL"] = str(gitconfig)
        actual = builder.checkout(destination, canonical, revision)
        self.assertEqual(actual, revision)
        self.assertEqual(builder.checkout(destination, canonical, revision), revision)
        self.assertEqual((destination / "file.txt").read_text(), "test")

    def test_cef_checkout_retains_history_and_upgrades_shallow_resume(self):
        origin = self.root / "cef-origin"
        origin.mkdir()
        subprocess.run(["git", "-C", str(origin), "init", "-q"], check=True)
        for index in range(3):
            (origin / "file.txt").write_text(str(index), encoding="utf8")
            subprocess.run(["git", "-C", str(origin), "add", "."], check=True)
            subprocess.run(["git", "-C", str(origin), "-c", "user.name=Test", "-c",
                            "user.email=test@example.invalid", "commit", "-qm", str(index)], check=True)
        revision = subprocess.check_output(["git", "-C", str(origin), "rev-parse", "HEAD"], text=True).strip()
        builder = self.builder()
        for shallow_first in (False, True):
            destination = self.root / ("cef-upgrade" if shallow_first else "cef-full")
            builder.checkout(destination, str(origin), revision, full_history=not shallow_first)
            if shallow_first:
                self.assertEqual(subprocess.check_output(["git", "-C", str(destination), "rev-list", "--count", "HEAD"], text=True).strip(), "1")
                builder.checkout(destination, str(origin), revision, full_history=True)
            self.assertEqual(subprocess.check_output(["git", "-C", str(destination), "rev-list", "--count", "HEAD"], text=True).strip(), "3")
            self.assertEqual(subprocess.check_output(["git", "-C", str(destination), "rev-parse", "origin/master"], text=True).strip(), revision)

    def test_package_assembly_moves_pdb_and_keeps_fallback_runtime(self):
        builder = self.builder()
        output = builder.src / "out/Release_GN_x64"
        output.mkdir(parents=True)
        def pe(path):
            path.parent.mkdir(parents=True, exist_ok=True)
            data = bytearray(128)
            data[:2] = b"MZ"
            struct.pack_into("<I", data, 0x3c, 64)
            data[64:68] = b"PE\0\0"
            struct.pack_into("<H", data, 68, build.MACHINE["x64"])
            path.write_bytes(data)
        pe(output / "libcef.dll")
        for name in ("libcef.lib", "libcef.dll.pdb", "args.gn"):
            (output / name).write_text(name, encoding="utf8")
        for name in ("libEGL.dll", "libGLESv2.dll"):
            pe(output / name)
            pe(output / "swiftshader" / name)
        compiler = builder.root / "runtime26100/x64/d3dcompiler_47.dll"
        pe(compiler)
        build.write_json(builder.state / "runtime-sdk26100.json", {"x64": {"sha256": build.sha256(compiler)}})
        shutil.copy2(build.PATCHES_DIR / "webgl/webgl-fallback.patch", builder.state / "mycef-webgl-fallback.patch")
        def distrib(command, **kwargs):
            staging = Path(command[command.index("--output-dir") + 1])
            subdir = command[command.index("--distrib-subdir") + 1]
            binary = staging / subdir / "Release"
            binary.mkdir(parents=True)
            cmake = staging / subdir / "cmake/cef_variables.cmake"
            cmake.parent.mkdir()
            cmake.write_text("set(CEF_BINARY_FILES libcef.dll)\n", encoding="utf8")
            for name in ("libcef.dll", "libcef.lib"):
                shutil.copy2(output / name, binary)
            symbols = staging / (subdir + "_release_symbols")
            symbols.mkdir()
            shutil.copy2(output / "libcef.dll.pdb", symbols)
            return 0, ""
        builder.run = distrib
        staging, result = builder.package("x64", "Release", output, {"version": build.CHROMIUM})
        self.assertFalse(any(staging.glob("*_symbols")))
        with zipfile.ZipFile(result["path"]) as archive:
            self.assertEqual(archive.read("Release/libcef.dll.pdb"), b"libcef.dll.pdb")
            for name in ("Release/swiftshader/libEGL.dll", "Release/swiftshader/libGLESv2.dll",
                         "Release/d3dcompiler_47.dll", "MYCEF_windows_build_patches/portable-processor-number.patch"):
                self.assertIn(name, archive.namelist())
            variables = archive.read("cmake/cef_variables.cmake").decode("utf8")
            for name in ("libEGL.dll", "libGLESv2.dll", "swiftshader"):
                self.assertIn("    " + name + "\n", variables)
            metadata = json.loads(archive.read("MYCEF_BUILD.json"))
            self.assertEqual(metadata["runtime_cmake_files"], ["libEGL.dll", "libGLESv2.dll", "swiftshader"])


if __name__ == "__main__":
    unittest.main()
