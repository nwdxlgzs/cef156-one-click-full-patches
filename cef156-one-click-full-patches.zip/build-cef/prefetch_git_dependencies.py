#!/usr/bin/env python3
"""Prefetch pinned Git submodules into their actual future checkout paths.

Only gitlinks in the locked Chromium tree may be initialized. No gclient
completion marker is written; the full normal sync must still succeed.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import os
from pathlib import Path
import re
import subprocess
import time

COMMIT = "aa939feff52ea94f0ca07d8029086738c2683685"
SELECTED = ['src/third_party/angle', 'src/third_party/dawn', 'src/third_party/skia',
            'src/third_party/swiftshader', 'src/v8', 'src/third_party/ffmpeg',
            'src/third_party/webrtc', 'src/third_party/icu', 'src/third_party/pdfium']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--pins', default=str(Path(__file__).with_name('dependency-pins.json')))
    parser.add_argument('--jobs', type=int, default=4, choices=range(1, 9))
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if (root / '.mycef-build-root').read_text('utf-8') != 'mycef-156.0.8071.0-v1':
        raise ValueError('Unrecognized dedicated build root')
    pins = json.loads(Path(args.pins).read_text('utf-8'))
    mirror = root / 'mirrors/chromium.git'
    env = {**os.environ, 'GIT_TERMINAL_PROMPT': '0'}
    results = []

    def prefetch(path):
        value = pins[path]
        url, revision = value.rsplit('@', 1)
        if not re.fullmatch('[0-9a-f]{40}', revision):
            raise ValueError('Dependency revision is not a fixed commit')
        relative = path.removeprefix('src/')
        link = subprocess.check_output(['git', '-C', str(mirror), 'ls-tree', COMMIT, '--', relative], env=env).decode().strip()
        if not link.startswith('160000 commit ' + revision + '\t'):
            raise ValueError('Dependency pin does not match Chromium gitlink: ' + path)
        folder = root / 'chromium' / path
        if root not in folder.resolve().parents:
            raise ValueError('Dependency path escaped the build root')
        log_path = root / 'logs' / ('git-prefetch-' + relative.replace('/', '_') + '.log')
        with log_path.open('ab') as log:
            def git(*command, capture=False, check=True):
                result = subprocess.run(['git', '-C', str(folder), *command], env=env,
                    stdout=subprocess.PIPE if capture else log, stderr=log)
                if result.returncode and check:
                    raise RuntimeError('Dependency Git command failed: ' + path + '; log ' + str(log_path))
                return result
            if not (folder / '.git').exists():
                folder.mkdir(exist_ok=True, parents=True)
                if any(folder.iterdir()):
                    raise ValueError('Dependency folder already contains unrelated files: ' + str(folder))
                git('init')
                git('remote', 'add', 'origin', url)
            actual_url = git('config', '--get', 'remote.origin.url', capture=True).stdout.decode().strip()
            if actual_url != url:
                raise ValueError('Unexpected dependency origin: ' + path)
            git('config', 'core.longpaths', 'true')
            git('config', 'core.autocrlf', 'false')
            head = git('rev-parse', '--verify', '--quiet', 'HEAD', capture=True, check=False)
            if head.returncode == 0:
                if head.stdout.decode().strip() != revision:
                    raise ValueError('Existing dependency checkout has a different revision: ' + path)
            else:
                for attempt in range(3):
                    fetched = git('-c', 'http.lowSpeedLimit=1024', '-c', 'http.lowSpeedTime=90',
                                  'fetch', '--depth=1', '--no-tags', 'origin', revision, check=False)
                    if fetched.returncode == 0:
                        break
                    if attempt == 2:
                        raise RuntimeError('Pinned dependency fetch failed: ' + path)
                    time.sleep(3 * (attempt + 1))
                git('checkout', '--detach', 'FETCH_HEAD')
            actual = git('rev-parse', 'HEAD', capture=True).stdout.decode().strip()
            if actual != revision:
                raise ValueError('Dependency checkout verification failed: ' + path)
        print('GIT_DEPENDENCY_VERIFIED ' + path + ' ' + revision, flush=True)
        return {'path': path, 'url': url, 'revision': revision}

    with ThreadPoolExecutor(args.jobs) as pool:
        pending = {pool.submit(prefetch, path): path for path in SELECTED}
        for future in as_completed(pending):
            try:
                results.append(future.result())
            except Exception as error:
                results.append({'path': pending[future], 'error': str(error)})
                print('GIT_DEPENDENCY_ERROR ' + pending[future] + ' ' + str(error), flush=True)
    (root / 'state/git-dependency-prefetch.json').write_text(json.dumps(results, indent=2), 'utf-8')
    if any('error' in result for result in results):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
