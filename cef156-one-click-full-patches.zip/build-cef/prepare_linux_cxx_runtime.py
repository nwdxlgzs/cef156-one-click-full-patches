#!/usr/bin/env python3
"""Fetch complete Debian GCC 10 runtimes using a signed Release/Packages chain."""
import argparse
import datetime as dt
import json
import lzma
from pathlib import Path
import re
import shutil
import subprocess
import urllib.request

from archive_posix import digest_file
from audit_elf import inspect, MACHINES, version_key
from prepare_posix import Preparation, write_json

BASE = 'https://mirrors.huaweicloud.com/debian/'


def fetch(url, path, expected=None):
    if path.is_file() and (expected is None or digest_file(path) == expected):
        return
    temporary = path.with_suffix(path.suffix + '.pending')
    with urllib.request.urlopen(url, timeout=60) as source, temporary.open('wb') as target:
        shutil.copyfileobj(source, target)
    if expected and digest_file(temporary) != expected:
        raise RuntimeError('Debian artifact differs from its signed metadata: ' + url)
    temporary.replace(path)


def prepare(prep):
    directory = prep.root / 'downloads/linux-cxx-runtime'
    directory.mkdir(exist_ok=True)
    release, signature = directory / 'Release', directory / 'Release.gpg'
    for path in (release, signature):
        fetch(BASE + 'dists/bullseye/' + path.name, path)
    subprocess.run(['gpgv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg',
                    str(signature), str(release)], check=True)
    text = release.read_text('utf-8')
    if not re.search(r'^Codename: bullseye$', text, re.M):
        raise RuntimeError('Unexpected signed Debian release')
    sums = text.split('\nSHA256:\n', 1)[1].split('\nSHA512:', 1)[0]
    records = {}
    for cpu, arch, triple in [('x64', 'amd64', 'x86_64-linux-gnu'), ('arm64', 'arm64', 'aarch64-linux-gnu')]:
        relative = 'main/binary-' + arch + '/Packages.xz'
        match = re.search(r'^ ([0-9a-f]{64})\s+(\d+)\s+' + re.escape(relative) + r'$', sums, re.M)
        if not match:
            raise RuntimeError('No authenticated runtime package index: ' + relative)
        index = directory / ('Packages-' + arch + '.xz')
        fetch(BASE + 'dists/bullseye/' + relative, index, match[1])
        if index.stat().st_size != int(match[2]):
            raise RuntimeError('Authenticated package-index length mismatch')
        packages = []
        base_packages = []
        for block in lzma.decompress(index.read_bytes()).decode().split('\n\n'):
            if block.startswith(('Package: libstdc++6\n', 'Package: gcc-10-base\n')):
                item = dict(line.split(': ', 1) for line in block.splitlines()
                            if ': ' in line and not line.startswith(' '))
                (packages if item['Package'] == 'libstdc++6' else base_packages).append(item)
        if len(packages) != 1 or packages[0]['Architecture'] != arch or not packages[0]['Version'].startswith('10.'):
            raise RuntimeError('Unexpected authenticated GCC runtime package')
        package = packages[0]
        archive = directory / Path(package['Filename']).name
        fetch(BASE + package['Filename'], archive, package['SHA256'])
        if archive.stat().st_size != int(package['Size']):
            raise RuntimeError('Runtime package length mismatch')
        extracted = prep.root / 'cache/linux-cxx-runtime' / arch / package['SHA256']
        extracted.mkdir(parents=True, exist_ok=True)
        subprocess.run(['dpkg-deb', '-x', str(archive), str(extracted)], check=True)
        if (len(base_packages) != 1 or base_packages[0]['Version'] != package['Version']
                or base_packages[0]['Architecture'] != arch):
            raise RuntimeError('Runtime copyright package does not match its exact version')
        base_package = base_packages[0]
        base_archive = directory / Path(base_package['Filename']).name
        fetch(BASE + base_package['Filename'], base_archive, base_package['SHA256'])
        if base_archive.stat().st_size != int(base_package['Size']):
            raise RuntimeError('Copyright package length mismatch')
        subprocess.run(['dpkg-deb', '-x', str(base_archive), str(extracted)], check=True)
        library = (extracted / 'usr/lib' / triple / 'libstdc++.so.6').resolve()
        if extracted not in library.parents:
            raise RuntimeError('Runtime library escaped its verified package')
        sections = subprocess.check_output(['readelf', '-SW', str(library)], text=True)
        if not re.search(r'\s\.text\s+PROGBITS', sections):
            raise RuntimeError('Runtime package has no executable implementation')
        elf = inspect(library)
        if (elf['machine'] != MACHINES[cpu] or elf['glibc_other_requirements']
                or version_key(elf['glibc_max_required']) > version_key('2.28')):
            raise RuntimeError('Complete runtime exceeds target compatibility limits')
        copyright = extracted / 'usr/share/doc/libstdc++6/copyright'
        if not copyright.is_file():
            # Debian may use a same-package GCC-base documentation symlink.
            raise RuntimeError('Authenticated runtime package lacks its copyright notice')
        records[cpu] = {'library': str(library), 'library_sha256': digest_file(library),
                        'copyright': str(copyright), 'copyright_sha256': digest_file(copyright),
                        'package': package, 'copyright_package': base_package,
                        'package_archive': str(archive),
                        'packages_index_sha256': match[1], 'release_sha256': digest_file(release),
                        'release_signature_sha256': digest_file(signature), 'elf': elf}
    report = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'targets': records,
              'signed_debian_release_verified': True,
              'scope': 'Complete authenticated runtime binaries, not stripped Chromium linker sysroot stubs. Actual client execution remains separately required.'}
    write_json(prep.root / 'state/linux-cxx-runtime.json', report)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(Preparation(args.root)), indent=2), flush=True)
