#!/usr/bin/env python3
"""Cache real Debian Linux 4.9 kernels for separate full-system validation.

Authenticate the historical Release with Debian's packaged current/removed
archive keys, then check the index and package SHA256 chain. Never install
these kernels on the build host.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import lzma
from pathlib import Path
import re
import subprocess

from prepare_posix import Preparation, write_json

MIRROR = 'https://mirrors.huaweicloud.com/debian-archive/debian/'


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def download(relative, destination, expected=None, size=None):
    if destination.is_file() and (expected is None or digest(destination) == expected):
        if size is None or destination.stat().st_size == size:
            return
    temporary = destination.with_suffix(destination.suffix + '.partial')
    subprocess.run(['curl', '--fail', '--location', '-sS', '--connect-timeout', '10',
                    '--max-time', '1800', '--continue-at', '-', '-o', str(temporary), MIRROR + relative], check=True)
    if expected and digest(temporary) != expected:
        raise RuntimeError('Debian archive SHA256 mismatch: ' + relative)
    if size is not None and temporary.stat().st_size != size:
        raise RuntimeError('Debian archive length mismatch: ' + relative)
    temporary.replace(destination)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    directory = prep.root / 'downloads/linux49'
    directory.mkdir(exist_ok=True)
    release, signature = directory / 'Release', directory / 'Release.gpg'
    download('dists/stretch/Release', release)
    download('dists/stretch/Release.gpg', signature)
    verification = subprocess.run([
        'gpgv', '--keyring', '/usr/share/keyrings/debian-archive-keyring.gpg',
        '--keyring', '/usr/share/keyrings/debian-archive-removed-keys.gpg',
        str(signature), str(release)], check=True, capture_output=True, text=True)
    (directory / 'release-signatures.log').write_text(verification.stderr, encoding='utf-8')
    sha_block = release.read_text().split('SHA256:\n', 1)[1].split('\nSHA512:', 1)[0]
    index = {}
    for line in sha_block.splitlines():
        fields = line.split()
        if len(fields) == 3 and re.fullmatch('[a-f0-9]{64}', fields[0]):
            index[fields[2]] = (fields[0], int(fields[1]))
    packages = []
    for arch in ('amd64', 'arm64'):
        relative = 'main/binary-' + arch + '/Packages.xz'
        expected, size = index[relative]
        path = directory / ('Packages-' + arch + '.xz')
        download('dists/stretch/' + relative, path, expected, size)
        candidates = []
        for block in lzma.decompress(path.read_bytes()).decode().split('\n\n'):
            fields = {}
            for line in block.splitlines():
                if line and not line.startswith(' ') and ': ' in line:
                    name, value = line.split(': ', 1)
                    fields[name] = value
            if re.fullmatch('linux-image-4\\.9\\.0-[0-9]+-' + arch, fields.get('Package', '')):
                candidates.append(fields)
        if not candidates:
            raise RuntimeError('No real Linux 4.9 kernel found for ' + arch)
        selected = max(candidates, key=lambda item: int(re.search('4\\.9\\.0-([0-9]+)', item['Package'])[1]))
        target = directory / Path(selected['Filename']).name
        download(selected['Filename'], target, selected['SHA256'], int(selected['Size']))
        packages.append({'architecture': arch, 'package': selected['Package'], 'version': selected['Version'],
                         'url': MIRROR + selected['Filename'], 'path': str(target), 'sha256': digest(target),
                         'bytes': target.stat().st_size, 'index_sha256': expected})
        print('LINUX49_KERNEL_VERIFIED', arch, selected['Version'], flush=True)
    write_json(prep.root / 'state/linux49-kernel-cache.json', {
        'release_sha256': digest(release), 'signature_verification': verification.stderr,
        'packages': packages, 'kernel_installed_on_build_host': False,
        'scope': 'Verified kernel packages cached for full-system VMs. No old-kernel boot or CEF runtime validation has occurred.',
    })


if __name__ == '__main__':
    main()
