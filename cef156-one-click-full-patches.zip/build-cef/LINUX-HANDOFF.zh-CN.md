# 当前 Linux / macOS goal

更新日期：2026-11-09。Windows 三套 Release SDK 已完成、校验并回收中间目录。Linux 主源码、九个主要依赖及完整真实 gclient sync 已完成（01:50:46 CST）。hooks、POSIX 补丁及 Linux x64 GN 现已实际通过，正在进入快照工具与 Ninja 编译。当前尚无 POSIX SDK 成品。用户要求先推进 Linux，macOS 后续验证仅在 Linux 编译期间进行。顺序仍为 Linux x64 → Linux ARM64 → macOS ARM64 → macOS x64，仅 Release，保留完整符号及旧 glibc / Linux 4.9 验证要求。

当前修复：`gclient runhooks` 解析 DEPS 时会删除已被旧安装器替换 GCS 元数据的工具链目录，因此改为先执行真实 hooks，再复用已校验本地缓存安装 Clang / Rust / sysroots。GN 对官方 Linux Release 默认启用 CFI，而本计划为控制内存已禁 ThinLTO；现明确设置 `is_cfi=false`，保留其他模块和完整符号。快照发现改用 GN 支持的整目标通配和 Ninja 当前 action 命令，避免无效部分通配及非 UTF-8 依赖命令导致入口失败。以下历史准备记录以本段及实际服务状态为准。

最新接续：Linux x64 为同一后台 Ninja / 准备服务持续编译。Linux ARM64 的完整 GN 也已在等待期间通过，尚未开始 ARM64 正式编译。`prepare_remaining_snapshot_plans.py` 在独立后台任务检查其余三个目标的真实快照依赖图，保持正在使用的 Linux x64 计划文件不变。已修正 GN 精确标签无法枚举其他 toolchain 的问题，确保找到真正的 x64 → ARM64 mksnapshot，而非误取目标架构程序。具体状态见 `state/remaining-snapshot-plans-prepared.json` 和日志；有文件不代表快照工具已编译或可跳过 Ninja。

`mycef-macos-release-continuation.service` 已安装、启用并运行，等待 Linux 两套归档和清理后，再按 macOS ARM64 → x64 做配置 / 编译 / SDK / 独立公共客户端 / 全符号 / 压缩校验 / 清理。服务安装器现包含此接续单元；安装服务、完成预检和完成 SDK 是不同证据。Mac 的符号、打包、客户端与归档入口仍要在真实 CEF 成品上实际执行；详情见 `MACOS-NOTES.zh-CN.md`。


四套真实 GN 与快照图已完成预备：Linux x64 / ARM64 各找到两个实际生成工具，macOS ARM64 / x64 各找到一个实际 mksnapshot。回执 `validation/posix-four-gn-and-snapshot-graphs.json`、`validation/remaining-snapshot-plans-prepared.json`；正在编译的 x64 计划内容保持不变。这里只验证了配置、依赖、输入哈希与命令，工具本体与快照仍按正式构建生成、导出和校验，不宣称已经实现跨目标复用。


并行度调整：主机实测 10 路编译只占约 10 个 vCPU、仍有约 24 GiB 可用内存，现默认改为 14 路。已通过 Ninja 的正常中断保留完成对象，并以实际剩余 6,419 项接续当前快照依赖阶段；实际主编译 PID 和参数见 `validation/linux-x64-parallel-resume.json`。源码、依赖没有重新拉取，后续仍根据实际内存 / 磁盘调整。当前阶段计数重置不代表全量重编。四目标 GN / 快照图摘要也已按恢复后的真实计划更新。


Linux 首次正式编译已推进到 27,395 / 27,563 后，cefclient 因 GTK 搜索路径缺失停止。真实 sysroot 的 GTK3/GTK4 头文件都存在；固定 CEF 默认 `cef_use_gtk=!use_sysroot`，导致显式构建 cefclient 时未添加所需 GTK 配置。现 Linux 两架构显式设置 `cef_use_gtk=true`，保留旧 args / GN 回执后在无活动构建的目标目录实际重新生成 GN；x64 已增量恢复，仅剩 193 项，没有重拉源码或清理对象，原失败 cefclient 文件已实际编译通过。新增 `--allow-reconfigure` 仅允许核验没有使用该 out 的 Ninja/编译/链接进程后保存旧配置并重新生成。具体链接 / SDK 验证仍待完成。


最后链接阶段资源调整：实际默认 Ninja link pool 深度为 3，CEF 主库与 GPU 验证程序同时链接时已快速占用大部分 32 GB 物理内存。现四目标明确设置 `concurrent_links=1`，正常中断短暂开始的链接后保留全部编译对象、重新生成 GN 并恢复；不删对象、不降符号、不裁模块。后续每套只允许一个大链接，编译并行仍为 14 路。


01:00 左右复查：仍是同一 gclient PID 150406 / 准备服务 PID 149721，多个真实 Git 临时 pack 与 GCS 临时下载持续增长，尚无终止错误；磁盘约 220 GiB 可用。GCS 下载文件会预分配全长，不能凭其长度或 stall 警告宣称完成 / 死锁。独立预检发现 CIPD shell 原先只把镜像地址用于 selfupdate，Go 客户端普通 ensure 不读取该环境变量；已补上仅此构建目录的 ensure / resolve 显式路由，并实际经 loopback 镜像安装、运行固定 GN 2574。当前 gclient 不需重启，后续执行 CIPD 时会读修正后的 wrapper。

macOS 新增真实 CLT SDK 元数据入口及条件化源码补丁，已通过固定源码应用检查和 GN 语法 / 格式检查；完整 GN / CEF 仍待执行。初始同步期间原工具链安装目录已不在原路径，hooks 前会通过真实原安装器复用 Clang / Rust 缓存，不能信任旧预取回执。详情与未完成项见 `MACOS-NOTES.zh-CN.md`。

01:03 后固定 Clang 已由实际 GCS 同步重新安装，原 SHA256 匹配。macOS 四套原菜单的生成代码已完成两 CPU / 两种内存管理共 16 份真正 Mach-O 对象编译，并用隔离提取的实际 CEF GN 模板生成 Ninja / 编译八份菜单和 owner 对象；原 plist 自动加载键的过滤逐字段通过。菜单 / SDK 新补丁的完整 CEF GN、链接和 macOS 目标 UI 运行仍待后续，不能把这些预检当作 macOS SDK 完成。

01:21 后用户要求集中推进 Linux、停止让 macOS 预研分散注意力。当前 Linux 服务仍持续同步，没有因预研暂停。新增 `prefetch_linux_cipd.py` 经原始固定 gclient_eval 读取同一 DEPS / .gclient，仅并行预热共享镜像缓存，不写工作树或同步完成标记；`mycef-linux-cipd-prefetch.service` 已实际运行，日志 `logs/linux-cipd-prefetch.log`，GN / Python / Ninja / gperf / TypeScript 等真实包已下载校验。主 gclient 自己仍负责安装与最终身份验证；下载中的有效 Git pack 与 GCS 文件继续保留。后续优先处理 hooks / Linux GN / Ninja 的真实错误，macOS 后续验证留待 Linux 编译占用 CPU 后。

## 服务器与空间

- 服务器 `81.68.82.48`，账户 `ubuntu`，已配置 SSH 密钥。登录凭据不写入构建包。
- 16 vCPU、32 GB 标称内存，Ubuntu 24.04.5 x64 / UEFI，当前内核 6.8.0-139。
- 根分区约 295 GiB；工作根目录 `/home/ubuntu/cef156`，工具包 `/opt/mycef/build-cef`。
- 2 GiB 原有 swap 加 30 GiB `/swap-mycef`，合计 32 GiB。swap 不是待回收的构建中间文件。
- 目标按顺序独立构建。归档逐文件校验、完整符号、独立客户端、适用运行验证及快照工具导出完成后才清理对应 out / SDK 暂存目录。

## 已完成的准备

- 基础构建包、Xvfb、QEMU 系统 / 用户态模拟器等已安装。Chromium 固定提交的官方 `install-build-deps.py` 已验证真实 Git blob 后成功运行（`--no-prompt --no-arm --no-chromeos-fonts`），systemd journal 确认成功退出；回执 `validation/chromium-build-deps.json`。ARM64 目标仍用受控 sysroot，未引入宿主 GCC 交叉工具链。
- Chromium 固定 tag 的真实 commit / tree 元数据已取得。源码归档已完整下载，官方 MD5 `8cfe678a480b592dc24d53e0b5d53518` 通过，回执 `validation/source-archive-verified.json`。后台正在按真实 Git blob 匹配导入并补全遗漏的测试等文件；分片是续传缓存，不替代 Git 完整性审计。
- CEF 固定提交及完整 3,634 个祖先提交已取得。GitHub 在此主机不稳定，CEF 通过 Bitbucket 仓库取得同一 Git 对象，固定提交未改变。
- 九个主要依赖已取得固定 commit / tree。`seed_posix_dependencies.py` 正在复用同一份官方源码归档，在一次解压扫描中导入它们的匹配 blob，再补全缺失对象，减少重复大下载；成功以实际对象审计和 fsck 为准。
- Linux CIPD 客户端通过官方 SHA256 校验，原始 CPython 3.11.8 由 Flutter 国内镜像装好。外层 depot_tools 引导已实际成功，回执为 `state/depot-bootstrap.json`；Chromium 固定的 nested depot_tools 引导仍待依赖工作树到位。原始客户端保留包身份校验。所有网络设置限于此构建根目录，不修改整机 DNS / hosts，不装 Clash。
- 干净 8071 的 CEF 117 补丁已用官方 patcher 严格通过，8 个独立 POSIX 适配及 4 个附加补丁已整理。`posix-patches/` 与 `validation/posix-source-patch-audit.json` 记录具体范围。没有把 Win7 补丁套到 Linux/macOS。
- 实际 Ubuntu 上当前 27 项准备工具测试通过，覆盖中断检出的原文件备份 / 类型冲突拒绝、Git 对象导入 / 恢复、HTTP / CIPD / wheel 续传、ELF 解析、Apple XAR 完整性及真正 zstd/tar 的执行权限 / framework 符号链接 / 全文件哈希回读 / 完成后恢复 / 内容变化拒绝；回执 `validation/posix-helper-validation-current.json`。Ubuntu 自带 Git 2.43 对缺失 promisor blob 的直接查询会中止；审计改为只枚举本地对象，实际验证不发起隐式下载。ELF 工具实际读取 `/bin/true` 得到 GLIBC 2.34，可识别宿主新 glibc，正式成品尚待审计。
- `posix-targets.json` 固定四个目标的 GN 计划、顺序及快照身份字段。快照工具实际生成、导出和合法预构建依赖接入仍待 GN / 工具链就绪，不能把规划当成已可复用的缓存。
- `snapshot_tools.py` 已实现真实 GN 图中的快照 action / 工具发现，以及配置、工具链 / sysroot / SDK 溯源、输入 / 生成命令和产物逐文件校验导出。脚本已语法检查，尚未在实际生成的 GN 图上执行。不会回填时间戳或宣称能绕过 Ninja；合法预构建依赖接入仍待完成。
- `configure_posix.py` 已用实际固定 CEF 的 Python 参数策略检查四个目标，Release、完整符号、媒体开关和 Linux sysroot 均保留，外部 `GN_DEFINES` 不会把本次配置变成 Debug / component，也不篡改 Python 宿主平台。回执 `validation/posix-gn-policy-preflight.json`；真正 `gn gen` 仍待源码 / hooks 到位。

## 同时进行的后续平台 / 兼容性预备

- 官方 Clang `llvmorg-24-init-7747-g62397f8b-29` 已于 2026-11-08 23:28（北京时间）完成下载、官方 MD5 验证和实际安装；归档 SHA256 为 `8039b5c9e7375df3a8082761cd1220223f90344b81d829c949f69224350d9d47`。`prefetch_clang.py` 调用真实 Git 内容匹配的原始 `tools/clang/scripts/update.py` 从已验证缓存安装。已实际执行 `clang --version`，主工作树的 `third_party/llvm-build/Release+Asserts` 提供 Clang 24。日志 `logs/clang-prefetch.log`，成功回执 `state/clang-prefetched.json`，副本 `validation/clang-prefetched.json`。没有开始 macOS 正式编译。
- 已从 Apple 公开软件更新目录取得 Xcode CLT 27.2 的 SDK-only 包，下载大小 71,479,724 字节，完整 SHA256 `1eb5196e069ad6e0abde1d750d967b7ea58f5b97f179dbf07aee2d00ca6c813e`。`apple_sdk_package.py` 验证目录 Digest 对应的 **压缩 XAR TOC**、TOC 内存储摘要和三个成员的摘要；目录 Digest 不是整个 pkg 文件的 SHA1。三个包含损坏检测的测试在本机 / Ubuntu 均通过。
- SDK 包已解压到 `cache/apple-research/extracted-sdk/Library/Developer/CommandLineTools/SDKs/MacOSX27.2.sdk`，体积约 1 GiB；临时 cpio 已删除，pkg 留存。真实 SDK 为 27.2 / build 26B118，声明 macosx 支持 x86_64 / ARM64，最低可设部署版本 12.0；这不代表 CEF 目标最低版本已经降低。固定 Chromium 默认 SDK 则为 27.0 / 26A425（universal 路线为 26.5 / 25F70），正式 GN 适配必须记录真实 SDK，不能伪造匹配版本。
- CLT 26.6 的 SDK 包为 61,622,368 字节，SHA256 `debe353b27a13cd678b26ab216a040acf07b62c0639d8ac522df4ca07d121eb2`。`extract_apple_sdk.py` 已验证原 XAR 并实际解出 **SDK 26.5 / build 25F70**，与固定 Chromium 的 universal SDK 版本和 build 完全匹配，原始文件没有改写。路径 `cache/apple-research/extracted-sdk-universal/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk`，两种 CPU 的六项编译 / 链接和两项 dSYM / UUID / DWARF 检查均通过，回执 `validation/apple-sdk-extracted-universal.json`、`validation/mac-cross-compiler-universal-smoke.json`。正式 GN 的 SDK / CLT 元数据接入仍待完成。旧下载日志里曾把目录 Digest 当完整包 SHA1 的失败已纠正。
- 旧 glibc 环境已完成：`validation/oldlinux/buster-x64` 的 Debian buster 用户态可实际 chroot 执行，glibc 2.28-10+deb10u1、GTK 3.24.5、NSS 3.42.1、Mesa 18.3.6、Xvfb 1.20.4 均已装好。使用华为 Debian archive 镜像，日志 `logs/oldlinux-buster-x64.log`，回执 `state/oldlinux-buster-x64.json`。此环境不是 UOS 教育版实机，也不能证明 Linux 4.9 内核兼容。
- `prefetch_49_kernels.py` / `mycef-linux49-kernels` 已从 Debian 已签名的 stretch Release → Packages.xz → deb SHA256 链取得 x64 / ARM64 的真实 Linux 4.9.228-1 内核，仅存入 `downloads/linux49`，不安装到编译宿主，回执 `state/linux49-kernel-cache.json`。使用 Debian 当前及 removed archive keyring 共同验证了全部历史签名；CEF 在其中运行仍待进行。
- `linux49_vm.py` 已实际启动两种架构的完整 QEMU Linux 4.9.228 VM（不是用户态模拟或新内核容器），x64 从只读 9p 用户态中执行 glibc 2.28 工具成功；ARM64 原生指令的 VM 也成功完成 Debian buster 第二阶段安装并执行 glibc 2.28。三份通过记录在 `validation/linux49-vm-*-boot.json`，CEF 自身仍未运行。宿主无 `/dev/kvm`，使用 TCG。ARM64 完成后的稀疏根镜像在 `cache/oldlinux/buster-arm64.img`，启动输入和日志已保留；重复的 foreign 解包目录约 252 MB 已在镜像实际启动验证后回收。
- `linux49_runtime_vm.py` 已实际在两种 Linux 4.9 / glibc 2.28 VM 中运行当前 Python 3.7 探针入口，并以普通用户启动 Xvfb，两个工具环境预检均通过。回执 `validation/linux49-{amd64,arm64}-tools-preflight.json`。提供 `--sdk` 和 `--media` 时会只读共享真实 SDK，执行默认沙箱、禁 GPU 沙箱、关闭沙箱三种 CEF 运行测试并将报告绑定 libcef SHA256 / CPU / 实际内核 / 实际 glibc；该 CEF 分支尚待产物。此入口以 root 运行以访问专用旧用户态和 ARM64 镜像，CEF 进程在 guest 内仍由 nobody 运行；勿同时启动两个使用同一 ARM64 原始根镜像的 VM。
- 两个受控 sysroot 的原始 SHA256 已通过，`linux-sysroots-lock.json` 对应固定源码中的真实 JSON Git blob；回执 `validation/linux-sysroots.json`。已使用原上游 canonical URL stamp 实际安装，后续安装器复查后可复用。这个缓存完成不等于最终 SDK 的 glibc 最低版本已证明。
- 两种 sysroot 现已实际安装在原始预期目录。主树尚未检出时，安装器从已验证 Git blob 读取原始 manifest 后核对锁定 SHA256；不制造源码文件。`linux_client_toolchain.py` 为 x64 / ARM64 实际生成 CMake 工具链、编译并链接 C++20 / GTK 探针，两种 ELF 的 glibc 需求分别为 2.2.5 / 2.17，且已在对应 Linux 4.9 / glibc 2.28 完整 VM 中以普通用户实际执行成功。回执 `validation/client-toolchain-linux-{x64,arm64}.json` 与更新后的 `validation/linux49-{amd64,arm64}-tools-preflight.json`。这是工具链小程序，不是 CEF 产物的 glibc 结果。
- macOS 基础预检已实际通过：ARM64 / x86_64 各完成 C / CoreFoundation、Objective-C++ / Cocoa 和 C++20 / SDK libc++ 编译、链接，六个真实 Mach-O 可执行文件的 CPU 均匹配。新增 `probe_macos_compiler.py --with-debug-tools` 为两架构实际生成完整小程序 DWARF / dSYM，使用上游要求的 dsymutil 参数，UUID 匹配、DWARF verify 和 llvm-otool 读取依赖均通过。回执 `state/mac-cross-compiler-smoke.json` 已同步至 `validation/`。不代表 Chromium 自带 libc++、完整 CEF / 大体积符号、资源、Helper、签名或 macOS 实机运行已经验证，也不生成 `mac-sdk-prepared.json`。
- depot_tools 引导曾因大 lxml wheel 超时失败，真实原始 wheel 已改为保留前缀续传，并保留官方索引 SHA256 校验；不改用内容不同的 PyPI 包。`UV_HTTP_TIMEOUT=1200` 给 loopback 下载等待留量，镜像端口固定为现有端口以便重启后缓存 URL 继续有效。10 项镜像 / 续传测试在 Windows 与 Ubuntu 均通过，外层引导已成功。
- Google Clang 默认下载域名在此服务器超时，改用同一官方 bucket 的 `https://storage.googleapis.com/chromium-browser-clang` 路径入口，TLS 校验仍保留。下载对象版本未改变。该入口已加入构建进程的 `CDS_CLANG_BUCKET_OVERRIDE`；不改整机网络。源码归档仍需等待完整下载，不能开始正式 GN / Ninja。

## 正在运行 / 后续继续

服务状态以 `systemctl show` 与实际日志为准，不因已有状态文件就重启相同下载。

- `mycef-source-archive.service`：源码归档下载；日志 `logs/source-archive.log`。已保留有效前缀后切为 24 路，当前进程参数已实际核对。失败可按间隔恢复；单片响应范围和最终对象 MD5 校验仍保留。
- `mycef-posix-bootstrap.service`：官方 Python / depot_tools 引导；日志 `logs/depot-bootstrap.log`。
- `mycef-cipd-mirror.service`：仅 loopback 的包元数据服务，真实包 ZIP 来自国内 HTTPS 镜像；就绪信息 `state/cipd-mirror.json`，日志 `logs/cipd-mirror.log`。
- `mycef-posix-preparation.service`：当前带 `--through-linux-x64-build`，等待真实归档后继续主源码及依赖对象导入、补全、实际 gclient sync、nested depot_tools / hooks、POSIX 补丁 / CEF 版本生成、Linux x64 GN、快照预编译、正式编译、Release SDK 暂存和独立客户端 / 宿主运行验证；随后停在 Linux 4.9 / glibc 2.28 运行和最终归档关口。日志 `logs/posix-preparation.log`，状态 `state/posix-preparation-status.json`。任何阶段失败均保留现场，不会把源同步或编译完成写成完整 SDK 完成。
- `mycef-linux-release-continuation.service` 已安装、加入开机链接并实际运行。`linux_release_runner.py` 等待当前 x64 服务自然结束和独立客户端记录，不重启下载；随后执行 x64 的 Linux 4.9 / glibc 2.28 运行 → 最终归档逐文件回读 → 清理 → ARM64 配置 / 编译 / SDK → 独立 CMake 客户端交叉编译 → ARM64 旧系统 VM 实际运行 → 归档 / 清理。任何失败保留当前现场并停止推进。还没有真实 SDK，因此这些 CEF 收尾步骤尚未完整执行；两套 Linux 后仍需完成 macOS GN / Framework 适配。
- 固定 nested depot_tools 已提前检出为 `910f543...`，原始 CIPD ensure 全部完成，回执 `validation/nested-depot-bootstrap.json`；不是提前标记 hooks 完成。主仓库指定对象区间预取和小批次补全已完成，原主审计又复查全部 blob 并执行 fsck。为结束重复网络工作而切换时，原进程已进入首次检出，留下部分未登记文件；恢复器逐个匹配 200,824 个现有文件，将一个中断写入的空文件保存到独立缓存，然后从原始 Git 索引恢复，不影响 gitlink 依赖和忽略目录。实际记录 `validation/source-initial-checkout-recovery.json`。相关两项真实 Git 测试在 Windows / Ubuntu 通过。
- `mycef-posix-tools.service` 和 `mycef-dependency-metadata.service` 已完成其仓库元数据阶段；重用已验证的固定对象。
- 原 `mycef-posix-source.service` 的元数据阶段已经结束；旧的下载子进程为切换续传下载器而结束，该主进程因此未完成工作树阶段。源码归档完成后，使用当前脚本继续，保留已经取得的 commit / tree。

上述镜像、归档、引导和后续准备的固定 systemd 单元、drop-in 和开机链接已写入 `/etc/systemd/system`。drop-in 同时覆盖现存 transient fragment，已用实际 `ExecStart` / `Restart` 检查确认，避免仅写 `/etc` 主文件却仍沿用旧参数。镜像保留当前 loopback 端口。未执行服务器重启来测试。预先完成的工具仓库和依赖元数据记录必须保留。

接续顺序：保留已完成 sync / hooks / prepared-posix 检查点 → Linux x64 快照工具及正式编译 → 打包和旧系统运行 → 归档校验与回收 → Linux ARM64。不能在已打补丁的工作树上重新 sync 或 reset。

分阶段入口现还包括 `prepare_posix_hooks.py`、`configure_posix.py`、`compile_posix.py`、`package_linux.py`、`runtime_probe_posix.py` 和 `archive_posix.py`。`compile_posix.py` 要求四项真实 WebGL GTest 全部执行并通过。`package_linux.py` 调用官方 standard make_distrib，要求 Release 完整 DWARF、资源 / 头文件 / ANGLE 和 ELF 审计；尚未执行真实 SDK 打包。运行探针已兼容旧环境的 Python 3.7，并支持明确传入独立编译的 cefsimple、记录其 SHA256；已在 buster x64 chroot 中实际导入并执行命令行入口，CEF 本身仍未运行。真正 GN / 编译及完整 SDK 打包流水线尚未跑通，不宣称 Linux/macOS 一键构建已完成。`archive_posix.py` 的真实压缩 / 回读测试已通过，会保留 POSIX 权限和 framework 符号链接；后续产物使用 `.tar.zst`，总脚本补丁包仍为要求的 `.zip`。SDK、完整符号、ELF/Mach-O、独立客户端、适用运行验证、快照导出及归档校验未齐之前，不清理本架构构建输出，也不开始下一架构。

## 时间预算与兼容范围

新增收尾入口：`validate_linux_clients.py` 默认用固定 Clang / target sysroot 编译沙箱 ON/OFF 的 cefsimple / cefclient；x64 执行宿主三模式运行，`--cross-compile --target linux-arm64` 只生成真实 ARM64 客户端构建记录，目标运行留给 `linux49_runtime_vm.py --clients-receipt`。VM 探针校验独立客户端 SHA256 / SDK 开发文件 / 引擎身份，再执行默认 / 禁 GPU / 无沙箱三种模式；成功后才写独立客户端的完整验证记录。`finalize_linux.py` 要求这些真实报告、独立开发源码清单、完整 DWARF、ELF 需求、Linux 4.9 / glibc 2.28 三模式 CEF 报告及快照文件全部匹配后，才生成 `.tar.zst` 并逐文件回读，`--cleanup` 随后回收本目标 out / SDK 暂存 / 大型客户端构建目录。独立客户端小型二进制单独留存。入口已语法 / CLI 检查，工具链探针已实际编译和运行；真实 CEF SDK 收尾仍待编译完成。

`audit_posix_features.py` 已接在真实 CEF 链接后，核对生成的 PDF / 打印 / 扩展 / FFmpeg / OpenH264 / Widevine 头文件和实际 args 身份。Linux SDK 会包含 `MYCEF_FEATURES.json`；这是生成配置审计，不把编译标志当端到端功能验证。尚无真实 GN 产物时不写通过记录。

源码下载器现保持原 16 MiB 分片身份与前缀回执，但将每次 HTTP 范围请求限制为 1 MiB，减轻长响应断流；四项续传 / 错误范围 / 前缀哈希 / 多请求合片测试在 Windows 和 Ubuntu 均通过。当前一次性辅助下载分片已交由官方完整 MD5 和真实 Git blob 审计最终判断，不绕过整包校验。

`prepare_macos_aux.py` 已实际执行并可重跑：`mac-aux-lock.json` 与 `toolchain-provenance/llvm-aux` 保存 LLVM 官方签名 Release / index / 公钥和包版本 / SHA256；验证签名链后，仅提取 Linux dsymutil / llvm-otool / llvm-dwarfdump 辅助工具，包不注册为系统 LLVM、不替换主 Clang。辅助工具 wrapper 在 `cache/mac-aux/bin`，回执 `validation/mac-aux-tools-verified.json`。使用 Ubuntu 镜像安装其宿主依赖 libz3-4 / libpfm4。原版本 `clang-mac-runtime-library` 980,916 字节已按锁定 MD5 / SHA256 校验，并由真实 Git 匹配的原始 update.py 安装到固定 Clang 的 Darwin 子目录；主编译器 SHA256 保持不变。工具和运行库接入真实 macOS GN 仍待完成，不通过关闭 dSYM 跳过符号需求。

源码归档实际导入主仓库 272,739 个匹配 blob；其余对象已按真正 Git blob ID 全部补齐，不制造占位文件。完整 471,804 个 blob、fsck 和固定提交实际检出记录在 `validation/source-objects-complete.json` 与 `validation/chromium-checkout.json`。归档中两个与 Git 不同的文件最终也使用原始 Git 内容。九个主要依赖全部完成对象审计 / fsck / 固定提交检出，回执 `validation/dependency-objects-complete.json` 无错误。真正 `gclient sync` 正在继续处理其余仓库 / CIPD / GCS 项；GN 或 CEF 编译尚未完成。

`prefetch_rust.py` 已从原始 Git DEPS 读取固定 Rust 包的 SHA256 / 长度，完成 276,524,576 字节归档校验，并调用真实 Git 匹配的原始 `update_rust.py` 安装。已实际执行 rustc 1.100.0-nightly（提交 1edd55dcf...，LLVM 24），回执 `validation/rust-prefetched.json`。同步器可能另行管理 first-class GCS 记录；此预取不伪造其状态，不代表完整 Chromium Rust 编译已通过。

`prefetch_macos_inputs.py` 已按原始 DEPS 固定的 CIPD 身份安装 Linux MIG 和 ANGLE Metal shader 资源，并使用 SDK 26.5 / 25F70 实际生成 user / server 桩代码，编译成两种架构各两个真实 Mach-O 对象；回执 `validation/mac-cross-inputs-prefetched.json`、`validation/mac-mig-compiler-smoke.json`。此处仅准备实际需要的跨平台输入，未宣称完成全部 macOS 依赖 / GN / CEF。

本机普通用户实测 `unshare --user --map-root-user /bin/true` 因 uid_map 权限被拒绝，AppArmor 的 `apparmor_restrict_unprivileged_userns=1`。运行验证现为同一 SDK 的 `chrome-sandbox` 安装独立 root:root / 4755 副本，再通过固定源码支持的 `CHROME_DEVEL_SANDBOX` 使用；不修改宿主 AppArmor / sysctl。旧 VM 同样在 guest 内安装 helper。探针检查 helper 身份 / 权限并继续验证 renderer 的 Seccomp / NoNewPrivs。真实 CEF 沙箱运行仍待 SDK。`LINUX-SDK.zh-CN.md` 会随 Linux SDK 打包，说明客户端编译及 helper 安装。

工具链和平台适配就绪后：Linux x64 4–8 小时，Linux ARM64 6–12 小时，macOS ARM64 5–10 小时，macOS x64 4–8 小时。下载和平台适配另计，首次整体先留 3–5 天；macOS 首次交叉构建可能更久。这是工程预算，尚非本主机实测编译时间。

glibc 2.28 是指定 UOS 环境需要覆盖的基线，继续尽量降低实际成品需求。旧 sysroot / glibc 审计、真正 Linux 4.9 内核测试、CPU 架构与 GPU 驱动测试互相不能替代。macOS SDK / Clang 工具、资源 / Framework / Helper 打包及两种 CPU 的运行仍需逐步验证；Linux 宿主能生成 GN 配置不等于完整 macOS SDK 已完成。

2026-11-09 04:42（北京时间）Linux x64 全部编译对象已生成，主库链接在读取部分压缩 DWARF 段时失败，报 `Unknown frame descriptor`；不是 OOM。抽查 ELF 压缩段由 Python zlib 解压和固定 LLD 的小范围链接均通过，因此保留全部对象，继续调查完整链接条件。单独的完整串行链接复现在 `logs/link-compression-serial.log`，不能将该试验当作正式 SDK 完成记录。

`linux_link_swap.py` 在低内存 Linux 宿主构建前，按需独占创建 `/swap-mycef-link` 的 32 GiB 临时 swap；不修改 fstab，不替换原有 swap。正式 Ninja 成功后仅在无链接器且内存足够时回收。链接失败时保留，以便继续构建；确认链接进程退出后可运行 `python3 /opt/mycef/build-cef/linux_link_swap.py --root /home/ubuntu/cef156 --stage release` 安全回收。每次实际操作记录在 `state/temporary-link-swap.json`。

完整单线程诊断因持续换页而中止，未声称成功或复现失败。追加 `linux-link-dwarf-without-index.patch`，在 Linux 非 split-DWARF 配置中取消可选的链接期 GDB 加速索引，保留全部 DWARF 及原编译参数，避免因此重编对象。实际 GN、编译命令一致性与 Ninja dry-run 记录在 `state/linux-without-gdb-index.json`；最终链接结果以正式构建日志为准。

随后预检发现全局链接参数也会进入 Rust 的编译命令；未启动那一轮编译。追加 `linux-cef-only-debug-index.patch` 恢复全局链接参数，仅给 `libcef.so` 添加末尾的 `--no-gdb-index`。实际 GN 生成及代表性 CEF 编译命令一致性检查通过，Ninja 仅剩 57 项（38 项资源依赖的增量编译，无 Rust 重编）；正式 Linux 构建与 Linux/macOS 接续服务已经恢复。

05:11 的完整串行链接避开了压缩输入解压错误，随后明确报 `R_X86_64_32 out of range`，偏移超过 4 GiB。仅压缩对象不能解决 DWARF32 偏移限制，不能继续将其作为可交付配置。追加 `linux-full-dwarf64-serial-link.patch`，为 Linux 非 split-DWARF 的 Clang / Rust 完整符号统一使用 64 位 DWARF 偏移（仍为 DWARF v4），恢复包装对象压缩，主库限定串行链接并不生成 GDB 加速索引。固定 Clang 的 x64 / ARM64 两个真实压缩 ELF 编译 / 链接 / DWARF64 读取检查，以及固定 Rust 的真实 DWARF64 对象与 64 位调试重定位检查均通过。正式服务已恢复，这次符号格式变化会合法触发相关对象重编，不再声称之前全部对象能原样复用。

2026-11-09 08:11（北京时间）Linux x64 已完整归档并清理，Linux ARM64 正式流程已接续。x64 归档为 `packages/cef_binary_156.0.8071.0_linux_x64_release.tar.zst`，4,546,522,175 字节，SHA256 `dfd5dbf32cb141dec03e1fa4cb8bf73cd506d17c70db47a536bd663d5d9b460c`。最高实际 GLIBC_2.25；SDK 独立 CMake 沙箱 ON/OFF 两套样例、宿主三模式和真正 Linux 4.9 / glibc 2.28 VM 三模式全部通过，归档每个文件回读通过。`state/sdk-linux-x64-verified.json` 和 `state/sdk-linux-x64-cleanup.json` 为正式凭据。所有 x64 out / 暂存 SDK / 大型客户端构建目录已删除，避免从头重跑 x64；已导出的快照工具、归档、回执和 `cache/validated-clients/linux-x64` 保留。

SDK 附带完整 Debian GCC 10 libstdc++6 运行库及版权通知，经 Release 签名 / Packages SHA256 / deb SHA256 验证；不得部署 Chromium sysroot 中被移除 .text 的链接用副本。`prepare_linux_cxx_runtime.py` 可恢复两种架构的完整输入。旧内核缺少 NoNewPrivs procfs 字段，报告保留 -1 并通过 seccomp / UID / capabilities / PID namespace 等实际观测验证，详见报告范围。各服务状态、ARM64 编译进度和后续 macOS 阶段仍须按实际进程核实。
