#!/usr/bin/env python3
"""Archive the real macOS SDK after symbols and independent SDK client checks.

Linux can validate compilation/linking, Mach-O and DWARF, but cannot establish
macOS runtime or Apple distribution-signing success. Preserve those boundaries
in both the SDK and its archive receipt. Reclaim outputs only after readback.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil

from archive_posix import create_archive, digest_file
from audit_macho import audit, match_dsym, inspect, RUNTIME_TYPES
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json
from validate_macos_clients import development_inputs

FRAMEWORK = 'Chromium Embedded Framework'


def read(path):
    return json.loads(Path(path).read_text('utf-8'))


def cleanup(prep, target, receipt):
    archive = Path(receipt['archive']).resolve()
    if (prep.root / 'packages' not in archive.parents
            or digest_file(archive) != receipt['archive_sha256']):
        raise RuntimeError('Retain outputs: the verified macOS archive changed')
    compiled = read(prep.root / 'state' / ('compiled-' + target + '.json'))
    prepared = read(prep.root / 'state' / ('sdk-' + target + '-prepared.json'))
    output = Path(compiled['output'])
    staging = Path(prepared['staging'])
    clients = prep.root / 'cache/independent-clients' / target
    if (output.is_symlink() or output.resolve().parent != prep.src / 'out'
            or staging.is_symlink() or staging.resolve() != prep.root / 'packages/staging' / target
            or clients.is_symlink()):
        raise RuntimeError('macOS cleanup boundary check failed')
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            name = (process / 'comm').read_text().strip()
            if name not in ('ninja', 'siso', 'clang', 'clang++', 'ld64.lld', 'ld.lld', 'rustc', 'dsymutil'):
                continue
            cwd = (process / 'cwd').resolve()
            command = (process / 'cmdline').read_bytes().decode(errors='replace')
            if cwd == output or output in cwd.parents or str(output) in command:
                raise RuntimeError('A live build still uses this macOS output')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    for image in (output / (FRAMEWORK + '.framework') / FRAMEWORK,
                  Path(prepared['sdk']) / 'Release' / (FRAMEWORK + '.framework') / FRAMEWORK):
        if image.exists() and digest_file(image) != receipt['sdk_engine_sha256']:
            raise RuntimeError('Engine changed after final macOS SDK verification')
    removed = []
    for path in (output, staging, clients):
        if path.exists():
            shutil.rmtree(path)
            removed.append(str(path))
    write_json(prep.root / 'state' / ('sdk-' + target + '-cleanup.json'), {
        'target': target, 'archive_sha256': receipt['archive_sha256'], 'removed': removed,
        'available_bytes': shutil.disk_usage(prep.root).free,
        'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat()})


def finalize(root, target, reclaim=False):
    prep = Preparation(root)
    verified_path = prep.root / 'state' / ('sdk-' + target + '-verified.json')
    if verified_path.exists():
        prior = read(verified_path)
        if (prior.get('passed') is not True or prior['target'] != target
                or digest_file(Path(prior['archive'])) != prior['archive_sha256']):
            raise RuntimeError('Existing macOS archive/receipt changed')
        if reclaim:
            cleanup(prep, target, prior)
        return prior
    compiled_path = prep.root / 'state' / ('compiled-' + target + '.json')
    prepared_path = prep.root / 'state' / ('sdk-' + target + '-prepared.json')
    symbols_path = prep.root / 'state' / ('symbols-' + target + '.json')
    clients_path = prep.root / 'state' / ('clients-' + target + '-built.json')
    compiled, prepared, symbols, clients = map(read, (compiled_path, prepared_path, symbols_path, clients_path))
    if (compiled['chromium_revision'] != CHROMIUM_REV or compiled['cef_revision'] != CEF_REV
            or prepared['compiled_receipt_sha256'] != digest_file(compiled_path)
            or prepared['symbols_receipt_sha256'] != digest_file(symbols_path)
            or clients['prepared_receipt_sha256'] != digest_file(prepared_path)):
        raise RuntimeError('macOS SDK compile/symbol/client provenance differs')
    sdk = Path(prepared['sdk']).resolve()
    if prep.root / 'packages/staging' not in sdk.parents:
        raise RuntimeError('SDK escaped the package staging directory')
    engine = sdk / 'Release' / (FRAMEWORK + '.framework') / FRAMEWORK
    engine_hash = digest_file(engine)
    if (engine_hash != prepared['sdk_engine_sha256'] or engine_hash != compiled['cef_binary_sha256']
            or engine_hash != clients['sdk_engine_sha256']):
        raise RuntimeError('The packaged macOS engine differs from the linked/public-client bytes')
    if (not clients.get('compilation_linking_passed')
            or {c['sandbox'] for c in clients['clients']} != {'ON', 'OFF'}
            or clients['sdk_development_inputs'] != development_inputs(sdk)):
        raise RuntimeError('Public SDK sandbox ON/OFF client builds are incomplete or changed')
    cpu = target.removeprefix('mac-')
    report = audit(sdk, cpu)
    if not report['passed'] or not symbols.get('passed'):
        raise RuntimeError('Final macOS SDK Mach-O or symbol validation failed')
    needed = {(f['cpu_type'], f['uuid']) for f in report['files'] if f['file_type'] in RUNTIME_TYPES}
    verified = set()
    for item in symbols['images']:
        binary, bundle, dwarf = Path(item['binary']), Path(item['bundle']), Path(item['dwarf'])
        if (sdk not in binary.resolve().parents or sdk not in bundle.resolve().parents
                or sdk not in dwarf.resolve().parents or not item['semantic_dwarf_verified']
                or digest_file(dwarf) != item['dwarf_sha256']):
            raise RuntimeError('Full original macOS SDK DWARF changed or escaped the SDK')
        current = match_dsym(binary, bundle)
        if current['uuid'] != item['uuid']:
            raise RuntimeError('Final macOS dSYM UUID changed')
        measured = inspect(binary)
        verified.add((measured['cpu_type'], measured['uuid']))
    if needed != verified:
        raise RuntimeError('Complete dSYM coverage is missing for one or more packaged images')
    for client in clients['clients']:
        for image in client['images']:
            if digest_file(Path(image['path'])) != image['sha256']:
                raise RuntimeError('Independent client binary changed after linking')
    snapshot = prep.root / 'cache/snapshot-tools' / target / compiled['snapshot_identity_sha256']
    snapshot_path = snapshot / 'manifest.json'
    manifest = read(snapshot_path)
    if manifest['identity_sha256'] != compiled['snapshot_identity_sha256'] or not manifest.get('files'):
        raise RuntimeError('The actual macOS snapshot tool export is incomplete')
    for relative, item in manifest['files'].items():
        path = snapshot / 'files' / relative
        if snapshot.resolve() not in path.resolve().parents or digest_file(path) != item['sha256']:
            raise RuntimeError('macOS snapshot tool cache changed')
    validation = sdk / 'validation'
    validation.mkdir(exist_ok=True)
    for name, path in (('full-symbols.json', symbols_path), ('independent-clients.json', clients_path),
                       ('features.json', prep.root / 'state' / ('features-' + target + '.json'))):
        shutil.copy2(path, validation / name)
    write_json(validation / 'macho-final.json', report)
    # Preserve the small independently linked clients before cleanup. Their
    # SDK framework link is an external validation convenience and is omitted;
    # consumers deploy Release/framework beside their own applications.
    for client in clients['clients']:
        folder = validation / ('client-sandbox-' + client['sandbox'].lower())
        folder.mkdir(exist_ok=True)
        for item in client['images']:
            source = Path(item['path'])
            shutil.copy2(source, folder / source.name)
            if digest_file(folder / source.name) != item['sha256']:
                raise RuntimeError('Independent client evidence copy differs')
    metadata = read(sdk / 'MYCEF_BUILD.json')
    metadata.update(independent_client_verified=True, macos_runtime_verified=False,
                    apple_distribution_signing_verified=False,
                    verified_scope='Linux cross-compilation/linking, public SDK CMake clients sandbox ON/OFF, all runtime CPU/UUID/full DWARF and complete archive readback. No macOS target execution or Apple distribution-signing claim.')
    write_json(sdk / 'MYCEF_BUILD.json', metadata)
    archive = prep.root / 'packages' / (sdk.name + '.tar.zst')
    result = create_archive(sdk, archive)
    receipt = {**result, 'passed': True, 'target': target, 'sdk_engine_sha256': engine_hash,
               'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
               'compiled_receipt_sha256': digest_file(compiled_path),
               'prepared_receipt_sha256': digest_file(prepared_path),
               'symbols_receipt_sha256': digest_file(symbols_path),
               'independent_clients_receipt_sha256': digest_file(clients_path),
               'snapshot_manifest_sha256': digest_file(snapshot_path),
               'macos_runtime_verified': False, 'apple_distribution_signing_verified': False,
               'verified_scope': metadata['verified_scope'],
               'verified_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    write_json(verified_path, receipt)
    if reclaim:
        cleanup(prep, target, receipt)
    print('MACOS_RELEASE_SDK_ARCHIVED_AND_VERIFIED', json.dumps(receipt), flush=True)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=('mac-arm64', 'mac-x64'))
    parser.add_argument('--cleanup', action='store_true')
    args = parser.parse_args()
    finalize(args.root, args.target, args.cleanup)


if __name__ == '__main__':
    main()
