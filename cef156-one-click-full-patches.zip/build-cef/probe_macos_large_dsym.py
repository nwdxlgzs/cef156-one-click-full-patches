#!/usr/bin/env python3
"""Cross-check large dSYM offsets against LLVM using real DWARF and sparse files.

Run on the Linux build host with a small compiled Mach-O/dSYM smoke pair.
This exercises symbol readers, not macOS runtime or a full CEF symbol link.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile

from audit_macho import MH_DSYM, inspect


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--source-dwarf', type=Path, required=True)
    parser.add_argument('--dwarfdump', type=Path, required=True)
    args = parser.parse_args()
    if sys.platform != 'linux':
        raise RuntimeError('Use the Linux host for the sparse 4 GB fixture')
    root = args.root.resolve(strict=True)
    binary = inspect(args.binary)
    original = inspect(args.source_dwarf)
    if (original['file_type'] != MH_DSYM or not binary['uuid']
            or original['uuid'] != binary['uuid']
            or original['cpu_type'] != binary['cpu_type']
            or not 0 < args.source_dwarf.stat().st_size < 16 * 1024 * 1024):
        raise RuntimeError('Expected a small real linked image and its matching full dSYM')
    source = args.source_dwarf.read_bytes()
    header = list(struct.unpack_from('<8I', source))
    commands, position, first, last_offset_field = [], 32, None, None
    gap = 1 << 32
    for _ in range(header[4]):
        kind, length = struct.unpack_from('<II', source, position)
        command = bytearray(source[position:position + length])
        position += length
        if kind == 0x19 and command[8:24].rstrip(b'\0') == b'__DWARF':
            if first is not None:
                raise RuntimeError('Expected exactly one DWARF segment')
            vm, vs, first, fs = struct.unpack_from('<4Q', command, 24)
            struct.pack_into('<Q', command, 32, vs + gap)
            struct.pack_into('<Q', command, 48, fs + gap)
            count = struct.unpack_from('<I', command, 64)[0]
            if count < 2:
                raise RuntimeError('Expected real debug sections')
            for index in range(count):
                field = 72 + index * 80 + 32
                address = struct.unpack_from('<Q', command, field)[0]
                struct.pack_into('<Q', command, field, address + gap)
            padding = struct.pack('<16s16sQQ8I', b'__mycef_pad', b'__DWARF',
                                  vm, gap, first, 0, 0, 0, 0, 0, 0, 0)
            command = command[:72] + padding + command[72:]
            struct.pack_into('<I', command, 4, length + 80)
            struct.pack_into('<I', command, 64, count + 1)
            last_offset_field = 32 + sum(map(len, commands)) + 72 + count * 80 + 48
        commands.append(command)
    minimum_payload = min(item['offset'] for item in original['sections'] if item['offset'])
    # The original symbol/string tables precede the DWARF segment. Extra load
    # command bytes must fit in existing header padding, without moving them.
    symtabs = []
    pos = 32
    for _ in range(header[4]):
        kind, length = struct.unpack_from('<II', source, pos)
        if kind == 2:
            symtabs.append(struct.unpack_from('<I', source, pos + 8)[0])
        pos += length
    if symtabs:
        minimum_payload = min(minimum_payload, *symtabs)
    if first is None or header[5] + 32 + 80 >= minimum_payload:
        raise RuntimeError('Smoke dSYM has no room for the sparse fixture header')
    header[5] += 80
    table = struct.pack('<8I', *header) + b''.join(commands)
    prefix = source[:minimum_payload]
    rewritten = table + prefix[len(table):]
    cpu = original['architecture']
    checks = []
    logdir = root / 'logs'
    cache = root / 'cache'
    logdir.mkdir(exist_ok=True)
    cache.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mac-large-dsym-', dir=cache) as folder:
        fixture = Path(folder) / 'overflow.dwarf'
        with fixture.open('wb') as out:
            out.write(rewritten)
            out.seek(minimum_payload)
            out.write(source[minimum_payload:first])
            out.seek(first + gap)
            out.write(source[first:])
        actual = inspect(fixture)
        payloads = []
        with fixture.open('rb') as stream:
            for old in original['sections']:
                if old['segment'] != '__DWARF' or not old['bytes']:
                    continue
                item = next(s for s in actual['sections'] if s['name'] == old['name'])
                stream.seek(item['offset'])
                data = stream.read(item['bytes'])
                expected = source[old['offset']:old['offset'] + old['bytes']]
                if item['offset'] != gap + old['offset'] or data != expected:
                    raise RuntimeError('Reconstructed DWARF position/content mismatch: ' + old['name'])
                payloads.append({'section': old['name'], 'offset': item['offset'],
                                 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        stat = fixture.stat()
        if actual.get('dwarf_section_offset_encoding') != 'llvm_ordered_32bit_wrap' or not payloads:
            raise RuntimeError('The fixture did not exercise real wrapped DWARF sections')

        def verify(label, should_pass):
            log = logdir / ('mac-large-dsym-' + cpu + '-' + label + '.log')
            with log.open('wb') as output:
                code = subprocess.run([str(args.dwarfdump), '--verify', str(fixture)],
                                      stdout=output, stderr=subprocess.STDOUT, timeout=120).returncode
            content = log.read_text(errors='replace')
            if (code == 0) != should_pass:
                raise RuntimeError('Unexpected LLVM verifier result: ' + str(log))
            if should_pass and (not re.search(r'Verifying unit: \d+ / [1-9]', content) or 'No errors.' not in content):
                raise RuntimeError('LLVM did not verify real compilation units: ' + str(log))
            checks.append({'case': label, 'llvm_exit_code': code, 'expected_success': should_pass,
                           'log': str(log), 'log_sha256': sha(log), 'passed': True})

        verify('valid', True)
        broken = bytearray(table)
        previous = struct.unpack_from('<I', broken, last_offset_field - 80)[0]
        struct.pack_into('<I', broken, last_offset_field, previous - 1)
        with fixture.open('r+b') as out:
            out.write(broken)
        try:
            inspect(fixture)
        except ValueError as error:
            if 'not ordered' not in str(error):
                raise
        else:
            raise RuntimeError('The auditor accepted unordered wrapped sections')
        verify('unordered', False)
        info = next(s for s in actual['sections'] if s['name'] == '__debug_info')
        with fixture.open('r+b') as out:
            out.write(table)
            out.truncate(info['offset'] + info['bytes'] // 2)
        try:
            inspect(fixture)
        except ValueError as error:
            if 'exceeds the actual file' not in str(error):
                raise
        else:
            raise RuntimeError('The auditor accepted truncated wrapped DWARF')
        verify('truncated', False)
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'cpu': cpu,
               'binary_sha256': sha(args.binary), 'source_dwarf_sha256': sha(args.source_dwarf),
               'uuid': binary['uuid'], 'auditor_sha256': sha(Path(__file__).with_name('audit_macho.py')),
               'probe_sha256': sha(__file__), 'dwarfdump_wrapper_sha256': sha(args.dwarfdump),
               'logical_fixture_bytes': stat.st_size, 'allocated_fixture_bytes': stat.st_blocks * 512,
               'verified_payloads': payloads, 'checks': checks, 'temporary_fixture_removed': True,
               'passed': True, 'scope': 'Real compiled smoke DWARF beyond 4 GB, independent LLVM semantic verification and rejection checks. Not a full CEF symbol link or macOS execution.'}
    destination = root / 'state' / ('mac-large-dsym-' + cpu + '-preflight.json')
    destination.write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print('MAC_LARGE_DSYM_PREFLIGHT_VERIFIED', destination, flush=True)


if __name__ == '__main__':
    main()
