#!/usr/bin/env python3
"""Exercise a real Linux CEF SDK against WebGL, H.264, AAC and encode tests.

Run inside the intended CPU/userland/kernel environment, with an X display
(for example xvfb-run). Records only the host actually executing the sample.
"""
from __future__ import annotations

import argparse
import datetime as dt
import http.server
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import stat
import subprocess
import tempfile
import threading
import time

from runtime_probe import Handler, FIXTURE_SHA256, file_hash


def process_evidence(browser_pid):
    processes = {}
    for item in Path('/proc').iterdir():
        if not item.name.isdigit():
            continue
        try:
            fields = dict(line.split(':', 1) for line in (item / 'status').read_text().splitlines() if ':' in line)
            parent = int(fields['PPid'].strip())
            processes[int(item.name)] = (item, fields, parent)
        except (OSError, ValueError, KeyError):
            continue
    descendants = {browser_pid}
    while True:
        children = {pid for pid, (_item, _fields, parent) in processes.items() if parent in descendants}
        if children <= descendants:
            break
        descendants.update(children)
    result = []
    for pid in sorted(descendants):
        if pid not in processes:
            continue
        item, fields, parent = processes[pid]
        try:
            arguments = (item / 'cmdline').read_bytes().split(b'\0')
            # Chromium's Linux process-title rewriting may collapse argv into
            # one NUL-delimited field. Match the type switch in that field too.
            command_line = b' '.join(arguments).decode(errors='replace').strip()
            process_type = re.search(r'(?:^|\s)--type=([^\s]+)', command_line)
            kind = process_type.group(1) if process_type else ('browser' if pid == browser_pid else 'other')
            result.append({'pid': pid, 'ppid': parent, 'type': kind,
                           'command_line': command_line,
                           'no_new_privs': int(fields.get('NoNewPrivs', '-1').strip()),
                           'no_new_privs_exposed_by_procfs': 'NoNewPrivs' in fields,
                           'seccomp': int(fields.get('Seccomp', '-1').strip()),
                           'capabilities': {name: int(fields.get(name, '-1').strip(), 16)
                                            for name in ('CapEff', 'CapPrm', 'CapInh', 'CapAmb')},
                           'tracer_pid': int(fields.get('TracerPid', '-1').strip()),
                           'uid': fields.get('Uid', '').strip(), 'namespace_pid': fields.get('NSpid', '').strip()})
        except OSError:
            continue
    return result


def renderer_sandboxed(item, kernel):
    if item.get('seccomp') != 2 or item.get('type') != 'renderer':
        return False
    if item.get('no_new_privs') == 1:
        return True
    # Linux 4.9 has no NoNewPrivs status field (added in 4.10). Do not
    # invent a value: require observed seccomp filtering, no capabilities,
    # non-root IDs, nested PID namespace and no tracer for that old kernel.
    return (kernel.startswith('4.9.') and not item.get('no_new_privs_exposed_by_procfs', True)
            and item.get('no_new_privs') == -1
            and all(item.get('capabilities', {}).get(name) == 0
                    for name in ('CapEff', 'CapPrm', 'CapInh', 'CapAmb'))
            and len(item.get('uid', '').split()) == 4
            and all(int(uid) != 0 for uid in item['uid'].split())
            and len(item.get('namespace_pid', '').split()) >= 2
            and item.get('tracer_pid') == 0
            and '--no-sandbox' not in item.get('command_line', ''))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sdk', type=Path, required=True)
    parser.add_argument('--media', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--client', type=Path,
                        help='Independently compiled cefsimple; deploy it with this SDK for validation')
    parser.add_argument('--mode', choices=['auto', 'gpu-disabled'], default='auto')
    parser.add_argument('--no-sandbox', action='store_true')
    parser.add_argument('--sandbox-helper', type=Path,
                        help='Installed root-owned mode-4755 chrome-sandbox for the setuid sandbox path')
    parser.add_argument('--timeout', type=int, default=240)
    args = parser.parse_args()
    binary, resources = args.sdk.resolve() / 'Release', args.sdk.resolve() / 'Resources'
    if platform.system() != 'Linux' or not (binary / 'libcef.so').is_file():
        parser.error('Run on Linux with a real Release CEF library')
    if not resources.is_dir() and not all((binary / name).exists() for name in
            ('resources.pak', 'icudtl.dat', 'locales')):
        parser.error('SDK resources are absent from both Resources and merged Release')
    if not os.environ.get('DISPLAY'):
        parser.error('Provide a real X display or run this command through xvfb-run')
    if os.geteuid() == 0 and not args.no_sandbox:
        parser.error('The sandbox runtime test must run as a normal user')
    client = args.client.resolve() if args.client else binary / 'cefsimple'
    if not client.is_file() or not os.access(client, os.X_OK):
        parser.error('The selected CEF client is not an executable file')
    helper = args.sandbox_helper.resolve() if args.sandbox_helper else None
    if helper:
        metadata = helper.stat()
        if args.no_sandbox or metadata.st_uid != 0 or stat.S_IMODE(metadata.st_mode) != 0o4755:
            parser.error('The requested sandbox helper must be root-owned mode 4755 and used with the sandbox enabled')
        if file_hash(helper) != file_hash(binary / 'chrome-sandbox'):
            parser.error('The installed helper differs from this exact SDK chrome-sandbox')
    if file_hash(args.media) != FIXTURE_SHA256:
        parser.error('The media fixture differs from the fixed Chromium H.264/AAC sample')
    args.output = args.output.resolve()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    server.daemon_threads = True
    server.token, server.media = secrets.token_hex(24), args.media.resolve()
    server.finished, server.report = threading.Event(), None
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    evidence = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                'kernel': platform.release(), 'cpu': platform.machine(),
                'userland': Path('/etc/os-release').read_text() if Path('/etc/os-release').exists() else None,
                'libc': platform.libc_ver(), 'euid': os.geteuid(), 'mode': args.mode,
                'glibc_runtime': os.confstr('CS_GNU_LIBC_VERSION'),
                'sandbox_requested': not args.no_sandbox,
                'libcef_sha256': file_hash(binary / 'libcef.so'), 'fixture_sha256': FIXTURE_SHA256,
                'client': str(client), 'client_sha256': file_hash(client),
                'independent_client_requested': args.client is not None,
                'sandbox_helper': str(helper) if helper else None,
                'sandbox_helper_sha256': file_hash(helper) if helper else None,
                'scope': 'Actual sample execution and media/WebGL checks on this CPU, userland and kernel. Does not prove other CPUs, UOS product releases or hardware GPU behavior.'}
    process = None
    with tempfile.TemporaryDirectory(prefix='mycef-linux-runtime-') as temporary:
        root = Path(temporary)
        deployment, cache = root / 'app', root / 'profile'
        def copy(source, destination):
            # Full Release DWARF can make libcef many GiB. The VM has a
            # small tmpfs and a read-only SDK share: load those immutable
            # libraries through symlinks instead of copying symbols to RAM.
            if '.so' in Path(source).name:
                os.symlink(os.path.realpath(source), destination)
                return destination
            try:
                os.link(source, destination)
            except OSError:
                shutil.copy2(source, destination)
            return destination
        shutil.copytree(binary, deployment, symlinks=True, copy_function=copy)
        # Debian buster's Python 3.7 lacks copytree(dirs_exist_ok=True).
        # SDK Release/Resources entries must be disjoint; reject collisions
        # instead of silently overwriting a shipped runtime dependency.
        for source in (resources.iterdir() if resources.is_dir() else []):
            destination = deployment / source.name
            if destination.exists() or destination.is_symlink():
                raise RuntimeError('SDK Release/Resources entry collision: ' + source.name)
            if source.is_symlink():
                destination.symlink_to(os.readlink(source))
            elif source.is_dir():
                shutil.copytree(source, destination, symlinks=True, copy_function=copy)
            else:
                copy(source, destination)
        if args.client:
            # The SDK file may have been hardlinked into this temporary tree.
            # Unlink it before copying the independent binary over that name.
            if (deployment / 'cefsimple').exists():
                (deployment / 'cefsimple').unlink()
            shutil.copy2(client, deployment / 'cefsimple')
        if helper:
            # Chromium prefers a helper next to its assets over the
            # CHROME_DEVEL_SANDBOX fallback. Replace only this temporary
            # deployment entry; never chmod the SDK's hardlinked file.
            deployed_helper = deployment / 'chrome-sandbox'
            if deployed_helper.exists() or deployed_helper.is_symlink():
                deployed_helper.unlink()
            deployed_helper.symlink_to(helper)
        cache.mkdir()
        command = [str(deployment / 'cefsimple'),
                   '--url=http://127.0.0.1:' + str(server.server_port) + '/' + server.token + '/index.html',
                   '--user-data-dir=' + str(cache), '--root-cache-path=' + str(cache),
                   '--resources-dir-path=' + str(deployment), '--locales-dir-path=' + str(deployment / 'locales'),
                   '--autoplay-policy=no-user-gesture-required', '--no-first-run',
                   '--disable-background-networking', '--disable-renderer-backgrounding',
                   '--enable-logging', '--log-file=' + str(args.output.with_suffix('.cef.log'))]
        if args.mode == 'gpu-disabled':
            command.append('--disable-gpu')
        if args.no_sandbox:
            command.append('--no-sandbox')
        evidence['command'] = command
        env = dict(os.environ)
        if helper:
            env['CHROME_DEVEL_SANDBOX'] = str(helper)
        env['LD_LIBRARY_PATH'] = str(deployment) + (':' + env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
        try:
            with args.output.with_suffix('.process.log').open('w', encoding='utf-8') as log:
                process = subprocess.Popen(command, cwd=deployment, env=env, stdout=log, stderr=subprocess.STDOUT,
                                           start_new_session=True)
                deadline = time.monotonic() + args.timeout
                while not server.finished.wait(1):
                    if process.poll() is not None:
                        raise RuntimeError('CEF exited before reporting: ' + str(process.returncode))
                    if time.monotonic() > deadline:
                        raise TimeoutError('CEF did not finish the real rendering and media checks')
                evidence['report'] = server.report
                evidence['processes'] = process_evidence(process.pid)
        except Exception as error:
            evidence['failure'] = repr(error)
        finally:
            if process is not None:
                # The process group is created by this probe and contains its
                # browser/renderer/GPU children; never target unrelated CEF.
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=10)
            server.shutdown()
            server.server_close()
            thread.join(timeout=5)
    report = evidence.get('report', {})
    webgl = report.get('webgl', {}).get('webgl', {})
    checks = {'webgl_draw': webgl.get('greenPixelDrawn') is True,
              'video_frames': report.get('video', {}).get('decodedFrames', 0) > 0
                              and report.get('video', {}).get('nonBlackPixels', 0) > 0,
              'aac_samples': report.get('audio', {}).get('frames', 0) > 0 and report.get('audio', {}).get('peak', 0) > 0,
              'webrtc_h264': 'video/H264' in report.get('webrtcVideoCodecs', []),
              'h264_encode_roundtrip': report.get('h264Encoder', {}).get('roundTripGreen') is True}
    if args.mode == 'gpu-disabled':
        renderer = webgl.get('renderer', '').lower()
        checks['software_renderer'] = any(name in renderer for name in ['swiftshader', 'llvmpipe', 'lavapipe', 'softpipe'])
    if not args.no_sandbox:
        renderers = [item for item in evidence.get('processes', []) if item['type'] == 'renderer']
        checks['renderer_seccomp_sandbox'] = bool(renderers) and all(
            renderer_sandboxed(item, evidence['kernel']) for item in renderers)
        evidence['renderer_sandbox_observation'] = (
            'seccomp filter; NoNewPrivs procfs flag' if all(item['no_new_privs'] == 1 for item in renderers)
            else 'Linux 4.9: NoNewPrivs unavailable through procfs; observe seccomp, non-root IDs, zero capabilities, nested PID namespace, no tracer. No direct no_new_privs value claim.')
    evidence.update(checks=checks, passed=all(checks.values()) and 'failure' not in evidence)
    args.output.write_text(json.dumps(evidence, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'passed': evidence['passed'], 'checks': checks, 'output': str(args.output)}), flush=True)
    return 0 if evidence['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
