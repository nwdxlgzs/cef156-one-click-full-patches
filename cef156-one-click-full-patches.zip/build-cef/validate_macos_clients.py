#!/usr/bin/env python3
"""Independently compile public macOS SDK clients with sandbox ON and OFF.

Uses packaged CEF headers, wrapper CMake project and original cefsimple sources.
Linux cross-linking is explicitly distinct from macOS target execution.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import plistlib
import shutil
import sys

from archive_posix import digest_file
from audit_macho import inspect, CPUS
from mac_client_toolchain import prepare as prepare_toolchain
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent
FRAMEWORK = 'Chromium Embedded Framework'

PROJECT = r'''cmake_minimum_required(VERSION 3.20)
project(MyCefIndependentMacClient LANGUAGES C CXX OBJC OBJCXX)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_OBJCXX_STANDARD 20)
set(CMAKE_OBJCXX_STANDARD_REQUIRED ON)
set(PROJECT_ARCH "@ARCH@")
set(CEF_ROOT "@SDK@")
list(APPEND CMAKE_MODULE_PATH "${CEF_ROOT}/cmake")
find_package(CEF REQUIRED)
add_subdirectory("${CEF_LIBCEF_DLL_WRAPPER_PATH}" wrapper)
set(sample "${CEF_ROOT}/tests/cefsimple")
add_executable(cefsimple MACOSX_BUNDLE
  "${sample}/simple_app.cc" "${sample}/simple_handler.cc"
  "${sample}/simple_handler_mac.mm" "${sample}/cefsimple_mac.mm"
  "${CMAKE_CURRENT_SOURCE_DIR}/menu.mm")
SET_EXECUTABLE_TARGET_PROPERTIES(cefsimple)
target_compile_definitions(cefsimple PRIVATE MYCEF_PROGRAMMATIC_MENU)
target_compile_options(cefsimple PRIVATE "$<$<COMPILE_LANGUAGE:OBJCXX>:-fobjc-arc>")
target_link_libraries(cefsimple PRIVATE libcef_dll_wrapper ${CEF_STANDARD_LIBS})
set_target_properties(cefsimple PROPERTIES
  MACOSX_BUNDLE_INFO_PLIST "${CMAKE_CURRENT_SOURCE_DIR}/main.plist"
  RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/apps")
set(helper_ids default alerts gpu renderer)
set(helper_names "cefsimple Helper" "cefsimple Helper (Alerts)"
                 "cefsimple Helper (GPU)" "cefsimple Helper (Renderer)")
foreach(index RANGE 0 3)
  list(GET helper_ids ${index} id)
  list(GET helper_names ${index} name)
  set(target "helper_${id}")
  add_executable(${target} MACOSX_BUNDLE "${sample}/process_helper_mac.cc")
  SET_EXECUTABLE_TARGET_PROPERTIES(${target})
  target_link_libraries(${target} PRIVATE libcef_dll_wrapper ${CEF_STANDARD_LIBS})
  set_target_properties(${target} PROPERTIES OUTPUT_NAME "${name}"
    MACOSX_BUNDLE_INFO_PLIST "${CMAKE_CURRENT_SOURCE_DIR}/helper-${id}.plist"
    RUNTIME_OUTPUT_DIRECTORY "${CMAKE_BINARY_DIR}/apps")
endforeach()
'''


def development_inputs(sdk):
    return {path.relative_to(sdk).as_posix(): digest_file(path)
            for name in ('include', 'libcef_dll', 'cmake', 'tests/cefsimple')
            for path in sorted((sdk / name).rglob('*')) if path.is_file() and not path.is_symlink()}


def write_stable(path, text):
    if path.exists() and path.read_text('utf-8') != text:
        raise RuntimeError('Independent project inputs changed; preserve the existing client build: ' + str(path))
    path.write_text(text, encoding='utf-8')


def plist(source, destination, name, suffix='', main=False):
    data = source.read_text('utf-8')
    for key, value in {'EXECUTABLE_NAME': name, 'PRODUCT_NAME': name,
                       'BUNDLE_ID_SUFFIX': suffix, 'VERSION_SHORT': '1.0.0'}.items():
        data = data.replace('${' + key + '}', value)
    values = plistlib.loads(data.encode())
    if main:
        if values.pop('NSMainNibFile', None) != 'MainMenu':
            raise RuntimeError('Unexpected original menu autoload setting')
    values['LSMinimumSystemVersion'] = '13.0'
    encoded = plistlib.dumps(values, sort_keys=False)
    if destination.exists() and destination.read_bytes() != encoded:
        raise RuntimeError('Independent client bundle metadata changed')
    destination.write_bytes(encoded)


def validate(root, target, jobs):
    prep = Preparation(root)
    cpu = target.removeprefix('mac-')
    prepared_path = prep.root / 'state' / ('sdk-' + target + '-prepared.json')
    prepared = json.loads(prepared_path.read_text('utf-8'))
    sdk = Path(prepared['sdk']).resolve()
    if (prepared['target'] != target or prep.root / 'packages/staging' not in sdk.parents
            or digest_file(sdk / 'Release' / (FRAMEWORK + '.framework') / FRAMEWORK) != prepared['sdk_engine_sha256']):
        raise RuntimeError('The real macOS SDK engine/path differs from its prepared identity')
    inputs = development_inputs(sdk)
    if not inputs:
        raise RuntimeError('The packaged CEF SDK development inputs are absent')
    toolchain = prepare_toolchain(prep, cpu, smoke=True)
    clients = []
    for sandbox in ('ON', 'OFF'):
        directory = prep.root / 'cache/independent-clients' / target / ('sandbox-' + sandbox.lower())
        source, output = directory / 'source', directory / 'build'
        source.mkdir(parents=True, exist_ok=True)
        text = PROJECT.replace('@SDK@', str(sdk)).replace('@ARCH@', toolchain['architecture'])
        write_stable(source / 'CMakeLists.txt', text)
        xib = sdk / 'tests/cefsimple/mac/English.lproj/MainMenu.xib'
        menu = source / 'menu.mm'
        # Use the same original XIB translator, leaving SDK source files intact.
        prep.run([sys.executable, HERE / 'mac_menu_source.py', '--input', xib, '--output', menu])
        plist(sdk / 'tests/cefsimple/mac/Info.plist.in', source / 'main.plist', 'cefsimple', main=True)
        for identifier, suffix, name in [('default', '', 'cefsimple Helper'),
                                         ('alerts', '.alerts', 'cefsimple Helper (Alerts)'),
                                         ('gpu', '.gpu', 'cefsimple Helper (GPU)'),
                                         ('renderer', '.renderer', 'cefsimple Helper (Renderer)')]:
            plist(sdk / 'tests/cefsimple/mac/helper-Info.plist.in', source / ('helper-' + identifier + '.plist'), name, suffix)
        configure = ['cmake', '-S', source, '-B', output, '-G', 'Ninja',
                     '-DCMAKE_BUILD_TYPE=Release', '-DUSE_SANDBOX=' + sandbox,
                     '-DCMAKE_TOOLCHAIN_FILE=' + toolchain['toolchain']]
        prep.run(configure)
        prep.run(['cmake', '--build', output, '-j', str(jobs)])
        app = output / 'apps/cefsimple.app'
        resources = app / 'Contents/Resources'
        resources.mkdir(exist_ok=True)
        shutil.copy2(sdk / 'tests/cefsimple/mac/cefsimple.icns', resources / 'cefsimple.icns')
        localization = sdk / 'tests/cefsimple/mac/English.lproj/InfoPlist.strings'
        if localization.is_file():
            (resources / 'English.lproj').mkdir(exist_ok=True)
            shutil.copy2(localization, resources / 'English.lproj/InfoPlist.strings')
        frameworks = app / 'Contents/Frameworks'
        frameworks.mkdir(exist_ok=True)
        engine = sdk / 'Release' / (FRAMEWORK + '.framework')
        link = frameworks / engine.name
        if link.exists():
            if not link.is_symlink() or link.resolve() != engine:
                raise RuntimeError('Existing independent client framework differs from the SDK')
        else:
            link.symlink_to(engine, target_is_directory=True)
        images = []
        executable = app / 'Contents/MacOS/cefsimple'
        for name in ('cefsimple Helper', 'cefsimple Helper (Alerts)',
                     'cefsimple Helper (GPU)', 'cefsimple Helper (Renderer)'):
            original = output / 'apps' / (name + '.app')
            destination = frameworks / original.name
            if not destination.exists():
                shutil.copytree(original, destination, symlinks=True)
            copied = destination / 'Contents/MacOS' / name
            if digest_file(copied) != digest_file(original / 'Contents/MacOS' / name):
                raise RuntimeError('Independent Helper deployment differs from its linked executable')
            images.append(copied)
        images.insert(0, executable)
        for image in images:
            measured = inspect(image)
            if measured['cpu_type'] != CPUS[cpu] or not measured['uuid']:
                raise RuntimeError('Independent macOS client has the wrong Mach-O CPU/UUID')
        cache = (output / 'CMakeCache.txt').read_text('utf-8')
        if 'USE_SANDBOX:BOOL=' + sandbox not in cache or 'CMAKE_BUILD_TYPE:STRING=Release' not in cache:
            raise RuntimeError('Independent CMake client sandbox/Release selection changed')
        clients.append({'sandbox': sandbox, 'app': str(app), 'executable': str(executable),
                        'images': [{'path': str(p), 'sha256': digest_file(p)} for p in images],
                        'cmake_cache_sha256': digest_file(output / 'CMakeCache.txt'),
                        'project_sha256': digest_file(source / 'CMakeLists.txt'),
                        'sdk_engine_sha256': prepared['sdk_engine_sha256'],
                        'configure_command': list(map(str, configure))})
    if development_inputs(sdk) != inputs:
        raise RuntimeError('SDK development files changed during independent client compilation')
    receipt = {'target': target, 'clients': clients, 'sdk_engine_sha256': prepared['sdk_engine_sha256'],
               'prepared_receipt_sha256': digest_file(prepared_path), 'sdk_development_inputs': inputs,
               'client_toolchain': toolchain, 'compilation_linking_passed': True,
               'runtime_verified': False, 'cross_compiled': True,
               'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
               'scope': 'Two independent Release CMake cefsimple applications and eight Helpers built from packaged SDK public headers/wrapper/sample sources, sandbox ON/OFF. SDK framework symlink avoids duplicate engines; macOS execution remains unverified.'}
    write_json(prep.root / 'state' / ('clients-' + target + '-built.json'), receipt)
    print('MACOS_PUBLIC_SDK_CLIENTS_CROSS_COMPILED', target, flush=True)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', required=True, choices=('mac-arm64', 'mac-x64'))
    parser.add_argument('--jobs', type=int, default=8, choices=range(1, 25))
    args = parser.parse_args()
    validate(args.root, args.target, args.jobs)


if __name__ == '__main__':
    main()
