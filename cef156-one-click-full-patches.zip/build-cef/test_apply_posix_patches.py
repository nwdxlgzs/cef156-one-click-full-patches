"""Exercise safe additions to an already patched source checkout."""
import copy
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import apply_posix_patches as subject
from prepare_posix import Preparation, write_json


class PreparedMigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.prep = Preparation(Path(self.temp.name) / 'work')
        self.prep.src.mkdir()
        subprocess.run(['git', 'init', '-q', self.prep.src], check=True)
        self.bundle = Path(self.temp.name) / 'bundle'
        self.bundle.mkdir()
        (self.bundle / 'old.patch').write_text('unchanged original payload\n')
        self.source = self.prep.src / 'existing.txt'
        self.source.write_text('existing patched source and user data\n')
        self.old = {'format': 1, 'chromium_revision': subject.CHROMIUM_REV,
                    'files': {'old.patch': subject.sha256(self.bundle / 'old.patch')},
                    'common_fixes': [], 'build_fixes': ['old.patch'], 'webgl_patch': 'original'}
        write_json(self.bundle / 'manifest.json', self.old)
        self.old_identity = subject.sha256(self.bundle / 'manifest.json')
        self.prior = {'posix_patch_bundle_sha256': self.old_identity,
                      'posix_patch_manifest': self.old,
                      'patched_source_sha256': {'existing.txt': subject.sha256(self.source)}}
        self.receipt = self.prep.root / 'state/prepared-posix.json'
        write_json(self.receipt, self.prior)
        (self.bundle / 'extra.patch').write_text(
            'diff --git a/extra.txt b/extra.txt\nnew file mode 100644\n'
            '--- /dev/null\n+++ b/extra.txt\n@@ -0,0 +1 @@\n+new target-only input\n')
        self.next = copy.deepcopy(self.old)
        self.next['build_fixes'].append('extra.patch')
        self.next['files']['extra.patch'] = subject.sha256(self.bundle / 'extra.patch')

    def migrate(self):
        write_json(self.bundle / 'manifest.json', self.next)
        with patch.object(subject, 'PATCHES', self.bundle), patch.object(subject, 'verify_bundle', return_value=self.next):
            return subject.install(self.prep)

    def test_addition_preserves_existing_source_and_original_receipt(self):
        before = self.source.read_bytes()
        result = self.migrate()
        self.assertEqual(self.source.read_bytes(), before)
        self.assertEqual((self.prep.src / 'extra.txt').read_text(), 'new target-only input\n')
        self.assertEqual(json.loads(Path(result['additive_migrations'][0]['previous_receipt']).read_text()), self.prior)
        self.assertEqual(self.migrate(), result)

    def test_existing_source_mutation_is_rejected_before_applying(self):
        self.source.write_text('new user edit must be retained\n')
        with self.assertRaisesRegex(RuntimeError, 'Prepared source changed'):
            self.migrate()
        self.assertFalse((self.prep.src / 'extra.txt').exists())

    def test_existing_payload_or_version_change_is_rejected(self):
        for name in ('payload', 'revision'):
            with self.subTest(name=name):
                self.next = copy.deepcopy(self.old)
                self.next['build_fixes'].append('extra.patch')
                self.next['files']['extra.patch'] = subject.sha256(self.bundle / 'extra.patch')
                if name == 'payload':
                    self.next['files']['old.patch'] = 'changed'
                else:
                    self.next['chromium_revision'] = 'changed'
                with self.assertRaises(RuntimeError):
                    self.migrate()
                self.assertFalse((self.prep.src / 'extra.txt').exists())

    def test_failed_patch_keeps_original_receipt(self):
        (self.bundle / 'extra.patch').write_text('invalid patch bytes\n')
        self.next['files']['extra.patch'] = subject.sha256(self.bundle / 'extra.patch')
        with self.assertRaisesRegex(RuntimeError, 'Patch does not apply'):
            self.migrate()
        self.assertEqual(json.loads(self.receipt.read_text()), self.prior)
        self.assertEqual(self.source.read_text(), 'existing patched source and user data\n')


if __name__ == '__main__':
    unittest.main()
