"""Verify the launcher aggregate accepts only all four actual WebGL tests."""
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

from compile_posix import verify_webgl_gtest


class WebglAggregateTests(unittest.TestCase):
    def report(self):
        root = ET.Element('testsuites', tests='4', failures='0', errors='0', disabled='0')
        suite = ET.SubElement(root, 'testsuite', name='GpuUtilTest')
        for name in ('MyCefWebGLRetainsHardwareWithCompositorRestriction', 'MyCefWebGLDefersUnknownHardwareState',
                     'MyCefWebGLFallsBackAfterConfirmedFailure', 'MyCefWebGLHonorsOptOutAndExplicitImplementation'):
            ET.SubElement(suite, 'testcase', name=name, classname='GpuUtilTest', status='run')
        return root

    def verify(self, root):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'launcher.xml'
            ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)
            verify_webgl_gtest(path)

    def test_all_four_executed(self):
        self.verify(self.report())

    def test_incomplete_failed_disabled_and_duplicate_cases_are_refused(self):
        for change in ('missing', 'failure', 'skipped', 'disabled', 'duplicate', 'wrong_suite'):
            with self.subTest(change=change):
                root = self.report()
                suite = root.find('testsuite')
                cases = suite.findall('testcase')
                if change == 'missing':
                    suite.remove(cases[-1])
                elif change in ('failure', 'skipped'):
                    ET.SubElement(cases[0], change)
                elif change == 'disabled':
                    cases[0].set('status', 'notrun')
                elif change == 'duplicate':
                    cases[-1].set('name', cases[0].get('name'))
                else:
                    cases[0].set('classname', 'OtherSuite')
                with self.assertRaises(RuntimeError):
                    self.verify(root)


if __name__ == '__main__':
    unittest.main()
