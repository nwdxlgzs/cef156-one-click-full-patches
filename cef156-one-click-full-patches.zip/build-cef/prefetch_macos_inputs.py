#!/usr/bin/env python3
"""Install original Linux MIG and ANGLE Metal inputs from the locked DEPS.

These are specific cross-build inputs, not a complete macOS gclient sync.
"""
from __future__ import annotations

import argparse
import ast
from concurrent.futures import ThreadPoolExecutor
import datetime as dt
import hashlib
import json
import plistlib
from pathlib import Path
import struct
import subprocess

from cipd_mirror import MirrorCache, instance_ref
from prepare_posix import Preparation, CHROMIUM_REV, write_json
from archive_posix import digest_file


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--sdk', type=Path,
                        help='Also generate and compile real MIG user/server stubs for both macOS CPUs')
    args = parser.parse_args()
    prep = Preparation(args.root)
    data = subprocess.check_output(['git', '-C', str(prep.src), 'show', CHROMIUM_REV + ':DEPS'], env=prep.env)
    blob = hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()
    expected = prep.git(prep.src, 'ls-tree', CHROMIUM_REV, '--', 'DEPS', capture=True).stdout.split()[2]
    if blob != expected:
        raise RuntimeError('The cross-platform inputs differ from the fixed original DEPS Git blob')
    tree = ast.parse(data.decode())
    dependencies = next(node.value for node in tree.body if isinstance(node, ast.Assign)
                        and any(isinstance(target, ast.Name) and target.id == 'deps' for target in node.targets))
    selected = {}
    required = {'src/third_party/mig/bin', 'src/ui/gl/resources/angle-metal'}
    for key, value in zip(dependencies.keys, dependencies.values):
        if isinstance(key, ast.Constant) and key.value in required:
            entry = ast.literal_eval(value)
            if entry['dep_type'] != 'cipd':
                raise RuntimeError('The original cross-platform dependency type changed')
            selected[key.value] = entry
    if set(selected) != required:
        raise RuntimeError('A required original cross-platform dependency is missing')
    cache = MirrorCache(prep.root / 'downloads/cipd-mirror')
    def install(item):
        name, entry = item
        directory = prep.root / 'chromium' / name
        directory.mkdir(parents=True, exist_ok=True)
        lines = ['$VerifiedPlatform linux-amd64', '$ParanoidMode CheckIntegrity']
        packages = []
        for pin in entry['packages']:
            package = pin['package'].replace('${{platform}}', 'linux-amd64')
            version = pin['version']
            if not instance_ref(version):
                raise RuntimeError('Expected an immutable original CIPD instance ID')
            cached = cache.resolve(package, version)
            lines.append(package + ' ' + version)
            packages.append({'package': package, 'instance_id': version, 'zip_sha256': cached['sha256']})
        manifest = prep.root / 'state' / ('mac-input-' + name.replace('/', '_') + '.ensure')
        manifest.write_text('\n'.join(lines) + '\n')
        prep.run([prep.depot / 'cipd', 'ensure', '-ensure-file', manifest, '-root', directory])
        files = {path.relative_to(directory).as_posix(): digest_file(path)
                 for path in directory.rglob('*') if path.is_file() and '.cipd' not in path.parts}
        if not files:
            raise RuntimeError('The original macOS input package installed no payload files')
        return {'path': name, 'directory': str(directory), 'original_condition': entry['condition'],
                'packages': packages, 'files': files}
    with ThreadPoolExecutor(2) as pool:
        futures = [pool.submit(install, item) for item in selected.items()]
        reports, errors = [], []
        for future in futures:
            try:
                reports.append(future.result())
            except Exception as error:
                errors.append(repr(error))
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'chromium_revision': CHROMIUM_REV,
               'original_deps_git_blob': blob, 'inputs': reports, 'errors': errors, 'passed': not errors,
               'full_mac_dependency_sync_complete': False,
               'scope': 'Original fixed DEPS MIG Linux tool and ANGLE Metal shader input packages, verified by the original CIPD client. Other macOS GN requirements still need inspection.'}
    write_json(prep.root / 'state/mac-cross-inputs-prefetched.json', receipt)
    if errors:
        raise RuntimeError('macOS cross input prefetch failed: ' + repr(errors))
    if args.sdk:
        sdk = args.sdk.resolve()
        if prep.root / 'cache/apple-research' not in sdk.parents:
            raise RuntimeError('Use an original verified SDK from the dedicated Apple cache')
        settings = plistlib.loads((sdk / 'SDKSettings.plist').read_bytes())
        version = plistlib.loads((sdk / 'System/Library/CoreServices/SystemVersion.plist').read_bytes())
        compiler = prep.src / 'third_party/llvm-build/Release+Asserts/bin/clang'
        compiler_receipt = json.loads((prep.root / 'state/clang-prefetched.json').read_text())
        if digest_file(compiler) != compiler_receipt['compiler_sha256']:
            raise RuntimeError('The actual pinned compiler changed')
        directory = prep.root / 'validation' / ('mac-mig-smoke-' + settings['Version'])
        directory.mkdir(parents=True, exist_ok=True)
        source = directory / 'probe.defs'
        source.write_text('subsystem MyCefProbe 48000;\n#include <mach/std_types.defs>\n'
                          'routine mycef_ping(server: mach_port_t; value: integer_t);\n')
        prep.env['MIGCC'] = str(compiler)
        prep.env['MIGCOM'] = str(prep.src / 'third_party/mig/bin/migcom')
        tests = []
        for cpu, machine in [('arm64', 0x0100000c), ('x86_64', 0x01000007)]:
            output = directory / cpu
            output.mkdir(exist_ok=True)
            command = [prep.src / 'third_party/mig/bin/mig', '-arch', cpu, '-isysroot', sdk,
                       '-header', output / 'probe.h', '-sheader', output / 'probe-server.h',
                       '-user', output / 'probe-user.c', '-server', output / 'probe-server.c', source]
            prep.run(command)
            for part in ['user', 'server']:
                target = output / ('probe-' + part + '.o')
                prep.run([compiler, '-target', cpu + '-apple-macos13.0', '-isysroot', sdk,
                          '-c', output / ('probe-' + part + '.c'), '-o', target])
                header = struct.unpack('<8I', target.read_bytes()[:32])
                if header[0] != 0xfeedfacf or header[1] != machine or header[3] != 1:
                    raise RuntimeError('MIG-generated code did not compile to the actual requested Mach-O object')
            tests.append({'cpu': cpu, 'mig_command': list(map(str, command)), 'passed': True,
                          'files': {path.name: digest_file(path) for path in output.iterdir() if path.is_file()}})
        write_json(prep.root / 'state/mac-mig-compiler-smoke.json', {
            'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'sdk_version': settings['Version'],
            'sdk_build': version['ProductBuildVersion'], 'sdk_settings_sha256': digest_file(sdk / 'SDKSettings.plist'),
            'original_inputs_receipt_sha256': digest_file(prep.root / 'state/mac-cross-inputs-prefetched.json'),
            'compiler_sha256': digest_file(compiler), 'tests': tests, 'passed': True,
            'scope': 'Actual original Linux MIG generation and Clang compilation of user/server stubs for both Mach-O architectures against the real Apple SDK. Not full CEF sandbox/runtime verification.'})
    print('ORIGINAL_MAC_CROSS_INPUTS_INSTALLED', flush=True)


if __name__ == '__main__':
    main()
