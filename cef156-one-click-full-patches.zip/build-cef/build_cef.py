#!/usr/bin/env python3
"""Resumable Windows CEF build. Invoked by Build-CEF.ps1, standard library only."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time
import zipfile

CHROMIUM = "156.0.8071.0"
CHROMIUM_REV = "aa939feff52ea94f0ca07d8029086738c2683685"
CEF_REV = "a26ddfd2792604564986b31ea298e30b09bd9b3f"
CEF_UPSTREAM_CHROMIUM = "156.0.8078.0"
PATCH_REV = "b4d1c429f461bd756443ea0b68270d0bdb1c5536"
PATCH_REPO = "https://github.com/e3kskoy7wqk/Chromium-for-windows-7-REWORK.git"
CEF_REPO = "https://github.com/chromiumembedded/cef.git"
CHROMIUM_REPO = "https://chromium.googlesource.com/chromium/src.git"
PATCHES_DIR = Path(__file__).resolve().with_name("patches")
ORDER = [(cpu, "Release") for cpu in ("x64", "x86", "arm64")]
MACHINE = {"x86": 0x14C, "x64": 0x8664, "arm64": 0xAA64}
SCRIPT_VERSION = 1


def sha256(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temp.replace(path)


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def verify_patch_bundle(directory: Path = PATCHES_DIR) -> dict:
    """Check the local payload before any source download or patch application."""
    manifest_path = directory / "manifest.json"
    if not manifest_path.is_file():
        raise RuntimeError("Missing patches/manifest.json. Extract the complete full-patches ZIP.")
    manifest = read_json(manifest_path)
    if (manifest.get("format") != 1 or manifest.get("chromium_version") != CHROMIUM or
            manifest.get("cef_revision") != CEF_REV or manifest.get("win7_revision") != PATCH_REV):
        raise RuntimeError("Bundled patch versions do not match this build script")
    files = manifest["files"]
    for relative, expected in files.items():
        path = directory / relative
        if directory.resolve() not in path.resolve().parents:
            raise RuntimeError(f"Invalid bundle manifest path: {relative}")
        if not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"Bundled patch missing or changed: {relative}")
    actual = {path.relative_to(directory).as_posix() for path in directory.rglob("*")
              if path.is_file() and path != manifest_path}
    if actual != set(files):
        raise RuntimeError("Patch directory contains unlisted or missing files; extract a fresh full-patches ZIP")
    win7 = directory / "win7" / f"chromium-{CHROMIUM}"
    names = [line.strip() for line in (win7 / "commit_hashes.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    if len(names) != 345 or len(names) != len(set(names)):
        raise RuntimeError("Expected exactly 345 unique Win7 patches in commit_hashes.txt")
    for name in names:
        if not re.fullmatch(r"[A-Za-z0-9_.-]+", name) or not (win7 / (name + ".diff")).is_file():
            raise RuntimeError(f"Invalid or missing Win7 patch: {name}")
    print(f"Verified bundled patches: 345 Win7 + 117 CEF configured patches + 10 CEF adaptations + Windows build fixes + WebGL fallback ({len(files)} files).", flush=True)
    return manifest


def safe_remove(path: Path, parent: Path) -> None:
    """Delete only an exact generated descendant; reject symlinks/junctions."""
    resolved, boundary = path.resolve(), parent.resolve()
    if resolved == boundary or boundary not in resolved.parents:
        raise RuntimeError(f"Refusing to remove a path outside {boundary}: {path}")
    if path.is_symlink() or (hasattr(path, "is_junction") and path.is_junction()):
        raise RuntimeError(f"Refusing to remove a linked directory: {path}")
    if path.exists():
        shutil.rmtree(path)


def verify_additive_build_fixes(directory: Path, previous_hash: str, manifest: dict) -> None:
    """Allow new Windows build fixes without changing any prepared patch."""
    if not re.fullmatch(r'[0-9a-f]{64}', previous_hash):
        raise RuntimeError('Invalid previous patch bundle identity')
    previous = directory / 'history' / (previous_hash + '.json')
    if not previous.is_file() or sha256(previous) != previous_hash:
        raise RuntimeError('Patch bundle changed since source preparation')
    old_files = read_json(previous)['files']
    new_files = manifest['files']
    if any(new_files.get(name) != digest for name, digest in old_files.items()):
        raise RuntimeError('An existing prepared patch was changed or removed')
    if any(not name.startswith(('windows-build/', 'history/')) for name in new_files.keys() - old_files.keys()):
        raise RuntimeError('Only additive Windows build fixes can reuse the prepared source tree')


def patch_paths(data: str) -> list[str]:
    # ---/+++ are authoritative. One upstream patch contains malformed Windows
    # absolute names on its 'diff --git' line; its ---/+++ paths are correct.
    return list(dict.fromkeys(re.findall(r"^\+\+\+ b/([^\r\n\t]+)", data, re.M)))


def normalize_patch(data: str) -> str:
    chunks = re.split(r"(?=^diff --git )", data.replace("\r\n", "\n"), flags=re.M)
    result = []
    for chunk in chunks:
        if chunk.startswith("diff --git "):
            old = re.search(r"^--- (?:a/([^\n\t]+)|/dev/null)$", chunk, re.M)
            new = re.search(r"^\+\+\+ (?:b/([^\n\t]+)|/dev/null)$", chunk, re.M)
            if old and new:
                old_path = old.group(1) or new.group(1)
                new_path = new.group(1) or old.group(1)
                if old_path and new_path:
                    chunk = re.sub(r"^diff --git [^\n]+", f"diff --git a/{old_path} b/{new_path}", chunk, count=1)
        result.append(chunk)
    return "".join(result)


def gn_defines() -> str:
    # Keep full CEF/Chromium PDBs in the requested optimized Release packages.
    values = {
        "is_official_build": "true", "is_component_build": "false",
        "symbol_level": "2", "blink_symbol_level": "2", "v8_symbol_level": "2",
        "use_thin_lto": "false", "chrome_pgo_phase": "0",
        "use_remoteexec": "false", "use_siso": "false",
        "treat_warnings_as_errors": "false",
        "proprietary_codecs": "true", "ffmpeg_branding": '"Chrome"',
        "media_use_openh264": "true", "rtc_use_h264": "true",
        "enable_platform_hevc": "true", "enable_hevc_parser_and_hw_decoder": "true",
        "enable_swiftshader": "true", "use_static_angle": "false",
    }
    return " ".join(f"{key}={value}" for key, value in values.items())


def pe_machine(path: Path) -> int:
    with path.open("rb") as stream:
        if stream.read(2) != b"MZ":
            raise RuntimeError(f"Not a PE file: {path}")
        stream.seek(0x3C)
        header_offset = struct.unpack("<I", stream.read(4))[0]
        stream.seek(header_offset)
        if stream.read(4) != b"PE\0\0":
            raise RuntimeError(f"Invalid PE header: {path}")
        return struct.unpack("<H", stream.read(2))[0]


def configure_sdk_runtime_copy(sdk: Path, binary: Path) -> list[str]:
    """Teach the distributed CMake projects to deploy the restored GL runtime."""
    files = ["libEGL.dll", "libGLESv2.dll", "swiftshader"]
    for name in files:
        if not (binary / name).exists():
            raise RuntimeError(f"Required SDK WebGL runtime is missing: {name}")
    if (binary / "dxil.dll").is_file():
        files.append("dxil.dll")
    cmake = sdk / "cmake/cef_variables.cmake"
    text = cmake.read_text(encoding="utf-8")
    tag = "# MYCEF: deploy the restored ANGLE and legacy SwiftShader runtime."
    block = (tag + "\nif(OS_WINDOWS)\n  list(APPEND CEF_BINARY_FILES\n" +
             "".join(f"    {name}\n" for name in files) +
             "  )\n  list(REMOVE_DUPLICATES CEF_BINARY_FILES)\nendif()\n")
    if tag in text:
        if not text.endswith(block):
            raise RuntimeError("SDK runtime CMake configuration has unexpected changes")
    else:
        cmake.write_text(text.rstrip() + "\n\n" + block, encoding="utf-8", newline="\n")
    return files


def make_archive(folder: Path, destination: Path, metadata: dict) -> dict:
    """ZIP64 with a per-file SHA256 manifest, CRC and archive SHA validation."""
    write_json(folder / "MYCEF_BUILD.json", metadata)
    listing = {str(p.relative_to(folder)).replace("\\", "/"): sha256(p)
               for p in sorted(folder.rglob("*")) if p.is_file() and p.name != "SHA256SUMS.json"}
    write_json(folder / "SHA256SUMS.json", listing)
    pending = destination.with_suffix(destination.suffix + ".partial")
    files = [p for p in sorted(folder.rglob("*")) if p.is_file()]
    with zipfile.ZipFile(pending, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=3, allowZip64=True) as archive:
        for index, path in enumerate(files, 1):
            archive.write(path, str(path.relative_to(folder)))
            if index % 200 == 0:
                print(f"  Compressing: {index}/{len(files)} files", flush=True)
    with zipfile.ZipFile(pending) as archive:
        if len(archive.infolist()) != len(files):
            raise RuntimeError("Archive file count mismatch")
        # Validate both CRC and the strong manifest before permitting cleanup.
        for name, expected in listing.items():
            digest = hashlib.sha256()
            with archive.open(name) as stream:
                for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
                    digest.update(block)
            if digest.hexdigest() != expected:
                raise RuntimeError(f"Archive validation failed for {name}")
        json.loads(archive.read("SHA256SUMS.json"))
    pending.replace(destination)
    digest = sha256(destination)
    destination.with_suffix(destination.suffix + ".sha256").write_text(
        f"{digest}  {destination.name}\n", encoding="ascii")
    return {"path": str(destination), "sha256": digest, "size": destination.stat().st_size,
            "files": len(files)}


class Builder:
    def __init__(self, args):
        self.args = args
        self.root = Path(args.root).resolve()
        self.state = self.root / "state"
        self.logs = self.root / "logs"
        self.chromium_dir = self.root / "chromium"
        self.src = self.chromium_dir / "src"
        self.cef = self.src / "cef"
        self.patch_root = PATCHES_DIR
        self.patch_dir = self.patch_root / "win7" / f"chromium-{CHROMIUM}"
        self.env = dict(os.environ)
        self.env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8",
                         "DEPOT_TOOLS_WIN_TOOLCHAIN": "0", "DEPOT_TOOLS_UPDATE": "0",
                         "CEF_ENABLE_ARM64": "1", "GIT_TERMINAL_PROMPT": "0"})
        self.number = 0

    def run(self, command, cwd=None, env=None, retry=1, capture=False, check=True):
        command = [str(arg) for arg in command]
        for attempt in range(1, retry + 1):
            self.number += 1
            log = self.logs / (dt.datetime.now().strftime("%Y%m%d-%H%M%S") + f"-{self.number:03}.log")
            print(f"\n>>> {subprocess.list2cmdline(command)}\n    log: {log}", flush=True)
            output = []
            # Windows command shims (.bat/.cmd) need cmd.exe. All arguments are
            # fixed or validated paths and are quoted by list2cmdline.
            invocation = command
            executable = shutil.which(command[0], path=(env or self.env).get("PATH")) or command[0]
            if os.name == "nt" and Path(executable).suffix.lower() in (".bat", ".cmd"):
                invocation = (subprocess.list2cmdline([os.environ["COMSPEC"]]) +
                              ' /d /s /c "' +
                              subprocess.list2cmdline([executable] + command[1:]) + '"')
            with log.open("w", encoding="utf-8") as stream:
                process = subprocess.Popen(invocation, cwd=cwd or self.root, env=env or self.env,
                                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                           text=True, encoding="utf-8", errors="replace")
                try:
                    for line in process.stdout:
                        stream.write(line)
                        stream.flush()
                        if capture:
                            output.append(line)
                        else:
                            print(line.rstrip(), flush=True)
                    code = process.wait()
                except KeyboardInterrupt:
                    if os.name == "nt":
                        subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    else:
                        process.terminate()
                    process.wait()
                    raise
                finally:
                    process.stdout.close()
            if code == 0 or attempt == retry:
                if code and check:
                    raise RuntimeError(f"Command failed ({code}); see {log}")
                return code, "".join(output)
            print(f"Network operation failed. Retrying ({attempt}/{retry})...", flush=True)
            time.sleep(min(15, attempt * 3))
        raise AssertionError("unreachable")

    def git(self, folder: Path, *args, **kwargs):
        return self.run(["git", "-C", folder, *args], **kwargs)

    def checkout(self, folder: Path, url: str, ref: str, sparse=None, full_history=False) -> str:
        folder.mkdir(parents=True, exist_ok=True)
        if not (folder / ".git").exists():
            if any(folder.iterdir()):
                raise RuntimeError(f"Refusing to initialize a nonempty directory: {folder}")
            self.git(folder, "init")
            self.git(folder, "remote", "add", "origin", url)
        # get-url expands insteadOf rules. Validate the configured canonical
        # origin so a selected mirror does not look like a changed checkout.
        _, remote = self.git(folder, "config", "--get", "remote.origin.url", capture=True)
        if remote.strip() != url:
            raise RuntimeError(f"Unexpected origin under {folder}: {remote.strip()}")
        self.git(folder, "config", "core.longpaths", "true")
        self.git(folder, "config", "core.autocrlf", "false")
        current_code, current = self.git(folder, "rev-parse", "--verify", "HEAD", capture=True, check=False)
        if current_code == 0:
            _, expected = self.git(folder, "rev-parse", "--verify", ref + "^{commit}", capture=True, check=False)
            if current.strip() == expected.strip() and re.fullmatch(r"[0-9a-f]{40}", current.strip()):
                if full_history:
                    self.ensure_cef_history(folder, ref)
                return current.strip()
            raise RuntimeError(f"Existing checkout is not at the locked revision: {folder}")
        if sparse:
            self.git(folder, "sparse-checkout", "init", "--cone")
            self.git(folder, "sparse-checkout", "set", sparse)
        fetch = ["fetch", "--no-tags"]
        if not full_history:
            fetch += ["--depth=1"]
        if sparse:
            fetch += ["--filter=blob:none"]
        self.git(folder, *fetch, "origin", ref, retry=4)
        # Keep the requested tag locally so reruns can verify its immutable HEAD.
        if ref.startswith("refs/tags/"):
            self.git(folder, "update-ref", ref, "FETCH_HEAD")
        self.git(folder, "checkout", "--detach", "FETCH_HEAD")
        _, revision = self.git(folder, "rev-parse", "HEAD", capture=True)
        if re.fullmatch(r"[0-9a-f]{40}", ref) and revision.strip() != ref:
            raise RuntimeError(f"Revision mismatch under {folder}")
        if full_history:
            self.ensure_cef_history(folder, ref)
        return revision.strip()

    def ensure_cef_history(self, folder: Path, ref: str):
        # CEF embeds `git rev-list --count HEAD` in version headers. A shallow
        # checkout produces the wrong build number. This pinned CEF revision
        # is from master; keep its master reference pinned too, so version
        # generation cannot depend on later changes to the remote branch.
        _, shallow = self.git(folder, "rev-parse", "--is-shallow-repository", capture=True)
        if shallow.strip() == "true":
            self.git(folder, "fetch", "--unshallow", "--no-tags", "origin", ref, retry=4)
        self.git(folder, "update-ref", "refs/remotes/origin/master", ref)

    def assert_space(self, minimum_gb: int, operation: str):
        free = shutil.disk_usage(self.root).free / (1024**3)
        print(f"Free build-volume space: {free:.1f} GiB ({operation})", flush=True)
        if free < minimum_gb:
            raise RuntimeError(f"Need {minimum_gb} GiB free for {operation}; only {free:.1f} GiB remains. "
                               "Expand the build volume, then rerun. Current source and outputs are preserved.")

    def apply_patch(self, patch: Path, root=None, already_ok=True, strip=1):
        directory = root or self.src
        check, _ = self.git(directory, "apply", f"-p{strip}", "--check", "--ignore-space-change", patch,
                            check=False, capture=True)
        if check:
            reverse, _ = self.git(directory, "apply", f"-p{strip}", "--reverse", "--check",
                                  "--ignore-space-change", patch, check=False, capture=True)
            if already_ok and reverse == 0:
                print(f"Already applied: {patch.name}", flush=True)
                return
            # Print the actual failing hunks before stopping, never silently skip.
            self.git(directory, "apply", f"-p{strip}", "--check", "--verbose", "--ignore-space-change", patch)
        self.git(directory, "apply", f"-p{strip}", "--ignore-space-change", "--whitespace=nowarn", patch)

    def prepare_nested_gsutil(self):
        """Reuse the verified official bootstrap for Chromium's pinned depot_tools."""
        if not self.env.get('CIPD_SERVICE_URL'):
            return
        depot = self.src / 'third_party/depot_tools'
        script = depot / 'gsutil.py'
        lock = read_json(Path(__file__).with_name('network-lock.json'))
        version = lock['gsutil_version']
        if not script.is_file() or not re.search(r'^VERSION\s*=\s*[\'"]' + re.escape(version) + r'[\'"]',
                                                script.read_text('utf-8'), re.M):
            raise RuntimeError('Pinned depot_tools gsutil version differs from its reviewed bootstrap lock')
        archive = self.root / 'downloads' / ('gsutil_' + version + '.zip')
        if not archive.is_file() or sha256(archive) != lock['gsutil_sha256']:
            raise RuntimeError('The verified gsutil bootstrap archive is missing; rerun Build-CEF.ps1')
        target = depot / 'external_bin/gsutil' / ('gsutil_' + version)
        if self.root.resolve() not in target.resolve().parents:
            raise RuntimeError('Pinned gsutil runtime escaped the dedicated build root')
        flag = target / 'gsutil/install.flag'
        if not flag.exists():
            with zipfile.ZipFile(archive) as payload:
                for member in payload.infolist():
                    path = (target / member.filename).resolve()
                    if target.resolve() not in path.parents and path != target.resolve():
                        raise RuntimeError('Invalid official gsutil archive member')
                payload.extractall(target)
            if not (target / 'gsutil/gsutil').is_file():
                raise RuntimeError('Pinned gsutil runtime is incomplete after extraction')
            flag.write_text('This flag file is dropped by gsutil.py', encoding='ascii')
        print('Prepared verified gsutil for the Chromium-pinned depot_tools hooks.', flush=True)

    def prepare_nested_depot_tools(self):
        self.prepare_nested_gsutil()
        if not self.env.get('CIPD_SERVICE_URL'):
            return
        depot = self.src / 'third_party/depot_tools'
        helper = Path(__file__).with_name('cipd_mirror.py')
        self.run([sys.executable, helper, '--cache', self.root / 'downloads/cipd-mirror',
                  '--bootstrap-depot', depot])
        self.run([sys.executable, helper, '--cache', self.root / 'downloads/cipd-mirror',
                  '--prefetch-depot', depot])
        batch = depot / 'cipd.bat'
        original = 'set CIPD_BACKEND=https://chrome-infra-packages.appspot.com'
        override = 'if defined CIPD_SERVICE_URL set CIPD_BACKEND=%CIPD_SERVICE_URL%'
        text = batch.read_bytes().decode('ascii')
        if override not in text:
            if original not in text:
                raise RuntimeError('Pinned depot_tools CIPD bootstrap changed; mirror adaptation requires review')
            text = text.replace(original, original + '\r\n' + override)
            batch.write_bytes(text.encode('ascii'))
        # Hooks such as generate_location_tags.py deliberately select the
        # source-pinned depot_tools directory instead of the outer bootstrap.
        self.run([depot / 'cipd.bat', 'ensure', '-ensure-file', depot / 'cipd_manifest.txt',
                  '-root', depot / '.cipd_bin'], cwd=depot, retry=3)
        self.run([depot / 'dirmd.bat', '-help'], cwd=depot)

    def prepare_source_mirror(self):
        """Build a complete local mirror before the first network source clone."""
        if not self.env.get('CIPD_SERVICE_URL'):
            return None
        # Existing working trees continue through their normal locked checkout
        # path. Never replace or reset an in-progress working tree here.
        if (self.src / '.git').exists():
            code, _ = self.git(self.src, 'rev-parse', '--verify', '--quiet', 'HEAD', capture=True, check=False)
            if code == 0:
                return None
        mirror = self.root / 'mirrors/chromium.git'
        record = self.state / 'source-mirror-complete.json'
        helper_root = Path(__file__).resolve().parent
        if record.exists():
            metadata = read_json(record)
            if (metadata.get('commit') != CHROMIUM_REV or metadata.get('missing_paths') or
                    metadata.get('required_blobs') != metadata.get('verified_blobs') or
                    metadata.get('git_fsck_exit') != 0):
                raise RuntimeError('Local source mirror record is incomplete')
        else:
            mirror.parent.mkdir(exist_ok=True)
            if not (mirror / 'HEAD').exists():
                if mirror.exists() and any(mirror.iterdir()):
                    raise RuntimeError('Unrecognized nonempty source mirror directory')
                self.run(['git', 'init', '--bare', mirror])
                self.git(mirror, 'remote', 'add', 'origin', CHROMIUM_REPO)
            _, url = self.git(mirror, 'config', '--get', 'remote.origin.url', capture=True)
            if url.strip() != CHROMIUM_REPO:
                raise RuntimeError('Source mirror origin does not match its locked canonical repository')
            self.git(mirror, 'config', 'remote.origin.promisor', 'true')
            self.git(mirror, 'config', 'remote.origin.partialclonefilter', 'blob:none')
            self.git(mirror, 'fetch', '--depth=1', '--filter=blob:none', '--no-tags', 'origin',
                     f'refs/tags/{CHROMIUM}:refs/tags/{CHROMIUM}', retry=3)
            _, commit = self.git(mirror, 'rev-parse', f'refs/tags/{CHROMIUM}^{{commit}}', capture=True)
            if commit.strip() != CHROMIUM_REV:
                raise RuntimeError('Metadata-only source mirror has an unexpected tag commit')
            archive_dir = self.root / 'downloads/source-archive'
            self.run([sys.executable, helper_root / 'prefetch_source_archive.py',
                      '--directory', archive_dir, '--jobs', '8'])
            # Official distribution tarballs omit test data. A nonzero seed
            # result is accepted only with a detailed partial-import record;
            # every missing object is then required by the completion stage.
            partial_record = self.state / 'source-mirror-archive.json'
            code, _ = self.run([sys.executable, helper_root / 'seed_source_objects.py',
                '--repository', mirror, '--archive', archive_dir / f'chromium-{CHROMIUM}.tar.xz',
                '--record', partial_record], check=False)
            if code:
                incomplete = partial_record.with_suffix('.incomplete.json')
                if not incomplete.is_file():
                    raise RuntimeError('Source archive seed failed before its object audit')
                evidence = read_json(incomplete)
                if evidence.get('commit') != CHROMIUM_REV or not evidence.get('missing_paths'):
                    raise RuntimeError('Unexpected source archive seed failure')
            self.run([sys.executable, helper_root / 'complete_source_objects.py',
                      '--repository', mirror, '--record', record, '--jobs', '4'])
        # A second read-only Git integrity check protects reuse of an existing
        # mirror completion record before it supplies the actual working tree.
        self.git(mirror, 'fsck', '--full', '--no-dangling')
        return mirror

    def prepare_sources(self):
        manifest = verify_patch_bundle(self.patch_root)
        bundle_hash = sha256(self.patch_root / "manifest.json")
        prepared = self.state / "prepared.json"
        # Resume skips sync/runhooks: those operations can overwrite patched
        # dependencies and the Rust sysroot. Never sync a patched checkout.
        if prepared.exists():
            meta = read_json(prepared)
            if meta["chromium_version"] != CHROMIUM or meta["cef_revision"] != CEF_REV or meta["patch_revision"] != PATCH_REV:
                raise RuntimeError("Source lock does not match this script")
            if meta.get("patch_bundle_sha256", bundle_hash) != bundle_hash:
                verify_additive_build_fixes(self.patch_root, meta['patch_bundle_sha256'], manifest)
            for folder, expected in ((self.src, meta["chromium_revision"]), (self.cef, CEF_REV)):
                _, current = self.git(folder, "rev-parse", "HEAD", capture=True)
                if current.strip() != expected:
                    raise RuntimeError(f"Source revision changed: {folder}")
            self.ensure_cef_history(self.cef, CEF_REV)
            for relative, expected in meta["custom_source_sha256"].items():
                if sha256(self.src / relative) != expected:
                    raise RuntimeError(f"Custom source changed since preparation: {relative}")
            self.install_cef_rebased_patches()
            self.install_windows_build_patches()
            self.install_webgl_patch()
            for relative in self.windows_build_patch_paths():
                meta['custom_source_sha256'][relative] = sha256(self.src / relative)
            meta["patch_bundle_sha256"] = bundle_hash
            write_json(prepared, meta)
            return meta

        mirror = self.prepare_source_mirror()
        if mirror is not None:
            self.src.mkdir(parents=True, exist_ok=True)
            if not (self.src / '.git').exists():
                if any(self.src.iterdir()):
                    raise RuntimeError('Source folder became nonempty during mirror preparation')
                self.git(self.src, 'init')
                self.git(self.src, 'remote', 'add', 'origin', CHROMIUM_REPO)
            _, origin = self.git(self.src, 'config', '--get', 'remote.origin.url', capture=True)
            if origin.strip() != CHROMIUM_REPO:
                raise RuntimeError('Source origin changed during mirror preparation')
            self.git(self.src, 'config', 'core.longpaths', 'true')
            self.git(self.src, 'config', 'core.autocrlf', 'false')
            self.git(self.src, 'fetch', '--depth=1', '--no-tags', mirror, f'refs/tags/{CHROMIUM}')
            self.git(self.src, 'update-ref', f'refs/tags/{CHROMIUM}', 'FETCH_HEAD')
            self.git(self.src, 'checkout', '--detach', f'refs/tags/{CHROMIUM}')
        source_sha = self.checkout(self.src, CHROMIUM_REPO, f"refs/tags/{CHROMIUM}")
        if source_sha != CHROMIUM_REV:
            raise RuntimeError("Chromium tag does not match the locked source commit")
        self.checkout(self.cef, CEF_REPO, CEF_REV, full_history=True)
        self.install_cef_official_patches()
        compatibility = (self.cef / "CHROMIUM_BUILD_COMPATIBILITY.txt").read_text(encoding="utf-8")
        if f"refs/tags/{CEF_UPSTREAM_CHROMIUM}" not in compatibility:
            raise RuntimeError("Unexpected upstream CEF compatibility entry")
        print(f"CUSTOM COMBINATION: CEF upstream expects {CEF_UPSTREAM_CHROMIUM}; using requested {CHROMIUM}.", flush=True)
        gclient = "solutions = " + repr([{
            "name": "src", "url": CHROMIUM_REPO, "managed": False,
            "custom_deps": {}, "custom_vars": {"checkout_pgo_profiles": False},
        }]) + "\ntarget_os = ['win']\n"
        (self.chromium_dir / ".gclient").write_text(gclient, encoding="utf-8")
        sync_marker = self.state / "sync-and-hooks.json"
        if not sync_marker.exists():
            deps_marker = self.state / 'dependencies-synced.json'
            if deps_marker.exists():
                if read_json(deps_marker).get('chromium_revision') != source_sha:
                    raise RuntimeError('Dependency sync marker belongs to a different source revision')
            else:
                # No --force, --reset or gclient revert. Existing work is retained.
                self.run(["gclient", "sync", "--nohooks", "--no-history", "-j", "8",
                          "--revision", f"src@{CHROMIUM_REV}"], cwd=self.chromium_dir, retry=4)
                write_json(deps_marker, {'chromium_revision': source_sha})
            version = (self.src / "chrome/VERSION").read_text(encoding="utf-8")
            parts = dict(re.findall(r"^(MAJOR|MINOR|BUILD|PATCH)=(\d+)$", version, re.M))
            actual = ".".join(parts[key] for key in ("MAJOR", "MINOR", "BUILD", "PATCH"))
            if actual != CHROMIUM:
                raise RuntimeError(f"Wrong Chromium version after sync: {actual}")
            self.prepare_nested_depot_tools()
            self.apply_patch(self.cef / "patch/patches/runhooks.patch", strip=0)
            self.run(["gclient", "runhooks"], cwd=self.chromium_dir, retry=3)
            write_json(sync_marker, {"chromium_revision": source_sha})

        patch_names = [line.strip() for line in (self.patch_dir / "commit_hashes.txt").read_text(encoding="utf-8-sig").splitlines() if line.strip()]
        if len(patch_names) != len(set(patch_names)):
            raise RuntimeError("Duplicate patch IDs in upstream commit_hashes.txt")
        # Upstream's BAT explicitly reverses commit_hashes.txt. Preserve order.
        patch_names.reverse()
        journal_path = self.state / "legacy-patches.json"
        journal = read_json(journal_path) if journal_path.exists() else {}
        normalized_dir = self.state / "normalized-patches"
        normalized_dir.mkdir(exist_ok=True)
        for index, name in enumerate(patch_names, 1):
            original = self.patch_dir / (name + ".diff")
            digest = sha256(original)
            if name in journal:
                if journal[name] != digest:
                    raise RuntimeError(f"Patch contents changed: {name}")
                continue
            print(f"\nWin7 patch {index}/{len(patch_names)}: {name}", flush=True)
            normalized = normalized_dir / original.name
            normalized.write_text(normalize_patch(original.read_text(encoding="utf-8-sig")), encoding="utf-8", newline="\n")
            self.apply_patch(normalized)
            journal[name] = digest
            write_json(journal_path, journal)

        # Check and apply CEF's entire patch set against this exact Chromium +
        # Win7 combination before spending hours compiling. CEF patcher exits
        # nonzero for failed hunks and recognizes already-applied patches.
        self.install_cef_rebased_patches()
        self.run([sys.executable, "tools/patcher.py"], cwd=self.cef)
        self.install_windows_build_patches()
        self.install_webgl_patch()
        custom = ["gpu/config/gpu_util.cc", "ui/gl/gl_features.cc",
                  "sandbox/win/src/handle_closer_agent.cc"]
        custom.extend(self.windows_build_patch_paths())
        meta = {
            "script_version": SCRIPT_VERSION, "chromium_version": CHROMIUM,
            "chromium_revision": source_sha, "cef_revision": CEF_REV,
            "cef_upstream_chromium": CEF_UPSTREAM_CHROMIUM,
            "custom_cef_chromium_combination": True, "patch_revision": PATCH_REV,
            "patch_bundle_sha256": bundle_hash,
            "legacy_patch_count": len(patch_names),
            "custom_source_sha256": {name: sha256(self.src / name) for name in custom},
            "prepared_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        }
        write_json(prepared, meta)
        return meta

    def install_cef_official_patches(self):
        """Use the bundled official patch set; retain recognized adaptations."""
        directory = self.patch_root / "cef-official"
        adaptations = read_json(self.patch_root / "cef-8071" / "manifest.json")
        for source in directory.rglob("*"):
            if not source.is_file() or source.name == "LICENSE.txt":
                continue
            destination = self.cef / "patch" / source.relative_to(directory)
            expected = sha256(source)
            current = sha256(destination) if destination.is_file() else None
            adapted = adaptations.get(source.stem, {}).get("rebased_sha256")
            if current == adapted and adapted:
                continue
            if current != expected:
                raise RuntimeError(f"CEF checkout patch differs from bundled revision: {destination}")
            shutil.copy2(source, destination)

    def install_webgl_patch(self):
        patch = self.patch_root / "webgl" / "webgl-fallback.patch"
        self.apply_patch(patch)
        shutil.copy2(patch, self.state / "mycef-webgl-fallback.patch")

    def install_windows_build_patches(self):
        for patch in sorted((self.patch_root / "windows-build").glob("*.patch")):
            self.apply_patch(patch)

    def windows_build_patch_paths(self):
        return list(dict.fromkeys(path for patch in sorted((self.patch_root / 'windows-build').glob('*.patch'))
                                  for path in patch_paths(patch.read_text('utf-8'))))

    def install_cef_rebased_patches(self):
        directory = self.patch_root / "cef-8071"
        manifest_path = directory / "manifest.json"
        if not manifest_path.is_file():
            raise RuntimeError("Missing patches/cef-8071/manifest.json; extract the complete script bundle")
        manifest = read_json(manifest_path)
        for name, hashes in manifest.items():
            source = directory / (name + ".patch")
            destination = self.cef / "patch/patches" / source.name
            if sha256(source) != hashes["rebased_sha256"]:
                raise RuntimeError(f"Adapted CEF patch checksum mismatch: {source.name}")
            current = sha256(destination)
            if current not in (hashes["upstream_sha256"], hashes["rebased_sha256"]):
                raise RuntimeError(f"CEF patch has unexpected local changes: {destination}")
            if current != hashes["rebased_sha256"]:
                shutil.copy2(source, destination)

    def generate(self, cpu: str, config: str):
        env = dict(self.env)
        env["GN_DEFINES"] = gn_defines()
        env["GN_OUT_CONFIGS"] = f"{config}_GN_{cpu}"
        env["GN_ARGUMENTS"] = "--fail-on-unused-args"
        self.run([sys.executable, "tools/gclient_hook.py"], cwd=self.cef, env=env)
        output = self.src / "out" / f"{config}_GN_{cpu}"
        args_text = (output / "args.gn").read_text(encoding="utf-8")
        expected = [f'target_cpu="{cpu}"', "symbol_level=2", "is_component_build=false", "is_debug=false"]
        if config == "Debug":
            expected.append("dcheck_always_on=true")
        compact = re.sub(r"\s+", "", args_text)
        for value in expected:
            if value not in compact:
                raise RuntimeError(f"Generated {output.name} is missing {value}")
        return output, env

    def package(self, cpu: str, config: str, output: Path, metadata: dict) -> tuple[Path, dict]:
        staging_parent = self.root / "packages" / "staging"
        staging = staging_parent / f"{cpu}-{config}"
        if staging.exists():
            safe_remove(staging, staging_parent)
        staging.mkdir(parents=True)
        subdir = f"cef_binary_{CHROMIUM}_windows_{cpu}_{config.lower()}"
        command = [sys.executable, "tools/make_distrib.py", "--output-dir", staging,
                   "--distrib-subdir", subdir, "--ninja-build", "--allow-partial",
                   "--no-docs", "--no-archive", "--no-format"]
        if cpu == "x64":
            command.append("--x64-build")
        elif cpu == "arm64":
            command.append("--arm64-build")
        self.run(command, cwd=self.cef)
        sdk = staging / subdir
        binary = sdk / config
        if not (binary / "libcef.dll").exists() or not (binary / "libcef.lib").exists():
            raise RuntimeError("CEF distribution is missing its DLL or import library")
        if pe_machine(binary / "libcef.dll") != MACHINE[cpu]:
            raise RuntimeError("Wrong target architecture in distribution")
        # The original make_distrib does not package the legacy software GL DLLs
        # restored by the Win7 patch. Include them with the correct relative path.
        for name in ("libEGL.dll", "libGLESv2.dll", "d3dcompiler_47.dll", "dxil.dll"):
            if (output / name).is_file():
                shutil.copy2(output / name, binary / name)
        if cpu in ("x64", "x86"):
            legacy_compiler = self.root / "runtime26100" / cpu / "d3dcompiler_47.dll"
            runtime_manifest = read_json(self.state / "runtime-sdk26100.json")
            if sha256(legacy_compiler).upper() != runtime_manifest[cpu]["sha256"].upper():
                raise RuntimeError("SDK 26100 runtime snapshot checksum mismatch")
            if pe_machine(legacy_compiler) != MACHINE[cpu]:
                raise RuntimeError("Wrong architecture in SDK 26100 runtime snapshot")
            shutil.copy2(legacy_compiler, binary / "d3dcompiler_47.dll")
        legacy = output / "swiftshader"
        for name in ("libEGL.dll", "libGLESv2.dll"):
            if not (legacy / name).is_file():
                raise RuntimeError(f"Software WebGL fallback DLL missing: {legacy / name}")
        shutil.copytree(legacy, binary / "swiftshader", dirs_exist_ok=True)
        runtime_cmake_files = configure_sdk_runtime_copy(sdk, binary)
        # Put PDBs beside their binaries, not in disposable make_distrib dirs.
        symbol_dir = staging / (subdir + f"_{config.lower()}_symbols")
        if not (symbol_dir / "libcef.dll.pdb").is_file():
            raise RuntimeError("CEF PDB was not generated; refusing to label this a debug-capable package")
        # make_distrib has already copied PDBs out of the build directory.
        # Rename these files on the same volume instead of making a third
        # full-sized copy while the SDK and its ZIP are being assembled.
        for source in symbol_dir.rglob("*"):
            if source.is_file():
                destination = binary / source.relative_to(symbol_dir)
                destination.parent.mkdir(parents=True, exist_ok=True)
                source.replace(destination)
        safe_remove(symbol_dir, staging)
        for name in ("libEGL.dll.pdb", "libGLESv2.dll.pdb"):
            if (output / name).is_file():
                shutil.copy2(output / name, binary / name)
        for example in ("cefclient.exe", "cefsimple.exe"):
            if (output / example).is_file():
                shutil.copy2(output / example, binary / example)
                if (output / (example + ".pdb")).is_file():
                    shutil.copy2(output / (example + ".pdb"), binary / (example + ".pdb"))
        shutil.copy2(output / "args.gn", sdk / "MYCEF_args.gn")
        shutil.copy2(self.state / "mycef-webgl-fallback.patch", sdk / "MYCEF_webgl_fallback.patch")
        shutil.copytree(self.patch_root / "cef-8071", sdk / "MYCEF_cef_8071_patches", dirs_exist_ok=True)
        shutil.copytree(self.patch_root / "windows-build", sdk / "MYCEF_windows_build_patches", dirs_exist_ok=True)
        shutil.copy2(self.patch_root / "manifest.json", sdk / "MYCEF_patch_bundle_manifest.json")
        shutil.copy2(self.patch_dir / "commit_hashes.txt", sdk / "MYCEF_upstream_commit_hashes.txt")
        validation = Path(__file__).with_name("verify-runtime.html")
        if validation.exists():
            shutil.copy2(validation, sdk / validation.name)
        meta = dict(metadata, target_cpu=cpu, configuration=config, gn_defines=gn_defines(),
                    build_jobs=self.args.jobs,
                    runtime_cmake_files=runtime_cmake_files,
                    debug_description="CEF official optimized Debug with DCHECK and full PDBs" if config == "Debug" else "CEF official optimized Release with full PDBs",
                    codecs={"h264": True, "aac": True, "mp4": True, "webrtc_openh264": True,
                            "hevc": "platform hardware/OS dependent", "x264_library": False},
                    built_utc=dt.datetime.now(dt.timezone.utc).isoformat())
        archive = self.root / "packages" / (subdir + ".zip")
        result = make_archive(sdk, archive, meta)
        return staging, result

    def prepare_build_python(self):
        # The Chromium-pinned depot_tools is also selected by source scripts.
        # Its GN/Ninja launchers require the official bootstrap Python export,
        # independently of vpython's environment. Run even on a prepared tree.
        depot = self.src / 'third_party/depot_tools'
        self.run([depot / 'bootstrap/win_tools.bat'], cwd=depot)
        self.run([depot / 'python-bin/python3.bat', '-c',
                  'import ssl, sqlite3, sys; assert sys.version_info[:2] == (3, 11); '
                  'print(sys.executable, sys.version)'], cwd=depot)

    def build(self):
        meta = self.prepare_sources()
        self.prepare_build_python()
        plan_path = self.state / "build-plan.json"
        plan = {"script_version": SCRIPT_VERSION, "gn_defines": gn_defines(),
                "order": ORDER, "chromium": CHROMIUM, "cef": CEF_REV, "patches": PATCH_REV}
        if plan_path.exists() and read_json(plan_path) != json.loads(json.dumps(plan)):
            legacy = dict(plan, order=[(cpu, config) for cpu in ("x64", "x86", "arm64")
                                      for config in ("Release", "Debug")])
            if read_json(plan_path) != json.loads(json.dumps(legacy)):
                raise RuntimeError("Build parameters changed since the first run. Use a new dedicated root for a different configuration.")
            previous = plan_path.read_bytes()
            history = self.state / "build-plan-history" / (hashlib.sha256(previous).hexdigest() + ".json")
            history.parent.mkdir(parents=True, exist_ok=True)
            history.write_bytes(previous)
            print("Updated the existing plan to Release only; verified Release packages are retained.", flush=True)
        write_json(plan_path, plan)
        for cpu, config in ORDER:
            marker = self.state / f"complete-{cpu}-{config}.json"
            output = self.src / "out" / f"{config}_GN_{cpu}"
            if marker.exists():
                prior = read_json(marker)
                archive = Path(prior["path"])
                print(f"Verifying completed package: {archive.name}", flush=True)
                if not archive.is_file() or sha256(archive) != prior["sha256"]:
                    raise RuntimeError(f"Completed package missing or changed: {archive}. Restore it, or remove {marker.name} to rebuild this configuration.")
                if not self.args.keep_intermediates and output.exists():
                    safe_remove(output, self.src / "out")
                leftover = self.root / "packages/staging" / f"{cpu}-{config}"
                if leftover.exists():
                    safe_remove(leftover, self.root / "packages/staging")
                print(f"Already complete: {cpu} {config}", flush=True)
                continue
            print(f"\n{'=' * 70}\nBUILDING {cpu} {config}\n{'=' * 70}", flush=True)
            built_marker = self.state / f"built-{cpu}-{config}.json"
            if built_marker.exists() and not output.exists():
                built_marker.unlink()
            if not built_marker.exists():
                minimum = 10 if (output / "build.ninja").exists() else self.args.build_free_gb
                self.assert_space(minimum, f"{cpu} {config}")
                output, env = self.generate(cpu, config)
                targets = ["cefclient", "cefsimple", "bootstrap", "bootstrapc",
                           "third_party/swiftshader/src/OpenGL/libEGL:swiftshader_libEGL",
                           "third_party/swiftshader/src/OpenGL/libGLESv2:swiftshader_libGLESv2"]
                if cpu == "arm64":
                    targets.remove("cefclient")
                self.run(["autoninja", "-C", output, "-j", str(self.args.jobs), *targets], cwd=self.src, env=env)
                if not (output / "libcef.dll").is_file():
                    raise RuntimeError("Build completed without libcef.dll")
                write_json(built_marker, {"dll_sha256": sha256(output / "libcef.dll")})
            elif not (output / "libcef.dll").is_file() or sha256(output / "libcef.dll") != read_json(built_marker)["dll_sha256"]:
                raise RuntimeError(f"Built output changed: {output}. Restore it, or remove {built_marker.name} to rebuild this configuration.")
            # Prevent a package copy + ZIP from exhausting the remaining disk.
            required_files = [output / "libcef.dll", output / "libcef.dll.pdb"]
            if not all(path.is_file() for path in required_files):
                raise RuntimeError("Build completed without libcef.dll/PDB")
            package_files = [path for path in output.iterdir() if path.is_file() and
                             path.suffix.lower() in (".dll", ".pdb", ".pak", ".lib", ".bin", ".dat", ".exe")]
            for subdir in ("swiftshader", "locales"):
                package_files.extend(path for path in (output / subdir).rglob("*") if path.is_file())
            needed = sum(path.stat().st_size for path in package_files)
            free = shutil.disk_usage(self.root).free
            # Two copies (SDK + archive), even if nothing compresses; retain
            # another 3 GiB for SDK sources and small generated files.
            if free < needed * 2 + 3 * 1024**3:
                raise RuntimeError("Insufficient packaging headroom. Built output is preserved; expand the disk and rerun.")
            staging, result = self.package(cpu, config, output, meta)
            write_json(marker, result)  # Mark complete BEFORE deleting any output.
            safe_remove(staging, self.root / "packages/staging")
            if not self.args.keep_intermediates:
                safe_remove(output, self.src / "out")
            print(f"PACKAGED AND VERIFIED: {result['path']}\nSHA256: {result['sha256']}", flush=True)
        print(f"\nAll three Release configurations are complete. Packages: {self.root / 'packages'}", flush=True)


def main():
    if sys.version_info < (3, 10):
        raise RuntimeError("The CEF build orchestrator requires Python 3.10 or newer; rerun the current Build-CEF.ps1")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True)
    parser.add_argument("--jobs", type=int, default=10)
    parser.add_argument("--build-free-gb", type=int, default=80)
    parser.add_argument("--keep-intermediates", action="store_true")
    args = parser.parse_args()
    root = Path(args.root)
    marker = root / ".mycef-build-root"
    if not marker.exists() or marker.read_text(encoding="utf-8") != "mycef-156.0.8071.0-v1":
        parser.error("Run Build-CEF.ps1 first; no recognized dedicated build root")
    if os.name != "nt":
        parser.error("Windows x64 build host required")
    if not 1 <= args.jobs <= 64:
        parser.error("--jobs must be between 1 and 64")
    try:
        Builder(args).build()
    except KeyboardInterrupt:
        print("Interrupted. Rerun Build-CEF.cmd to resume.", file=sys.stderr)
        return 130
    except Exception as exc:
        print(f"\nBUILD STOPPED: {exc}\nCompleted archives and incomplete outputs have been preserved.", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
