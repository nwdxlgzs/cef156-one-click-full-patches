#!/usr/bin/env python3
"""Record actual generated CEF features and reject missing requested modules."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import re

from archive_posix import digest_file
from prepare_posix import Preparation, CHROMIUM_REV, CEF_REV, write_json

HEADERS = {
    'pdf/buildflags.h': {'ENABLE_PDF': '1'},
    'printing/buildflags/buildflags.h': {'ENABLE_PRINTING': '1', 'ENABLE_PRINT_PREVIEW': '1'},
    'extensions/buildflags/buildflags.h': {'ENABLE_EXTENSIONS': '1', 'ENABLE_EXTENSIONS_CORE': '1'},
    'media/media_buildflags.h': {'ENABLE_FFMPEG': '1', 'ENABLE_FFMPEG_VIDEO_DECODERS': '1', 'ENABLE_OPENH264': '1'},
    'third_party/widevine/cdm/buildflags.h': {'ENABLE_WIDEVINE': '1', 'BUNDLE_WIDEVINE_CDM': '0'},
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--target', choices=['linux-x64', 'linux-arm64', 'mac-arm64', 'mac-x64'], required=True)
    args = parser.parse_args()
    prep = Preparation(args.root)
    configuration = json.loads((prep.root / 'state' / ('gn-' + args.target + '.json')).read_text('utf-8'))
    output = Path(configuration['output']).resolve()
    if prep.src / 'out' not in output.parents or digest_file(output / 'args.gn') != configuration['args_gn_sha256']:
        raise RuntimeError('Actual target GN arguments changed since generation')
    expected = {'is_debug': False, 'is_component_build': False, 'symbol_level': 2,
                'blink_symbol_level': 2, 'v8_symbol_level': 2, 'proprietary_codecs': True,
                'ffmpeg_branding': 'Chrome', 'media_use_openh264': True, 'rtc_use_h264': True,
                'enable_swiftshader': True, 'use_static_angle': False}
    errors = [name + ' differs from the requested configuration'
              for name, value in expected.items() if configuration['args'].get(name) != value]
    headers = []
    for relative, required in HEADERS.items():
        path = output / 'gen' / relative
        if not path.is_file():
            errors.append('Required actual generated feature header is missing: ' + relative)
            continue
        text = path.read_text('utf-8')
        flags = dict(re.findall(r'^#define\s+BUILDFLAG_INTERNAL_([A-Z0-9_]+)\(\)\s+\((.*)\)\s*$', text, re.M))
        for name, value in required.items():
            if flags.get(name) != value:
                errors.append(relative + ': ' + name + ' expected ' + value + ', measured ' + repr(flags.get(name)))
        headers.append({'path': 'gen/' + relative, 'sha256': digest_file(path), 'flags': flags})
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'target': args.target,
               'chromium_revision': CHROMIUM_REV, 'cef_revision': CEF_REV,
               'args_gn_sha256': digest_file(output / 'args.gn'), 'gn_args': configuration['args'],
               'generated_headers': headers, 'errors': errors, 'passed': not errors,
               'independent_libx264_included': False, 'widevine_binary_included': False,
               'scope': 'Actual generated headers and GN identity after the build. Enabled code paths do not prove PDF/printing/extensions/WebRTC call, HEVC or DRM runtime operation.'}
    write_json(prep.root / 'state' / ('features-' + args.target + '.json'), receipt)
    print('ACTUAL_POSIX_FEATURE_AUDIT', args.target, 'passed=' + str(receipt['passed']), json.dumps(errors), flush=True)
    if errors:
        raise RuntimeError('The actual target feature audit failed')


if __name__ == '__main__':
    main()
