#!/usr/bin/env python3
"""Finish x64 validation/cleanup, then build and verify Linux ARM64 Release.

Wait for the existing source/x64 service without interrupting its downloads.
Every SDK/cleanup gate uses actual outputs; failure preserves the current work.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import subprocess
import sys
import time
import traceback

from archive_posix import digest_file
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--wait-hours', type=float, default=72)
    args = parser.parse_args()
    prep = Preparation(args.root)
    state = prep.root / 'state/linux-release-status.json'
    def record(phase, **extra):
        value = {'phase': phase, 'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
                 'all_four_platform_sdks_complete': False, **extra}
        write_json(state, value)
        print('LINUX_RELEASE_CONTINUATION', json.dumps(value), flush=True)
    def execute(script, *values, privileged=False):
        command = [sys.executable, HERE / script, '--root', prep.root, *values]
        if privileged:
            command = ['sudo', '-n', *command]
        prep.run(command)
    def complete(target):
        path = prep.root / 'state' / ('sdk-' + target + '-verified.json')
        if not path.is_file():
            return False
        receipt = json.loads(path.read_text('utf-8'))
        archive = Path(receipt['archive'])
        if (receipt.get('passed') is not True or receipt.get('target') != target
                or digest_file(archive) != receipt['archive_sha256']):
            raise RuntimeError('An existing completed SDK archive changed: ' + target)
        return True
    try:
        deadline = time.monotonic() + args.wait_hours * 3600
        while not complete('linux-x64'):
            service = subprocess.run(['systemctl', 'show', 'mycef-posix-preparation.service',
                                      '-p', 'ActiveState', '--value'], capture_output=True, text=True)
            client = prep.root / 'state/clients-linux-x64-verified.json'
            if client.is_file() and service.returncode == 0 and service.stdout.strip() not in ('active', 'activating', 'reloading'):
                break
            preparation = prep.root / 'state/posix-preparation-status.json'
            if preparation.is_file():
                current = json.loads(preparation.read_text('utf-8'))
                if current.get('phase') == 'failed' and service.stdout.strip() not in ('active', 'activating', 'reloading'):
                    raise RuntimeError('Source/x64 preparation stopped; retain it and fix the recorded failure: ' + current.get('error', 'unknown'))
            if time.monotonic() >= deadline:
                raise TimeoutError('The x64 preparation service has not produced a verified independent client; work retained')
            record('waiting_for_existing_linux_x64_service', service_active_state=service.stdout.strip(),
                   independent_client_receipt_exists=client.is_file())
            time.sleep(30)
        media = prep.src / 'media/test/data/bear-1280x720.mp4'
        if not complete('linux-x64'):
            record('validating_linux_x64_on_old_kernel_and_userland')
            execute('linux49_runtime_vm.py', '--arch', 'amd64', '--sdk',
                    json.loads((prep.root / 'state/sdk-linux-x64-prepared.json').read_text())['sdk'],
                    '--media', media, '--clients-receipt', prep.root / 'state/clients-linux-x64-verified.json',
                    privileged=True)
            record('archiving_and_reclaiming_linux_x64')
            execute('finalize_linux.py', '--target', 'linux-x64', '--cleanup')
        else:
            execute('finalize_linux.py', '--target', 'linux-x64', '--cleanup')
        if not complete('linux-arm64'):
            for phase, script in [('configuring_linux_arm64', 'configure_posix.py'),
                                  ('compiling_linux_arm64', 'compile_posix.py'),
                                  ('preparing_linux_arm64_sdk', 'package_linux.py')]:
                record(phase)
                execute(script, '--target', 'linux-arm64')
            record('cross_compiling_independent_linux_arm64_clients')
            execute('validate_linux_clients.py', '--target', 'linux-arm64', '--media', media, '--cross-compile')
            record('validating_linux_arm64_on_old_kernel_and_userland')
            execute('linux49_runtime_vm.py', '--arch', 'arm64', '--sdk',
                    json.loads((prep.root / 'state/sdk-linux-arm64-prepared.json').read_text())['sdk'],
                    '--media', media, '--clients-receipt', prep.root / 'state/clients-linux-arm64-built.json',
                    privileged=True)
            record('archiving_and_reclaiming_linux_arm64')
            execute('finalize_linux.py', '--target', 'linux-arm64', '--cleanup')
        else:
            execute('finalize_linux.py', '--target', 'linux-arm64', '--cleanup')
        if not complete('linux-x64') or not complete('linux-arm64'):
            raise RuntimeError('The final Linux archive verification did not complete')
        record('both_linux_release_archives_verified', verified_targets=['linux-x64', 'linux-arm64'],
               next_required=['macos_arm64_gn_and_framework_adaptation', 'macos_arm64_release', 'macos_x64_release'])
    except Exception as error:
        record('failed', error=repr(error))
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
