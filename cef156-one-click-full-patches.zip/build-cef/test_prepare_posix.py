"""Exercise first-checkout recovery with real Git and interrupted file bytes."""
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

import prepare_posix


class RootMarkerTests(unittest.TestCase):
    def test_parallel_initialization_publishes_complete_marker_once(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / 'concurrent-build'
            with ThreadPoolExecutor(max_workers=12) as pool:
                preparations = list(pool.map(lambda _: prepare_posix.Preparation(root), range(96)))
            self.assertEqual(len(preparations), 96)
            marker = root / '.mycef-build-root'
            self.assertEqual(marker.read_text().strip(), prepare_posix.ROOT_MARKER)
            previous = marker.stat()
            prepare_posix.Preparation(root)
            current = marker.stat()
            self.assertEqual((current.st_ino, current.st_mtime_ns),
                             (previous.st_ino, previous.st_mtime_ns))
            self.assertEqual(list(root.glob('.mycef-root-*')), [])

    def test_invalid_existing_marker_is_preserved_and_refused(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            marker = root / '.mycef-build-root'
            marker.write_bytes(b'other build root\n')
            with self.assertRaisesRegex(RuntimeError, 'Unrecognized build root marker'):
                prepare_posix.Preparation(root)
            self.assertEqual(marker.read_bytes(), b'other build root\n')


class InitialCheckoutTests(unittest.TestCase):
    def create(self, folder):
        donor = folder / 'donor'
        donor.mkdir()
        subprocess.run(['git', 'init', '-q', str(donor)], check=True)
        for name, payload in [('correct.txt', b'unchanged original'), ('partial.txt', b'complete original contents')]:
            (donor / name).write_bytes(payload)
        subprocess.run(['git', '-C', str(donor), 'add', '.'], check=True)
        subprocess.run(['git', '-C', str(donor), '-c', 'user.name=fixture', '-c', 'user.email=fixture@example.invalid',
                        'commit', '-qm', 'original tree'], check=True)
        commit = subprocess.check_output(['git', '-C', str(donor), 'rev-parse', 'HEAD'], text=True).strip()
        prep = prepare_posix.Preparation(folder / 'dedicated-build')
        prep.src.mkdir(parents=True)
        subprocess.run(['git', 'init', '-q', str(prep.src)], check=True)
        subprocess.run(['git', '-C', str(prep.src), 'fetch', '-q', '--depth=1', str(donor), commit], check=True)
        return prep, commit

    def test_interrupted_file_is_backed_up_before_exact_original_checkout(self):
        with tempfile.TemporaryDirectory() as temporary:
            prep, commit = self.create(Path(temporary))
            (prep.src / 'correct.txt').write_bytes(b'unchanged original')
            (prep.src / 'partial.txt').write_bytes(b'incomplete')
            (prep.src / 'unrelated-cache.txt').write_bytes(b'preserve unrelated bytes')
            with mock.patch.object(prepare_posix, 'CHROMIUM_REV', commit):
                prep.initial_checkout()
            self.assertEqual((prep.src / 'partial.txt').read_bytes(), b'complete original contents')
            self.assertEqual((prep.src / 'unrelated-cache.txt').read_bytes(), b'preserve unrelated bytes')
            report = json.loads((prep.root / 'state/source-initial-checkout-recovery.json').read_text())
            self.assertEqual(report['existing_files_git_blob_matched'], 1)
            self.assertEqual(len(report['interrupted_payload_backups']), 1)
            backup = Path(report['interrupted_payload_backups'][0]['preserved_backup'])
            self.assertEqual(backup.read_bytes(), b'incomplete')
            self.assertEqual(subprocess.check_output(['git', '-C', str(prep.src), 'rev-parse', 'HEAD'], text=True).strip(), commit)
            self.assertEqual(subprocess.check_output(['git', '-C', str(prep.src), 'status', '--porcelain', '--untracked-files=no']), b'')

    def test_type_conflict_is_preserved_without_forcing_checkout(self):
        with tempfile.TemporaryDirectory() as temporary:
            prep, commit = self.create(Path(temporary))
            conflict = prep.src / 'partial.txt'
            conflict.mkdir()
            (conflict / 'keep.bin').write_bytes(b'keep this directory intact')
            (prep.src / 'correct.txt').write_bytes(b'unchanged original')
            with mock.patch.object(prepare_posix, 'CHROMIUM_REV', commit):
                with self.assertRaisesRegex(RuntimeError, 'different file type'):
                    prep.initial_checkout()
            self.assertEqual((conflict / 'keep.bin').read_bytes(), b'keep this directory intact')
            self.assertNotEqual(subprocess.run(['git', '-C', str(prep.src), 'rev-parse', '--verify', '--quiet', 'HEAD'],
                                              capture_output=True).returncode, 0)


if __name__ == '__main__':
    unittest.main()
