#!/usr/bin/env python3
"""Unattended continuation on the already prepared Windows build CVM."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import msvcrt
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import threading
import traceback
import uuid
import zipfile

import build_cef as build

STATUS = {}
STATUS_LOCK = threading.Lock()
ROOT = None


def status(**values):
    with STATUS_LOCK:
        STATUS.update(values, updated_utc=dt.datetime.now(dt.timezone.utc).isoformat())
        build.write_json(ROOT / 'state/cloud-status.json', STATUS)


def codeview(path):
    """Read the PE debug directory, rather than searching arbitrary RSDS bytes."""
    with path.open('rb') as stream:
        stream.seek(0x3c)
        pe = struct.unpack('<I', stream.read(4))[0]
        stream.seek(pe)
        if stream.read(4) != b'PE\0\0':
            raise RuntimeError(f'Invalid PE: {path}')
        coff = struct.unpack('<HHIIIHH', stream.read(20))
        optional = stream.read(coff[5])
        magic = struct.unpack_from('<H', optional)[0]
        directory = {0x10b: 96, 0x20b: 112}.get(magic)
        if directory is None:
            raise RuntimeError(f'Unsupported PE optional header: {path}')
        debug_rva, size = struct.unpack_from('<II', optional, directory + 6 * 8)
        sections = [struct.unpack('<8sIIIIIIHHI', stream.read(40)) for _ in range(coff[1])]
        offset = None
        for section in sections:
            if section[2] <= debug_rva < section[2] + max(section[1], section[3]):
                offset = section[4] + debug_rva - section[2]
                break
        if offset is None:
            raise RuntimeError(f'No mapped PE debug directory: {path}')
        stream.seek(offset)
        entries = [struct.unpack('<IIHHIIII', stream.read(28)) for _ in range(size // 28)]
        for entry in entries:
            if entry[4] == 2:
                stream.seek(entry[7])
                value = stream.read(entry[5])
                if value.startswith(b'RSDS') and len(value) >= 24:
                    return str(uuid.UUID(bytes_le=value[4:20])).upper(), struct.unpack_from('<I', value, 20)[0]
    raise RuntimeError(f'No RSDS record: {path}')


def audit_pair(builder, binary, pdb):
    tool = builder.src / 'third_party/llvm-build/Release+Asserts/bin/llvm-pdbutil.exe'
    _, summary = builder.run([tool, 'dump', '--summary', pdb], capture=True)
    guid = re.search(r'Guid:\s*\{?([0-9A-F-]{36})\}?', summary, re.I)
    age = re.search(r'Age:\s*(\d+)', summary, re.I)
    expected = codeview(binary)
    if not guid or not age or (guid[1].upper(), int(age[1])) != expected:
        raise RuntimeError(f'Binary/PDB identity mismatch: {binary}')
    for label in ('Has Debug Info', 'Has Types', 'Has IDs', 'Has Globals', 'Has Publics'):
        if not re.search(re.escape(label) + r':\s*true\b', summary, re.I):
            raise RuntimeError(f'Incomplete PDB ({label}): {pdb}')
    if not re.search(r'Is stripped:\s*false\b', summary, re.I):
        raise RuntimeError(f'Stripped PDB: {pdb}')
    return {'binary': binary.name, 'binary_sha256': build.sha256(binary),
            'pdb_sha256': build.sha256(pdb), 'guid': expected[0], 'age': expected[1],
            'full_symbols': True}


def extract_sdk(archive, target, symbols=False):
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as package:
        manifest = json.loads(package.read('SHA256SUMS.json'))
        for item in package.infolist():
            name = item.filename.replace('\\', '/')
            if item.is_dir() or (not symbols and name.lower().endswith('.pdb')):
                continue
            destination = (target / name).resolve()
            if target.resolve() not in destination.parents:
                raise RuntimeError(f'Unsafe archive path: {name}')
            destination.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with package.open(item) as source, destination.open('wb') as output:
                for block in iter(lambda: source.read(4 * 1024 * 1024), b''):
                    output.write(block)
                    digest.update(block)
            if name != 'SHA256SUMS.json' and digest.hexdigest() != manifest[name]:
                raise RuntimeError(f'SDK extraction checksum mismatch: {name}')


def runtime(builder, sdk, cpu, label, mode='gpu-disabled'):
    evidence = builder.state / f'cloud-{cpu}-Release-{label}.json'
    command = [sys.executable, Path(__file__).with_name('runtime_probe.py'), '--sdk', sdk,
               '--configuration', 'Release', '--media',
               builder.src / 'media/test/data/bear-1280x720.mp4', '--mode', mode,
               '--require-h264-encoder', '--timeout', '120', '--output', evidence]
    builder.run(command)
    if build.read_json(evidence).get('passed') is not True:
        raise RuntimeError(f'Runtime validation failed: {evidence}')
    return str(evidence)


def external_client(builder, sdk, cpu):
    """Compile the shipped CMake example as a sandboxed external client DLL."""
    scripts = builder.root / 'VS2026/VC/Auxiliary/Build'
    vcvars = scripts / {'x64': 'vcvars64.bat', 'x86': 'vcvarsamd64_x86.bat',
                       'arm64': 'vcvarsamd64_arm64.bat'}[cpu]
    env = dict(builder.env, VSLANG='1033')
    invocation = (subprocess.list2cmdline([os.environ['COMSPEC']]) + ' /d /s /c "call ' +
                  subprocess.list2cmdline([str(vcvars)]) + ' && set"')
    result = subprocess.run(invocation,
                            env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding='mbcs', errors='replace', check=True)
    for line in result.stdout.splitlines():
        key, separator, value = line.partition('=')
        if separator and key and not key.startswith('='):
            env[key.upper()] = value
    tools = builder.root / 'VS2026/Common7/IDE/CommonExtensions/Microsoft/CMake'
    env['PATH'] = str(tools / 'Ninja') + os.pathsep + env.get('PATH', env.get('Path', ''))
    output = builder.root / 'cloud-check' / f'cmake-{cpu}-Release'
    cmake = tools / 'CMake/bin/cmake.exe'
    builder.run([cmake, '-S', sdk, '-B', output, '-G', 'Ninja',
                 '-DCMAKE_BUILD_TYPE=Release', '-DUSE_SANDBOX=ON',
                 '-DPROJECT_ARCH=' + {'x64': 'x86_64', 'x86': 'x86', 'arm64': 'arm64'}[cpu]], env=env)
    builder.run([cmake, '--build', output, '--target', 'cefsimple', '--parallel',
                 str(min(builder.args.jobs, 10))], env=env, retry=2)
    client = output / 'tests/cefsimple'
    if build.pe_machine(client / 'Release/cefsimple.dll') != build.MACHINE[cpu]:
        raise RuntimeError(f'External client architecture mismatch: {cpu}')
    if cpu in ('x64', 'x86'):
        (client / 'Resources').mkdir(exist_ok=True)
        return runtime(builder, client, cpu, 'bootstrap-runtime')
    return 'ARM64 external client linked and PE architecture checked; runtime requires Windows on ARM.'


def validate_sdk(builder, sdk, cpu):
    status(phase=f'verify-{cpu}-Release')
    binary = sdk / 'Release'
    if build.pe_machine(binary / 'libcef.dll') != build.MACHINE[cpu]:
        raise RuntimeError(f'Wrong CEF architecture: {cpu}')
    record = {'cpu': cpu, 'configuration': 'Release', 'symbols': [], 'runtime': []}
    for name in ('libcef.dll', 'bootstrap.exe', 'bootstrapc.exe'):
        record['symbols'].append(audit_pair(builder, binary / name, binary / (name + '.pdb')))
    if cpu in ('x64', 'x86'):
        record['runtime'].append(runtime(builder, sdk, cpu, 'auto-runtime', 'auto'))
        record['runtime'].append(runtime(builder, sdk, cpu, 'software-runtime'))
    record['external_client'] = external_client(builder, sdk, cpu)
    record['scope'] = ('Actual runtime evidence applies to this Server 2025 host. '
                       'Windows 7 and Windows on ARM runtime behavior is not verified.')
    build.write_json(builder.state / f'cloud-verified-{cpu}-Release.json', record)
    return record


def refresh_existing_x64(builder):
    marker = builder.state / 'complete-x64-Release.json'
    if not marker.exists():
        return
    prior = build.read_json(marker)
    archive = Path(prior['path'])
    actual_hash = build.sha256(archive)
    if actual_hash != prior['sha256']:
        transaction = builder.state / 'x64-Release-refresh-transaction.json'
        repair = build.read_json(transaction) if transaction.exists() else {}
        if repair.get('previous') != prior or repair.get('next', {}).get('sha256') != actual_hash:
            raise RuntimeError('Existing x64 archive changed')
        prior = dict(repair['next'], path=str(archive))
        build.write_json(marker, prior)
        archive.with_suffix('.zip.sha256').write_text(actual_hash + '  ' + archive.name + '\n', encoding='ascii')
    with zipfile.ZipFile(archive) as package:
        metadata = json.loads(package.read('MYCEF_BUILD.json'))
    if metadata.get('patch_bundle_sha256') == build.sha256(builder.patch_root / 'manifest.json'):
        return
    # An ARM64-only addition does not invalidate an already verified x64 SDK.
    # Preserve its archive and original provenance; do not relabel its binaries.
    old_hash = metadata.get('patch_bundle_sha256', '')
    history = builder.patch_root / 'history' / (old_hash + '.json')
    if re.fullmatch(r'[0-9a-f]{64}', old_hash) and history.is_file():
        current = build.read_json(builder.patch_root / 'manifest.json')
        build.verify_additive_build_fixes(builder.patch_root, old_hash, current)
        old_files = build.read_json(history)['files']
        added = current['files'].keys() - old_files.keys()
        arm64_fixes = {
            'windows-build/boringssl-arm64-synchronization.patch':
                'b980127cd4d16ce6e8a1426f8ad1c7b420ae049a2ca06e1f1ee4e07d5552e63f',
            'windows-build/arm64-processor-number.patch':
                'e554f7d85131e64ae2b14e9bdc9f9adf0a7ff04a8696e522742902736103d2e8',
            'windows-build/libwebp-arm64-synchronization.patch':
                '2a5f5b22cb704ace9b534963c556c0dc5715d763591b1a9525988b908a4d5346',
            'windows-build/cpuinfo-arm64-once.patch':
                'a2f1a4e3a9546b75686e420bbca06f38979ffb74cc374e24696dc46aacb21007',
        }
        added_code = {name for name in added if name.endswith('.patch')}
        allowed = set(arm64_fixes) | {'windows-build/boringssl-arm64-synchronization.md'}
        bootstrap = 'windows-build/bootstrap-sandbox-command-line.patch'
        if (added_code and
                all(name in allowed or name.startswith('history/') for name in added) and
                all(current['files'][name] == arm64_fixes.get(name) for name in added_code) and
                old_files.get(bootstrap) == current['files'][bootstrap]):
            print('Keeping the verified x64 SDK with its original manifest; new fix applies only to ARM64.', flush=True)
            return
    if prior['sha256'] != '2bc22921ffa43e7fcf86711961be9b1d83e142fc25ed63a9dd822af39cb08e51':
        raise RuntimeError('Unrecognized old x64 archive; refusing a component-only refresh')
    status(phase='rebuild-x64-Release-bootstrap')
    builder.prepare_sources()
    builder.prepare_build_python()
    output = builder.src / 'out/Release_bootstrap_GN_x64'
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as package:
        arguments = package.read('MYCEF_args.gn')
    if (output / 'args.gn').exists() and (output / 'args.gn').read_bytes() != arguments:
        raise RuntimeError('Bootstrap rebuild arguments changed')
    if not (output / 'args.gn').exists():
        (output / 'args.gn').write_bytes(arguments)
    if not (output / 'build.ninja').exists():
        builder.run(['gn', 'gen', output, '--fail-on-unused-args'], cwd=builder.src)
    builder.run(['autoninja', '-C', output, '-j', str(builder.args.jobs), 'bootstrap', 'bootstrapc'],
                cwd=builder.src)
    staging_parent = builder.root / 'packages/staging'
    staging = staging_parent / 'refresh-x64-Release'
    if staging.exists():
        build.safe_remove(staging, staging_parent)
    sdk = staging / 'sdk'
    extract_sdk(archive, sdk, symbols=True)
    binary = sdk / 'Release'
    for name in ('bootstrap.exe', 'bootstrapc.exe', 'bootstrap.exe.pdb', 'bootstrapc.exe.pdb'):
        shutil.copy2(output / name, binary / name)
    metadata['runtime_cmake_files'] = build.configure_sdk_runtime_copy(sdk, binary)
    prepared = build.read_json(builder.state / 'prepared.json')
    metadata['libcef_build_patch_bundle_sha256'] = metadata['patch_bundle_sha256']
    metadata['patch_bundle_sha256'] = prepared['patch_bundle_sha256']
    metadata['custom_source_sha256'] = prepared['custom_source_sha256']
    metadata['bootstrap_rebuild'] = {'previous_archive_sha256': prior['sha256'],
                                     'patch': 'bootstrap-sandbox-command-line.patch',
                                     'libcef_unchanged_sha256': build.sha256(binary / 'libcef.dll'),
                                     'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat()}
    shutil.copy2(builder.patch_root / 'manifest.json', sdk / 'MYCEF_patch_bundle_manifest.json')
    shutil.copytree(builder.patch_root / 'windows-build', sdk / 'MYCEF_windows_build_patches', dirs_exist_ok=True)
    verification = validate_sdk(builder, sdk, 'x64')
    refreshed = archive.with_name(archive.stem + '.refreshed.zip')
    result = build.make_archive(sdk, refreshed, metadata)
    build.write_json(builder.state / 'x64-Release-refresh-transaction.json', {'previous': prior, 'next': result})
    refreshed.replace(archive)
    result['path'] = str(archive)
    archive.with_suffix('.zip.sha256').write_text(result['sha256'] + '  ' + archive.name + '\n', encoding='ascii')
    build.write_json(marker, result)
    verification['archive_sha256'] = result['sha256']
    build.write_json(builder.state / 'cloud-verified-x64-Release.json', verification)
    build.write_json(builder.state / 'cloud-refreshed-x64-Release.json', result)
    refreshed.with_suffix('.zip.sha256').unlink(missing_ok=True)
    build.safe_remove(staging, staging_parent)
    build.safe_remove(output, builder.src / 'out')


class CloudBuilder(build.Builder):
    def generate(self, cpu, config):
        status(phase=f'build-{cpu}-{config}')
        return super().generate(cpu, config)

    def package(self, cpu, config, output, metadata):
        status(phase=f'package-{cpu}-{config}')
        staging, result = super().package(cpu, config, output, metadata)
        verification = validate_sdk(self, staging / f'cef_binary_{build.CHROMIUM}_windows_{cpu}_release', cpu)
        verification['archive_sha256'] = result['sha256']
        build.write_json(self.state / f'cloud-verified-{cpu}-Release.json', verification)
        status(phase='build-remaining-Release')
        return staging, result


def main():
    global ROOT
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--jobs', type=int, default=14)
    args = parser.parse_args()
    args.root = str(Path(args.root).resolve())
    args.keep_intermediates, args.build_free_gb = False, 80
    ROOT = Path(args.root)
    if (ROOT / '.mycef-build-root').read_text('utf-8') != 'mycef-156.0.8071.0-v1':
        raise RuntimeError('Not a recognized prepared build root')
    lock = (ROOT / 'state/cloud-runner.lock').open('a+b')
    lock.seek(0)
    lock.write(b'0')
    lock.flush()
    lock.seek(0)
    msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
    logfile = ROOT / 'logs' / ('cloud-' + dt.datetime.now().strftime('%Y%m%d-%H%M%S') + '.log')
    stream = logfile.open('w', encoding='utf-8', buffering=1)
    sys.stdout = sys.stderr = stream
    status(status='running', phase='starting', pid=os.getpid(), log=str(logfile),
           order=[list(item) for item in build.ORDER], scope='Release only; full PDBs retained')
    stopped = threading.Event()
    def heartbeat():
        while not stopped.wait(30):
            status()
    threading.Thread(target=heartbeat, daemon=True).start()
    try:
        builder = CloudBuilder(args)
        for cpu in ('x64', 'x86', 'arm64'):
            abandoned = builder.src / 'out' / f'Debug_GN_{cpu}'
            if abandoned.exists():
                status(phase=f'cleanup-cancelled-Debug-{cpu}')
                build.safe_remove(abandoned, builder.src / 'out')
        refresh_existing_x64(builder)
        status(phase='build-remaining-Release')
        builder.build()
        packages = []
        for cpu, config in build.ORDER:
            result = build.read_json(builder.state / f'complete-{cpu}-{config}.json')
            if build.sha256(Path(result['path'])) != result['sha256']:
                raise RuntimeError(f'Final package checksum mismatch: {cpu}')
            receipt = builder.state / f'cloud-verified-{cpu}-Release.json'
            verified = build.read_json(receipt) if receipt.exists() else {}
            if verified.get('archive_sha256') != result['sha256']:
                destination = builder.root / 'cloud-check' / f'completed-{cpu}-Release'
                if destination.exists():
                    build.safe_remove(destination, builder.root / 'cloud-check')
                extract_sdk(Path(result['path']), destination, symbols=True)
                verified = validate_sdk(builder, destination, cpu)
                verified['archive_sha256'] = result['sha256']
                build.write_json(receipt, verified)
                build.safe_remove(destination, builder.root / 'cloud-check')
            packages.append(result)
        build.write_json(builder.state / 'cloud-all-Release-complete.json', {'packages': packages})
        status(status='complete', phase='complete', packages=packages)
        return 0
    except Exception as error:
        traceback.print_exc()
        status(status='failed', error=str(error))
        return 1
    finally:
        stopped.set()
        stream.flush()
        lock.close()


if __name__ == '__main__':
    sys.exit(main())
