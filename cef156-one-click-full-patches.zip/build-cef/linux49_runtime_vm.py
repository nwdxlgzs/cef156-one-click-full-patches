#!/usr/bin/env python3
"""Run old Python/display preflight or actual CEF inside a Linux 4.9 VM."""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
import re
import shutil
import subprocess

from linux49_vm import make_initramfs, arm_busybox, digest
from prepare_posix import Preparation, write_json

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--arch', choices=['amd64', 'arm64'], required=True)
    parser.add_argument('--sdk', type=Path)
    parser.add_argument('--media', type=Path)
    parser.add_argument('--client-toolchain-probe', action='store_true',
                        help='Run the real C++20/GTK toolchain smoke binary inside the old guest')
    parser.add_argument('--complete-cxx-runtime-probe', action='store_true',
                        help='Execute the real GLIBCXX_3.4.26/filesystem/exception probe and full C++ runtime')
    parser.add_argument('--clients-receipt', type=Path,
                        help='Independent ON/OFF client build receipt; run its exact executables in this guest')
    parser.add_argument('--timeout', type=int, default=2400)
    args = parser.parse_args()
    prep = Preparation(args.root)
    if bool(args.sdk) != bool(args.media):
        parser.error('--sdk and --media must be supplied together for actual CEF validation')
    if args.clients_receipt and not args.sdk:
        parser.error('--clients-receipt requires --sdk and --media')
    suffix = args.arch + '-runtime'
    boot_receipt = prep.root / 'state' / ('linux49-vm-' + suffix + '.json')
    if not boot_receipt.exists():
        busybox = arm_busybox(prep) if args.arch == 'arm64' else Path('/usr/bin/busybox')
        make_initramfs(prep, args.arch, busybox, runtime=True)
    boot = json.loads(boot_receipt.read_text('utf-8'))
    for key in ['kernel', 'initramfs']:
        if digest(Path(boot[key])) != boot[key + '_sha256']:
            raise RuntimeError('The verified VM boot input changed: ' + key)
    label = 'cef' if args.sdk else 'cxx-runtime-preflight' if args.complete_cxx_runtime_probe else 'tools-preflight'
    stamp = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S%f')
    exchange = prep.root / 'validation/oldlinux' / (suffix + '-' + label + '-' + stamp)
    exchange.mkdir(parents=True)
    reports = exchange / 'reports'
    reports.mkdir(mode=0o777)
    reports.chmod(0o777)
    for name in ['runtime_probe.py', 'runtime_probe_posix.py']:
        shutil.copy2(HERE / name, exchange / name)
    guest = '''set -eu
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export LC_ALL=C
uname -a
ldd --version
/usr/bin/python3 -c 'import json,os,platform; print(json.dumps({"kernel":platform.release(),"cpu":platform.machine(),"glibc":os.confstr("CS_GNU_LIBC_VERSION")}))'
/usr/bin/python3 /opt/mycef-validation/runtime_probe_posix.py --help
/usr/sbin/runuser -u nobody -- /usr/bin/xvfb-run -a /usr/bin/python3 -c 'import os; assert os.environ["DISPLAY"]; print("MYCEF_OLD_DISPLAY_PYTHON_OK")'
'''
    toolchain_probe = None
    cxx_runtime_probe = None
    if args.complete_cxx_runtime_probe:
        cpu = 'x64' if args.arch == 'amd64' else 'arm64'
        cxx_runtime_probe = json.loads((prep.root / 'state' / ('cxx-runtime-probe-' + cpu + '.json')).read_text('utf-8'))
        binary = Path(cxx_runtime_probe['binary'])
        runtime = Path(cxx_runtime_probe['runtime']['library'])
        if (not cxx_runtime_probe['compilation_linking_passed']
                or digest(binary) != cxx_runtime_probe['binary_sha256']
                or digest(runtime) != cxx_runtime_probe['runtime']['library_sha256']):
            raise RuntimeError('Actual complete runtime/probe inputs changed')
        folder = exchange / 'complete-cxx-runtime'
        folder.mkdir()
        shutil.copy2(binary, folder / 'cxx_runtime_probe')
        shutil.copy2(runtime, folder / 'libstdc++.so.6')
        guest += ('/usr/sbin/runuser -u nobody -- /usr/bin/env '
                  'LD_LIBRARY_PATH=/opt/mycef-validation/complete-cxx-runtime '
                  '/opt/mycef-validation/complete-cxx-runtime/cxx_runtime_probe\n')
    if args.client_toolchain_probe:
        cpu = 'x64' if args.arch == 'amd64' else 'arm64'
        toolchain = json.loads((prep.root / 'state' / ('client-toolchain-linux-' + cpu + '.json')).read_text('utf-8'))
        source = Path(toolchain['binary'])
        if not toolchain['smoke_build_passed'] or digest(source) != toolchain['binary_sha256']:
            raise RuntimeError('The real target client toolchain probe changed')
        shutil.copy2(source, exchange / 'client-toolchain-probe')
        guest += ('/usr/sbin/runuser -u nobody -- /opt/mycef-validation/client-toolchain-probe\n'
                  'echo MYCEF_OLD_CLIENT_TOOLCHAIN_OK\n')
        toolchain_probe = {'binary_sha256': digest(source), 'toolchain_receipt': toolchain}
    expected_hash = None
    independent = None
    expected_clients = {}
    if args.sdk:
        sdk = args.sdk.resolve()
        if prep.root / 'packages/staging' not in sdk.parents:
            raise RuntimeError('SDK must belong to the dedicated package staging tree')
        expected_hash = digest(sdk / 'Release/libcef.so')
        if args.clients_receipt:
            independent = json.loads(args.clients_receipt.read_text('utf-8'))
            target = 'linux-x64' if args.arch == 'amd64' else 'linux-arm64'
            prepared = prep.root / 'state' / ('sdk-' + target + '-prepared.json')
            if (independent.get('target') != target or independent.get('sdk_libcef_sha256') != expected_hash
                    or independent.get('prepared_receipt_sha256') != digest(prepared)
                    or {client['sandbox'] for client in independent['clients']} != {'ON', 'OFF'}):
                raise RuntimeError('The independent client build receipt belongs to another SDK')
            from validate_linux_clients import development_inputs
            if independent.get('sdk_development_inputs') != development_inputs(sdk):
                raise RuntimeError('Independent clients used different SDK development inputs')
            for client in independent['clients']:
                for key in ['cefsimple', 'cefclient']:
                    if digest(Path(client[key])) != client[key + '_sha256']:
                        raise RuntimeError('An independently compiled CEF client changed')
                name = 'cefsimple-' + client['sandbox'].lower()
                shutil.copy2(client['cefsimple'], exchange / name)
                expected_clients[client['sandbox']] = client['cefsimple_sha256']
        from runtime_probe import FIXTURE_SHA256
        if digest(args.media) != FIXTURE_SHA256:
            raise RuntimeError('The runtime media fixture changed')
        shutil.copy2(args.media, exchange / 'fixture.mp4')
        guest += ('install -D -o root -g root -m 4755 /opt/mycef-sdk/Release/chrome-sandbox '
                  '/usr/local/libexec/mycef-sandbox/chrome-sandbox\n')
        for mode, no_sandbox in [('auto', False), ('gpu-disabled', False), ('auto', True)]:
            name = mode + ('-no-sandbox' if no_sandbox else '-sandbox')
            guest += ('/usr/sbin/runuser -u nobody -- /usr/bin/xvfb-run -a /usr/bin/python3 '
                      '/opt/mycef-validation/runtime_probe_posix.py --sdk /opt/mycef-sdk '
                      '--media /opt/mycef-validation/fixture.mp4 --output /opt/mycef-validation/reports/'
                      + name + '.json --timeout 600 --mode ' + mode
                      + (' --no-sandbox' if no_sandbox else ' --sandbox-helper /usr/local/libexec/mycef-sandbox/chrome-sandbox')
                      + (' --client /opt/mycef-validation/cefsimple-' + ('off' if no_sandbox else 'on') if independent else '') + '\n')
    (exchange / 'guest-run.sh').write_text(guest, encoding='utf-8')
    if args.arch == 'amd64':
        command = ['qemu-system-x86_64', '-machine', 'q35,accel=tcg', '-cpu', 'max',
                   '-append', 'console=ttyS0 panic=-1 rdinit=/init']
        userland = prep.root / 'validation/oldlinux/buster-x64'
        command += ['-virtfs', 'local,path=' + str(userland) + ',mount_tag=oldroot,security_model=none']
    else:
        command = ['qemu-system-aarch64', '-machine', 'virt,accel=tcg,gic-version=2', '-cpu', 'cortex-a72',
                   '-append', 'console=ttyAMA0 panic=-1 rdinit=/init']
        image = prep.root / 'cache/oldlinux/buster-arm64.img'
        command += ['-drive', 'file=' + str(image) + ',format=raw,if=virtio']
    command += ['-m', '4096', '-smp', '4', '-kernel', boot['kernel'], '-initrd', boot['initramfs'],
                '-display', 'none', '-monitor', 'none', '-serial', 'stdio', '-no-reboot', '-nic', 'none',
                '-virtfs', 'local,path=' + str(exchange) + ',mount_tag=exchange,security_model=none']
    if args.sdk:
        command += ['-virtfs', 'local,path=' + str(sdk) + ',mount_tag=sdk,security_model=none,readonly=on']
    log = exchange / 'vm.log'
    timed_out = False
    with log.open('w') as stream:
        try:
            result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=args.timeout)
            code = result.returncode
        except subprocess.TimeoutExpired:
            timed_out, code = True, None
    text = log.read_text('utf-8', errors='replace')
    passed = (code == 0 and not timed_out and 'MYCEF_GUEST_VALIDATION_DONE' in text
              and 'MYCEF_OLD_DISPLAY_PYTHON_OK' in text and 'MYCEF_GUEST_VALIDATION_FAILED' not in text
              and bool(re.search(r'Linux version 4\.9\.', text)) and 'GLIBC 2.28' in text)
    if args.client_toolchain_probe:
        passed = passed and 'MYCEF_OLD_CLIENT_TOOLCHAIN_OK' in text and 'MyCEF GTK 3.' in text
    if args.complete_cxx_runtime_probe:
        passed = passed and 'MYCEF_COMPLETE_CXX_RUNTIME_OK ' in text
    runs = []
    if args.sdk:
        for name in ['auto-sandbox', 'gpu-disabled-sandbox', 'auto-no-sandbox']:
            path = reports / (name + '.json')
            report = json.loads(path.read_text('utf-8')) if path.is_file() else {}
            valid = (report.get('passed') is True and report.get('libcef_sha256') == expected_hash
                     and report.get('kernel', '').startswith('4.9.') and report.get('glibc_runtime') == 'glibc 2.28'
                     and report.get('cpu') == ('x86_64' if args.arch == 'amd64' else 'aarch64')
                     and report.get('sandbox_requested') is (name != 'auto-no-sandbox'))
            if independent:
                setting = 'OFF' if name == 'auto-no-sandbox' else 'ON'
                valid = (valid and report.get('independent_client_requested') is True
                         and report.get('client_sha256') == expected_clients[setting])
            passed = passed and valid
            runs.append({'name': name, 'report': str(path), 'validated': valid,
                         'report_sha256': digest(path) if path.is_file() else None})
    receipt = {'observed_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'architecture': args.arch,
               'mode': label, 'passed': passed, 'command': command, 'returncode': code,
               'timeout': timed_out, 'log': str(log), 'log_sha256': digest(log), 'reports': runs,
               'sdk_libcef_sha256': expected_hash, 'cef_runtime_verified': bool(args.sdk) and passed,
               'client_toolchain_probe': toolchain_probe,
               'complete_cxx_runtime_probe': cxx_runtime_probe,
               'scope': ('Actual CEF software graphics/media/sandbox execution in full-system Linux 4.9/glibc 2.28 VM.'
                         if args.sdk else 'Actual old kernel/userland Python and Xvfb execution; no CEF runtime was tested.')}
    write_json(prep.root / 'state' / ('linux49-' + args.arch + '-' + label + '.json'), receipt)
    if passed and independent:
        target = independent['target']
        independent.update(passed=True, runtime_verified=True,
                           observed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                           runtime_environment='Full-system Linux 4.9/glibc 2.28 QEMU TCG guest',
                           runtime_reports=[{'sandbox': 'OFF' if item['name'] == 'auto-no-sandbox' else 'ON',
                                             'mode': 'gpu-disabled' if item['name'] == 'gpu-disabled-sandbox' else 'auto',
                                             'path': item['report'], 'sha256': item['report_sha256']} for item in runs],
                           scope='Actual independent ON/OFF CMake client builds and three CEF software graphics/media/sandbox runs inside a full-system old Linux target-architecture VM. No native ARM hardware or UOS product/GPU-driver claim.')
        write_json(prep.root / 'state' / ('clients-' + target + '-verified.json'), independent)
    print(json.dumps(receipt, indent=2), flush=True)
    if not passed:
        raise RuntimeError('Old Linux guest validation failed; inspect ' + str(log))


if __name__ == '__main__':
    main()
