#!/usr/bin/env python3
"""Prepare an explicit Darwin CMake toolchain using verified cross-build inputs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from archive_posix import digest_file
from audit_macho import inspect, CPUS, version_tuple
from mac_cross_sdk_info import load
from prepare_posix import Preparation, write_json


def quoted(value):
    text = str(value)
    if any(char in text for char in ('\n', '\r', '"', ';', '$')):
        raise RuntimeError('Unsupported character in an explicit CMake toolchain path')
    return '"' + text + '"'


def prepare(prep, cpu, smoke=False):
    if cpu not in CPUS:
        raise ValueError('Expected x64 or arm64')
    marker = json.loads((prep.root / 'state/mac-gn-inputs-prepared.json').read_text())
    metadata = Path(marker['metadata_path'])
    if digest_file(metadata) != marker['metadata_sha256']:
        raise RuntimeError('Verified macOS cross-input metadata changed')
    sdk = load(metadata)
    architecture = 'x86_64' if cpu == 'x64' else 'arm64'
    compiler_dir = prep.src / 'third_party/llvm-build/Release+Asserts/bin'
    directory = prep.root / 'cache/mac-client-toolchain' / cpu / 'v2'
    directory.mkdir(parents=True, exist_ok=True)
    # Chromium ships llvm-ar, but not its llvm-ranlib alias. The same LLVM
    # executable selects genuine ranlib behavior from its invocation name.
    ranlib = directory / 'llvm-ranlib'
    if ranlib.is_symlink():
        if ranlib.resolve() != (compiler_dir / 'llvm-ar').resolve():
            raise RuntimeError('The explicit LLVM ranlib alias changed')
    elif ranlib.exists():
        raise RuntimeError('Unexpected file at the LLVM ranlib alias path')
    else:
        ranlib.symlink_to(compiler_dir / 'llvm-ar')
    path = directory / 'toolchain.cmake'
    values = {
        'CMAKE_SYSTEM_NAME': 'Darwin', 'CMAKE_SYSTEM_PROCESSOR': architecture,
        'CMAKE_OSX_ARCHITECTURES': architecture, 'CMAKE_OSX_DEPLOYMENT_TARGET': '13.0',
        'CMAKE_OSX_SYSROOT': sdk['sdk_path'],
        'CMAKE_C_COMPILER': compiler_dir / 'clang',
        'CMAKE_CXX_COMPILER': compiler_dir / 'clang++',
        'CMAKE_OBJC_COMPILER': compiler_dir / 'clang',
        'CMAKE_OBJCXX_COMPILER': compiler_dir / 'clang++',
        'CMAKE_AR': compiler_dir / 'llvm-ar', 'CMAKE_RANLIB': ranlib,
        'CMAKE_FIND_ROOT_PATH': sdk['sdk_path'],
        'CMAKE_FIND_ROOT_PATH_MODE_PROGRAM': 'NEVER',
        'CMAKE_FIND_ROOT_PATH_MODE_LIBRARY': 'ONLY',
        'CMAKE_FIND_ROOT_PATH_MODE_INCLUDE': 'ONLY',
        'CMAKE_FIND_ROOT_PATH_MODE_PACKAGE': 'ONLY',
    }
    for lang in ('C', 'CXX', 'OBJC', 'OBJCXX'):
        values['CMAKE_' + lang + '_COMPILER_TARGET'] = architecture + '-apple-macos13.0'
    for kind in ('EXE', 'SHARED', 'MODULE'):
        values['CMAKE_' + kind + '_LINKER_FLAGS_INIT'] = '-fuse-ld=lld'
    text = '\n'.join('set(' + key + ' ' + quoted(value) + ')' for key, value in values.items()) + '\n'
    if path.exists() and path.read_text() != text:
        raise RuntimeError('Existing independent macOS toolchain changed; preserve its outputs')
    path.write_text(text, encoding='utf-8')
    record = {'target_cpu': cpu, 'architecture': architecture, 'toolchain': str(path),
              'toolchain_sha256': digest_file(path), 'metadata_sha256': marker['metadata_sha256'],
              'llvm_ar_sha256': digest_file(compiler_dir / 'llvm-ar'), 'ranlib_alias': str(ranlib),
              'target_execution_verified': False}
    if smoke:
        source = directory / 'smoke-source'
        source.mkdir(exist_ok=True)
        (source / 'CMakeLists.txt').write_text(
            'cmake_minimum_required(VERSION 3.20)\n'
            'project(MyCefMacCmakeToolchain LANGUAGES C CXX OBJCXX)\n'
            'set(CMAKE_CXX_STANDARD 20)\n'
            'add_executable(probe probe.cpp appkit.mm)\n'
            'target_link_libraries(probe PRIVATE "-framework AppKit")\n', encoding='utf-8')
        (source / 'probe.cpp').write_text(
            '#include <string>\nextern int probe_appkit();\n'
            'int main() { std::string value="CEF"; return value.size()==3 ? probe_appkit() : 1; }\n', encoding='utf-8')
        (source / 'appkit.mm').write_text(
            '#import <AppKit/AppKit.h>\nint probe_appkit() { @autoreleasepool {'
            ' NSMenu *menu=[[NSMenu alloc] initWithTitle:@"CEF"];'
            ' return menu.title.length==3 ? 0 : 1; } }\n', encoding='utf-8')
        output = directory / 'smoke-build'
        prep.run(['cmake', '-S', source, '-B', output, '-G', 'Ninja',
                  '-DCMAKE_BUILD_TYPE=Release', '-DCMAKE_TOOLCHAIN_FILE=' + str(path)])
        prep.run(['cmake', '--build', output, '-j', '2'])
        image = output / 'probe'
        info = inspect(image)
        if (info['cpu_type'] != CPUS[cpu] or not info['uuid'] or not info['versions']
                or any(v['platform'] != 1 or version_tuple(v['minimum']) > (13, 0, 0) for v in info['versions'])):
            raise RuntimeError('Actual CMake C++/Objective-C++ image has the wrong CPU/deployment')
        record.update(cmake_smoke_compiled_and_linked=True, smoke_binary=str(image),
                      smoke_binary_sha256=digest_file(image), smoke_macho=info)
    record['scope'] = 'Verified explicit Linux-to-Darwin CMake toolchain; optional actual C++20/AppKit compile/link. Independent CEF SDK client and macOS runtime remain separate.'
    write_json(prep.root / 'state' / ('mac-client-toolchain-' + cpu + '.json'), record)
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', required=True)
    parser.add_argument('--cpu', required=True, choices=('x64', 'arm64'))
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    print(json.dumps(prepare(Preparation(args.root), args.cpu, args.smoke), indent=2))


if __name__ == '__main__':
    main()
