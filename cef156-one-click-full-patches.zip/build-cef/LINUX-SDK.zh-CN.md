# Linux Release SDK 使用

这是 Chromium 156.0.8071.0 与固定 CEF 适配组合的 Linux SDK。实际 CPU、GN 参数、glibc 符号需求和验证范围见 `MYCEF_BUILD.json` 与 `validation/`。Release 包保留完整调试符号；不包含另一个 Debug 引擎。

## 编译自己的应用

在 SDK 根目录中，以目标架构的开发工具链执行：

```sh
cmake -S . -B build-sandbox -G Ninja -DCMAKE_BUILD_TYPE=Release -DUSE_SANDBOX=ON
cmake --build build-sandbox --target cefsimple cefclient -j 8
```

`cefsimple` 是最小示例，`cefclient` 用于演示更多 CEF API。你可以修改示例或新建自己的项目；发布业务应用时，使用自己的可执行文件及所需的 CEF 运行文件。Linux 的这两个示例生成普通可执行文件。

`cmake/cef_variables.cmake` 中的 `CEF_BINARY_FILES`、`CEF_RESOURCE_FILES` 是运行文件复制清单，包含本组合需要的 ANGLE 库。初次集成先保持这些库、Vulkan / SwiftShader 文件、资源包和 locales 完整。

## 沙箱

默认使用 `USE_SANDBOX=ON`。应用由普通用户运行；系统需要允许相应的用户命名空间，或正确安装 SDK 附带的 `chrome-sandbox` helper。

需要使用 setuid helper 时，可以从 SDK 根目录执行：

```sh
sudo install -D -o root -g root -m 4755 Release/chrome-sandbox /usr/local/libexec/mycef/chrome-sandbox
export CHROME_DEVEL_SANDBOX=/usr/local/libexec/mycef/chrome-sandbox
ln -sfn /usr/local/libexec/mycef/chrome-sandbox ./build-sandbox/tests/cefsimple/Release/chrome-sandbox
./build-sandbox/tests/cefsimple/Release/cefsimple
```

helper 必须来自同一套 SDK。正式软件也可以由安装程序把它配置在适当的系统目录中。

编译关闭沙箱的独立客户端时，另建目录：

```sh
cmake -S . -B build-no-sandbox -G Ninja -DCMAKE_BUILD_TYPE=Release -DUSE_SANDBOX=OFF
cmake --build build-no-sandbox --target cefsimple cefclient -j 8
```

这个开关用于客户端的沙箱接入，无需重新编译整个 CEF 引擎。

## 旧系统

最终 ELF 的实际 glibc 需求以包内审计报告为准。Linux 4.9 / glibc 2.28 的完整虚拟机运行测试覆盖软件图形、媒体与沙箱；具体 UOS 教育版安装环境和实际 GPU 驱动仍需在部署机器上检查。开发机的 C++ 工具链也会影响你自己应用的 glibc / libstdc++ 需求。

本 SDK 附带经 Debian Release 签名与包摘要验证的完整 `Release/libstdc++.so.6`，其自身 glibc 需求已单独审计；CMake 复制清单包含该文件，用于在旧发行版运行 C++20 客户端。与自己的应用部署在同一运行目录，不替换系统库；对应许可证位于 `licenses/libstdc++/`。Chromium sysroot 中的共享库经过裁剪，仅能用于链接，不能部署。如果改用其他编译器或 C++ ABI，应重新检查应用与此运行库的匹配关系。
