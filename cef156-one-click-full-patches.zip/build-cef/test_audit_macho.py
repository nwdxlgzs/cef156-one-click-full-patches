"""Boundary/refusal checks for the large dSYM section table contract.

The independent Linux preflight additionally verifies an actual sparse >4 GB
dSYM with the pinned llvm-dwarfdump and checks payload bytes at these offsets.
"""
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from audit_macho import CPUS, MH_DSYM, MH_MAGIC_64, inspect


class SectionOffsetTests(unittest.TestCase):
    def parse(self, sections, file_size, filetype=MH_DSYM):
        entries = b''.join(struct.pack('<16s16sQQ8I', name.encode(), b'__DWARF',
                                     0, size, offset, 0, 0, 0, flags, 0, 0, 0)
                           for name, offset, size, flags in sections)
        command = struct.pack('<II16s4Q4I', 0x19, 72 + len(entries), b'__DWARF',
                              0, file_size, 0, file_size, 7, 3, len(sections), 0) + entries
        header = struct.pack('<8I', MH_MAGIC_64, CPUS['arm64'], 0, filetype,
                             1, len(command), 0, 0)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'table.dwarf'
            path.write_bytes(header + command)
            # Only the table is read by this unit. Real physical-file and DWARF
            # parsing are exercised independently by the pinned LLVM preflight.
            with patch.object(Path, 'stat', return_value=SimpleNamespace(st_size=file_size)):
                return inspect(path)

    def test_small_dsym_keeps_file_offsets(self):
        result = self.parse([('__debug_info', 512, 32, 0)], 1024)
        self.assertEqual(result['sections'][0]['offset'], 512)
        self.assertNotIn('dwarf_section_offset_encoding', result)

    def test_wrapped_dsym_reports_real_payload_position(self):
        result = self.parse([('__padding', 4096, 1 << 32, 0),
                             ('__debug_info', 4096, 32, 0),
                             ('__debug_line', 4128, 16, 0)], (1 << 32) + 8192)
        self.assertEqual(result['sections'][1]['offset'], 4294971392)
        self.assertEqual(result['sections'][2]['offset'], 4294971424)
        self.assertEqual(result['sections'][1]['offset_in_header'], 4096)
        self.assertEqual(result['dwarf_section_offset_encoding'], 'llvm_ordered_32bit_wrap')

    def test_truncated_wrapped_payload_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'exceeds the actual file'):
            self.parse([('__padding', 4096, 1 << 32, 0),
                        ('__debug_info', 4096, 32, 0)], (1 << 32) + 4127)

    def test_unordered_wrapped_sections_are_rejected(self):
        with self.assertRaisesRegex(ValueError, 'not ordered'):
            self.parse([('__padding', 4096, 1 << 32, 0),
                        ('__debug_info', 8192, 32, 0),
                        ('__debug_line', 4096, 16, 0)], (1 << 32) + 16384)

    def test_regular_runtime_offsets_remain_ordinary(self):
        result = self.parse([('__text', 512, 32, 0)], 1024, filetype=6)
        self.assertEqual(result['sections'][0]['offset'], 512)
        self.assertNotIn('dwarf_section_offset_encoding', result)

    def test_virtual_zero_fill_does_not_require_file_bytes(self):
        result = self.parse([('__bss', 0, 1 << 30, 1)], 1024, filetype=6)
        self.assertEqual(result['sections'][0]['bytes'], 1 << 30)


if __name__ == '__main__':
    unittest.main()
